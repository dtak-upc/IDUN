"""Read-only, bounded inspection of saved Integration results, never live inference."""
import collections
import json
import integration


def capture_input(db, revision):
    # Publication already checks this revision. Read the producer's small metadata,
    # without invoking status(), rebuilding candidates or loading scores.
    if not db.execute("SELECT 1 FROM sqlite_master WHERE name='discovery_report'").fetchone():
        return None
    row = db.execute('SELECT revision,data FROM discovery_report WHERE id=1').fetchone()
    if not row:
        return None
    from evidence_storage import decode
    state = decode(row['data'])
    if row['revision'] != revision:
        return None
    return {'revision': revision, **{key: state.get(key) for key in ('evidence_filter', 'handoff', 'matrix', 'summary')}}


def read(store, run_id, query):
    offset = int(query.get('offset', '0'))
    kind, outcome, relation = query.get('kind', 'candidates'), query.get('outcome', ''), query.get('relation', '')
    if offset < 0 or kind not in ('candidates', 'tables') or outcome not in ('', 'include', 'abstain', 'conflict', 'unreviewed'):
        raise ValueError('Choose valid Integration inspection filters and a nonnegative offset')
    with store.lock, store.db() as db:
        saved = db.execute('SELECT revision,data,materialized FROM integration_plans WHERE id=?', (run_id,)).fetchone()
        if not saved:
            raise KeyError('Integration run was removed or is unavailable')
        plan = json.loads(saved['data'])
        revision = integration.content_revision(plan)
        if query.get('revision') and query['revision'] != revision:
            raise ValueError('This Integration run changed. Reopen Data Journey before inspecting it.')
        if plan.get('version') != integration.VERSION:
            raise ValueError('This legacy Integration run cannot supply a semantic journey')
        cases = plan.get('cases', [])
        case_lookup = {c['candidate']: c for c in cases}
        decisions = {d['candidate']: d for d in plan.get('decisions', [])}
        def status(case):
            value = decisions.get(case['candidate'], {}).get('status')
            return value if value in ('include', 'abstain', 'conflict') else 'unreviewed'
        outcomes = {key: 0 for key in ('include', 'abstain', 'conflict', 'unreviewed')}
        for case in cases:
            outcomes[status(case)] += 1
        def outputs():
            if saved['materialized']:
                if kind != 'tables':
                    return
                clause = 'plan_id=?' + (' AND json_extract(data,\'$.relation\')=?' if relation else '')
                args = (run_id, relation) if relation else (run_id,)
                for row in db.execute('SELECT data FROM integration_rows WHERE '+clause+' ORDER BY idx LIMIT 12 OFFSET ?', (*args, offset)):
                    yield json.loads(row['data'])
            else:
                yield from integration.rows(plan)
        groups = collections.Counter()
        output_rows = 0
        total = 0
        items = []
        if kind == 'candidates':
            for case in cases:
                if outcome and status(case) != outcome:
                    continue
                if offset <= total < offset + 12:
                    items.append({'candidate': case['candidate'], 'status': status(case),
                                  'decision': decisions.get(case['candidate']),
                                  'left': case['left'], 'right': case['right'],
                                  'document_name': case.get('document_name'),
                                  'paths': [{k: v for k, v in p.items() if k != 'vector'} for p in case.get('paths', [])]})
                total += 1
        # Summaries always describe the full saved output, not the current page.
        # Materialized rows stay in SQLite: only the selected page is decoded in Python.
        if saved['materialized']:
            for group in db.execute("SELECT json_extract(data,'$.relation') relation,count(*) n FROM integration_rows WHERE plan_id=? GROUP BY relation", (run_id,)):
                groups[group['relation']] = group['n']
            output_rows = sum(groups.values())
            if kind == 'tables':
                total = groups.get(relation, 0) if relation else output_rows
        for row in outputs():
            if not saved['materialized']:
                groups[row['relation']] += 1
                output_rows += 1
            if kind == 'tables' and (not relation or row['relation'] == relation):
                if saved['materialized'] or offset <= total < offset + 12:
                    case = case_lookup.get(row['candidate'])
                    items.append({'candidate': row['candidate'], 'relation': row['relation'],
                                  'direction': row.get('direction', 'undirected'),
                                  'document_name': case.get('document_name') if case else None,
                                  'left': {'name': case['left']['name'] if case else 'Source table', 'columns': row['left_columns'], 'record': {'record_id': row.get('left_record'), 'cells': row['left_cells']}},
                                  'right': {'name': case['right']['name'] if case else 'Source table', 'columns': row['right_columns'], 'record': {'record_id': row.get('right_record'), 'cells': row['right_cells']}},
                                  'paths': row.get('evidence', []), 'evidence_quote': row.get('evidence_quote', '')})
                if not saved['materialized']:
                    total += 1
        return {'id': run_id, 'title': plan['title'], 'revision': revision,
                'discovery_revision': saved['revision'], 'input': plan.get('journey_input'),
                'model': plan.get('model'), 'materialized': bool(saved['materialized']),
                'batch': plan.get('batch', {}), 'parent_run_id': plan.get('parent_run_id'),
                'coverage': plan.get('coverage', {}), 'outcomes': outcomes,
                'candidates': len(cases), 'output_rows': output_rows,
                'groups': [{'relation': name, 'rows': count} for name, count in sorted(groups.items())],
                'curated': bool(plan.get('curation') or plan.get('relationship_row_edits')),
                'page': {'kind': kind, 'total': total, 'offset': offset, 'limit': 12, 'items': items}}
