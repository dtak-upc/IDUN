"""Reviewed scoped entity keys. Duplicate values are candidates, never identity facts."""
import json
import math
import time
import knowledge as kg


def read(store):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_entity_keys(id TEXT PRIMARY KEY,data TEXT NOT NULL)')
        db.execute('CREATE TABLE IF NOT EXISTS kg_entity_key_events(sequence INTEGER PRIMARY KEY AUTOINCREMENT,recorded REAL,data TEXT NOT NULL)')
        return [json.loads(r['data']) for r in db.execute('SELECT data FROM kg_entity_keys ORDER BY id')]


def stale(item,graph,runs):
    attributes={a['id']:a for a in graph['attributes']}
    return (sorted(runs)!=item['runs'] or item['revisions']!={l['run']:l['revision'] for l in graph['layers']}
            or any(attributes.get(a['id'])!=a for a in item['attributes']))


def catalog(store,graph,runs):
    saved=read(store);concepts={c['id'] for c in graph['concepts']}
    return {'revision':kg.digest(saved),'items':[dict(k,stale=stale(k,graph,runs)) for k in saved
            if k['status']=='accepted' and k['concept'] in concepts]}


def key_value(raw,attributes):
    record=json.loads(raw);columns=record.get('columns',[]);cells=record.get('cells',[])
    values=[]
    for attribute in attributes:
        name=attribute['name']
        # Ambiguous repeated columns and unavailable cells cannot form a key.
        if columns.count(name)!=1:return None
        index=columns.index(name)
        if index>=len(cells):return None
        value=cells[index]
        if value is None or isinstance(value,str) and not value.strip():return None
        if isinstance(value,bool):kind='boolean'
        elif isinstance(value,(int,float)):
            if isinstance(value,float) and not math.isfinite(value):return None
            kind='number'
        elif isinstance(value,str):kind='string'
        else:return None
        if kind!=attribute['datatype']:return None
        if kind=='number':value=str(int(value)) if isinstance(value,int) or value.is_integer() else repr(value)
        values.append([kind,value])
    return json.dumps(values,ensure_ascii=False,separators=(',',':'))


def materialize(db,runs,concept,attributes):
    scope=','.join('?' for _ in runs)
    parts=[];args=[]
    for side in ('subject','object'):
        parts.append(f"SELECT run,json_extract(data,'$.{side}') record FROM kg_auto_instances WHERE run IN ({scope}) AND json_extract(data,'$.{side}.concept_id')=?")
        args.extend([*runs,concept])
    sql="""WITH observations AS (SELECT run,record,json_extract(record,'$.id') rid,kg_entity_key(record) value FROM ("""+' UNION ALL '.join(parts)+""")),
    records AS (SELECT rid,count(DISTINCT value) variations,sum(value IS NULL) absent,max(value) value,
        min(record) record,group_concat(DISTINCT run) runs FROM observations GROUP BY rid),
    complete AS (SELECT * FROM records WHERE variations=1 AND absent=0)
    """
    db.create_function('kg_entity_key',1,lambda raw:key_value(raw,attributes),deterministic=True)
    # Materialize once per check; never rescore or copy records into a durable cache.
    db.execute('CREATE TEMP TABLE kg_key_records AS '+sql+'SELECT * FROM records',args)
    db.execute('CREATE INDEX kg_key_records_value ON kg_key_records(value) WHERE variations=1 AND absent=0')
    complete='WITH complete AS (SELECT * FROM kg_key_records WHERE variations=1 AND absent=0) '


def inspect(store,runs,concept,attributes):
    with store.db() as db:
        materialize(db,runs,concept,attributes)
        complete='WITH complete AS (SELECT * FROM kg_key_records WHERE variations=1 AND absent=0) '
        row=db.execute("""SELECT count(*) total,coalesce(sum(variations=1 AND absent=0),0) complete,
            coalesce(sum(variations>1),0) conflicting,coalesce(sum(variations<=1 AND absent>0),0) incomplete FROM kg_key_records""").fetchone()
        stats=dict(row)
        stats['duplicate_groups']=db.execute(complete+'SELECT count(*) FROM (SELECT value FROM complete GROUP BY value HAVING count(*)>1)').fetchone()[0]
        groups=[]
        for duplicate in db.execute(complete+'SELECT value,count(*) n FROM complete GROUP BY value HAVING count(*)>1 ORDER BY n DESC,value LIMIT 8'):
            records=[]
            for match in db.execute(complete+'SELECT record,runs FROM complete WHERE value=? ORDER BY rid LIMIT 4',[duplicate['value']]):
                record=json.loads(match['record']);records.append({'label':record['label'],'source':record['source'],'row':record['row'],'runs':match['runs'].split(',')})
            groups.append({'values':[v[1] for v in json.loads(duplicate['value'])],'count':duplicate['n'],'records':records})
    return {'coverage':stats,'groups':groups,'group_limit':8,'records_per_group':4}


def route(store,action,body):
    import knowledge_auto as auto
    runs=auto.selected(body)
    with store.lock:
        graph=auto.view(store,runs)
        if action=='entity-keys':return catalog(store,graph,runs)
        if graph['revision']!=body.get('revision'):raise ValueError('Graph changed; refresh and preview again')
        if any(l['update_available'] for l in graph['layers']):raise ValueError('Review pending graph updates before defining entity keys')
        if kg._jobs.get(str(store.root),{}).get('status')=='running':raise ValueError('Wait for the current graph task')
        saved=read(store)
        if action=='undo-entity-key':
            item=next((k for k in saved if k['id']==body.get('id') and k['status']=='accepted'),None)
            if not item or item['concept'] not in {c['id'] for c in graph['concepts']}:raise ValueError('Choose a visible saved key')
            if body.get('key_revision')!=kg.digest(saved):raise ValueError('Entity keys changed; reload before removing')
            result=dict(item,status='undone')
        else:
            concept=body.get('concept');selected=body.get('attributes')
            if not runs:raise ValueError('Select Integration runs first')
            if concept not in {c['id'] for c in graph['concepts']}:raise ValueError('Choose a visible concept')
            if not isinstance(selected,list) or not 1<=len(selected)<=4 or any(not isinstance(a,str) for a in selected) or len(set(selected))!=len(selected):raise ValueError('Choose one to four distinct key attributes')
            lookup={a['id']:a for a in graph['attributes']}
            if any(a not in lookup or lookup[a]['concept']!=concept or lookup[a]['datatype'] not in ('string','number','boolean') for a in selected):raise ValueError('Key attributes must belong to the concept and have an unambiguous supported type')
            attributes=[lookup[a] for a in sorted(selected)]
            result={'id':'entity_key_'+kg.digest([concept,sorted(runs)]),'concept':concept,'attributes':attributes,
                    'runs':sorted(runs),'revisions':{l['run']:l['revision'] for l in graph['layers']},'status':'accepted'}
            preview={'key':result,**inspect(store,runs,concept,attributes)}
            preview['token']=kg.digest([graph['revision'],saved,preview])
            if action=='preview-entity-key':return preview
            if action!='apply-entity-key' or body.get('token')!=preview['token']:raise ValueError('Key preview changed; preview again')
            if body.get('confirmed') is not True:raise ValueError('Confirm that these attributes identify this concept in the selected sources')
            if not preview['coverage']['complete']:raise ValueError('No records have a complete, consistent key')
        with store.db() as db:
            before=next((k for k in saved if k['id']==result['id']),None)
            db.execute('INSERT OR REPLACE INTO kg_entity_keys VALUES(?,?)',(result['id'],json.dumps(result)))
            db.execute('INSERT INTO kg_entity_key_events(recorded,data) VALUES(?,?)',(time.time(),json.dumps({'before':before,'after':result,'revision':graph['revision']})))
        return catalog(store,graph,runs)
