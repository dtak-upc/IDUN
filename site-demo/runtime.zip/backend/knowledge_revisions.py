"""Pinned automatic projections and explicit, optimistic update application."""
import json
import time
import knowledge as kg


def setup(store):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_projection_history(run TEXT,revision TEXT,recorded REAL,data TEXT,PRIMARY KEY(run,revision))')
        db.execute('CREATE TABLE IF NOT EXISTS kg_projection_history_items(run TEXT,revision TEXT,id TEXT,edge TEXT,data TEXT,PRIMARY KEY(run,revision,id))')


def archive(db,run):
    row=db.execute('SELECT revision,data FROM kg_auto_runs WHERE run=?',(run,)).fetchone()
    if not row:return
    if db.execute('SELECT 1 FROM kg_projection_history WHERE run=? AND revision=?',(run,row['revision'])).fetchone():return
    db.execute('INSERT INTO kg_projection_history VALUES(?,?,?,?)',(run,row['revision'],time.time(),row['data']))
    db.execute('INSERT INTO kg_projection_history_items SELECT run,?,id,edge,data FROM kg_auto_instances WHERE run=?',(row['revision'],run))


def prepare(store,runs):
    import knowledge_auto as auto
    graph=auto.view(store,runs);updates=[];prepared=[]
    with store.db() as db:
        names={r['id']:r['name'] for r in db.execute('SELECT id,name FROM assets')}
        for layer in graph['layers']:
            if not layer['update_available']:continue
            run=layer['run'];plan,revision=kg.load_plan(store,run)
            key=auto.projection_key(store,run,revision)
            refined=auto.knowledge_concepts.read(store,run,revision)
            meta,items=auto.project_run(store,run,plan,revision,names,refined)
            old={r['id']:r['data'] for r in db.execute('SELECT id,data FROM kg_auto_instances WHERE run=?',(run,))}
            new={a['id']:json.dumps(a) for a in items};common=set(old)&set(new)
            updates.append({'run':run,'title':meta['title'],'before':len(old),'after':len(new),
                'added':len(set(new)-set(old)),'removed':len(set(old)-set(new)),
                'retained':len(common),'evidence_changed':sum(json.loads(old[i])['evidence']!=json.loads(new[i])['evidence'] for i in common),
                'semantic_reset':layer.get('semantic',False) and not meta['semantic'],
                'revision':key})
            prepared.append((run,key,revision,meta,items))
    token=kg.digest([graph['revision'],updates,prepared])
    return {'token':token,'updates':updates},prepared


def retention_preview(store,graph,keep):
    if type(keep) is not int or not 0<=keep<=1000:
        raise ValueError('Keep between 0 and 1000 inactive revisions per selected run')
    candidates=[];protected=0;retained=0;state=[]
    with store.db() as db:
        checkpoint_refs=set()
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_query_checkpoints'").fetchone():
            checkpoint_refs={(run,revision) for r in db.execute('SELECT data FROM kg_query_checkpoints') for run,revision in json.loads(r['data'])['projections'].items()}
        for layer in graph['layers']:
            rows=list(db.execute('SELECT * FROM kg_projection_history WHERE run=? ORDER BY recorded DESC,revision DESC',(layer['run'],)))
            inactive=[]
            for row in rows:
                state.append([row['run'],row['revision'],row['recorded']])
                if row['revision']==layer['revision'] or (row['run'],row['revision']) in checkpoint_refs:protected+=1
                else:inactive.append(row)
            retained+=min(keep,len(inactive))
            for row in inactive[keep:]:
                meta=json.loads(row['data'])
                size=db.execute('SELECT coalesce(sum(length(cast(data AS BLOB))),0) FROM kg_projection_history_items WHERE run=? AND revision=?',(row['run'],row['revision'])).fetchone()[0]
                candidates.append({'run':row['run'],'revision':row['revision'],'recorded':row['recorded'],
                    'title':meta['title'],'count':meta['count'],'bytes':size+len(row['data'].encode('utf-8'))})
    return {'token':kg.digest([graph['revision'],state,keep,candidates]),'keep':keep,'candidates':candidates,
            'protected':protected,'retained':retained,'bytes':sum(c['bytes'] for c in candidates)}


def route(store,action,body):
    import knowledge_auto as auto
    runs=auto.selected(body);auto.setup(store)
    with store.lock:
        if action in ('preview-update','apply-update'):
            preview,prepared=prepare(store,runs)
            if action=='preview-update':return preview
            if body.get('token')!=preview['token']:raise ValueError('The update preview changed; preview again before applying')
            if kg._jobs.get(str(store.root),{}).get('status')=='running':raise ValueError('Wait for the current graph task before updating')
            with store.db() as db:
                for run,key,revision,meta,items in prepared:
                    if kg.load_plan(store,run)[1]!=revision or auto.projection_key(store,run,revision)!=key:raise ValueError('Integration changed; preview again')
                    archive(db,run)
                    db.execute('DELETE FROM kg_auto_instances WHERE run=?',(run,))
                    db.executemany('INSERT INTO kg_auto_instances VALUES(?,?,?,?)',[(run,a['id'],a['edge'],json.dumps(a)) for a in items])
                    db.execute('INSERT OR REPLACE INTO kg_auto_runs VALUES(?,?,?)',(run,key,json.dumps(meta)))
            return auto.view(store,runs)
        graph=auto.view(store,runs)
        if action in ('preview-retention','apply-retention'):
            preview=retention_preview(store,graph,body.get('keep'))
            if action=='preview-retention':return preview
            if body.get('token')!=preview['token']:raise ValueError('History changed; preview cleanup again')
            if kg._jobs.get(str(store.root),{}).get('status')=='running':raise ValueError('Wait for the current graph task before cleaning history')
            with store.db() as db:
                for c in preview['candidates']:
                    db.execute('DELETE FROM kg_projection_history_items WHERE run=? AND revision=?',(c['run'],c['revision']))
                    db.execute('DELETE FROM kg_projection_history WHERE run=? AND revision=?',(c['run'],c['revision']))
            return {'removed':len(preview['candidates']),'bytes':preview['bytes']}
        if action=='history':
            with store.db() as db:
                return {'items':[dict(run=r['run'],revision=r['revision'],recorded=r['recorded'],title=json.loads(r['data'])['title'],count=json.loads(r['data'])['count']) for run in runs for r in db.execute('SELECT * FROM kg_projection_history WHERE run=? ORDER BY recorded DESC',(run,))]}
        if action=='restore':
            run=body.get('run')
            if run not in runs or body.get('graph_revision')!=graph['revision']:raise ValueError('Graph changed; refresh before restoring')
            if kg._jobs.get(str(store.root),{}).get('status')=='running':raise ValueError('Wait for the current graph task before restoring')
            with store.db() as db:
                row=db.execute('SELECT * FROM kg_projection_history WHERE run=? AND revision=?',(run,body.get('revision'))).fetchone()
                if not row:raise ValueError('Saved projection revision not found')
                names={r[0] for r in db.execute('SELECT id FROM assets')}
                if not set(json.loads(row['data'])['assets'])<=names:raise ValueError('A source was removed; this revision cannot be restored')
                archive(db,run)
                db.execute('DELETE FROM kg_auto_instances WHERE run=?',(run,))
                db.execute('INSERT INTO kg_auto_instances SELECT run,id,edge,data FROM kg_projection_history_items WHERE run=? AND revision=?',(run,row['revision']))
                db.execute('INSERT OR REPLACE INTO kg_auto_runs VALUES(?,?,?)',(run,row['revision'],row['data']))
            return auto.view(store,runs)
    raise ValueError('Unknown graph revision operation')
