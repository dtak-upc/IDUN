"""Compact evidence encoding and retention for possible join paths."""
import collections
import json
import zlib

MAGIC = b'IDUNZ1\0'
POLICY_V1 = 'join-candidates-v1'
POLICY_V2 = 'evidence-retention-v2'
POLICY = POLICY_V2


def policy_for(store):
    """Select legacy retention by configured preset, never by dataset name."""
    path = store.root / 'lake_config.json'
    config = json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {}
    from semantic import is_clinical_context
    return POLICY_V1 if is_clinical_context({**config.get('schema_config', {}),
                                            'prompt_id': config.get('prompt_id')}) else POLICY_V2


def encode(value):
    return MAGIC + zlib.compress(json.dumps(value, separators=(',', ':'), ensure_ascii=False).encode('utf-8'), 6)


def decode(value):
    if isinstance(value, bytes) and value.startswith(MAGIC):
        value = zlib.decompress(value[len(MAGIC):])
    return json.loads(value)


def retain(context, roles=None, protected=frozenset(), policy=None, allow_same_table=False):
    """Preserve candidate evidence with bounded diversity across rows, tables, and windows.

    Supports versioned retention policies:
    - 'join-candidates-v1': Legacy clinical retention requiring diagnosis/medication roles.
    - 'evidence-retention-v2' (default): Domain-neutral bounded retention ensuring nonclinical
      links across tables survive with bounded diversity, while preserving clinical pairing
      when clinical roles are present.
    """
    pol = policy or POLICY
    roles = roles or {}
    groups = collections.defaultdict(list)
    for link in context.get('links', []):
        groups[(link['start'], link['end'])].append(link)
    tables = {link['table'] for link in context.get('links', [])}
    retained = []
    total_scored = context.get('retention', {}).get('scored_links', len(context.get('links', [])))

    has_multiple_tables = len(tables) > 1 or (len(context.get('members', [])) > 2 and len(tables) >= 1)

    if pol == POLICY_V1:
        # Legacy v1 clinical retention
        for group in groups.values():
            ranked = sorted(group, key=lambda l: (-l['score'], l['id']))
            diagnoses = [l for l in ranked if roles.get(l['table']) == 'diagnosis'][:3]
            medications = [l for l in ranked if roles.get(l['table']) == 'medication'][:4]
            chosen = {l['id'] for l in group if l['id'] in protected}
            if diagnoses and medications:
                pairs = sorted(((a, b) for a in diagnoses for b in medications), key=lambda pair: -(pair[0]['score'] + pair[1]['score']))[:8]
                chosen.update(l['id'] for pair in pairs for l in pair)
            elif len(tables) > 1:
                counts = collections.Counter()
                for link in ranked:
                    cap = 4 if roles.get(link['table']) == 'medication' else 3
                    if counts[link['table']] < cap:
                        chosen.add(link['id'])
                        counts[link['table']] += 1
            retained.extend(l for l in group if l['id'] in chosen)
    else:
        # Version 2: Domain-neutral bounded retention
        for group in groups.values():
            ranked = sorted(group, key=lambda l: (-l['score'], l['id']))
            chosen = {l['id'] for l in group if l['id'] in protected}

            diagnoses = [l for l in ranked if roles.get(l['table']) == 'diagnosis'][:3]
            medications = [l for l in ranked if roles.get(l['table']) == 'medication'][:4]

            if diagnoses and medications:
                # Clinical pairing path preserved for clinical tables
                pairs = sorted(((a, b) for a in diagnoses for b in medications), key=lambda pair: -(pair[0]['score'] + pair[1]['score']))[:8]
                chosen.update(l['id'] for pair in pairs for l in pair)
            elif has_multiple_tables:
                # Domain-neutral multi-table diversity:
                # 1. Cap links per table in this span (max 4 per table)
                counts = collections.Counter()
                for link in ranked:
                    if counts[link['table']] < 4:
                        chosen.add(link['id'])
                        counts[link['table']] += 1
                # 2. Cross-table pairs across distinct tables within this span (top 8 pairs)
                group_tables = {l['table'] for l in ranked}
                if len(group_tables) > 1:
                    table_links = collections.defaultdict(list)
                    for l in ranked:
                        table_links[l['table']].append(l)
                    t_list = list(table_links.keys())
                    cross_pairs = []
                    for i in range(len(t_list)):
                        for j in range(i + 1, len(t_list)):
                            for a in table_links[t_list[i]][:3]:
                                for b in table_links[t_list[j]][:3]:
                                    cross_pairs.append((a, b))
                    cross_pairs.sort(key=lambda p: -(p[0]['score'] + p[1]['score']))
                    for a, b in cross_pairs[:8]:
                        chosen.add(a['id'])
                        chosen.add(b['id'])
            elif allow_same_table:
                # Same-table retention when explicitly enabled
                for link in ranked[:3]:
                    chosen.add(link['id'])

            retained.extend(l for l in group if l['id'] in chosen)

    starts = {str(l['start']) for l in retained}
    return {
        **context,
        'links': retained,
        'sentence_vectors': {k: v for k, v in context.get('sentence_vectors', {}).items() if k in starts},
        'retention': {
            'policy': pol,
            'scored_links': total_scored,
            'retained_links': len(retained),
            'omitted_links': max(0, total_scored - len(retained)),
        }
    }


def source_roles(profile):
    from semantic import role
    roles = {}
    for s in profile.get('sources', []):
        cols = [c['name'] for c in s.get('columns', []) if isinstance(c, dict) and 'name' in c]
        roles[s['asset_id']] = role(cols)[0] if cols else None
    return roles
