"""Bounded, row-diverse paths over document evidence, independent of GPU batches."""
import bisect
import collections


def neighborhoods(links, roles, window, allow_same_table=False, required_roles=None):
    documents = collections.defaultdict(list)
    for link in links:
        documents[(link['text'],link['text_version'])].append(link)
    for (doc,_), group in documents.items():
        # Same-span paths are a separate evidence channel. Preserve them before
        # neighborhood pruning: a stronger link elsewhere must not erase a join.
        spans = collections.defaultdict(dict)
        for link in group:
            key = (link['context'], link['start'], link['end'])
            previous = spans[key].get(link['record_id'])
            if previous is None or link['score'] > previous['score']:
                spans[key][link['record_id']] = link
        emitted = set()
        for rows in spans.values():
            rows = sorted(rows.values(), key=lambda l: (l['table'], l['record_id']))
            # Yield small batches, without discarding the remaining pairs.
            batch = []
            for i, a in enumerate(rows):
                for b in rows[i + 1:]:
                    if a['table'] == b['table'] or a['record_id'] == b['record_id']:
                        continue
                    if required_roles and {roles.get(a['table'], (None,))[0], roles.get(b['table'], (None,))[0]} != set(required_roles):
                        continue
                    identity = (a['record_id'], b['record_id'], a['start'], a['end'])
                    if identity in emitted:
                        continue
                    emitted.add(identity)
                    batch.append((a, b, 0))
                    if len(batch) == 16:
                        yield doc, batch, len(batch)
                        batch = []
            if batch:
                yield doc, batch, len(batch)
        # The same link can be scored in overlapping compute blocks. Keep its best
        # context for ranking; compute-context identity is not a semantic boundary.
        unique = {}
        for l in group:
            key=(l['record_id'],l['start'],l['end'])
            if key not in unique or (l['score'],l['id']) > (unique[key]['score'],unique[key]['id']):unique[key]=l
        ordered=sorted(unique.values(),key=lambda l:(l['start'],l['id']))
        starts=[l['start'] for l in ordered]
        for anchor in sorted(set(starts)):
            local=ordered[bisect.bisect_left(starts,anchor):bisect.bisect_right(starts,anchor+window)]
            tables=collections.defaultdict(dict)
            for l in sorted(local,key=lambda l:(-l['score'],l['start'],l['id'])):
                rows=tables[l['table']]
                if l['record_id'] in rows or len(rows)>=4:continue
                rows[l['record_id']]=l
            queues=[]
            ids=sorted(tables)
            for i,aid in enumerate(ids):
                for bid in ids[i+1:]:
                    if required_roles and {roles.get(aid,(None,None))[0],roles.get(bid,(None,None))[0]}!=set(required_roles):continue
                    candidates=[]
                    for a in tables[aid].values():
                        for b in tables[bid].values():
                            if a['record_id']==b['record_id']:continue
                            if (a['start'], a['end']) == (b['start'], b['end']) and (a['record_id'], b['record_id'], a['start'], a['end']) in emitted:continue
                            if aid==bid and a['record_id']>=b['record_id']:continue
                            # Emit from a selected anchor only; later windows cover others.
                            if min(a['start'],b['start'])!=anchor:continue
                            candidates.append((a,b,abs(a['start']-b['start'])))
                    candidates.sort(key=lambda p:(-(p[0]['score']+p[1]['score']),p[2],p[0]['id'],p[1]['id']))
                    if candidates:queues.append(collections.deque(candidates))
            raw=sum(map(len,queues));chosen=[]
            queues.sort(key=lambda q:-(q[0][0]['score']+q[0][1]['score']))
            # Round-robin source pairs so a high-scoring table pair cannot consume
            # every slot; the final run budget is still applied after reranking.
            while len(chosen)<16 and any(queues):
                for queue in queues:
                    if queue and len(chosen)<16:chosen.append(queue.popleft())
            if chosen:yield doc,chosen,raw
