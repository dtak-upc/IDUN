"""Schema-selected paths over bounded starting records; reuse the witness engine."""
import json
import sqlite3
import threading
import time
import knowledge as kg
import knowledge_auto as auto
import knowledge_overlays as overlays
import knowledge_path_patterns as patterns
import knowledge_traversal as traversal
import knowledge_value_comparisons as comparisons
import knowledge_temporal_query as temporal


def prepare(store,graph,runs,body):
    concept=body.get('concept')
    if not isinstance(concept,str) or concept not in {c['id'] for c in graph['concepts']}:raise ValueError('Select a starting concept in this query scope')
    if not isinstance(body.get('pattern'),list) or any(not isinstance(s,dict) or s.get('kind','assertion') not in ('assertion','identity') for s in body['pattern']):raise ValueError('Visual paths use integrated relationships or reviewed identity steps')
    proxy=dict(body,start={'id':'schema-query','concept_id':concept})
    raw=body['pattern']
    if any(not isinstance(s.get('target'),str) for s in raw):raise ValueError('Choose a target concept for every connection')
    for s in raw:
        if type(s.get('optional',False)) is not bool:raise ValueError('Optional must be true or false')
        if not isinstance(s.get('alternatives',[]),list) or len(s.get('alternatives',[]))>64 or any(not isinstance(a,str) for a in s.get('alternatives',[])):raise ValueError('Choose up to 64 compatible relationship alternatives')
    prepared_comparisons=comparisons.prepare(graph,body)
    if (isinstance(body.get('temporal'),dict) and body['temporal'].get('mode')=='simultaneous') or body.get('comparisons') or any('parent' in step or 'target_binding' in step or step.get('optional') or step.get('alternatives') for step in raw):
        compiled=[];summaries=[];tokens=[]
        for i,step in enumerate(raw):
            parent=step.get('parent',i-1)
            if type(parent) is not int or not -1<=parent<i:raise ValueError('Each branch must attach to the start or an earlier selected concept')
            source=concept if parent==-1 else raw[parent]['target']
            if type(step.get('optional',False)) is not bool:raise ValueError('Optional must be true or false')
            if step.get('optional'):
                if 'target_binding' in step or any(t.get('parent',j-1)==i or t.get('target_binding')==i for j,t in enumerate(raw[i+1:],i+1)) or any(o.get('binding')==i for c in body.get('comparisons',[]) for o in (c.get('left',{}),c.get('right',{}))):raise ValueError('Optional connections must be independent leaf roles without comparisons or closing bindings')
            alternatives=step.get('alternatives',[])
            if not isinstance(alternatives,list) or len(alternatives)>64 or any(not isinstance(a,str) for a in alternatives):raise ValueError('Choose up to 64 compatible relationship alternatives')
            if alternatives and step.get('kind')=='identity':raise ValueError('Identity steps cannot have relationship alternatives')
            options=[]
            for eid in dict.fromkeys([step.get('relationship',''),*alternatives]):
                option=dict(step,relationship=eid)
                part=traversal.prepare_pattern(store,graph,runs,dict(proxy,start={'id':'schema-query','concept_id':source},pattern=[option]),max_steps=None)
                options.append(part['steps'][0])
            if any(o['selected_direction']!=options[0]['selected_direction'] for o in options):raise ValueError('Alternative relationships must use the same direction semantics')
            part['steps'][0]['relations']={k:v for o in options for k,v in o['relations'].items()}
            part['steps'][0]['label']=' OR '.join(dict.fromkeys(o['label'] for o in options))
            part['summary'][0]['relationship']=part['steps'][0]['label']
            part['summary'][0]['optional']=step.get('optional',False)
            binding=step.get('target_binding')
            if 'target_binding' in step:
                if type(binding) is not int or not -1<=binding<i:raise ValueError('A closing connection must refer to the start or an earlier record binding')
                bound_concept=concept if binding==-1 else raw[binding]['target']
                if bound_concept!=step['target']:raise ValueError('Closing connection must target the referenced concept')
            compiled.append(dict(part['steps'][0],parent=parent,**({'target_binding':binding} if 'target_binding' in step else {})))
            summaries.append(dict(part['summary'][0],parent=parent,source=next(c['label'] for c in graph['concepts'] if c['id']==source),**({'target_binding':binding} if 'target_binding' in step else {})))
            tokens.append(part['token'])
        if not compiled:raise ValueError('Choose at least one relationship step')
        pattern={'steps':compiled,'summary':summaries,'tree':True,'mode':body.get('pattern_mode','exact'),'token':kg.digest([tokens,raw])}
    else:
        pattern=traversal.prepare_pattern(store,graph,runs,proxy,max_steps=None)
    condition=patterns.prepare_condition(graph,body.get('start_condition'))
    if condition and not any(a['concept']==concept for a in condition['resolved']):raise ValueError('Starting condition must belong to the selected concept')
    pattern['comparisons']=prepared_comparisons
    reviewed=(condition and condition['values_mode']=='reviewed') or any(o['prepared']['values_mode']=='reviewed' for c in pattern['comparisons'] for o in (c['left'],c['right']))
    claim_revision=overlays.read(store) if reviewed else None
    labels=body.get('role_labels',{})
    if not isinstance(labels,dict) or any(k not in {str(i) for i in range(-1,len(raw))} or not isinstance(v,str) or len(v)>100 for k,v in labels.items()):raise ValueError('Record role labels must be at most 100 characters')
    for c in pattern['comparisons']:
        for o in (c['left'],c['right']):
            label=labels.get(str(o['binding']))
            if label:o['label']=label+' · '+o['label'].split(' · ')[-1]
    pattern['token']=kg.digest([pattern['token'],body.get('start_condition'),body.get('comparisons',[]),claim_revision,labels])
    return pattern,condition


def route(store,action,body):
    runs=auto.selected(body)
    with store.lock:
        graph,runs,history_refs,snapshot=context(store,body)
        if graph['revision']!=body.get('revision'):raise ValueError('Query schema changed; rebuild the visual preview')
        pattern,condition=prepare(store,graph,runs,body)
        if snapshot:
            if any(s.get('kind')=='identity' or (s['condition_prepared'] and s['condition_prepared']['values_mode']=='reviewed') for s in pattern['steps']) or (condition and condition['values_mode']=='reviewed') or any(o['prepared']['values_mode']=='reviewed' for c in pattern['comparisons'] for o in (c['left'],c['right'])):raise ValueError('Saved views contain original values and captured assertions only; reviewed identities and claims are not captured')
            pattern['token']=kg.digest([pattern['token'],kg.digest(snapshot)])
        pattern['temporal']=temporal.prepare(store,graph,body,snapshot)
        if pattern['temporal']:
            if pattern['temporal']['mode']=='simultaneous' and any(s.get('optional') for s in pattern['steps']):raise ValueError('Shared-time queries currently require required connections; turn off optional leaf connections or use independent range overlap')
            if any(s.get('kind')=='identity' for s in pattern['steps']):raise ValueError('Identity links have no reviewed valid-time interval; remove the identity step or temporal filter')
            pattern['token']=kg.digest([pattern['token'],pattern['temporal']])
        if action=='preview-visual-path':
            return {'token':pattern['token'],'summary':pattern['summary'],'temporal':body.get('temporal'),'comparisons':comparisons.describe(pattern['comparisons']),'start':next(c['label'] for c in graph['concepts'] if c['id']==body['concept']),'branching':bool(pattern.get('tree')),'constraints':any('target_binding' in s for s in pattern['steps'])}
        if action!='visual-path':raise ValueError('Unknown visual query operation')
        if body.get('preview_token')!=pattern['token']:raise ValueError('Preview the current visual path before running it')
        limit=traversal.integer(body,'limit',20,1,100);budget=traversal.integer(body,'budget',500,10,5000)
        start_limit=traversal.integer(body,'start_limit',100,1,1000)
        key=traversal.request_key(store,body);event=threading.Event()
        with traversal._guard:
            if key in traversal._requests:raise ValueError('Query request is already running')
            traversal._requests[key]=event
        try:
            result=execute(store,graph,runs,body,pattern,condition,limit,budget,start_limit,event,history_refs=history_refs)
            result['scope']={'runs':runs,'revision':graph['revision'],'checkpoint':snapshot and {k:snapshot[k] for k in ('id','title','recorded')},'role_labels':body.get('role_labels',{}),'temporal':body.get('temporal')}
            return result
        finally:
            with traversal._guard:traversal._requests.pop(key,None)


def execute(store,graph,runs,body,pattern,condition,limit,budget,start_limit,event,history_refs=None):
    deadline=time.monotonic()+10;interrupted=lambda:event.is_set() or time.monotonic()>=deadline
    results=[];examined=0;scanned=0;matched=0;stop=None;overflow=False
    with store.db() as db:
        db.set_progress_handler(interrupted,1000)
        try:
            scope=','.join('?' for _ in runs);parts=[];args=[]
            table='kg_auto_instances';where=f'run IN ({scope})';scope_args=list(runs)
            if history_refs is not None:
                table='kg_projection_history_items';where='('+' OR '.join('(run=? AND revision=?)' for _ in history_refs)+')';scope_args=[v for pair in history_refs.items() for v in pair]
            for side in ('subject','object'):
                parts.append(f"SELECT json_extract(data,'$.{side}.id') id,json_extract(data,'$.{side}') record FROM {table} WHERE {where} AND json_extract(data,'$.{side}.concept_id')=?")
                args.extend([*scope_args,body['concept']])
            seeds=list(db.execute('SELECT id,min(record) record FROM ('+' UNION ALL '.join(parts)+') GROUP BY id ORDER BY id LIMIT ?',[*args,start_limit+1]))
            overflow=len(seeds)>start_limit
            for row in seeds[:start_limit]:
                if interrupted():stop='cancelled' if event.is_set() else 'time_limit';break
                if examined>=budget:stop='work_budget';break
                scanned+=1;examined+=1;record=json.loads(row['record'])
                if condition:
                    if condition['values_mode']=='reviewed':
                        _,contributions=traversal.projected_record(db,runs,record)
                        assertions=[{'subject':record,'object':{'id':'','concept_id':''},'contributions':contributions}]
                        overlays.annotate(store,graph,runs,assertions,interrupted=interrupted)
                    matches=patterns.condition_matches(record,condition)
                    if not matches:continue
                else:matches=[]
                matched+=1
                if examined>=budget:stop='work_budget';break
                if pattern.get('tree'):
                    data=execute_tree(store,graph,runs,record,pattern,limit-len(results),budget-examined,event,deadline,history_refs=history_refs)
                else:
                    data=traversal.explore(store,graph,runs,{'id':record['id'],'concept_id':record['concept_id']},len(pattern['steps']),limit-len(results),budget-examined,False,event,pattern,deadline=deadline,history_refs=history_refs)
                examined+=data['examined']
                for result in data['items']:results.append(dict(result,start=traversal.summary(record),start_attribute_matches=matches))
                if data['stop']:stop=data['stop'];break
                if len(results)>=limit:stop='result_limit';break
            if overflow and not stop:stop='starting_record_limit'
        except sqlite3.OperationalError as e:
            if 'interrupted' not in str(e):raise
            stop='cancelled' if event.is_set() else 'time_limit'
        finally:db.set_progress_handler(None,0)
    return {'items':results,'returned':len(results),'examined':examined,'starts_scanned':scanned,'starts_matched':matched,'start_limit':start_limit,'truncated':bool(stop),'stop':stop,
            'branching':bool(pattern.get('tree')),'constraints':any('target_binding' in s for s in pattern['steps']),'semantics':('Required connections must match; alternatives are OR within a connection. Optional leaf absence is reported only after a complete scan. All other selected connections must match with shared record bindings; closing and parallel connections must reuse their referenced records. One witness per complete record assignment; results may be partial.' if pattern.get('tree') else 'One witness per starting record and destination matching the complete path. Starting records and adjacent assertions share one work budget; results may be partial.')}


def execute_tree(store,graph,runs,start,pattern,limit,budget,event,deadline,history_refs=None):
    """Conjunctive graph matching with shared parents and explicit closing bindings."""
    shared=pattern.get('temporal') and pattern['temporal']['mode']=='simultaneous'
    initial=[(pattern['temporal']['start'],pattern['temporal']['end'])] if shared else []
    stack=[([],[],[],initial)];items=[];work=0;stop=None;seen=set();cache={}
    def values(operand,records):
        target=start if operand['binding']==-1 else records[operand['binding']]
        key=(target['id'],target['concept_id'],operand['prepared']['values_mode'])
        if key not in cache:
            with store.db() as db:
                db.set_progress_handler(lambda:event.is_set() or time.monotonic()>=deadline,1000)
                record,contributions=traversal.projected_record(db,runs,target,history_refs=history_refs)
            record['concept']=next(c['label'] for c in graph['concepts'] if c['id']==record['concept_id'])
            if operand['prepared']['values_mode']=='reviewed':overlays.annotate(store,graph,runs,[{'subject':record,'object':{'id':'','concept_id':''},'contributions':contributions}],interrupted=lambda:event.is_set() or time.monotonic()>=deadline)
            cache[key]=record
        return cache[key]

    while stack and not stop:
        if event.is_set():stop='cancelled';break
        if time.monotonic()>=deadline:stop='time_limit';break
        records,witness,value_matches,windows=stack.pop();index=len(witness)
        if index==0:
            accepted,new_matches,used,reason=comparisons.evaluate(pattern.get('comparisons',[]),-1,lambda o:values(o,records),budget-work,event,deadline)
            work+=used
            if reason:stop=reason;break
            if not accepted:continue
            value_matches=value_matches+new_matches
        if index==len(pattern['steps']):
            key=tuple((r['id'],r['concept_id']) for r in records)
            if key not in seen:
                seen.add(key);items.append({'record':next((r for r in reversed(records) if r['id']),traversal.summary(start)),'records':records,'steps':witness,'comparison_matches':value_matches,**({'shared_intervals':temporal.intervals(windows)} if shared else {})})
            if len(items)>=limit:stop='result_limit'
            continue
        if work>=budget:stop='work_budget';break
        work+=1  # Charge each partial-assignment expansion, including failed branches.
        if work>=budget:stop='work_budget';break
        selected=pattern['steps'][index];source=start if selected['parent']==-1 else records[selected['parent']]
        part={'steps':[selected],'summary':[pattern['summary'][index]],'temporal':pattern.get('temporal'),'all_candidates':bool(shared)}
        data=traversal.explore(store,graph,runs,{'id':source['id'],'concept_id':source['concept_id']},1,budget-work+1,budget-work,False,event,part,deadline=deadline,history_refs=history_refs)
        work+=data['examined']
        candidates=[]
        for match in data['items']:
            if 'target_binding' in selected:
                bound=start if selected['target_binding']==-1 else records[selected['target_binding']]
                if (match['record']['id'],match['record']['concept_id'])!=(bound['id'],bound['concept_id']):continue
            step=dict(match['steps'][0],source=traversal.summary(source),parent=selected['parent'],**({'target_binding':selected['target_binding']} if 'target_binding' in selected else {}))
            common=windows
            if shared:
                common,used,reason=temporal.advance(windows,step,budget-work,event,deadline)
                work+=used
                if reason:stop=reason;break
                if not common:continue
            bound=records+[match['record']]
            accepted,new_matches,used,reason=comparisons.evaluate(pattern.get('comparisons',[]),index,lambda o:values(o,bound),budget-work,event,deadline)
            work+=used
            if reason:stop=reason;break
            if accepted:candidates.append((bound,witness+[step],value_matches+new_matches,common))
        if stop or data['stop']:
            # Complete witnesses from the final step are still valid even if adjacency scanning was partial.
            if index+1==len(pattern['steps']):
                for bound,steps,value_witnesses,common in candidates:
                    key=tuple((r['id'],r['concept_id']) for r in bound)
                    if key not in seen and len(items)<limit:
                        seen.add(key);items.append({'record':bound[-1],'records':bound,'steps':steps,'comparison_matches':value_witnesses,**({'shared_intervals':temporal.intervals(common)} if shared else {})})
            stop=stop or data['stop'];break
        if not candidates and selected.get('optional'):
            missing={'id':'','concept_id':selected['target'],'label':'No matching optional record','source':'','row':0}
            candidates.append((records+[missing],witness+[{'kind':'optional_missing','id':'','relation':selected['label'],'source':traversal.summary(source),'target':missing,'contributions':[],'explanation':'No matching assertion after a complete adjacency scan.'}],value_matches,windows))
        stack.extend(reversed(candidates))
    return {'items':items,'examined':work,'stop':stop}


def context(store,body):
    checkpoint=body.get('checkpoint')
    if not checkpoint:return auto.view(store,auto.selected(body)),auto.selected(body),None,None
    import knowledge_checkpoints as checkpoints
    checkpoints.setup(store)
    with store.db() as db:
        row=db.execute('SELECT data FROM kg_query_checkpoints WHERE id=?',(checkpoint,)).fetchone()
        if not row:raise ValueError('Saved view not found')
        snapshot=json.loads(row['data'])
        if not checkpoints.available(db,snapshot):raise ValueError('Captured projections unavailable; current records will not be substituted')
    return snapshot['graph'],list(snapshot['projections']),snapshot['projections'],snapshot
