"""Typed lake-local vectors. SQLite publishes active generation references last.

Supports:
- Representation-aware table namespacing (units_{representation_key})
- Configurable vector dimensions (384, 768, 1024, etc.)
- Strict shape validation without truncation or padding
- Atomic publication and orphan cleanup per representation
"""
import hashlib
import json
import math
import sys
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional


def quoted(value):
    return "'" + str(value).replace("'", "''") + "'"


def get_representation_key(
    encoder_name: str = "medembed",
    dimension: int = 1024,
    normalization: bool = True,
    token_limit: int = 512,
    lsh_key: str = "lsh8043-16x8",
) -> str:
    """Computes a stable alphanumeric key for namespacing vector tables."""
    payload = f"{encoder_name}:{dimension}:{normalization}:{token_limit}:{lsh_key}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


class Vectors:
    def __init__(
        self,
        store: Any,
        representation_key: Optional[str] = None,
        dimension: Optional[int] = None,
    ):
        # Optional workspace-only dependencies keep the model environment untouched.
        target = Path(__file__).resolve().parents[1] / ".idun/backend-deps"
        marker = target / "python-version.json"
        if marker.exists() and json.loads(marker.read_text()) == list(sys.version_info[:2]):
            if str(target) not in sys.path:
                sys.path.insert(0, str(target))
        try:
            import lancedb
            import pyarrow as pa
        except ImportError as error:
            raise ValueError("Install backend/requirements-api.txt in the selected API Python environment") from error

        self.store = store
        self.connection = lancedb.connect(str(store.root / "vectors.lance"))

        # Resolve representation key and dimension
        if representation_key is None and dimension is None:
            if not (store.root / "lake_config.json").exists():
                # Legacy unconfigured lake
                self.representation_key = "legacy"
                self.dimension = 1024
            else:
                cfg = {}
                try:
                    import lake_config
                    import model_registry
                    cfg = lake_config.read_lake_config(store)
                    bundle = model_registry.configured_bundle(cfg)
                    self.dimension = bundle["dimensions"]
                    self.representation_key = get_representation_key(
                        encoder_name=bundle.get("retrieval_encoder", "unknown") + ('@' + bundle['encoder_revision'] if bundle.get('encoder_revision') else ''),
                        dimension=self.dimension,
                    )
                except Exception:
                    if cfg.get('generic_encoder'):
                        raise
                    self.representation_key = "legacy"
                    self.dimension = 1024
        elif representation_key is None:
            self.dimension = dimension
            self.representation_key = f"dim_{dimension}"
        elif dimension is None:
            self.representation_key = representation_key
            self.dimension = 1024
        else:
            self.representation_key = representation_key
            self.dimension = dimension

        # Legacy backward-compatibility table name
        if self.representation_key in ("default", "legacy") and self.dimension == 1024:
            self.table_name = "units"
        else:
            self.table_name = f"units_{self.representation_key}"

        schema = pa.schema([
            pa.field("id", pa.string()),
            pa.field("unit_id", pa.string()),
            pa.field("generation", pa.string()),
            pa.field("asset_id", pa.string()),
            pa.field("kind", pa.string()),
            pa.field("vector", pa.list_(pa.float32(), self.dimension)),
        ])
        self.table = self.connection.create_table(self.table_name, schema=schema, exist_ok=True)

    def stage(self, asset_id: str, kind: str, units: List[Dict[str, Any]]) -> str:
        generation = uuid.uuid4().hex
        rows = []
        for i, unit in enumerate(units):
            vector = unit["vector"]
            if len(vector) != self.dimension or not all(math.isfinite(v) for v in vector):
                raise ValueError(
                    f"Expected a finite {self.dimension}-dimensional embedding, got {len(vector)}. "
                    "Dimension truncation or padding is prohibited."
                )
            rows.append({
                "id": f"{generation}:{i}",
                "unit_id": f"{asset_id}:{i}",
                "generation": generation,
                "asset_id": asset_id,
                "kind": kind,
                "vector": vector,
            })
        if rows:
            self.table.add(rows)
            # Refuse to publish SQLite references unless the whole source arrived.
            if self.table.count_rows("generation = " + quoted(generation)) != len(rows):
                raise ValueError("Incomplete vector generation")
        return generation

    def fetch(self, ids: List[str]) -> Dict[str, List[float]]:
        result = {}
        for start in range(0, len(ids), 256):
            batch = ids[start:start + 256]
            if not batch:
                continue
            result.update({
                r["id"]: r["vector"]
                for r in self.table.search()
                .where("id IN (" + ",".join(map(quoted, batch)) + ")")
                .limit(len(batch))
                .to_list()
            })
        if any(i not in result for i in ids):
            raise ValueError("An indexed vector is missing; rebuild the lake index")
        return result

    def search(self, vector: List[float], generations: List[str], limit: int = 128) -> List[Dict[str, Any]]:
        if not generations:
            return []
        if len(vector) != self.dimension:
            raise ValueError(
                f"Query vector dimension mismatch: expected {self.dimension}, got {len(vector)}"
            )
        condition = "kind = 'txt' AND generation IN (" + ",".join(map(quoted, generations)) + ")"
        return (
            self.table.search(vector)
            .distance_type("dot")
            .where(condition, prefilter=True)
            .nprobes(128)
            .limit(limit)
            .to_list()
        )

    def cleanup(self) -> None:
        with self.store.lock, self.store.db() as db:
            generations = [
                r[0]
                for r in db.execute(
                    "SELECT generation FROM retrieval_generations WHERE policy_key=? OR policy_key IS NULL",
                    (self.representation_key,),
                ).fetchall()
            ]
            # Discovery-only row vectors have published unit references but no
            # profiling generation. Preserve them until those units are removed.
            generations = set(generations)
            generations.update(
                json.loads(r[0])["vector_id"].rsplit(":", 1)[0]
                for r in db.execute("SELECT data FROM retrieval_units WHERE json_extract(data, '$.policy_key')=? AND json_extract(data, '$.vector_id') IS NOT NULL", (self.representation_key,))
            )
            condition = (
                "generation NOT IN (" + ",".join(map(quoted, generations)) + ")"
                if generations
                else "true"
            )
            if self.table.count_rows(condition):
                self.table.delete(condition)

    def maintain(self) -> None:
        with self.store.lock:
            self.cleanup()
            try:
                self.table = self.connection.open_table(self.table_name)
            except Exception:
                pass
            # Small lakes use exact native scans. Larger lakes get an unquantized ANN index.
            count = self.table.count_rows()
            if count >= 4096:
                for attempt in range(4):
                    try:
                        self.table = self.connection.open_table(self.table_name)
                        existing = self.table.list_indices()
                        for column, kind in [("id", "BTREE"), ("generation", "BITMAP")]:
                            if not any(column in i.columns for i in existing):
                                self.table.create_scalar_index(column, index_type=kind)
                                self.table = self.connection.open_table(self.table_name)
                        existing = self.table.list_indices()
                        if not any("vector" in i.columns for i in existing):
                            self.table.create_index(
                                metric="dot",
                                index_type="IVF_FLAT",
                                num_partitions=max(1, int(math.sqrt(count))),
                                vector_column_name="vector",
                            )
                        else:
                            self.table.optimize()
                        break
                    except Exception as e:
                        err_str = str(e).lower()
                        if any(kw in err_str for kw in ("retryable", "conflict", "preempted")):
                            import time
                            time.sleep(0.5 * (attempt + 1))
                            if attempt == 3:
                                break
                            continue
                        raise


def vectors(
    store: Any,
    representation_key: Optional[str] = None,
    dimension: Optional[int] = None,
) -> Vectors:
    """Returns a Vectors instance for the store, cached by (representation_key, dimension)."""
    with store.lock:
        if representation_key is None and dimension is None:
            from retrieval import get_encoder_policy
            policy = get_encoder_policy(store)
            representation_key, dimension = policy['policy_key'], policy['dimensions']
        if not hasattr(store, "_vectors_by_rep"):
            store._vectors_by_rep = {}

        # If already cached under explicit key
        cache_key = (representation_key, dimension)
        if cache_key in store._vectors_by_rep:
            v = store._vectors_by_rep[cache_key]
            store._vectors = v
            return v

        v = Vectors(store, representation_key=representation_key, dimension=dimension)
        # Store under both actual resolved attributes and requested key
        store._vectors_by_rep[cache_key] = v
        store._vectors_by_rep[(v.representation_key, v.dimension)] = v
        store._vectors = v
        return v
