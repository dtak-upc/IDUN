"""One typed predicate over projected cells, with reviewed attribute equivalence."""
import json
from collections import deque
from decimal import Decimal, InvalidOperation

NUMERIC = {'integer', 'int', 'float', 'double', 'real', 'decimal', 'number', 'numeric'}
BOOLEAN = {'boolean', 'bool'}
OPERATORS = {'eq', 'contains', 'gt', 'gte', 'lt', 'lte', 'present', 'missing'}


def numeric(value, datatype):
    if isinstance(value, bool) or value is None:
        return None
    try:
        number = Decimal(str(value).strip())
        if not number.is_finite() or (datatype in ('integer', 'int') and number != number.to_integral_value()):
            return None
        return number
    except (InvalidOperation, ValueError):
        return None


def boolean(value):
    if isinstance(value, bool):return value
    if isinstance(value, str) and value.strip().casefold() in ('true', 'false'):
        return value.strip().casefold() == 'true'
    return None


def condition(operator, value, datatype):
    datatype = datatype.casefold()
    if operator not in OPERATORS:raise ValueError('Choose a supported attribute condition')
    if not isinstance(value, str) or len(value) > 1000:raise ValueError('Attribute filter values must be at most 1,000 characters')
    if operator in ('present', 'missing'):
        return lambda raw: (raw is None or isinstance(raw, str) and not raw.strip()) == (operator == 'missing')
    if datatype in ('unknown', 'conflicting', ''):raise ValueError('This attribute has no unambiguous type; use present or missing')
    if not value.strip():raise ValueError('Enter an attribute filter value')
    if operator in ('gt', 'gte', 'lt', 'lte') and datatype not in NUMERIC:
        raise ValueError('Ordered comparisons require a declared numeric attribute')
    if datatype in NUMERIC:
        if operator == 'contains':raise ValueError('Numeric attributes do not support text contains')
        target = numeric(value, datatype)
        if target is None:raise ValueError('Enter a finite number compatible with the declared type')
        def compare(raw):
            actual = numeric(raw, datatype)
            if actual is None:return False
            return {'eq': actual == target, 'gt': actual > target, 'gte': actual >= target,
                    'lt': actual < target, 'lte': actual <= target}[operator]
        return compare
    if datatype in BOOLEAN:
        if operator != 'eq':raise ValueError('Boolean attributes support equality, present or missing')
        target = boolean(value)
        if target is None:raise ValueError('Enter true or false')
        return lambda raw: boolean(raw) is not None and boolean(raw) == target
    if operator == 'contains':return lambda raw: isinstance(raw, str) and value.casefold() in raw.casefold()
    return lambda raw: isinstance(raw, str) and raw == value


def prepare(graph, query):
    selected = query.get('attribute', [''])[0]
    if not selected:return None
    lookup = {a['id']: a for a in graph['attributes']}
    if selected not in lookup:raise ValueError('Selected attribute is outside the query scope; clear the attribute filter')
    values_mode = query.get('attribute_values', ['original'])[0]
    if values_mode not in ('original','reviewed'):raise ValueError('Choose original or reviewed attribute values')
    mode = query.get('attribute_mode', ['exact'])[0]
    if mode not in ('exact', 'aligned'):raise ValueError('Choose exact or aligned attribute matching')
    operator = query.get('attribute_op', ['eq'])[0]
    value = query.get('attribute_value', [''])[0]
    attribute = lookup[selected]
    predicate = condition(operator, value, attribute['datatype'])
    paths = {selected: []};adjacency = {}
    if mode == 'aligned':
        for mapping in sorted(graph.get('attribute_alignments', []), key=lambda a: a['id']):
            if mapping.get('stale') or mapping.get('status', 'accepted') != 'accepted':continue
            pair = mapping['attributes']
            if len(pair) != 2 or any(lookup.get(a['id']) != a for a in pair):continue
            if any(a['datatype'] != attribute['datatype'] for a in pair):continue
            for a, b in (pair, pair[::-1]):adjacency.setdefault(a['id'], []).append((b['id'], mapping))
        queue = deque([selected])
        names = {c['id']: c['label'] for c in graph['concepts']}
        while queue:
            current = queue.popleft()
            for candidate, mapping in adjacency.get(current, []):
                if candidate in paths:continue
                a, b = mapping['attributes']
                paths[candidate] = [*paths[current], {'id': mapping['id'],
                    'source_label': names[a['concept']] + ' · ' + a['name'],
                    'target_label': names[b['concept']] + ' · ' + b['name']}]
                queue.append(candidate)
    return {'selected': selected, 'mode': mode, 'operator': operator, 'value': value,
            'values_mode':values_mode, 'resolved': [dict(lookup[aid], via=path) for aid, path in paths.items()], 'predicate': predicate}


def sql_filter(prepared):
    # Membership and predicate evaluation occur before DISTINCT/pagination. Join
    # columns/cells by index: an unavailable projected column is not a null cell.
    return """ AND EXISTS (
        SELECT 1 FROM json_each(?) attr
        JOIN json_each(json_array(json_extract(data,'$.subject'),json_extract(data,'$.object'))) record
        ON json_extract(record.value,'$.concept_id')=json_extract(attr.value,'$.concept')
        JOIN json_each(json_extract(record.value,'$.columns')) col
        ON col.value=json_extract(attr.value,'$.name')
        JOIN json_each(json_extract(record.value,'$.cells')) cell ON cell.key=col.key
        WHERE kg_attribute_match(cell.value,cell.type)=1
    )""", json.dumps(prepared['resolved'])


def matches(assertion, prepared):
    result = []
    for side in ('subject', 'object'):
        record = assertion[side]
        for attribute in prepared['resolved']:
            if record['concept_id'] != attribute['concept']:continue
            for index, (name, value) in enumerate(zip(record['columns'], record['cells'])):
                if name == attribute['name'] and prepared['predicate'](value):
                    result.append({'side': side, 'column_index': index, 'id': attribute['id'], 'name': name,
                                   'concept_label': record['concept'], 'value': value, 'via': attribute['via']})
    return result


def describe(graph, prepared):
    names = {c['id']: c['label'] for c in graph['concepts']}
    return {k: v for k, v in prepared.items() if k not in ('predicate', 'resolved')} | {
        'revision': graph['revision'], 'resolved': [dict(a, concept_label=names[a['concept']]) for a in prepared['resolved']]}
