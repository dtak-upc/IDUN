"""Cancellable download child. Credentials arrive over stdin, never command arguments."""
import json
import sys

if __name__ == '__main__':
    try:
        import truststore
        truststore.inject_into_ssl()
    except ImportError:
        pass
    try:
        from huggingface_hub import snapshot_download
        request = json.load(sys.stdin)
        snapshot_download(repo_id=request['repo_id'], token=request.get('token'))
        result = {'ok': True}
    except Exception as error:
        result = {'error': str(error)}
    sys.stdout.write(json.dumps(result))
