"""Explicit property axioms; never rewrite Integration predicates or source records."""
import json
import knowledge as kg
import knowledge_mapping_history as history


def read(store):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_property_axioms(id TEXT PRIMARY KEY,data TEXT)')
        return [json.loads(r['data']) for r in db.execute('SELECT data FROM kg_property_axioms ORDER BY id')]


def signature(edge):
    return kg.digest([edge[k] for k in ('id','label','source','target','direction')])


def visible(saved,edges):
    lookup={e['id']:e for e in edges}
    return [dict(a,stale=any(signature(lookup[i])!=a['signatures'][i] for i in (a['source'],a['target'])))
            for a in saved if a['status']=='accepted' and a['source'] in lookup and a['target'] in lookup]


def validate(items):
    # Parity constraints: equivalent=0, inverse=1. Do not implicitly assert symmetry.
    adjacency={}
    for a in items:
        parity=int(a['kind']=='inverse')
        adjacency.setdefault(a['source'],[]).append((a['target'],parity))
        adjacency.setdefault(a['target'],[]).append((a['source'],parity))
    values={}
    def visit(n,value):
        if n in values:
            if values[n]!=value:raise ValueError('These mappings imply both equivalent and inverse roles; explicit symmetry is not supported')
            return
        values[n]=value
        for other,parity in adjacency[n]:visit(other,value^parity)
    for n in adjacency:
        if n not in values:visit(n,0)


def route(store,action,body):
    import knowledge_auto as auto
    with store.lock:
        graph=auto.view(store,auto.selected(body))
        if body.get('revision')!=graph['revision']:raise ValueError('Graph changed; refresh and preview again')
        if kg._jobs.get(str(store.root),{}).get('status')=='running':raise ValueError('Wait for the current graph task')
        saved=read(store)
        if action=='undo-property':
            item=next((a for a in graph['property_alignments'] if a['id']==body.get('id')),None)
            if not item:raise ValueError('Choose a visible property mapping')
            item=dict(item,status='undone');item.pop('stale',None)
            with store.db() as db:
                history.record(db,'property',item,graph,auto.selected(body))
                db.execute('UPDATE kg_property_axioms SET data=? WHERE id=?',(json.dumps(item),item['id']))
            return auto.view(store,auto.selected(body))
        edges={e['id']:e for e in graph['relationships']}
        source=body.get('source');target=body.get('target');kind=body.get('kind')
        if kind not in ('equivalent','inverse') or source not in edges or target not in edges or source==target:
            raise ValueError('Choose two different visible relationships and a mapping type')
        source,target=sorted([source,target]);a,b=edges[source],edges[target]
        if any(e['direction']!='directed' for e in (a,b)):
            raise ValueError('Set a single direction for both relationships before aligning their endpoint roles')
        item={'id':'property_'+kg.digest([source,target,kind]),'source':source,'target':target,'kind':kind,'status':'accepted',
              'signatures':{source:signature(a),target:signature(b)}}
        current=[x for x in saved if x['status']=='accepted']
        if any(x['id']==item['id'] for x in current):raise ValueError('Undo the existing mapping before reviewing it again')
        validate([*current,item])
        pairs=[(a['source'],b['target'] if kind=='inverse' else b['source']),
               (a['target'],b['source'] if kind=='inverse' else b['target'])]
        names={c['id']:c['label'] for c in graph['concepts']}
        preview={'mapping':item,'endpoints':[{'left':names[x],'right':names[y],'same':x==y} for x,y in pairs],
                 'counts':[a['count'],b['count']],'token':kg.digest([graph['revision'],saved,item])}
        if action=='preview-property':
            from knowledge_mapping_examples import examples
            preview['examples']=examples(store,graph,auto.selected(body),'property',item)
            return preview
        if action!='apply-property' or preview['token']!=body.get('token'):raise ValueError('Preview changed; review again')
        with store.db() as db:
            history.record(db,'property',item,graph,auto.selected(body))
            db.execute('INSERT OR REPLACE INTO kg_property_axioms VALUES(?,?)',(item['id'],json.dumps(item)))
        return auto.view(store,auto.selected(body))
