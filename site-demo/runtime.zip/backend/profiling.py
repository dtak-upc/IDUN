"""Incremental profiling with persistent lexical and semantic passage indices."""
import collections,hashlib,json,math,re,time,threading,uuid,os,subprocess
from pathlib import Path
from inference import prepare,identifier_mask
from retrieval import Index, encode, ENCODER_KEY, get_encoder_policy
VERSION = 'profile-v3.7-full-index'
STOP = set(
    'the a an and or of in on to for with is was were be has have had this that '
    'patient patients no not from by as at it are been he she his her its '
    'all any both each few more most other some such than too very can will just should now '
    'into only also then them their what which who whom'.split()
)
def terms(text, excluded_terms=None):
    ex = {'subject', 'hadm'}
    if excluded_terms:
        ex = ex | set(t.lower() for t in excluded_terms)
    return [t for t in re.findall(r'[^\W\d_][^\W\d_\-]{2,}', text.lower(), re.UNICODE) if t not in STOP and t not in ex]
def signature(store, policy=None):
    pol = policy or get_encoder_policy(store)
    import lake_config
    try:
        cfg = lake_config.read_lake_config(store) if hasattr(store, "root") else {}
        cand_pol = cfg.get("candidate_policy", {})
    except Exception:
        cand_pol = {}
    top_k = cand_pol.get("profiling_top_k", 0)
    with store.db() as db:
        rows = [tuple(r) for r in db.execute('SELECT asset_id,version,status FROM jobs ORDER BY asset_id')]
    return hashlib.sha256(json.dumps([VERSION, pol["policy_str"], top_k, rows]).encode()).hexdigest()
def setup(store, policy=None):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS lake_profile(id INTEGER PRIMARY KEY, signature TEXT, data TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS profile_cache(asset_id TEXT PRIMARY KEY,cache_key TEXT,data TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS profile_revision(id INTEGER PRIMARY KEY,value TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS profile_job(id INTEGER PRIMARY KEY,data TEXT)')
    Index(store, policy=policy).setup()
def upgrade_projection_metadata(store):
    # Upgrade only provenance whose old fingerprint verifies against today's inputs.
    with store.lock, store.db() as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='profile_cache'").fetchone():
            return
        missing = [r for r in db.execute('SELECT asset_id,cache_key,data FROM profile_cache') if 'encoder_policy' not in json.loads(r['data'])]
        if not missing:
            return
        mask = identifier_mask(db)
        policy = get_encoder_policy(store)
        for row in missing:
            source = json.loads(row['data'])
            key = hashlib.sha256((source['version'] + mask.policy_key + VERSION + policy['policy_str']).encode()).hexdigest()
            if key == row['cache_key']:
                source.update(encoder_policy=policy['policy_str'] + VERSION, inference_key=key)
                db.execute('UPDATE profile_cache SET data=? WHERE asset_id=?', (json.dumps(source), row['asset_id']))

def clear_removed(db,ids):
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='profile_cache'").fetchone():
  for aid in ids:
   db.execute('DELETE FROM profile_cache WHERE asset_id=?',(aid,))
   db.execute('DELETE FROM retrieval_fts WHERE asset_id=?',(aid,))
   db.execute('DELETE FROM retrieval_buckets WHERE unit_id IN (SELECT id FROM retrieval_units WHERE asset_id=?)',(aid,))
   db.execute('DELETE FROM retrieval_units WHERE asset_id=?',(aid,))
   if db.execute("SELECT 1 FROM sqlite_master WHERE name='retrieval_generations'").fetchone():db.execute('DELETE FROM retrieval_generations WHERE asset_id=?',(aid,))
def status(store):
 with store.lock:return _status(store)

def _status(store):
 setup(store)
 with store.db() as db:
  r=db.execute('SELECT signature FROM lake_profile WHERE id=1').fetchone()
  revision=db.execute('SELECT value FROM profile_revision WHERE id=1').fetchone()
  j=db.execute('SELECT data FROM profile_job WHERE id=1').fetchone()
 state=json.loads(j['data']) if j else None
 if state and state['status'] in ('queued','running','cancelling') and not getattr(store,'profile_active',False):
  state.update(status='interrupted',phase='Service restarted; run again to resume cached sources')
  with store.db() as db:db.execute('UPDATE profile_job SET data=? WHERE id=1',(json.dumps(state),))
 return {'status':'empty' if not r else 'ready' if r['signature']==signature(store) else 'stale','revision':revision['value'] if revision else None,'job':state}
def read(store):
 with store.lock:return _read(store)

def _read(store):
 setup(store)
 with store.db() as db:
  r=db.execute('SELECT signature,data FROM lake_profile WHERE id=1').fetchone()
  job=db.execute('SELECT data FROM profile_job WHERE id=1').fetchone()
 state=json.loads(job['data']) if job else None
 if state and state['status'] in ('queued','running','cancelling') and not getattr(store,'profile_active',False):
  state.update(status='interrupted',phase='Service restarted; run again to resume cached sources')
  with store.db() as db:db.execute('UPDATE profile_job SET data=? WHERE id=1',(json.dumps(state),))
 result={'status':'empty'}
 if r:
  report=json.loads(r['data'])
  report['candidates'].sort(key=lambda c:(-c['score'],c['table'],c['text']))
  result={'status':'stale'} if r['signature']!=signature(store) or report.get('version')!=VERSION else {'status':'ready',**report}
 if state:result['job']=state
 return result
def profile_source(store,j,mask,check):
 total_chars=0;total_records=0;samples=[]
 aid=j['asset_id'];source={'name':j['name'],'asset_id':aid,'version':j['version'],'columns':[],'units':[],'records':0,'status':'profiled','issues':[]};bag=collections.Counter()
 try:
  batch_size = 200
  page = prepare(store, aid, _mask=mask, limit=batch_size); payload = page['payload']; csv = 'rows' in payload; source['kind'] = 'csv' if csv else 'txt'
  source['excluded_columns'] = page['excluded_columns']; stats = [{'name': h, 'nonempty': 0, 'numeric': 0, 'values': set()} for h in payload.get('columns', [])]; text_parts = []
  for offset in range(0, page['total'], batch_size):
   check()
   if offset: page = prepare(store, aid, offset, _mask=mask, limit=batch_size)
   payload = page['payload']; values = payload['rows'] if csv else payload['chunks']; total_records += len(values)
   if total_records>1000000:raise OverflowError('Profiling limit: 1,000,000 stored records per source')
   for value in values:
    total_chars+=sum(map(len,value)) if csv else len(value)
    if total_chars>64*1024*1024:raise OverflowError('Profiling limit: 64 MiB of projected characters')
    if csv:
     source['records']+=1
     samples.append({'text':'; '.join(value)[:1500],'record_index':source['records']+1,'character_clipped':len('; '.join(value))>1500})
     for s,v in zip(stats,value):
      if v.strip():s['nonempty']+=1
      try:float(v);s['numeric']+=bool(v.strip())
      except ValueError:pass
      if len(s['values'])<1000:s['values'].add(v)
      bag.update(terms(v))
    else:text_parts.append(value)
  if csv:
   for s in stats:
    source['columns'].append({'name':s['name'],'nonempty':s['nonempty'],'missing':source['records']-s['nonempty'],'type':'numeric' if s['nonempty'] and s['numeric']==s['nonempty'] else 'text','distinct_lower_bound':len(s['values']),'distinct_capped':len(s['values'])>=1000})
   source['header_policy']='Provisional first-record header'
  else:
   text=''.join(text_parts)
   # Preserve wrapped lines inside paragraphs; only sentence punctuation or blank lines ends a unit.
   # Offsets always refer to original text, never a whitespace-normalized copy.
   for paragraph in re.finditer(r'\S.*?(?=(?:\r?\n)[ \t]*(?:\r?\n)|\s*\Z)',text,re.S):
    for m in re.finditer(r'.+?(?:[.!?](?=\s+[A-Z•]|$)|$)',paragraph.group(),re.S):
     start=paragraph.start()+m.start();end=paragraph.start()+m.end()
     while start<end and text[start].isspace():start+=1
     while end>start and text[end-1].isspace():end-=1
     if start==end:continue
     for pos in range(start,end,1000):
      unit=text[pos:min(pos+1000,end)];bag.update(terms(unit));source['records']+=1
      samples.append({'text':unit,'start':pos,'end':min(pos+1000,end)})
      source['units'].append({'start':pos,'end':min(pos+1000,end),'preview':unit[:180],'clipped':len(unit)>180,'bounded_split':end-start>1000})
   source['unit_policy']='Paragraph-aware provisional sentences; wrapped lines and decimal doses preserved; 1,000-character maximum'
  source['terms']=[{'term':t,'count':n} for t,n in bag.most_common(12)]
  if not bag:source['issues'].append('No lexical retrieval terms after projection')
 except (ValueError,KeyError) as e:
  samples.clear();source.update(status='unresolved',issues=[str(e)],columns=[],units=[],terms=[]);bag.clear()
 # Index every eligible unit; previews remain bounded separately.
 eligible=[x for x in samples if terms(x['text'])]
 selected=sorted(eligible,key=lambda x:x.get('record_index',x.get('start',0)))
 source['coverage']={'available_units':len(samples),'indexed_units':len(selected),'sampled':False,'eligible_units':len(eligible),'skipped_nonlexical_units':len(samples)-len(eligible),'character_clipped_units':sum(u.get('character_clipped',False) for u in selected)}
 source['units']=source['units'][:128]
 source['terms']=[{'term':t,'count':n} for t,n in bag.most_common(12)]
 return source,selected
class ProfileCancelled(Exception):pass

def run(store, encoder=encode, progress=lambda **kw:None, check=lambda:None, policy=None):
    import inspect
    from retrieval import get_encoder_policy
    policy = policy or get_encoder_policy(store)
    setup(store, policy=policy)
    check()
    before = signature(store, policy=policy)
    started = time.perf_counter()
    old = read(store)
    if old['status'] == 'ready':
        old.pop('job', None)
        progress(phase='Reusing unchanged index', completed=len(old['sources']), total=len(old['sources']), reused=len(old['sources']))
        old['work'] = {**old.get('work', {}), 'reused_sources': len(old['sources']), 'updated_sources': 0, 'encoded_units': 0, 'scored_passages': 0, 'expanded_queries': 0}
        with store.db() as db:
            db.execute('UPDATE lake_profile SET data=? WHERE id=1', (json.dumps(old),))
            db.execute('INSERT OR REPLACE INTO profile_revision VALUES(1,?)', (uuid.uuid4().hex,))
        from storage_compaction import reclaim_after_publication
        reclaim_after_publication(store, policy)
        return old
    with store.db() as db:
        jobs = [dict(r) for r in db.execute("SELECT j.asset_id,j.version,a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE status='ready' ORDER BY asset_id")]
        mask_signature = tuple(tuple(r) for r in db.execute("SELECT j.asset_id,j.version FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.status='ready' AND lower(a.name) LIKE '%.csv' ORDER BY j.asset_id"))
        prior = getattr(store, 'profile_identifier_mask', None)
        mask = prior[1] if prior and prior[0] == mask_signature else identifier_mask(db)
        store.profile_identifier_mask = (mask_signature, mask)
    if not jobs:
        raise ValueError('Save raw CSV/TXT files before profiling')
    sources = []
    changed = []
    reused = 0
    index = Index(store, policy=policy)
    for number, j in enumerate(jobs):
        check()
        progress(phase='Profiling changed sources', completed=number, total=len(jobs), reused=reused)
        key = hashlib.sha256((j['version'] + mask.policy_key + VERSION + policy['policy_str']).encode()).hexdigest()
        with store.db() as db:
            cached = db.execute('SELECT data FROM profile_cache WHERE asset_id=? AND cache_key=?', (j['asset_id'], key)).fetchone()
        if cached:
            source = json.loads(cached['data'])
            source['name'] = j['name']
            reused += 1
        else:
            source, samples = profile_source(store, j, mask, check)
            with store.db() as db:
                previous = db.execute('SELECT cache_key,data FROM profile_cache WHERE asset_id=?', (j['asset_id'],)).fetchone()
                metadata = [(r['id'], json.loads(r['data'])) for r in index.profile_units(db, j['asset_id'])]
            previous_source = json.loads(previous['data']) if previous else {}
            fields = ('text', 'start', 'end', 'record_index', 'character_clipped')
            projection = lambda units: [[u.get(k) for k in fields] for u in units]
            source['encoder_policy'] = policy['policy_str'] + VERSION
            if previous_source.get('encoder_policy') == source['encoder_policy'] and previous_source.get('version') == j['version'] and projection(samples) == projection([u for _, u in metadata]):
                source['inference_key'] = previous_source.get('inference_key', previous['cache_key'])
                reused += 1
                with store.db() as db:
                    db.execute('UPDATE profile_cache SET cache_key=?,data=? WHERE asset_id=?', (key, json.dumps(source), j['asset_id']))
            else:
                source['inference_key'] = key
                changed.append((source, key, samples))
        sources.append(source)
    encoded_count = 0
    truncated_count = 0
    peak_gpu = 0
    device = None
    # Commit completed batches, so cancellation/restart can reuse completed sources.
    batches = []
    batch = []
    size = 0
    for item in changed:
        if batch and size + len(item[2]) > 4096:
            batches.append(batch)
            batch = []
            size = 0
        batch.append(item)
        size += len(item[2])
    if batch:
        batches.append(batch)
    for batch_number, batch in enumerate(batches):
        texts = [u['text'] for _, _, units in batch for u in units]
        progress(phase=f'Embedding changed units locally: batch {batch_number+1}/{len(batches)}', completed=encoded_count, total=sum(len(x[2]) for x in changed), reused=reused, encoding_units=len(texts))
        store.profile_embedding_progress = lambda done: progress(completed=encoded_count + done)
        enc_params = inspect.signature(encoder).parameters
        encoded = {'items': [], 'truncated': 0}
        for offset in range(0, len(texts), 4096):
            check()
            chunk = texts[offset:offset+4096]
            part = encoder(store, chunk, check, policy=policy) if 'policy' in enc_params else encoder(store, chunk, check)
            if len(part['items']) != len(chunk):
                raise ValueError('Incomplete encoder response')
            encoded['items'].extend(part['items'])
            encoded['truncated'] += part.get('truncated', 0)
            encoded['device'] = part.get('device')
            encoded['peak_reserved_gib'] = max(encoded.get('peak_reserved_gib') or 0, part.get('peak_reserved_gib') or 0)
        check()
        cursor = 0
        peak_gpu = max(peak_gpu, encoded.get('peak_reserved_gib') or 0)
        device = encoded.get('device', device)
        with store.lock:
            if signature(store, policy=policy) != before:
                raise ValueError('Lake changed during indexing; run again')
            with store.db() as db:
                for source, key, units in batch:
                    for unit in units:
                        unit.update(encoded['items'][cursor])
                        cursor += 1
                    index.replace(db, source, units)
                    db.execute('INSERT OR REPLACE INTO profile_cache VALUES(?,?,?)', (source['asset_id'], key, json.dumps(source)))
                    # Release vectors after SQLite publication; subsequent retrieval is index-backed.
                    units.clear()
        encoded_count += cursor
    from vector_store import vectors
    vectors(store, representation_key=policy['policy_key'], dimension=policy['dimensions']).maintain()
    with store.lock:
        if signature(store, policy=policy) != before:
            raise ValueError('Lake changed during indexing; run again')
        with store.db() as db:
            valid = {s['asset_id'] for s in sources}
            for r in db.execute('SELECT asset_id FROM profile_cache').fetchall():
                if r['asset_id'] not in valid:
                    clear_removed(db, [r['asset_id']])
    candidates = []
    scored = 0
    expanded = 0
    tables = [s for s in sources if s.get('kind') == 'csv' and s['status'] == 'profiled']
    documents = [s for s in sources if s.get('kind') == 'txt' and s['status'] == 'profiled']

    # Dynamic vs Configured Top-K
    import lake_config
    try:
        lake_cfg = lake_config.read_lake_config(store) if hasattr(store, "root") else {}
        cand_pol = lake_cfg.get("candidate_policy", {})
    except Exception:
        cand_pol = {}
    user_k = cand_pol.get("profiling_top_k")
    num_docs = len(documents)
    if user_k and isinstance(user_k, int) and user_k > 0:
        effective_k = min(num_docs, user_k) if num_docs > 0 else user_k
        k_mode = "user"
    else:
        # Dynamic K: scales sublinearly with document count (between 5 and 25)
        effective_k = min(num_docs, max(5, min(25, int(math.ceil(math.sqrt(num_docs) * 1.8))))) if num_docs > 0 else 5
        k_mode = "dynamic"

    for i, table in enumerate(tables):
        check()
        progress(phase='Searching passage indices', completed=i, total=len(tables), reused=reused)
        neighbors, work = index.search(table, check, top_k=effective_k)
        candidates.extend(neighbors)
        scored += work['scored_passages']
        expanded += work['expanded_queries']
        table['anchor'] = {
            'columns': [c['name'] for c in table['columns'] if c['type'] == 'text'],
            'terms': [t['term'] for t in table['terms'][:5]],
            'candidate_count': len(neighbors),
        }
    linked = {c[k] for c in candidates for k in ('table', 'text')}
    for source in sources:
        if source['asset_id'] not in linked:
            source['issues'].append('No candidate in retained indexed neighborhoods; coverage is approximate')
    counts = collections.Counter(t['term'] for s in sources for t in s['terms'])
    report = {
        'version': VERSION,
        'created': time.time(),
        'seconds': time.perf_counter() - started,
        'sources': sources,
        'candidates': sorted(candidates, key=lambda c: (-c['score'], c['table'], c['text'])),
        'concepts': [{'term': t, 'sources': n} for t, n in counts.most_common(30) if n > 1],
        'summary': {
            'sources': len(sources),
            'tables': len(tables),
            'texts': len(documents),
            'candidates': len(candidates),
            'unresolved': sum(bool(s['issues']) for s in sources),
            'top_k': effective_k,
            'top_k_mode': k_mode,
        },
        'work': {
            'reused_sources': reused,
            'updated_sources': len(changed),
            'encoded_units': encoded_count,
            'scored_passages': scored,
            'expanded_queries': expanded,
            'sampled_sources': sum(s['coverage']['sampled'] for s in sources),
            'token_truncated_units': truncated_count,
            'embedding_device': device,
            'peak_reserved_gib': peak_gpu,
        },
        'method': f'Indexed hybrid retrieval: lexical FTS5 + LanceDB vector search. Up to {effective_k} candidates per table ({k_mode} K); approximate coverage, not verified associations.',
    }
    with store.lock:
        check()
        if signature(store, policy=policy) != before:
            raise ValueError('Lake changed during retrieval; run again')
        with store.db() as db:
            db.execute('INSERT OR REPLACE INTO lake_profile VALUES(1,?,?)', (before, json.dumps(report)))
            db.execute('INSERT OR REPLACE INTO profile_revision VALUES(1,?)', (uuid.uuid4().hex,))
        from storage_compaction import reclaim_after_publication
        reclaim_after_publication(store, policy)
    return {'status': 'ready', **report}

def start(store):
 setup(store)
 with store.lock:
  if getattr(store,'integration_active',False):raise ValueError('Wait for integration to finish or cancel it first')
  if getattr(store,'discovery_active',False):raise ValueError('Wait for LOKI discovery to finish before indexing')
  if getattr(store,'profile_active',False):return status(store)
  store.profile_active=True;store.profile_cancel=threading.Event()
  state={'status':'queued','phase':'Preparing index','completed':0,'total':0}
  with store.db() as db:db.execute('INSERT OR REPLACE INTO profile_job VALUES(1,?)',(json.dumps(state),))
 def update(**kw):
  with store.lock:
   state.update(kw)
   with store.db() as db:db.execute('INSERT OR REPLACE INTO profile_job VALUES(1,?)',(json.dumps(state),))
 def check():
  if store.profile_cancel.is_set():raise ProfileCancelled('Profiling cancelled')
 def work():
  try:
   update(status='running');run(store,encoder=encode,progress=update,check=check);update(status='complete',phase='Index ready',completed=state.get('total',0))
  except ProfileCancelled:update(status='cancelled',phase='Cancelled; previously completed source caches retained')
  except Exception as e:update(status='failed',phase=str(e))
  finally:
   with store.lock:store.profile_active=False
 store.profile_future=store.pool.submit(work)
 return status(store)
def cancel(store):
 with store.lock:
  if getattr(store,'profile_active',False):
   store.profile_cancel.set()
   queued=getattr(store,'profile_future',None)
   cancelled=bool(queued and queued.cancel())
   if cancelled:store.profile_active=False
   with store.db() as db:
    row=db.execute('SELECT data FROM profile_job WHERE id=1').fetchone()
    state=json.loads(row['data']);state.update(status='cancelled' if cancelled else 'cancelling',phase='Cancelled before indexing' if cancelled else 'Cancelling indexing')
    db.execute('UPDATE profile_job SET data=? WHERE id=1',(json.dumps(state),))
 return status(store)
