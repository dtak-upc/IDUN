"""Text embedding policy, shared by preparation and offline workers (no ML imports)."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL = 'google/embeddinggemma-2'
REVISION = 'main'
BOOTSTRAP_COMMIT = '914f7f89142e33e77833254d9c9b90c3cef7303b'
PROMPT = 'task: sentence similarity | query: '


def options(model):
    if model == MODEL:
        return {'config_kwargs': {'vision_config': None, 'audio_config': None}, 'prompt': PROMPT}
    return {}


def key(model, revision):
    identity = f'{model}@{revision}'
    if options(model):
        identity += ':' + json.dumps(options(model), sort_keys=True)
    return hashlib.sha256(identity.encode()).hexdigest()


def default_spec():
    pointer = ROOT / 'models/custom-encoders/embeddinggemma2-default.json'
    if pointer.exists():
        value = json.loads(pointer.read_text(encoding='utf-8'))
        if value.get('model') != MODEL or not isinstance(value.get('revision'), str) or len(value['revision']) != 40:
            raise ValueError('Invalid default encoder receipt. Prepare EmbeddingGemma-2 again.')
        return value
    # Existing installation remains usable until main is explicitly prepared.
    return dict(model=MODEL, revision=BOOTSTRAP_COMMIT, dimensions=768, token_limit=262144, requested_revision='main')


def default_directory():
    return ROOT / 'models/custom-encoders' / key(MODEL, default_spec()['revision'])


def output_dimensions(model, native, selected=None):
    if selected is None:
        return native
    if isinstance(selected, bool) or not isinstance(selected, int):
        raise ValueError('Embedding dimensions must be an integer')
    if model == MODEL:
        if selected not in (128, 256, 512, 768):
            raise ValueError('Choose 128, 256, 512 or 768 dimensions for EmbeddingGemma-2')
    elif selected != native:
        raise ValueError('This encoder requires its native embedding dimensions')
    return selected


def runtime_python():
    return ROOT / '.idun/runtimes/embeddinggemma2' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def worker_python(model, selected):
    if model != MODEL:
        return selected
    python = runtime_python()
    if not python.exists():
        raise ValueError('Prepare EmbeddingGemma-2 in Settings first; its separate text-embedding runtime is missing.')
    return str(python)


def load_kwargs(model):
    # FP16 is unsupported. Load on CPU in FP32 before moving to a supported GPU dtype.
    if model == MODEL:
        return {'config_kwargs': options(model)['config_kwargs'], 'model_kwargs': {'dtype': 'float32'}}
    return {}


def encode_kwargs(model):
    return {'prompt': PROMPT} if model == MODEL else {}
