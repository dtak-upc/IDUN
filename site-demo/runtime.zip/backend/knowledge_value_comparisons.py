"""Typed comparisons between explicit visual-query record bindings."""
import time
import knowledge_attribute_query as attributes
import knowledge_path_patterns as patterns

def family(datatype):
    datatype=datatype.casefold()
    if datatype in attributes.NUMERIC:return 'number'
    if datatype in attributes.BOOLEAN:return 'boolean'
    if datatype in ('string','text','varchar','char'):return 'text'
    raise ValueError('Comparisons require unambiguous numeric, text or boolean attributes')

def prepare(graph,body):
    raw=body.get('comparisons',[])
    if not isinstance(raw,list) or len(raw)>64:raise ValueError('Choose at most 64 attribute comparisons')
    lookup={a['id']:a for a in graph['attributes']};result=[]
    for item in raw:
        if not isinstance(item,dict) or item.get('operator') not in ('eq','ne','gt','gte','lt','lte'):raise ValueError('Choose a supported comparison operator')
        pair=[]
        for side in ('left','right'):
            operand=item.get(side)
            if not isinstance(operand,dict):raise ValueError('Choose both comparison operands')
            binding=operand.get('binding')
            if type(binding) is not int or not -1<=binding<len(body['pattern']):raise ValueError('Comparison record must be the start or a selected query step')
            concept=body['concept'] if binding==-1 else body['pattern'][binding]['target']
            if not isinstance(operand.get('attribute'),str):raise ValueError('Choose a comparison attribute')
            attribute=lookup.get(operand['attribute'])
            if not attribute or attribute['concept']!=concept:raise ValueError('Comparison attribute must belong to its selected record role')
            prepared=patterns.prepare_condition(graph,dict(operand,operator='present',value=''))
            pair.append(dict(operand,binding=binding,prepared=prepared,family=family(attribute['datatype']),datatype=attribute['datatype'],label=('Start' if binding==-1 else f'Step {binding+1}')+' · '+next(c['label'] for c in graph['concepts'] if c['id']==concept)+' · '+attribute['name']))
        if pair[0]['family']!=pair[1]['family']:raise ValueError('Comparison attributes must have compatible declared types')
        if item['operator'] not in ('eq','ne') and pair[0]['family']!='number':raise ValueError('Ordering comparisons require numeric attributes')
        result.append({'left':pair[0],'right':pair[1],'operator':item['operator']})
    return result

def describe(items):
    return [{'left':c['left']['label'],'right':c['right']['label'],'operator':c['operator']} for c in items]

def normalized(match,operand):
    value=match['value']
    if match.get('claim'):
        try:claim_family=family(match.get('datatype') or '')
        except ValueError:return None
        if claim_family!=operand['family']:return None
    if operand['family']=='number':
        if match.get('unit'):return None
        return attributes.numeric(value,operand['datatype'].casefold())
    if operand['family']=='boolean':return attributes.boolean(value)
    return value if isinstance(value,str) and value.strip() else None

def evaluate(items,stage,load,budget,event,deadline):
    witnesses=[];work=0
    for index,c in enumerate(items):
        if max(c['left']['binding'],c['right']['binding'])!=stage:continue
        def observations(operand):
            record=load(operand);matches=patterns.condition_matches(record,operand['prepared'])
            claims={(a['layer'],a['id']):a for a in record.get('augmentation_claims',[])}
            return [dict(m,datatype=claims.get((m.get('layer'),m.get('claim')),{}).get('datatype')) if m.get('claim') else m for m in matches]
        left=observations(c['left']);right=observations(c['right'])
        if not left or not right:return False,[],work,None
        found=None
        identical=c['left']['binding']==c['right']['binding'] and c['left']['prepared']['selected']==c['right']['prepared']['selected'] and c['left']['prepared']['mode']==c['right']['prepared']['mode'] and c['left']['prepared']['values_mode']==c['right']['prepared']['values_mode']
        for a in left:
            for b in right:
                if event.is_set():return False,[],work,'cancelled'
                if time.monotonic()>=deadline:return False,[],work,'time_limit'
                if work>=budget:return False,[],work,'work_budget'
                work+=1
                if identical and (a['id'],a['column_index'],a.get('origin'),a.get('layer'),a.get('claim'))!=(b['id'],b['column_index'],b.get('origin'),b.get('layer'),b.get('claim')):continue
                av,bv=normalized(a,c['left']),normalized(b,c['right'])
                if av is None or bv is None:continue
                if {'eq':av==bv,'ne':av!=bv,'gt':av>bv,'gte':av>=bv,'lt':av<bv,'lte':av<=bv}[c['operator']]:found=(a,b);break
            if found:break
        if not found:return False,[],work,None
        witnesses.append({'index':index,'operator':c['operator'],'left':dict(found[0],side='subject',record=load(c['left'])['label'],role=c['left']['label']),'right':dict(found[1],side='object',record=load(c['right'])['label'],role=c['right']['label'])})
    return True,witnesses,work,None
