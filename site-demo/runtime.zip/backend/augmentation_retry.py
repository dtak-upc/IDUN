"""Explicit, bounded second pass for unresolved cells in an existing run."""
import json
import threading
import time

_lock = threading.Lock()


def eligible(db, run_id):
    grouped = {}
    for row in db.execute('SELECT id,data FROM augmentation_proposals WHERE run_id=?', (run_id,)):
        p = json.loads(row['data'])
        grouped.setdefault(p['target_id'], []).append((row['id'], row['data'], p))
    return {key: rows for key, rows in grouped.items()
            if all(p['decision'] == 'unresolved' and p.get('proposed_value') is None for _, _, p in rows)}


def execute(store, run_id, options):
    if not _lock.acquire(blocking=False):
        raise ValueError('A document second pass is already running. Please wait.')
    try:
        return _execute(store, run_id, options)
    finally:
        _lock.release()


def _execute(store, run_id, options):
    import augmentation as aug
    import augmentation_selection
    import thor
    import thor_adapter
    import typed_extraction
    from augmentation_document_pass import expand
    run = aug.get_augmentation_run(store, run_id)
    selection = augmentation_selection.validate({**(run['config'].get('selection') or {}),
        'nearby_radius': options.get('nearby_radius', 1500), 'nearby_limit': options.get('nearby_limit', 2)})
    with store.db() as db:
        pending = eligible(db, run_id)
    if not pending:
        raise ValueError('This run has no unresolved None values to retry')
    engine = run['config'].get('engine', 'thor')
    prompt = dict(run['config'].get('typed_extraction') or {})
    calls = [0]
    prompt['_on_llm_call'] = lambda: calls.__setitem__(0, calls[0] + 1)
    if engine != 'thor':
        active, provider = typed_extraction.is_llm_active(store)
        if not active: raise ValueError('Configure an LLM provider and model in Settings')
        prompt['_llm_config'] = provider
    prep = thor.prepare(store, scope=run['scope'], run_id=run['base_run_id'], table_id=selection['table_id'])
    runtime = thor_adapter.Extractor(thor.config(store)['config'])
    # Old proposals predate the target snapshot; only reuse their saved evidence.
    legacy = None
    retried = unavailable = 0
    errors = []
    for target_id, previous in list(pending.items())[:100]:
        p = previous[0][2]
        target = p.get('retry_target')
        if not target:
            if legacy is None:
                targets = (augmentation_selection.source_targets(store, selection) if run['scope'] == 'source'
                           else aug.compile_targets(store, run['base_run_id'], selection=selection))
                legacy = {t['id']: t for t in targets}
            target = legacy.get(target_id)
            anchors = [old['evidence'] for _, _, old in previous if old.get('evidence')]
            if target and anchors: target = {**target, 'evidence_contexts': anchors}
            else: target = None
        if not target:
            unavailable += 1
            errors.append('A saved target or its original evidence is unavailable; run a new selected batch.')
            continue
        concept = next((c for c in prep['concepts'] if c['source'] == target['asset_id']
                        and c['version'] == target['version'] and c['name'] == target['column_name']), None)
        try:
            contexts, report = expand(store, target, concept, runtime, selection)
            if contexts:
                proposals = aug.extract_proposals_for_target({**target, 'evidence_contexts': contexts}, concept,
                    engine, runtime if engine == 'thor' else None, run_id, time.time(), prompt_snapshot=prompt, store=store)
                retried += 1
            else:
                proposals = [dict(old) for _, _, old in previous]
                unavailable += 1
            for proposal in proposals:
                proposal['second_pass'] = {**report, 'first_pass': [
                    {'decision':old['decision'], 'evidence_id':(old.get('evidence') or {}).get('evidence_id')}
                    for _, _, old in previous]}
                if proposal['decision'] == 'unresolved': proposal['retry_target'] = target
            with store.db() as db:
                db.execute('BEGIN IMMEDIATE')
                current = list(db.execute('SELECT id,data FROM augmentation_proposals WHERE run_id=? AND target_id=?', (run_id,target_id)))
                if {(r['id'],r['data']) for r in current} != {(i,data) for i,data,_ in previous}:
                    errors.append('A cell changed during extraction; its review decisions were preserved.')
                    continue
                if not db.execute('SELECT 1 FROM augmentation_runs WHERE id=?',(run_id,)).fetchone():
                    raise ValueError('The run was removed during extraction')
                db.execute('DELETE FROM augmentation_proposals WHERE run_id=? AND target_id=?',(run_id,target_id))
                db.executemany('INSERT INTO augmentation_proposals VALUES(?,?,?,?,?)',
                    [(v['id'],run_id,target_id,json.dumps(v),v['decision']) for v in proposals])
                aug.recalculate_counts(db,run_id)
        except Exception as error:
            errors.append(str(error)); break
    telemetry = typed_extraction.calculate_telemetry(store, run_id)
    with store.db() as db:
        row = db.execute('SELECT config,counts FROM augmentation_runs WHERE id=?',(run_id,)).fetchone()
        if not row: raise ValueError('Augmentation run no longer exists')
        config, counts = json.loads(row['config']),json.loads(row['counts'])
        config['document_retry'] = dict(retried=retried, unavailable=unavailable, errors=errors,
            radius=selection['nearby_radius'], passages=selection['nearby_limit'], timestamp=time.time())
        config['document_retry']['engine'] = engine
        if engine != 'thor':
            config['document_retry']['provider'] = {k:provider.get(k) for k in ('provider','model','base_url')}
        counts['llm_calls'] = counts.get('llm_calls',0)+calls[0]
        saved = [json.loads(r['data']) for r in db.execute('SELECT data FROM augmentation_proposals WHERE run_id=?',(run_id,))]
        counts['second_pass_targets'] = len({p['target_id'] for p in saved if p.get('second_pass',{}).get('status') == 'expanded'})
        counts['second_pass_unavailable'] = unavailable
        counts['telemetry'] = telemetry
        db.execute('UPDATE augmentation_runs SET config=?,counts=?,updated=? WHERE id=?',
                   (json.dumps(config),json.dumps(counts),time.time(),run_id))
    return aug.get_augmentation_run(store,run_id)
