"""Immutable, lake-local candidate scopes. No embedding or model work in preview."""
import json
import profile_graph as graph


def setup(db):
    db.executescript('''CREATE TABLE IF NOT EXISTS discovery_scopes(id TEXT PRIMARY KEY,generation TEXT,data TEXT);
    CREATE TABLE IF NOT EXISTS discovery_scope_pairs(scope_id TEXT,table_id TEXT,document_id TEXT,
    PRIMARY KEY(scope_id,table_id,document_id));''')


def preview(store, body):
    with store.lock:
        result=graph.query(store,{'generation':body.get('generation'),'recipe':body.get('recipe',{'mode':'all'}),'limit':1})
        with store.db() as db:
            sql,args=graph.resolve(db,result['recipe'])
            # Count existing indexed units only; no source projection/vector preparation here.
            has_units=db.execute("SELECT 1 FROM sqlite_master WHERE name='retrieval_units'").fetchone()
            work=None
            if has_units:
                work=db.execute(sql+''', unit_counts AS (SELECT asset_id,kind,count(*) n FROM retrieval_units GROUP BY asset_id,kind)
                    SELECT coalesce(sum(t.n*d.n),0) FROM selected s
                    JOIN unit_counts t ON t.asset_id=s.table_id AND t.kind='csv'
                    JOIN unit_counts d ON d.asset_id=s.document_id AND d.kind='txt' ''',args).fetchone()[0]
        return {'generation':result['graph']['generation'],'recipe':result['recipe'],'counts':result['counts'],
                'total_pairs':result['graph']['edges'],'indexed_pair_scores':work,
                'notice':'Indexed row × text-unit workload estimate; runtime contexts may overlap or prepare additional eligible rows. No inference has run.'}


def commit(store,body):
    with store.lock:
        summary=preview(store,body)
        if not summary['counts']['pairs']:raise ValueError('The selection is empty; select at least one candidate pair')
        sid=graph.digest([summary['generation'],summary['recipe']])
        with store.db() as db:
            setup(db)
            sql,args=graph.resolve(db,summary['recipe'])
            db.execute('INSERT OR IGNORE INTO discovery_scopes VALUES(?,?,?)',(sid,summary['generation'],json.dumps({'id':sid,**summary})))
            db.execute(sql+'INSERT OR IGNORE INTO discovery_scope_pairs SELECT ?,table_id,document_id FROM selected',args+[sid])
        return {'id':sid,**summary}


def read(store,sid):
    if not isinstance(sid,str) or not sid:raise ValueError('Invalid Discovery scope')
    with store.lock:
        meta=graph.ensure(store)
        with store.db() as db:
            setup(db)
            row=db.execute('SELECT data,generation FROM discovery_scopes WHERE id=?',(sid,)).fetchone()
        if not row:raise ValueError('Scope not found in this lake; review and commit a selection')
        if row['generation']!=meta['generation']:raise ValueError('Scope is stale; review the current graph and commit again')
        return json.loads(row['data'])


def restrict(store,profile,sid):
    if sid is None:return profile
    read(store,sid)
    with store.db() as db:
        members={(r['table_id'],r['document_id']) for r in db.execute('SELECT table_id,document_id FROM discovery_scope_pairs WHERE scope_id=?',(sid,))}
    candidates=[c for c in profile['candidates'] if (c['table'],c['text']) in members]
    if not candidates:raise ValueError('The scope has no candidate pairs')
    used={v for c in candidates for v in (c['table'],c['text'])}
    return {**profile,'candidates':candidates,'sources':[s for s in profile['sources'] if s['asset_id'] in used]}


def inspect_handoff(store, body):
    """Inspect actual draft or committed pair membership; never starts inference."""
    offset, limit = body.get('offset', 0), body.get('limit', 12)
    if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 50:
        raise ValueError('Use a nonnegative offset and page size 1–50')
    group = body.get('group', 'included')
    if group not in ('all', 'included', 'outside'):
        raise ValueError('Choose all profiled pairs, included or outside scope')
    with store.lock:
        sid = body.get('id')
        summary = read(store, sid) if sid is not None else preview(store, body)
        with store.db() as db:
            if sid is not None:
                sql = 'WITH selected AS (SELECT table_id,document_id FROM discovery_scope_pairs WHERE scope_id=?) '
                args = [sid]
            else:
                sql, args = graph.resolve(db, summary['recipe'])
            condition = ('NOT ' if group == 'outside' else '') + '''EXISTS (
                SELECT 1 FROM selected s WHERE s.table_id=e.table_id AND s.document_id=e.document_id)'''
            if group == 'all': condition = '1=1'
            total = db.execute(sql + 'SELECT count(*) FROM candidate_graph_edges e WHERE ' + condition, args).fetchone()[0]
            rows = db.execute(sql + 'SELECT e.data FROM candidate_graph_edges e WHERE ' + condition +
                              ' ORDER BY e.score DESC,e.id LIMIT ? OFFSET ?', args + [limit, offset]).fetchall()
        return {'receipt': {'version': 1, 'kind': 'table_document_scope', 'generation': summary['generation'],
                'scope_id': sid, 'status': 'committed' if sid is not None else 'preview',
                'unit': 'table_document_pairs', 'counts': summary['counts'], 'total_pairs': summary['total_pairs'],
                'outside_pairs': summary['total_pairs'] - summary['counts']['pairs'],
                'recipe': summary['recipe'], 'indexed_pair_scores': summary['indexed_pair_scores']},
                'group': group, 'total': total, 'offset': offset, 'limit': limit,
                'items': [json.loads(row['data']) for row in rows]}
