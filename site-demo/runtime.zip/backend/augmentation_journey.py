"""Small, read-only downstream receipts; never derives an enriched lake."""
import json
import knowledge as kg


def capture_assessment(db, scope, base, revision):
    if not exists(db, 'augmentation_workspaces'): return None
    row = db.execute('SELECT assessment FROM augmentation_workspaces WHERE scope=? AND base_run=?', (scope, base or '')).fetchone()
    data = json.loads(row['assessment']) if row and row['assessment'] else None
    return data if data and data.get('revision') == revision else None


def exists(db, table):
    return bool(db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone())


def stamp(row):
    config = json.loads(row['config'])
    return kg.digest([row['id'], row['updated'], config.get('review', {})])


def record_materialization(db, run, policy, augmentation, revision, rows=None):
    db.execute('CREATE TABLE IF NOT EXISTS integration_materialization_receipts(run TEXT PRIMARY KEY,data TEXT NOT NULL)')
    source = db.execute('SELECT * FROM augmentation_runs WHERE id=?', (augmentation,)).fetchone() if augmentation and exists(db, 'augmentation_runs') else None
    data = {'run': run, 'policy': policy, 'augmentation': augmentation,
            'augmentation_revision': stamp(source) if source else None, 'integration_revision': revision,
            'applied_targets': len({p['proposal_id'] for row in (rows or []) for side in ('left','right') for p in row.get(side+'_augmentations',[]) if p.get('proposal_id')}) if rows is not None else None}
    db.execute('INSERT OR REPLACE INTO integration_materialization_receipts VALUES(?,?)', (run, json.dumps(data)))


def consumers(db, row, accepted):
    materialized, layers = [], []
    if exists(db, 'integration_materialization_receipts') and exists(db, 'integration_plans'):
        for record in db.execute("SELECT r.data,p.data plan FROM integration_materialization_receipts r JOIN integration_plans p ON p.id=r.run WHERE p.materialized=1 AND json_extract(r.data,'$.augmentation')=?", (row['id'],)):
            data, plan = json.loads(record['data']), json.loads(record['plan'])
            materialized.append({'title': plan.get('title', 'Integration run'), 'run': data['run'],
                                 'applied_targets': data.get('applied_targets'),
                                 'current': data['augmentation_revision'] == stamp(row) and data['integration_revision'] == kg.digest(plan)})
    if exists(db, 'kg_augmentation_layers'):
        records = list(db.execute("SELECT data FROM kg_augmentation_layers WHERE json_extract(data,'$.augmentation')=?", (row['id'],)))
        current_source = None
        if records:
            import knowledge_overlays
            source, proposals = knowledge_overlays.source(db, row['id'])
            current_source = knowledge_overlays.fingerprint(source, proposals)
        for record in records:
            layer = json.loads(record['data'])
            projections = {}
            if exists(db, 'kg_auto_runs'):
                projections = {r['run']: r['revision'] for r in db.execute('SELECT run,revision FROM kg_auto_runs')}
            layers.append({'title': layer['title'], 'count': layer['count'], 'enabled': layer['enabled'],
                           'current': layer['source_revision'] == current_source,
                           'graph_current': all(projections.get(run) == version for run, version in layer['projections'].items())})
    base_exists = row['scope'] == 'source' or exists(db, 'integration_plans') and bool(db.execute('SELECT 1 FROM integration_plans WHERE id=?', (row['base_run_id'],)).fetchone())
    return {'derived_view': 'available' if accepted and base_exists else 'base_unavailable' if not base_exists else 'no_accepted_values',
            'indexing': 'not_automatically_connected', 'discovery': 'not_automatically_connected',
            'materialized': materialized, 'kg_layers': layers,
            'history_notice': 'Materialization receipts are recorded from this version onward. Older outputs are not assumed to have consumed these values.'}
