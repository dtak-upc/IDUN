"""Reviewed identity attribute mappings; no coercion, imputation or unit conversion."""
import json
import knowledge as kg
import knowledge_mapping_history as history


def read(store):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_attribute_axioms(id TEXT PRIMARY KEY,data TEXT)')
        return [json.loads(r['data']) for r in db.execute('SELECT data FROM kg_attribute_axioms ORDER BY id')]


def attributes(concepts):
    result={}
    for c in concepts:
        for a in c['attributes']:
            key=kg.digest([c['id'],a['name']])
            item={'id':key,'concept':c['id'],'name':a['name'],'datatype':a['datatype']}
            if key in result and result[key]['datatype']!=a['datatype']:item['datatype']='conflicting'
            result[key]=item
    return result


def visible(saved,concepts):
    lookup=attributes(concepts)
    return [dict(a,stale=any(lookup.get(e['id'])!=e for e in a['attributes'])) for a in saved
            if a['status']=='accepted' and all(e['concept'] in {c['id'] for c in concepts} for e in a['attributes'])]


def route(store,action,body):
    import knowledge_auto as auto
    with store.lock:
        graph=auto.view(store,auto.selected(body))
        if graph['revision']!=body.get('revision'):raise ValueError('Graph changed; refresh and preview again')
        if kg._jobs.get(str(store.root),{}).get('status')=='running':raise ValueError('Wait for the current graph task')
        saved=read(store)
        if action=='undo-attribute':
            item=next((a for a in graph['attribute_alignments'] if a['id']==body.get('id')),None)
            if not item:raise ValueError('Choose a visible attribute mapping')
            item=dict(item,status='undone');item.pop('stale',None)
            with store.db() as db:
                history.record(db,'attribute',item,graph,auto.selected(body))
                db.execute('UPDATE kg_attribute_axioms SET data=? WHERE id=?',(json.dumps(item),item['id']))
            return auto.view(store,auto.selected(body))
        lookup=attributes(graph['concepts']);source=body.get('source');target=body.get('target')
        if source not in lookup or target not in lookup or source==target:raise ValueError('Choose two different visible attributes')
        a,b=[lookup[i] for i in sorted([source,target])]
        if a['datatype']!=b['datatype'] or a['datatype'] in ('conflicting','unknown',''):
            raise ValueError('Declared attribute types differ or are ambiguous; conversion mappings are not supported')
        item={'id':'attribute_'+kg.digest([a['id'],b['id']]),'attributes':[a,b],'status':'accepted'}
        if any(x['id']==item['id'] and x['status']=='accepted' for x in saved):raise ValueError('Undo the existing mapping before reviewing again')
        preview={'mapping':item,'token':kg.digest([graph['revision'],saved,item])}
        if action=='preview-attribute':
            from knowledge_mapping_examples import examples
            preview['examples']=examples(store,graph,auto.selected(body),'attribute',item)
            return preview
        if action!='apply-attribute' or body.get('token')!=preview['token']:raise ValueError('Preview changed; review again')
        if body.get('compatible') is not True:raise ValueError('Confirm matching meaning, units and value representation')
        with store.db() as db:
            history.record(db,'attribute',item,graph,auto.selected(body))
            db.execute('INSERT OR REPLACE INTO kg_attribute_axioms VALUES(?,?)',(item['id'],json.dumps(item)))
        return auto.view(store,auto.selected(body))
