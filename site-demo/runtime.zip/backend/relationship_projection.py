"""Display-only PCA coordinates; clustering continues to use full embeddings."""
import numpy as np


def project_pairs(vectors):
    matrix = np.asarray(vectors, dtype=float)
    if matrix.size == 0:
        return np.zeros((0, 3))
    if matrix.ndim != 2 or not np.isfinite(matrix).all():
        raise ValueError('Pair embeddings must be a finite matrix')
    centered = matrix - matrix.mean(axis=0)
    u, sv, _ = np.linalg.svd(centered, full_matrices=False)
    points = np.zeros((len(matrix), 3))
    components = min(3, u.shape[1])
    points[:, :components] = u[:, :components] * sv[:components]
    return points
