"""Reviewed concept-pair relationship edits shared by Integration and its KG."""
import copy
import json
import re
import time
import uuid
import knowledge as kg


def setup(db):
    db.execute('CREATE TABLE IF NOT EXISTS kg_relationship_declarations(id TEXT PRIMARY KEY,data TEXT)')
    db.execute('CREATE TABLE IF NOT EXISTS kg_relationship_edit_history(id TEXT PRIMARY KEY,created REAL,data TEXT)')


def declarations(store,runs,concepts):
    with store.db() as db:
        setup(db)
        values=[json.loads(r['data']) for r in db.execute('SELECT data FROM kg_relationship_declarations')]
    return [dict(v,count=0,direction='unspecified',declared=True) for v in values
            if set(v['runs']) & set(runs) and v['source'] in concepts and v['target'] in concepts]


def route(store,action,body):
    import knowledge_auto as auto
    import knowledge_concepts as concepts
    import knowledge_assignments as assignments
    import knowledge_revisions as revisions
    import semantic
    import integration
    runs=auto.selected(body)
    if not runs:raise ValueError('Choose Integration runs to edit')
    with store.lock:
        if getattr(store,'integration_active',False) or kg._jobs.get(str(store.root),{}).get('status')=='running':
            raise ValueError('Wait for the active Integration or graph task')
        graph=auto.view(store,runs)
        if graph['revision']!=body.get('revision'):raise ValueError('Schema changed; preview the edit again')
        if any(l['update_available'] for l in graph['layers']):raise ValueError('Synchronize pending Integration updates before editing relationships')
        operation=body.get('operation')
        if operation not in ('add','rename','merge','remove'):raise ValueError('Choose add, rename, merge or remove')
        ids=body.get('edges',[])
        if not isinstance(ids,list) or any(not isinstance(e,str) for e in ids):raise ValueError('Choose schema relationships')
        ids=list(dict.fromkeys(ids));edges={e['id']:e for e in graph['relationships']}
        if operation!='add' and (not ids or any(e not in edges for e in ids)):raise ValueError('Choose current schema relationships')
        selected=[edges[e] for e in ids]
        if operation=='merge' and len(ids)<2:raise ValueError('Choose at least two relationships to merge')
        if operation in ('rename','remove') and len(ids)!=1:raise ValueError('Choose one concept-pair relationship')
        if operation=='merge' and len({tuple(sorted([e['source'],e['target']])) for e in selected})!=1:
            raise ValueError('Merge only relationships connecting the same two concepts; review concept assignments first')
        target=body.get('label','').strip() if isinstance(body.get('label',''),str) else ''
        if operation!='remove' and (not re.fullmatch(r'[A-Z0-9_]{2,64}',target) or target in ('NEGATIVE','UNRESOLVED')):
            raise ValueError('Use a non-reserved UPPER_SNAKE_CASE name of 2–64 characters')
        definition=body.get('definition','')
        if not isinstance(definition,str) or len(definition)>1200:raise ValueError('Definition must be text up to 1200 characters')
        definition=definition.strip()
        if operation=='add':
            source,end=body.get('source'),body.get('target')
            visible={c['id'] for c in graph['concepts']}
            if source not in visible or end not in visible:raise ValueError('Choose visible source and target concepts')
            source,end=sorted([source,end])
            if any(e['label']==target and sorted([e['source'],e['target']])==[source,end] for e in edges.values()):raise ValueError('This schema relationship already exists')
        else:source,end=sorted([selected[0]['source'],selected[0]['target']])
        affected={};samples=[];plans={};refined={};overrides={};assignment_edits=assignments.read(store)
        with store.db() as db:names={r['id']:r['name'] for r in db.execute('SELECT id,name FROM assets')}
        for run in runs:
            plan,revision=kg.load_plan(store,run);plans[run]=(plan,revision)
            refined[run]=concepts.read(store,run,revision)
            overrides[run]=assignments.mappings(assignment_edits,run,revision)
            _,instances=auto.project_run(store,run,plan,revision,names,refined[run],overrides[run])
            relevant=[a for a in instances if a['edge'] in ids] if operation!='add' else []
            keys=sorted({k for a in relevant for k in a.get('origin_row_keys',[])})
            if relevant and not keys:raise ValueError('Source lineage is unavailable; rebuild this Integration projection before editing')
            affected[run]=keys
            samples.extend({'run':run,'run_title':plan.get('title','Integration run'),'relationship':a['relation'],
                            'left':a['subject'],'right':a['object'],'evidence':a['evidence']} for a in relevant[:3])
        token=kg.digest([graph['revision'],operation,ids,target,definition,source,end,affected])
        preview={'token':token,'operation':operation,'label':target,'definition':definition,'runs':runs,
                 'counts':[{'run':r,'title':plans[r][0].get('title','Integration run'),'rows':len(k)} for r,k in affected.items()],
                 'rows':sum(len(k) for k in affected.values()),'examples':samples[:6],
                 'notice':'Only selected concept-pair connections in these runs change. Original model decisions and evidence are preserved. Changed connections may need new direction/alignment review.'}
        if action=='preview-relationship-edit':return preview
        if body.get('preview_token')!=token:raise ValueError('Preview this exact edit before applying it')
        prepared=[];event={'id':str(uuid.uuid4()),'created':time.time(),'operation':operation,'edges':ids,'label':target,'definition':definition,'runs':runs,'before':{},'affected':affected}
        for run,(plan,old_revision) in plans.items():
            if not affected[run] and operation!='add':continue
            updated=copy.deepcopy(plan)
            event['before'][run]=copy.deepcopy(plan.get('relationship_row_edits',{}))
            edits=updated.setdefault('relationship_row_edits',{})
            for key in affected[run]:edits[key]=None if operation=='remove' else target
            if operation!='remove':
                if not isinstance(updated.get('schema_config'),dict):updated['schema_config']={'mode':'hybrid','labels':[],'definitions':{}}
                config=updated['schema_config']
                config['labels']=list(dict.fromkeys(config.get('labels',[])+[target]))
                if definition:config.setdefault('definitions',{})[target]=definition
                else:config.setdefault('definitions',{}).setdefault(target,'')
            updated.setdefault('relationship_edit_audit',[]).append({'id':event['id'],'operation':operation,'edges':ids,'label':target,'row_count':len(affected[run]),'created':event['created']})
            new_revision=kg.digest(updated)
            meta,items=auto.project_run(store,run,updated,new_revision,names,refined[run],overrides[run])
            key=auto.assignment_key(auto.base_projection_key(new_revision,refined[run]),overrides[run])
            prepared.append((run,updated,old_revision,new_revision,key,meta,items))
        # Everything is prepared before the single database transaction. No partial multi-run edits.
        with store.db() as db:
            setup(db)
            columns={r['name'] for r in db.execute('PRAGMA table_info(integration_plans)')}
            for run,updated,old_revision,new_revision,key,meta,items in prepared:
                current=json.loads(db.execute('SELECT data FROM integration_plans WHERE id=?',(run,)).fetchone()['data'])
                if kg.digest(current)!=old_revision:raise ValueError('Integration changed; preview again')
                revisions.archive(db,run)
                db.execute('UPDATE integration_plans SET data=? WHERE id=?',(json.dumps(updated),run))
                if 'materialized' in columns and db.execute('SELECT materialized FROM integration_plans WHERE id=?',(run,)).fetchone()[0]:
                    db.execute('DELETE FROM integration_rows WHERE plan_id=?',(run,))
                    db.executemany('INSERT INTO integration_rows VALUES(?,?,?)',[(run,i,json.dumps(row)) for i,row in enumerate(semantic.rows(updated))])
                if refined[run]:db.execute('UPDATE kg_semantic_concepts SET revision=? WHERE run=? AND revision=?',(new_revision,run,old_revision))
                for edit in assignment_edits:
                    if edit.get('revisions',{}).get(run)==old_revision:
                        edit.setdefault('relationship_revision_history',[]).append({'run':run,'before':old_revision,'after':new_revision,'edit':event['id']})
                        edit['revisions'][run]=new_revision
                        db.execute('UPDATE kg_assignment_edits SET data=? WHERE id=?',(json.dumps(edit),edit['id']))
                db.execute('DELETE FROM kg_auto_instances WHERE run=?',(run,))
                db.executemany('INSERT INTO kg_auto_instances VALUES(?,?,?,?)',[(run,a['id'],a['edge'],json.dumps(a)) for a in items])
                db.execute('UPDATE kg_auto_runs SET revision=?,data=? WHERE run=?',(key,json.dumps(meta),run))
            for edge in selected:
                if edge.get('declared'):db.execute('DELETE FROM kg_relationship_declarations WHERE id=?',(edge['id'],))
            if operation=='add' or (selected and all(e.get('declared') for e in selected) and operation!='remove'):
                declaration={'id':'relation_'+kg.digest([target,source,end]),'label':target,'source':source,'target':end,'definition':definition,'runs':runs}
                db.execute('INSERT OR REPLACE INTO kg_relationship_declarations VALUES(?,?)',(declaration['id'],json.dumps(declaration)))
            if operation!='remove':
                db.execute('CREATE TABLE IF NOT EXISTS integration_schema(id INTEGER PRIMARY KEY,data TEXT)')
                row=db.execute('SELECT data FROM integration_schema WHERE id=1').fetchone()
                import llm
                config=json.loads(row['data']) if row else {'mode':'hybrid','labels':list(llm.DEFAULT_LABELS),'definitions':{}}
                config['labels']=list(dict.fromkeys(config['labels']+[target]));
                if definition:config.setdefault('definitions',{})[target]=definition
                else:config.setdefault('definitions',{}).setdefault(target,'')
                config=integration.validate_schema(config)
                db.execute('INSERT OR REPLACE INTO integration_schema VALUES(1,?)',(json.dumps(config),))
            event['after']={run:new for run,_,_,new,_,_,_ in prepared}
            db.execute('INSERT INTO kg_relationship_edit_history VALUES(?,?,?)',(event['id'],event['created'],json.dumps(event)))
        return {'graph':auto.view(store,runs),'edit':event['id'],'rows':preview['rows']}
