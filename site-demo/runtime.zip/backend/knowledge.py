"""Lake-local, immutable Integration graph snapshots. No inference dependencies at import."""
import hashlib
import json
import threading
import time
import uuid

VERSION = 'kg-records-v2'
_guard = threading.RLock()
_jobs = {}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def setup(store):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_snapshots(id TEXT PRIMARY KEY,run_id TEXT,revision TEXT,created REAL,data TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS kg_assertions(snapshot TEXT,id TEXT,data TEXT,PRIMARY KEY(snapshot,id))')
        db.execute("CREATE INDEX IF NOT EXISTS kg_assertion_edge ON kg_assertions(snapshot,json_extract(data,'$.edge'),id)")
        db.execute('CREATE TABLE IF NOT EXISTS kg_workspace(id INTEGER PRIMARY KEY,current TEXT)')


def load_plan(store, run_id):
    with store.db() as db:
        row = db.execute('SELECT data FROM integration_plans WHERE id=?', (run_id,)).fetchone()
    if not row:
        raise KeyError('Integration run not found in this lake')
    plan = json.loads(row['data'])
    if plan.get('version') != 'semantic-joins-v5.1':
        raise ValueError('Unsupported Integration revision; create a current Integration run first')
    return plan, digest(plan)


def project(lake, run_id, plan, rows, names, cancelled=lambda: False):
    """Project record associations, without asserting entity identity or inferred valid time."""
    classes, properties, assertions = {}, {}, {}
    original = {d['candidate']: d for d in plan.get('model_decisions', plan.get('decisions', []))}
    def curated(label):
        for operation in plan.get('curation', []):
            if label in operation.get('sources', []):
                label = operation['target']
        return label
    lineages = {}
    for decision in original.values():
        for path in decision.get('path_decisions', []):
            label = path.get('relationship')
            if label:
                lineages.setdefault(curated(label), set()).add(label)
    skipped = 0
    for row in rows:
        if cancelled():
            raise InterruptedError('Graph build cancelled')
        endpoints = []
        for side in ('left', 'right'):
            ref = row.get(side + '_record', '')
            parts = ref.rsplit(':', 2)
            if len(parts) != 3 or not parts[2].isdigit() or not parts[1]:
                break
            asset, version, number = parts
            if asset not in names:
                raise ValueError('A source table was removed; the run cannot be projected')
            cid = 'c_' + digest([lake, asset, version])
            name = names[asset]
            source_class = classes.setdefault(cid, {'id': cid, 'label': name, 'provisional': True,
                            'columns': [], 'asset': asset, 'version': version})
            for column in row.get(side + '_columns', []):
                if column not in source_class['columns']:source_class['columns'].append(column)
            endpoints.append({'id': 'r_' + digest([lake, asset, version, int(number)]),
                              'class_id': cid, 'source': name, 'reference': ref, 'row': int(number),
                              'columns': row.get(side + '_columns', []), 'cells': row.get(side + '_cells', []),
                              'label': str(row.get(side + '_value', '')), 'provenance': 'Saved Integration record'})
        if len(endpoints) != 2:
            skipped += 1
            continue
        direction = row.get('direction', 'undirected')
        if direction not in ('a_to_b', 'b_to_a', 'bidirectional', 'undirected'):
            raise ValueError('Unsupported relationship direction')
        paths = row.get('evidence', [])
        # Context is the immutable mediator version, never its present-day bytes.
        contexts = sorted({p.get('text_version', '') for p in paths})
        doc = row.get('text_source', '')
        if doc not in names:
            raise ValueError('An evidence document was removed; the run cannot be projected')
        originals = sorted({p.get('relationship') for p in original.get(row.get('candidate'), {}).get('path_decisions', [])
                            if p.get('evidence') in {e.get('evidence') for e in paths}
                            and p.get('relationship') and (curated(p['relationship']) == row['relation'] or curated(p['relationship']) in row.get('original_relations',[]))})
        # Run-local vocabulary lineage survives display label edits.
        pid = 'p_' + digest([lake, run_id, sorted(lineages.get(row['relation'], {row['relation']}))])
        a, b = endpoints if direction != 'b_to_a' else endpoints[::-1]
        kind = {'undirected': 'unspecified', 'bidirectional': 'bidirectional'}.get(direction, 'directed')
        if kind != 'directed':
            a, b = sorted((a, b), key=lambda r: r['id'])
        edge = 'e_' + digest([pid, a['class_id'], b['class_id'], kind])
        properties[edge] = {'id': edge, 'property_id': pid, 'label': row['relation'],
                            'source': a['class_id'], 'target': b['class_id'], 'direction': kind,
                            'original_labels': originals, 'count': 0}
        ids = [a['id'], b['id']]
        if kind != 'directed':
            ids.sort()
        aid = 'a_' + digest([lake, ids, pid, kind, doc, contexts])
        if aid not in assertions:
            assertions[aid] = {'id': aid, 'edge': edge, 'relation': row['relation'], 'direction': kind,
                               'original_direction': direction, 'original_labels': originals,
                               'record_a': endpoints[0]['id'], 'record_b': endpoints[1]['id'],
                               'subject': a, 'object': b, 'document': names[doc], 'document_id': doc,
                               'document_versions': contexts, 'evidence': [],
                               'review': 'Model-proposed; not human-confirmed', 'valid_time': None}
        origin_keys=assertions[aid].setdefault('origin_row_keys',[])
        origin_keys.extend(k for k in row.get('origin_row_keys',[]) if k not in origin_keys)
        from knowledge_journey import origin
        receipt = origin(row)
        origins = assertions[aid].setdefault('integration_origins', [])
        if receipt not in origins: origins.append(receipt)
        saved = assertions[aid]['evidence']
        seen = {digest(p) for p in saved}
        for path in paths:
            clean = {k: v for k, v in path.items() if k not in ('vector', 'vector_context')}
            if digest(clean) not in seen:
                saved.append(clean)
                seen.add(digest(clean))
    for assertion in assertions.values():
        properties[assertion['edge']]['count'] += 1
    return {'classes': list(classes.values()), 'properties': list(properties.values()),
            'skipped_rows': skipped, 'assertions': list(assertions.values()),
            'excluded_decisions': sum(d.get('status') != 'include' for d in plan.get('decisions', []))}


def overview(store):
    setup(store)
    with store.db() as db:
        exists = db.execute("SELECT 1 FROM sqlite_master WHERE name='integration_plans'").fetchone()
        runs = []
        if exists:
            for r in db.execute('SELECT id,data,created FROM integration_plans ORDER BY created DESC'):
                p = json.loads(r['data'])
                runs.append({'id': r['id'], 'title': p.get('title', 'Integration run'), 'model': p.get('model', ''), 'created':r['created'],
                             'revision': digest(p), 'supported': p.get('version') == 'semantic-joins-v5.1'})
        current = db.execute('SELECT current FROM kg_workspace WHERE id=1').fetchone()
        snapshots = [json.loads(r['data']) for r in db.execute('SELECT data FROM kg_snapshots ORDER BY created DESC')]
    revisions = {r['id']: r['revision'] for r in runs}
    for s in snapshots:
        s['update_available'] = revisions.get(s['run_id']) != s['revision']
    with _guard:
        job = _jobs.get(str(store.root))
        public = {k: v for k, v in job.items() if k != 'cancel'} if job else None
    return {'runs': runs, 'snapshots': snapshots, 'current': current['current'] if current else None, 'job': public}


def build(store, body):
    setup(store)
    run_id = body.get('run_id')
    plan, revision = load_plan(store, run_id)
    if revision != body.get('revision'):
        raise ValueError('Integration run changed; refresh before building')
    key = str(store.root)
    with _guard:
        if _jobs.get(key, {}).get('status') == 'running':
            raise ValueError('A graph build is already running in this lake')
        job = {'id': str(uuid.uuid4()), 'status': 'running', 'phase': 'Projecting saved records', 'cancel': threading.Event()}
        _jobs[key] = job
        store.knowledge_active = True
        store.knowledge_cancel = job['cancel']
    def work():
        try:
            from semantic import rows
            with store.db() as db:
                names = {r['id']: r['name'] for r in db.execute('SELECT id,name FROM assets')}
            output = project(store.lake_id, run_id, plan, rows(plan), names, job['cancel'].is_set)
            assertions = output.pop('assertions')
            sid = digest([VERSION, store.lake_id, run_id, revision])
            meta = {**output, 'id': sid, 'run_id': run_id, 'revision': revision, 'version': VERSION,
                    'title': plan.get('title', 'Integration run'), 'model': plan.get('model', ''),
                    'recorded_at': time.time(), 'assertion_count': len(assertions),
                    'record_count': len({a[side]['id'] for a in assertions for side in ('subject', 'object')})}
            with store.lock, _guard:
                if job['cancel'].is_set():
                    raise InterruptedError('Graph build cancelled')
                if load_plan(store, run_id)[1] != revision:
                    raise ValueError('Integration changed during build; previous snapshot retained')
                with store.db() as db:
                    current = db.execute('SELECT current FROM kg_workspace WHERE id=1').fetchone()
                    if (current['current'] if current else None) != body.get('expected_parent'):
                        raise ValueError('Graph workspace changed; refresh before building')
                    db.execute('INSERT OR IGNORE INTO kg_snapshots VALUES(?,?,?,?,?)',
                               (sid, run_id, revision, meta['recorded_at'], json.dumps(meta)))
                    db.executemany('INSERT OR IGNORE INTO kg_assertions VALUES(?,?,?)',
                                   ((sid, a['id'], json.dumps(a)) for a in assertions))
                    db.execute('INSERT OR REPLACE INTO kg_workspace VALUES(1,?)', (sid,))
                job.update(status='completed', phase='Snapshot published', snapshot=sid)
        except InterruptedError as e:
            job.update(status='cancelled', phase=str(e))
        except Exception as e:
            job.update(status='failed', phase=str(e))
        finally:
            with _guard:
                if _jobs.get(key) is job:
                    store.knowledge_active = False
    thread = threading.Thread(target=work, daemon=True, name='knowledge-build')
    store.knowledge_thread = thread
    thread.start()
    return {'id': job['id'], 'status': 'running'}


def read(store, sid, offset=0, edge=''):
    setup(store)
    if offset < 0:
        raise ValueError('Invalid page offset')
    with store.db() as db:
        row = db.execute('SELECT data,run_id FROM kg_snapshots WHERE id=?', (sid,)).fetchone()
        if not row:
            raise KeyError('Graph snapshot not found in this lake')
        meta = json.loads(row['data'])
        # Do not expose retained source content after its owning run or sources are removed.
        source_plan = db.execute('SELECT data FROM integration_plans WHERE id=?', (row['run_id'],)).fetchone()
        if not source_plan:
            raise ValueError('The source run was removed; delete this unavailable graph snapshot')
        assets = {r['id'] for r in db.execute('SELECT id FROM assets')}
        if any(c['asset'] not in assets for c in meta.get('source_classes', meta['classes'])):
            raise ValueError('A source was removed; this snapshot is unavailable')
        edges = list(dict.fromkeys(edge.split(','))) if edge else []
        if len(edges)>500: raise ValueError('Select at most 500 schema edges')
        where = 'snapshot=?' + (" AND json_extract(data,'$.edge') IN ("+','.join('?' for _ in edges)+')' if edges else '')
        args = (sid, *edges)
        total = db.execute('SELECT count(*) FROM kg_assertions WHERE ' + where, args).fetchone()[0]
        items = [json.loads(r['data']) for r in db.execute('SELECT data FROM kg_assertions WHERE ' + where + ' ORDER BY id LIMIT 25 OFFSET ?', (*args, offset))]
        if any(a['document_id'] not in assets for a in items):
            raise ValueError('An evidence document was removed; this snapshot is unavailable')
        plan = json.loads(source_plan['data'])
        if digest(plan) == meta['revision']:
            from knowledge_review import endpoint_checks
            endpoint_checks(plan,items)
    return {'snapshot': meta, 'items': items, 'total': total, 'offset': offset, 'limit': 25}


def remove(store, sid):
    setup(store)
    with store.lock, _guard, store.db() as db:
        if _jobs.get(str(store.root), {}).get('status') == 'running':
            raise ValueError('Cancel the active build before removing a snapshot')
        if not db.execute('SELECT 1 FROM kg_snapshots WHERE id=?', (sid,)).fetchone():
            raise KeyError('Graph snapshot not found in this lake')
        db.execute('DELETE FROM kg_assertions WHERE snapshot=?', (sid,))
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_schema_drafts'").fetchone():
            db.execute('DELETE FROM kg_schema_drafts WHERE snapshot=?',(sid,))
        db.execute('DELETE FROM kg_snapshots WHERE id=?', (sid,))
        db.execute('UPDATE kg_workspace SET current=NULL WHERE current=?', (sid,))
        from knowledge_workspace import prune
        prune(db)
    return {'removed': sid}


def prune_removed_runs(db):
    """Called in the owning run/source deletion transaction; no retained private copies."""
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_validity_events'").fetchone():
        db.execute("DELETE FROM kg_validity_events WHERE run NOT IN (SELECT id FROM integration_plans) OR EXISTS (SELECT 1 FROM json_each(kg_validity_events.data,'$.assets') a WHERE a.value NOT IN (SELECT id FROM assets))")
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_auto_runs'").fetchone():
        db.execute('DELETE FROM kg_auto_instances WHERE run NOT IN (SELECT id FROM integration_plans)')
        db.execute('DELETE FROM kg_auto_runs WHERE run NOT IN (SELECT id FROM integration_plans)')
        db.execute("DELETE FROM kg_auto_directions WHERE type NOT IN (SELECT json_extract(data,'$.relation') FROM kg_auto_instances)")
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_projection_history'").fetchone():
        # Deletion privacy takes precedence over historical availability.
        db.execute("DELETE FROM kg_projection_history WHERE run NOT IN (SELECT id FROM integration_plans) OR EXISTS (SELECT 1 FROM json_each(kg_projection_history.data,'$.assets') a WHERE a.value NOT IN (SELECT id FROM assets))")
        db.execute("DELETE FROM kg_projection_history_items WHERE NOT EXISTS (SELECT 1 FROM kg_projection_history h WHERE h.run=kg_projection_history_items.run AND h.revision=kg_projection_history_items.revision)")
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_semantic_concepts'").fetchone():
        db.execute("DELETE FROM kg_semantic_concepts WHERE run NOT IN (SELECT id FROM integration_plans)")
    for table in ('kg_alignment_suggestions','kg_alignment_batches'):
        if db.execute("SELECT 1 FROM sqlite_master WHERE name=?",(table,)).fetchone():
            db.execute(f"DELETE FROM {table} WHERE EXISTS (SELECT 1 FROM json_each({table}.data,'$.runs') r WHERE r.value NOT IN (SELECT id FROM integration_plans))")
    if not db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_snapshots'").fetchone():
        return
    db.execute('DELETE FROM kg_assertions WHERE snapshot IN (SELECT id FROM kg_snapshots WHERE run_id NOT IN (SELECT id FROM integration_plans))')
    db.execute('DELETE FROM kg_snapshots WHERE run_id NOT IN (SELECT id FROM integration_plans)')
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_schema_drafts'").fetchone():
        db.execute('DELETE FROM kg_schema_drafts WHERE snapshot NOT IN (SELECT id FROM kg_snapshots)')
    db.execute('UPDATE kg_workspace SET current=NULL WHERE current NOT IN (SELECT id FROM kg_snapshots)')
    from knowledge_workspace import prune
    prune(db)


def route(store, method, path, body, query):
    if path and path[0] == 'automatic':
        import knowledge_auto
        return knowledge_auto.route(store,method,path[1:],body,query)
    if path and path[0] == 'workspace':
        import knowledge_workspace
        return knowledge_workspace.route(store, method, path[1:], body, query)
    if len(path) == 3 and path[0] == 'snapshots' and path[2].startswith('schema'):
        import knowledge_schema
        if method == 'GET' and path[2] == 'schema': return knowledge_schema.draft(store,path[1])
        operation = {'schema-save':knowledge_schema.save,'schema-accept':knowledge_schema.accept,'schema-suggest':knowledge_schema.suggest}.get(path[2])
        if method == 'POST' and operation: return operation(store,path[1],body())
    if method == 'GET' and not path:
        return overview(store)
    if method == 'POST' and path == ['build']:
        return build(store, body())
    if method == 'POST' and path == ['cancel']:
        with _guard:
            job = _jobs.get(str(store.root))
            if job and job['status'] == 'running':
                job['cancel'].set()
        return {'status': 'Cancellation requested'}
    if len(path) == 2 and path[0] == 'snapshots' and method == 'GET':
        return read(store, path[1], int(query.get('offset', ['0'])[0]), query.get('edge', [''])[0])
    if len(path) == 3 and path[0] == 'snapshots' and path[2] == 'remove' and method == 'POST':
        return remove(store, path[1])
    raise KeyError('Knowledge Graph operation not found')
