"""THOR-ranked neighborhoods around versioned row/link evidence, never a lake scan."""
import json
import re

import inference


def expand(store, target, concept, extractor, selection):
    import augmentation
    radius = selection.get('nearby_radius', 1500)
    limit = selection.get('nearby_limit', 2)
    result, skipped, seen = [], [], set()
    with store.db() as db:
        mask = inference.identifier_mask(db, augmentation.policy(store).get('exclude_identifiers', []))
        has_links = db.execute("SELECT 1 FROM sqlite_master WHERE name='discovery_links'").fetchone()
        for anchor in target.get('evidence_contexts', []):
            document = anchor.get('document')
            version = anchor.get('document_version')
            if not version and has_links:
                for link_id in anchor.get('origin_link_ids', []) + [anchor.get('evidence_id')]:
                    if not link_id: continue
                    row = db.execute('SELECT data FROM discovery_links WHERE id=?', (link_id,)).fetchone()
                    link = augmentation.decode_discovery_data(row['data']) if row else {}
                    if link.get('text') == document and link.get('text_version'):
                        version = link['text_version']; break
            if not version:
                skipped.append('Original document version is unavailable'); continue
            start, end = anchor.get('start'), anchor.get('end')
            if not isinstance(start, int) or not isinstance(end, int) or end <= start:
                skipped.append('Original evidence offsets are unavailable'); continue
            if end-start > 12000:
                skipped.append('Original evidence exceeds the second-pass window budget'); continue
            lo, hi = max(0, start-radius), end+radius
            chunks = db.execute('SELECT start,end,data FROM records WHERE asset_id=? AND version=? AND end>? AND start<? ORDER BY start', (document,version,lo,hi)).fetchall()
            pieces, cursor, base = [], None, None
            for chunk in chunks:
                text = json.loads(chunk['data'])
                if not isinstance(text, str): continue
                a,b = max(lo,chunk['start']),min(hi,chunk['end'])
                if cursor is not None and a != cursor:
                    pieces=[]; break
                if base is None: base=a
                pieces.append(text[a-chunk['start']:b-chunk['start']]); cursor=b
            text = mask(''.join(pieces))
            if base is None or not text or text[start-base:end-base] != mask(anchor.get('text', '')):
                skipped.append('Original evidence no longer matches its saved document span'); continue
            if base == start and base+len(text) == end:
                skipped.append('Original evidence already covers the available document'); continue
            key=(document,version,base,base+len(text))
            if key in seen: continue
            seen.add(key)
            result.append(dict(document=document,document_name=anchor.get('document_name',document),
                document_version=version,start=base,end=base+len(text),text=text,
                evidence_id=f'nearby:{document}:{version}:{base}:{base+len(text)}',
                retrieval={'method':'thor_document_neighborhood','anchor_evidence_id':anchor.get('evidence_id'),
                    'anchor_start':start,'anchor_end':end,'radius':radius}))

    # Model work stays outside the catalog connection. Inputs remain projected.
    hints = []
    if concept and concept.get('seeds'):
        hints.append(concept)
    for index,(name,value) in enumerate(target.get('row_context', {}).items()):
        if len(hints) >= 9: break
        if not isinstance(value,str) or '█' in value or not re.search(r'[^\W\d_]{2}',value): continue
        hints.append({'id':f'row-anchor-{index}','name':name,'seeds':[{'value':value[:250]}]})
    for context in result:
        matches = extractor.extract(context['text'], hints, check_attribution=True) if hints else []
        matched = sorted(matches,key=lambda m:-m.get('scores',{}).get('combined',0))[:10]
        context['retrieval']['matches'] = [{'concept':m['concept'],'value':m['value'],
            'start':context['start']+m['start'],'end':context['start']+m['end'],
            'score':m.get('scores',{}).get('combined',0)} for m in matched]
        context['retrieval']['ranking_score'] = max((m['score'] for m in context['retrieval']['matches']),default=0)
        context['retrieval']['seeded_target'] = bool(concept and concept.get('seeds'))
    result.sort(key=lambda c:-c['retrieval']['ranking_score'])
    return result[:limit], {'status':'expanded' if result else 'unavailable',
        'passages':min(limit,len(result)), 'skipped':list(dict.fromkeys(skipped))}
