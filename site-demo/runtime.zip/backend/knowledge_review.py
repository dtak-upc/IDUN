"""Conservative lexical review hints, not semantic acceptance or rejection."""
import re


def endpoint_checks(plan, assertions):
    targets = {(a['subject']['reference'], a['object']['reference'], a['relation'], a['document_id']): a for a in assertions}
    cases = {c['candidate']:c for c in plan.get('cases',[])}
    for decision in plan.get('decisions',[]):
        if decision.get('status') != 'include': continue
        case = cases.get(decision.get('candidate'))
        if not case: continue
        refs = [case[s]['record']['record_id'] for s in ('left','right')]
        for path in decision.get('path_decisions',[]):
            if path.get('basis') != 'text_supported': continue
            rel = path.get('relationship'); doc = case.get('document')
            a = targets.get((refs[0],refs[1],rel,doc)) or targets.get((refs[1],refs[0],rel,doc))
            if not a: continue
            checks=a.setdefault('endpoint_checks',[])
            for side,key,legacy in [('left','record_a_quote','diagnosis_quote'),('right','record_b_quote','medication_quote')]:
                quote=path.get(key,path.get(legacy,''))
                if not isinstance(quote,str) or not quote.strip(): continue
                record=case[side]['record']
                # Hints deliberately compare against all projected cells. Aliases and abbreviations
                # can fail this check; no row or model decision is removed or rewritten.
                tokens=set(re.findall(r'[^\W_]{4,}',quote.casefold()))
                cells=' '.join(str(v) for v in record.get('cells',[])).casefold()
                hint={'reference':record['record_id'],'quote':quote,
                      'status':'lexical_overlap' if tokens and any(t in cells for t in tokens) else 'needs_review'}
                if hint not in checks:checks.append(hint)
