"""Explicit pairwise identity links; originals stay immutable, no automatic transitive merge."""
import json
import time
import knowledge as kg
import knowledge_entity_keys as keys


def read(store):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_identity_links(id TEXT PRIMARY KEY,data TEXT NOT NULL)')
        db.execute('CREATE TABLE IF NOT EXISTS kg_identity_events(sequence INTEGER PRIMARY KEY AUTOINCREMENT,recorded REAL,data TEXT NOT NULL)')
        return [json.loads(r['data']) for r in db.execute('SELECT data FROM kg_identity_links ORDER BY id')]


def offset(body,name='offset'):
    value=body.get(name,0)
    if type(value) is not int or not 0<=value<=1000000:raise ValueError('Invalid identity page offset')
    return value


def visible(store,graph,runs,start=0):
    definitions={k['id']:k for k in keys.read(store)};saved=read(store)
    items=[dict(link,stale=(definitions.get(link['key']['id'])!=link['key'] or keys.stale(link['key'],graph,runs)))
        for link in saved if link['status']=='accepted' and link['key']['concept'] in {c['id'] for c in graph['concepts']}]
    return {'revision':kg.digest(saved),'total':len(items),'offset':start,'limit':20,'items':items[start:start+20]}


def summary(row):
    record=json.loads(row['record'])
    return {'id':row['rid'],'label':record['label'],'source':record['source'],'row':record['row'],'runs':row['runs'].split(',')}


def compare(db,runs,pair,definition):
    records=list(db.execute('SELECT * FROM kg_key_records WHERE rid IN (?,?) AND variations=1 AND absent=0 ORDER BY rid',pair))
    if len(records)!=2 or records[0]['value']!=records[1]['value']:raise ValueError('Choose two distinct records with the same complete key')
    variants=[];details=[]
    for row in records:
        item=summary(row);record=json.loads(row['record']);item.update(columns=record['columns'],cells=record['cells'])
        scope=','.join('?' for _ in runs);parts=[];args=[]
        for side in ('subject','object'):
            parts.append(f"SELECT json_extract(data,'$.{side}.columns') columns,json_extract(data,'$.{side}.cells') cells FROM kg_auto_instances WHERE run IN ({scope}) AND json_extract(data,'$.{side}.id')=?")
            args.extend([*runs,row['rid']])
        variants.append(db.execute('SELECT count(*) FROM (SELECT DISTINCT columns,cells FROM ('+' UNION ALL '.join(parts)+'))',args).fetchone()[0])
        details.append(item)
    columns=list(dict.fromkeys(c for d in details for c in d['columns']))
    key_names={a['name'] for a in definition['attributes']};fields=[]
    for column in columns:
        values=[]
        for d in details:
            index=d['columns'].index(column) if column in d['columns'] else -1
            values.append({'available':0<=index<len(d['cells']),'value':d['cells'][index] if 0<=index<len(d['cells']) else None})
        # Typed JSON comparison distinguishes false, zero, null and unavailable.
        conflict=json.dumps(values[0],sort_keys=True)!=json.dumps(values[1],sort_keys=True)
        fields.append({'name':column,'key':column in key_names,'values':values,'conflict':conflict})
    return {'records':details,'fields':fields,'conflicts':sum(f['conflict'] and not f['key'] for f in fields),'projection_variants':variants,'can_accept':all(v==1 for v in variants)}


def route(store,action,body):
    import knowledge_auto as auto
    runs=auto.selected(body)
    with store.lock:
        graph=auto.view(store,runs)
        if action=='identity-links':return visible(store,graph,runs,offset(body))
        if graph['revision']!=body.get('revision'):raise ValueError('Graph changed; refresh identity review')
        saved=read(store)
        if action=='undo-identity':
            link=next((l for l in saved if l['id']==body.get('id') and l['status']=='accepted'),None)
            if not link or link['key']['concept'] not in {c['id'] for c in graph['concepts']}:raise ValueError('Choose a visible identity link')
            if body.get('link_revision')!=kg.digest(saved):raise ValueError('Identity links changed; reload before undo')
            result=dict(link,status='undone')
        else:
            if any(l['update_available'] for l in graph['layers']):raise ValueError('Review pending graph updates before identity matching')
            definition=next((k for k in keys.read(store) if k['id']==body.get('key') and k['status']=='accepted'),None)
            if not definition or keys.stale(definition,graph,runs):raise ValueError('Choose a current reviewed entity key for these runs')
            with store.db() as db:
                keys.materialize(db,runs,definition['concept'],definition['attributes'])
                base=' FROM kg_key_records WHERE variations=1 AND absent=0 '
                if action=='identity-candidates':
                    start=offset(body);groups=[]
                    total=db.execute('SELECT count(*) FROM (SELECT value'+base+'GROUP BY value HAVING count(*)>1)').fetchone()[0]
                    for row in db.execute('SELECT value,count(*) n'+base+'GROUP BY value HAVING count(*)>1 ORDER BY n DESC,value LIMIT 8 OFFSET ?',(start,)):
                        groups.append({'value':row['value'],'values':[v[1] for v in json.loads(row['value'])],'count':row['n']})
                    return {'total':total,'offset':start,'limit':8,'groups':groups}
                if action=='identity-members':
                    value=body.get('value');start=offset(body)
                    if not isinstance(value,str):raise ValueError('Choose a shared-key group')
                    total=db.execute('SELECT count(*)'+base+'AND value=?',(value,)).fetchone()[0]
                    if total<2:raise ValueError('Shared-key group no longer exists')
                    return {'total':total,'offset':start,'limit':20,'items':[summary(r) for r in db.execute('SELECT *'+base+'AND value=? ORDER BY rid LIMIT 20 OFFSET ?',(value,start))]}
                pair=body.get('records')
                if not isinstance(pair,list) or len(pair)!=2 or any(not isinstance(r,str) for r in pair) or pair[0]==pair[1]:raise ValueError('Choose exactly two distinct records')
                review=compare(db,runs,pair,definition)
            result={'id':'identity_'+kg.digest([definition['id'],sorted(pair)]),'key':definition,'records':sorted(pair),'summaries':[{k:v for k,v in r.items() if k not in ('columns','cells')} for r in review['records']],'status':'accepted'}
            preview={**review,'token':kg.digest([graph['revision'],definition,saved,review]),'link':result}
            if action=='preview-identity':return preview
            if action!='apply-identity' or body.get('token')!=preview['token']:raise ValueError('Identity preview changed; compare again')
            if body.get('confirmed') is not True:raise ValueError('Confirm that both records represent the same entity')
            if not review['can_accept']:raise ValueError('Resolve inconsistent projected records before accepting identity')
        if kg._jobs.get(str(store.root),{}).get('status')=='running':raise ValueError('Wait for the current graph task')
        with store.db() as db:
            before=next((l for l in saved if l['id']==result['id']),None)
            db.execute('INSERT OR REPLACE INTO kg_identity_links VALUES(?,?)',(result['id'],json.dumps(result)))
            db.execute('INSERT INTO kg_identity_events(recorded,data) VALUES(?,?)',(time.time(),json.dumps({'before':before,'after':result,'revision':graph['revision']})))
        return visible(store,graph,runs)
