"""Complete contextual scores on disk; browsing and evidence filters never invoke a model."""
import array,base64,heapq,json,math,sys,time,uuid,zlib
import discovery
from evidence_storage import encode,decode,retain,source_roles,POLICY,policy_for
VERSION='context-scores-f32-v1'

def setup(store):
 with store.db() as db:
  db.execute('CREATE TABLE IF NOT EXISTS discovery_score_blocks(generation TEXT,key TEXT,context BLOB,scores BLOB,vectors BLOB,global_score REAL,PRIMARY KEY(generation,key))')

def values(blob,rows,units):
 a=array.array('f');a.frombytes(zlib.decompress(blob))
 if sys.byteorder!='little':a.byteswap()
 if len(a)!=rows*units or any(not math.isfinite(v) or not -1.01<=v<=1.01 for v in a):raise ValueError('Invalid LOKI score matrix')
 return a

def current(store,generation=None):
 r=discovery.status(store)
 if r['status']!='ready' or not r.get('matrix'):raise ValueError('Compute complete LOKI scores first; legacy evidence cannot be expanded into a matrix')
 if generation is not None and r['matrix']['generation']!=generation:raise ValueError('Discovery scores changed; reload the results')
 return r

def filters(body):
 bridge_cap(body)
 low,high=body.get('min_score',-1),body.get('max_score',1.01)
 if any(type(v) not in (int,float) or not math.isfinite(v) for v in (low,high)) or not -1.01<=low<=high<=1.01:raise ValueError('Invalid score range')
 k=body.get('top_k',0)
 if type(k)!=int or not 0<=k<=32:raise ValueError('Evidence Top-K must be 0 (all) or 1–32')
 source=body.get('source','');order=body.get('sort','desc')
 if not isinstance(source,str) or order not in ('asc','desc'):raise ValueError('Invalid source or score order')
 return low,high,k,source,order

def bridge_cap(body):
 cap=body.get('bridge_cap',2000)
 if type(cap)!=int or not 0<=cap<=9007199254740991:raise ValueError('Join-path cap must be a nonnegative integer (0 = all)')
 return cap

def blocks(store,generation):
 # One numerical block and its source mapping in memory at a time.
 with store.db() as db:
  for b in db.execute('SELECT * FROM discovery_score_blocks WHERE generation=? ORDER BY key',(generation,)):
   yield b,decode(b['context'])

def cells(c,a,policy):
 low,high,k,source,_=policy;n=len(c['units'])
 for i,row in enumerate(c['rows']):
  if source and source not in (row['asset_id'],c['text_id']):continue
  matches=[(a[i*n+j],j) for j in range(n) if low<=a[i*n+j]<=high]
  if k:matches=sorted(matches,key=lambda v:(-v[0],v[1]))[:k]
  for score,j in matches:yield i,j,score

def query(store,body):
 policy=filters(body);offset=body.get('offset',0)
 if type(offset)!=int or not 0<=offset<=10000:raise ValueError('Browse offset must be 0–10000; narrow the filters for deeper results')
 with store.lock:
  r=current(store,body.get('generation'));generation=r['matrix']['generation'];total=0;heap=[];hist=[0]*20
  for b,c in blocks(store,generation):
   a=values(b['scores'],len(c['rows']),len(c['units']))
   for i,j,score in cells(c,a,policy):
    total+=1;hist[min(19,max(0,int((score+1)*10)))]+=1
    rank=score if policy[-1]=='desc' else -score
    item=(rank,b['key'],i,j,score)
    if len(heap)<offset+20:heapq.heappush(heap,item)
    elif item>heap[0]:heapq.heapreplace(heap,item)
  chosen=sorted(heap,reverse=True)[offset:offset+20];items=[];contexts={}
  with store.db() as db:
   for _,key,i,j,score in chosen:
    if key not in contexts:contexts[key]=decode(db.execute('SELECT context FROM discovery_score_blocks WHERE generation=? AND key=?',(generation,key)).fetchone()[0])
    c=contexts[key];row=c['rows'][i];unit=c['units'][j]
    items.append({'id':f'{key}:{i}:{j}','table_name':row.get('name',row['asset_id']),'document_name':c['text_name'],'row_index':row['record_index'],
      'score':score,'row_preview':row['text'],'text_preview':unit['text'],'start':unit['start'],'end':unit['end']})
  return {'generation':generation,'total':total,'offset':offset,'items':items,'histogram':hist,'complete_scores':r['matrix']['cells']}

def publish(store,before,report,links,bridges,check,contexts=()):
 with store.lock:
  check()
  if discovery.current_signature(store,(report.get('scope') or {}).get('id'))!=before:raise ValueError('Lake or model changed during Discovery; results were not published')
  with store.db() as db:
   from integration import pin_saved
   pin_saved(db)
   db.execute('DELETE FROM discovery_links');db.execute('DELETE FROM discovery_bridges');db.execute('DELETE FROM discovery_cache')
   db.executemany('INSERT INTO discovery_cache VALUES(?,?,?)',((c['key'],json.dumps(c['members']),encode(c)) for c in contexts))
   db.executemany('INSERT INTO discovery_links VALUES(?,?,?,?,?)',((l['id'],l['table'],l['text'],l['score'],encode(l)) for l in links))
   db.executemany('INSERT INTO discovery_bridges VALUES(?,?,?)',((b['id'],b['score'],json.dumps(b)) for b in bridges))
   db.execute('INSERT OR REPLACE INTO discovery_report VALUES(1,?,?,?)',(before,uuid.uuid4().hex,json.dumps(report)))
   db.execute('DELETE FROM discovery_score_blocks WHERE generation<>?',(report['matrix']['generation'],))


def compute(store,scope_id=None,execute=discovery.worker,check=lambda:None,progress=lambda **kw:None):
 setup(store);discovery.setup(store);before=discovery.current_signature(store,scope_id)
 if before is None:raise ValueError('A current profile is required')
 old=discovery.status(store)
 with store.db() as db:
  previous=db.execute('SELECT data FROM discovery_report WHERE id=1').fetchone()
  previous_matrix=(decode(previous['data']).get('matrix') or {}) if previous else {}
  previous_generation=previous_matrix.get('generation','') if previous_matrix.get('version')==VERSION else ''
 # Published and orphaned blocks are retained until a successful atomic replacement.
 if old['status']=='ready' and old.get('matrix',{}).get('version')==VERSION and (old.get('scope') or {}).get('id')==scope_id:
  progress(phase='Complete saved scores reused; no model call',completed=old['matrix']['contexts'],total=old['matrix']['contexts']);return old
 import profiling,discovery_scope
 profile=profiling.read(store);contexts,sources=discovery.contexts_for(store,profile,-1,check=check,progress=progress,scope_id=scope_id)
 if not contexts:raise ValueError('No eligible indexed row–text contexts in this scope')
 generation=uuid.uuid4().hex;started=time.perf_counter();count=0;size=0;hist=[0]*20;device=None;peak=0;published=False;reused=0
 session=discovery.WorkerSession(store) if execute is discovery.worker else None
 batch_execute=session.execute if session else execute
 try:
  for offset in range(0,len(contexts),4):
   check();batch=[{**c,'full_scores':True} for c in contexts[offset:offset+4]]
   progress(phase='Computing complete LOKI score blocks',completed=offset,total=len(contexts))
   outputs={};missing=[]
   with store.db() as db:
    for c in batch:
     cached=db.execute('SELECT * FROM discovery_score_blocks WHERE generation=? AND key=?',(previous_generation,c['key'])).fetchone()
     if cached:
      outputs[c['key']]={'scores':base64.b64encode(cached['scores']).decode(),'score_format':'f32le-zlib','rows':len(c['rows']),'units':len(c['units']),'global_score':cached['global_score'],'sentence_vectors':decode(cached['vectors'])};reused+=1
     else:missing.append(c)
   if missing:
    out=batch_execute(store,missing,-1,check,lambda n:progress(completed=offset+n,total=len(contexts)))
    if not out.get('strict_load') or len(out.get('contexts',[]))!=len(missing):raise ValueError('Incomplete LOKI matrix response')
    outputs.update((c['key'],r) for c,r in zip(missing,out['contexts']))
    device=out.get('device');peak=max(peak,out.get('peak_reserved_gib') or 0)
   with store.db() as db:
    for c in batch:
     result=outputs[c['key']]
     if result.get('score_format')!='f32le-zlib' or result['rows']!=len(c['rows']) or result['units']!=len(c['units']):raise ValueError('LOKI matrix dimensions differ from source mapping')
     if not math.isfinite(result['global_score']):raise ValueError('Invalid global LOKI score')
     blob=base64.b64decode(result['scores'],validate=True);a=values(blob,result['rows'],result['units']);count+=len(a);size+=len(blob)
     for v in a:hist[min(19,max(0,int((v+1)*10)))]+=1
     db.execute('INSERT INTO discovery_score_blocks VALUES(?,?,?,?,?,?)',(generation,c['key'],encode(c),blob,encode(result.get('sentence_vectors',{})),result['global_score']))
  report={'version':discovery.VERSION,'retention_policy':policy_for(store),'threshold':None,'scope':discovery_scope.read(store,scope_id) if scope_id else None,
   'sources':[{'id':aid,'name':s['name']} for aid,s in sources.items()],
   'matrix':{'version':VERSION,'generation':generation,'cells':count,'contexts':len(contexts),'score_bytes':size,'histogram':hist,
     'tables':len({r['asset_id'] for c in contexts for r in c['rows']}),'documents':len({c['text_id'] for c in contexts}),
     'rows':len({(r['asset_id'],r['record_index']) for c in contexts for r in c['rows']}),'text_units':len({(c['text_id'],u['start'],u['end']) for c in contexts for u in c['units']})},
   'summary':{'contexts':len(contexts),'links':0,'bridges':0,'one_sided':0,'rows_without_links':0},
   'coverage':{'max_row_combinations_omitted':max((c.get('row_combinations_omitted',0) for c in contexts),default=0),'sampled_sources':sum(s.get('coverage',{}).get('sampled',False) for s in sources.values()),'split_contexts':sum(c['split_document_context'] for c in contexts),'eligible_links':count,'bridge_group_links_omitted':0,'bridges_omitted':0},
   'work':{'reused_contexts':reused,'scored_contexts':len(contexts)-reused,'device':device,'peak_reserved_gib':peak,'seconds':time.perf_counter()-started},
   'storage':{'policy':'complete numeric scores; evidence not prepared','scored_links':count,'retained_links':0},
   'notice':'All scores in eligible scoped contexts are saved. Overlapping contexts count separately. Scores are similarities, not probabilities. Prepare an evidence view after filtering to use Integration.'}
  publish(store,before,report,[],[],check);published=True;__import__('storage_compaction').reclaim_after_publication(store);progress(phase='Complete scores ready to explore',completed=len(contexts),total=len(contexts));return discovery.status(store)
 finally:
  if session:session.close()
  if not published:
   with store.db() as db:db.execute('DELETE FROM discovery_score_blocks WHERE generation=?',(generation,))

def apply(store,body,check=lambda:None,progress=lambda **kw:None):
 policy=filters(body);original=current(store,body.get('generation'));generation=original['matrix']['generation'];scope_id=(original.get('scope') or {}).get('id');before=discovery.current_signature(store,scope_id)
 import profiling
 roles=source_roles(profiling.read(store));links=[];retained_contexts=[];eligible=0;bounded_count=0;started=time.perf_counter()
 for n,(b,c) in enumerate(blocks(store,generation)):
  check();a=values(b['scores'],len(c['rows']),len(c['units']));selected=list(cells(c,a,policy));eligible+=len(selected)
  # Evidence is a bounded derivative. Complete numerical matrices remain untouched.
  byrow={}
  for i,j,score in selected:byrow.setdefault(i,[]).append({'row':i,'unit':j,'score':score})
  bounded=[l for row in byrow.values() for l in sorted(row,key=lambda l:(-l['score'],l['unit']))[:32]]
  bounded_count+=len(bounded)
  result={'rows':len(c['rows']),'units':len(c['units']),'global_score':b['global_score'],'eligible_links':len(selected),'links':bounded,'sentence_vectors':decode(b['vectors'])}
  retained=retain(discovery.materialize(c,result,policy[0]),roles,policy=policy_for(store));links.extend(retained['links']);retained_contexts.append(retained)
  progress(phase='Preparing evidence from saved scores · no model calls',completed=n+1,total=original['matrix']['contexts'])
 check();progress(phase='Building cross-table paths from filtered evidence',completed=original['matrix']['contexts'],total=original['matrix']['contexts'])
 bridges,bounds=discovery.bridges_for(links,cap=bridge_cap(body))
 report={k:v for k,v in original.items() if k not in ('job','status','revision')}
 report.update(retention_policy=policy_for(store),threshold=policy[0],evidence_filter={'min_score':policy[0],'max_score':policy[1],'top_k':policy[2],'source':policy[3],'bridge_cap':bridge_cap(body)},
  summary={**report['summary'],'links':len(links),'bridges':len(bridges),'one_sided':sum(l['one_sided'] for l in links)},
  coverage={**report['coverage'],'eligible_links':eligible,**bounds},
  storage={'policy':policy_for(store),'scored_links':original['matrix']['cells'],'retained_links':len(links)},
  filter_work={'seconds':time.perf_counter()-started,'model_calls':0},
  handoff={'version':1,'kind':'published_discovery_evidence','prepared_at':time.time(),
   'observations':{'scored':original['matrix']['cells'],'matching':eligible,
    'outside_filter':original['matrix']['cells']-eligible,'after_row_bound':bounded_count,
    'row_bound_omitted':eligible-bounded_count,'retention_omitted':bounded_count-len(links)},
   'published':{'link_entries':len(links),'unique_row_spans':len({(l['table'],l['row_version'],l['row_index'],l['text'],l['text_version'],l['start'],l['end']) for l in links}),
    'shared_span_paths':len(bridges),'paths_before_cap':len(bridges)+bounds['bridges_omitted']},
   'limits':{'links_per_row_context':32,'links_per_shared_span':12,'bridge_cap':bridge_cap(body)},
   'consumer':'Integration constructs and ranks row-pair candidates from published link entries; the shared-span path list is a separate inspection view.'},
  notice='Evidence prepared from complete saved scores. Per-row and join-path retention limits apply to this Integration view, not to the saved matrix.')
 with store.lock:
  current(store,generation)
  progress(phase='Saving prepared evidence',completed=original['matrix']['contexts'],total=original['matrix']['contexts'])
 publish(store,before,report,links,bridges,check,retained_contexts)
 return discovery.status(store)
