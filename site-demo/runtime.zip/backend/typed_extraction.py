"""Typed extraction extensions and prompt management for IDUN Augmentation (Stage 11.F).

Provides:
- Separately named, editable generic LLM prompts for seedless concepts, numeric, date, and unit extraction.
- Engine modes: 'thor', 'typed_llm', and 'hybrid' with explicit proposal-level labeling.
- Bounded typed extraction requiring exact passage evidence, explicit normalization, units, temporal scope, precision, and range validation.
- Rejection of unsupported or ungrounded numerical predictions.
- Lake-scoped prompt configuration with immutable per-job snapshotting.
- Storage and telemetry measurement (disk use, retrieval coverage, validation quality, acceptance rate, shared evidence compression).
"""

import copy
import hashlib
import json
import logging
import re
import time
import uuid
import urllib.request
import urllib.error
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

logger = logging.getLogger("idun.typed_extraction")

TYPED_EXTRACTION_PROMPT_ID = "typed-extraction-v1"

DEFAULT_TYPED_SYSTEM_TEMPLATE = (
    "You are an evidence-grounded typed attribute extractor for structured data records.\n"
    "Given a target concept, its expected data type (numeric, date, unit_quantity, or qualitative string), "
    "the target record's known context attributes, and an evidence passage from an untrusted source document:\n"
    "Extract the exact value of the concept for this specific target entity.\n\n"
    "CRITICAL RULES:\n"
    "1. Grounding: Every extracted value MUST be directly supported by the narrative evidence for THIS specific entity/subject.\n"
    "2. No Unsupported Predictions: Never invent, extrapolate, or estimate numerical or date values. If not explicitly stated, return status 'unresolved'.\n"
    "3. Negation & Hypotheticals: If the value is negated, hypothetical, or refers to another subject, set attribution status accordingly ('negated', 'hypothetical', 'wrong_subject').\n"
    "4. Raw Quote: Always provide 'raw_quoted' as the exact verbatim substring from the evidence passage.\n"
    "5. Normalization: Standardize numbers to floats/integers, dates to ISO 8601 (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS), and units to standard symbols (e.g. 'mg', 'mg/dL', 'kg', 'years').\n"
    "6. Validation: Validate that numbers have physical units if required, dates are plausible, and values fall within expected domains.\n"
    "Output only valid JSON."
)

DEFAULT_TYPED_PROMPT_CONFIG: Dict[str, Any] = {
    "prompt_id": TYPED_EXTRACTION_PROMPT_ID,
    "name": "Evidence-Grounded Typed Attribute Extractor",
    "description": "Extracts normalized numerical, date, and unit values with exact quote verification and attribution checks.",
    "system_template": DEFAULT_TYPED_SYSTEM_TEMPLATE,
    "temperature": 0.0,
    "max_tokens": 512,
    "version": "1.0.0",
}


def get_typed_prompt(store: Any) -> Dict[str, Any]:
    """Retrieves the lake-scoped typed extraction prompt configuration, falling back to default."""
    path = getattr(store, "root", None)
    if path:
        cfg_file = Path(path) / "typed_prompt.json"
        if cfg_file.exists():
            try:
                return json.loads(cfg_file.read_text(encoding="utf-8"))
            except Exception as e:
                logger.warning("Failed to read lake typed_prompt.json: %s", e)
    return copy.deepcopy(DEFAULT_TYPED_PROMPT_CONFIG)


def save_typed_prompt(store: Any, config: Dict[str, Any]) -> Dict[str, Any]:
    """Saves a customized typed extraction prompt configuration for the lake."""
    cfg = copy.deepcopy(DEFAULT_TYPED_PROMPT_CONFIG)
    cfg.update(config)
    cfg["updated_at"] = time.time()
    template_str = cfg.get("system_template", "")
    cfg["hash"] = hashlib.sha256(template_str.encode("utf-8")).hexdigest()[:16]

    path = getattr(store, "root", None)
    if path:
        cfg_file = Path(path) / "typed_prompt.json"
        cfg_file.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return cfg


def snapshot_typed_prompt(store: Any, custom_prompt: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Creates an immutable prompt snapshot for an augmentation run."""
    base = custom_prompt if custom_prompt else get_typed_prompt(store)
    template_str = base.get("system_template", DEFAULT_TYPED_SYSTEM_TEMPLATE)
    prompt_hash = hashlib.sha256(template_str.encode("utf-8")).hexdigest()[:16]
    return {
        "snapshot_id": f"snap_{uuid.uuid4().hex[:12]}",
        "prompt_id": base.get("prompt_id", TYPED_EXTRACTION_PROMPT_ID),
        "name": base.get("name", "Typed Extraction Prompt"),
        "system_template": template_str,
        "hash": prompt_hash,
        "temperature": base.get("temperature", 0.0),
        "version": base.get("version", "1.0.0"),
        "snapshotted_at": time.time(),
    }


def normalize_numeric_string(raw: str) -> Tuple[Optional[Union[int, float]], Optional[str], str]:
    """Extracts and normalizes a number and its accompanying unit from raw text.
    
    Returns (normalized_value, unit, precision).
    """
    clean = raw.strip()
    match = re.search(
        r"([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)\s*([A-Za-z/%_^\-]+(?:\s*per\s*[A-Za-z]+)?)?",
        clean,
    )
    if not match:
        return None, None, "unknown"

    num_str = match.group(1)
    unit_str = match.group(2).strip() if match.group(2) else None

    # Determine precision
    if "." in num_str or "e" in num_str.lower():
        decimals = len(num_str.split(".")[1]) if "." in num_str else 0
        precision = f"float_{decimals}"
        val = float(num_str)
    else:
        precision = "integer"
        val = int(num_str)

    # Standardize unit symbols
    if unit_str:
        u_lower = unit_str.lower()
        if u_lower in ("mg/dl", "mg/100ml"):
            unit_str = "mg/dL"
        elif u_lower in ("g/dl",):
            unit_str = "g/dL"
        elif u_lower in ("ml", "milliliter", "milliliters"):
            unit_str = "mL"
        elif u_lower in ("l", "liter", "liters"):
            unit_str = "L"
        elif u_lower in ("kg", "kilogram", "kilograms"):
            unit_str = "kg"
        elif u_lower in ("mg", "milligram", "milligrams"):
            unit_str = "mg"
        elif u_lower in ("mcg", "ug", "microgram", "micrograms"):
            unit_str = "mcg"
        elif u_lower in ("%", "percent", "pct"):
            unit_str = "%"
        elif u_lower in ("day", "days"):
            unit_str = "days"
        elif u_lower in ("year", "years", "yr", "yrs"):
            unit_str = "years"
        elif u_lower in ("hour", "hours", "hr", "hrs"):
            unit_str = "hours"

    return val, unit_str, precision


def normalize_date_string(raw: str) -> Tuple[Optional[str], str]:
    """Normalizes dates to ISO 8601 (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS).
    
    Returns (iso_date_string, precision).
    """
    clean = raw.strip()
    from datetime import date, datetime
    # ISO full datetime
    dt_match = re.search(r"(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}(?::\d{2})?)", clean)
    if dt_match:
        try: return datetime.fromisoformat(dt_match.group(0)).isoformat(), "datetime"
        except ValueError: return None, "unknown"

    # ISO date YYYY-MM-DD
    d_match = re.search(r"\b(\d{4})-(\d{2})-(\d{2})\b", clean)
    if d_match:
        y, m, d = int(d_match.group(1)), int(d_match.group(2)), int(d_match.group(3))
        try: return date(y, m, d).isoformat(), "day"
        except ValueError: return None, "unknown"

    # US date MM/DD/YYYY
    us_match = re.search(r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b", clean)
    if us_match:
        m, d, y = int(us_match.group(1)), int(us_match.group(2)), int(us_match.group(3))
        try: return date(y, m, d).isoformat(), "day"
        except ValueError: return None, "unknown"

    # Year only
    y_match = re.search(r"\b(19\d\d|20\d\d)\b", clean)
    if y_match:
        return y_match.group(1), "year"

    return None, "unknown"


def validate_quote_grounding(raw_quote: str, passage_text: str) -> bool:
    """Verifies that the raw quoted text appears verbatim in the passage."""
    if not raw_quote or not passage_text:
        return False
    return raw_quote in passage_text


def detect_attribution_cues(passage_text: str, quote: str) -> Tuple[str, str]:
    """Checks linguistic markers surrounding the quote for negation, hypotheticals, or third-party subjects."""
    lower_text = passage_text.lower()
    lower_quote = quote.lower()
    idx = lower_text.find(lower_quote)
    if idx == -1:
        return "unresolved", "Quote not found in evidence text"

    # Context window around quote
    start_win = max(0, idx - 80)
    end_win = min(len(lower_text), idx + len(lower_quote) + 80)
    window = lower_text[start_win:end_win]

    # Negation
    neg_patterns = [
        r"\b(?:no|not|denies|denied|without|negative for|absent|ruled out)\b",
        r"\b(?:discontinued|stopped|ceased|withdrawn)\b",
    ]
    for np in neg_patterns:
        if re.search(np, window):
            return "negated", f"Negation or cessation cue detected in context window: '{window.strip()}'"

    # Hypothetical / conditional
    hypo_patterns = [
        r"\b(?:suspected|possible|potential|risk of|evaluate for|consider|rule out|presumed)\b",
        r"\b(?:might|may|could|would)\b",
    ]
    for hp in hypo_patterns:
        if re.search(hp, window):
            return "hypothetical", f"Hypothetical or uncertainty cue detected in context window: '{window.strip()}'"

    # Wrong subject / family history
    subj_patterns = [
        r"\b(?:mother|father|sister|brother|sibling|parent|family history|maternal|paternal|spouse)\b",
    ]
    for sp in subj_patterns:
        if re.search(sp, window):
            return "wrong_subject", f"Third-party or familial subject cue detected in context window: '{window.strip()}'"

    return "attributed", "Quote directly supported and attributed in passage context"


def parse_and_validate_typed_value(
    raw_quoted: str,
    passage_text: str,
    expected_type: Optional[str] = None,
    expected_unit: Optional[str] = None,
    bounds: Optional[Tuple[float, float]] = None,
) -> Dict[str, Any]:
    """Validates raw text against passage evidence and parses normalized typed values."""
    if not validate_quote_grounding(raw_quoted, passage_text):
        return {
            "valid": False,
            "raw_quoted": raw_quoted,
            "normalized_value": None,
            "value_type": expected_type or "string",
            "unit": None,
            "temporal_scope": None,
            "precision": "unknown",
            "validation": "unsupported_quote",
            "attribution_status": "unresolved",
            "attribution_rationale": "Quoted value does not appear verbatim in evidence passage",
        }

    attr_status, attr_rationale = detect_attribution_cues(passage_text, raw_quoted)

    def invalid(reason):
        return {'valid':False,'raw_quoted':raw_quoted,'normalized_value':None,'value_type':expected_type or 'string',
            'unit':None,'temporal_scope':None,'precision':'unknown','validation':'unparseable',
            'attribution_status':'unresolved','attribution_rationale':reason}
    if expected_type in ('string','qualitative'):
        if re.fullmatch(r'[\d\s.,+%/:-]+', raw_quoted.strip()):
            return invalid('Expected a descriptive string; evidence contains only a number/date/code')
        return {'valid':True,'raw_quoted':raw_quoted,'normalized_value':raw_quoted.strip(),'value_type':'string',
            'unit':None,'temporal_scope':None,'precision':'string','validation':'valid',
            'attribution_status':attr_status,'attribution_rationale':attr_rationale}
    if expected_type == 'date' and not normalize_date_string(raw_quoted)[0]: return invalid('Expected a valid date')
    if expected_type in ('numeric','unit_quantity') and not re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?(?:\s*[A-Za-z/%_^\-]+(?:\s*per\s*[A-Za-z]+)?)?',raw_quoted.strip()):
        return invalid('Expected a complete numeric value, not an incidental number in prose')
    # Determine type and normalize
    # 1. Date
    if expected_type == "date" or (not expected_type and re.search(r"\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b", raw_quoted)):
        iso_val, prec = normalize_date_string(raw_quoted)
        if iso_val:
            return {
                "valid": True,
                "raw_quoted": raw_quoted,
                "normalized_value": iso_val,
                "value_type": "date",
                "unit": None,
                "temporal_scope": None,
                "precision": prec,
                "validation": "valid",
                "attribution_status": attr_status,
                "attribution_rationale": attr_rationale,
            }

    # 2. Numeric / Unit Quantity
    num_val, unit_val, prec = normalize_numeric_string(raw_quoted)
    if num_val is not None:
        if expected_type == 'unit_quantity' and not unit_val: return invalid('Quantity requires a unit in the quoted evidence')
        if expected_unit and unit_val and expected_unit.casefold() != unit_val.casefold(): return invalid('Quoted unit differs from the expected unit; no conversion performed')
        effective_unit = unit_val
        is_unit_quantity = bool(effective_unit)

        # Check bounds if specified
        if bounds and (num_val < bounds[0] or num_val > bounds[1]):
            return {
                "valid": False,
                "raw_quoted": raw_quoted,
                "normalized_value": num_val,
                "value_type": "unit_quantity" if is_unit_quantity else "numeric",
                "unit": effective_unit,
                "temporal_scope": None,
                "precision": prec,
                "validation": "out_of_range",
                "attribution_status": "unresolved",
                "attribution_rationale": f"Value {num_val} is out of expected domain bounds {bounds}",
            }

        return {
            "valid": True,
            "raw_quoted": raw_quoted,
            "normalized_value": num_val,
            "value_type": "unit_quantity" if is_unit_quantity else "numeric",
            "unit": effective_unit,
            "temporal_scope": None,
            "precision": prec,
            "validation": "valid",
            "attribution_status": attr_status,
            "attribution_rationale": attr_rationale,
        }

    # 3. String / Qualitative fallback
    clean_val = raw_quoted.strip()
    return {
        "valid": bool(clean_val),
        "raw_quoted": raw_quoted,
        "normalized_value": clean_val,
        "value_type": "string",
        "unit": None,
        "temporal_scope": None,
        "precision": "string",
        "validation": "valid" if clean_val else "unparseable",
        "attribution_status": attr_status,
        "attribution_rationale": attr_rationale,
    }


def find_sentence_bounds(text: str, start: int, end: int) -> Tuple[int, int]:
    """Finds the character bounds of the sentence enclosing [start, end]."""
    s_start = 0
    for p in (text.rfind('.', 0, start), text.rfind('\n', 0, start), text.rfind(';', 0, start)):
        if p != -1 and p + 1 > s_start:
            s_start = p + 1
    while s_start < start and text[s_start].isspace():
        s_start += 1

    s_end = len(text)
    for p in (text.find('.', end), text.find('\n', end), text.find(';', end)):
        if p != -1 and p < s_end:
            s_end = p + 1
    return s_start, s_end


def is_llm_active(store: Any) -> Tuple[bool, Dict[str, Any]]:
    """Checks whether an active LLM provider and model are configured. Requests report connection failures directly."""
    import settings, lake_config
    cfg = dict(settings.read(store).get("llm", {}))
    for key, value in lake_config.read_lake_config(store).get('llm_overrides', {}).items():
        if key in cfg and key != 'key_env' and value is not None: cfg[key] = value
    return cfg.get('provider') not in ('disabled', '', None) and bool(cfg.get('model', '').strip()), cfg


def extract_typed_attribute_deterministic(
    concept: Dict[str, Any],
    target_record: Dict[str, Any],
    evidence_context: Dict[str, Any],
    engine_label: str = "heuristic",
) -> Optional[Dict[str, Any]]:
    """Deterministic extractor for offline, test, or local runtime without active LLM."""
    text = evidence_context.get("text", "")
    if not text:
        return None
    col_name = concept.get("name", "")
    col_lower = col_name.lower()

    # 1. Specialized clinical frequency matcher for concepts like per_day, frequency, daily
    is_frequency = any(f in col_lower for f in ("per_day", "frequency", "daily", "times_per_day", "freq"))
    if is_frequency:
        med_freq_patterns = [
            (r'\b(?:every|q)\s*24\s*h(?:ours?)?\b', 1, "times/day"),
            (r'\b(?:every|q)\s*12\s*h(?:ours?)?\b', 2, "times/day"),
            (r'\b(?:every|q)\s*8\s*h(?:ours?)?\b', 3, "times/day"),
            (r'\b(?:every|q)\s*6\s*h(?:ours?)?\b', 4, "times/day"),
            (r'\b(?:every|q)\s*4\s*h(?:ours?)?\b', 6, "times/day"),
            (r'\b(?:once|1\s*time|1x)\s*(?:a|per)?\s*(?:day|daily)\b', 1, "times/day"),
            (r'\b(?:twice|2\s*times|2x)\s*(?:a|per)?\s*(?:day|daily)\b', 2, "times/day"),
            (r'\b(?:three\s*times|3\s*times|3x)\s*(?:a|per)?\s*(?:day|daily)\b', 3, "times/day"),
            (r'\b(?:four\s*times|4\s*times|4x)\s*(?:a|per)?\s*(?:day|daily)\b', 4, "times/day"),
            (r'\b(?:bid|b\.i\.d\.)\b', 2, "times/day"),
            (r'\b(?:tid|t\.i\.d\.)\b', 3, "times/day"),
            (r'\b(?:qid|q\.i\.d\.)\b', 4, "times/day"),
            (r'\b(?:qd|q\.d\.|daily)\b', 1, "times/day"),
            (r'\b(\d{1,2})\s*(?:times?\s*(?:a|per)\s*day|x\s*daily)\b', None, "times/day"),
        ]
        for pat, calc_val, unit in med_freq_patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                raw_quote = m.group(0)
                norm_val = calc_val if calc_val is not None else int(m.group(1))
                abs_start = m.start(0)
                abs_end = m.end(0)
                sent_start, sent_end = find_sentence_bounds(text, abs_start, abs_end)
                attr_status, attr_rat = detect_attribution_cues(text, raw_quote)
                return {
                    "valid": True,
                    "normalized_value": norm_val,
                    "unit": unit,
                    "precision": "integer",
                    "raw_quoted": raw_quote,
                    "validation": "valid",
                    "attribution_status": attr_status,
                    "attribution_rationale": attr_rat,
                    "found": True,
                    "engine": engine_label,
                    "start": abs_start,
                    "end": abs_end,
                    "sentence_start": sent_start,
                    "sentence_end": sent_end,
                    "concept": concept,
                    "evidence_context": evidence_context
                }
        # For frequency concepts, do not fall through to extract unrelated weights, heights, or blood pressures
        return None

    # Look for patterns near concept name or anchor keywords in text
    keywords = [col_lower]
    subwords = [w for w in re.split(r'[_ \-]+', col_lower) if len(w) >= 3]
    keywords.extend(subwords)

    # Add common aliases
    if "weight" in col_lower:
        keywords.extend(["weight", "wt", "kg", "lbs"])
    elif "age" in col_lower:
        keywords.extend(["age", "years old", "yo", "yr old"])
    elif "blood" in col_lower or "glucose" in col_lower:
        keywords.extend(["glucose", "bg", "mg/dl"])
    elif "date" in col_lower or "time" in col_lower:
        keywords.extend(["date", "on", "admitted", "started"])

    # First attempt: search near matched keywords
    matched_pos = -1
    for kw in keywords:
        p = text.lower().find(kw)
        if p != -1:
            matched_pos = p
            break

    search_snippets = []
    if matched_pos != -1:
        s_start = max(0, matched_pos - 40)
        s_end = min(len(text), matched_pos + 120)
        search_snippets.append((s_start, text[s_start:s_end]))
    # Fallback snippet if short text
    if len(text) <= 1000:
        search_snippets.append((0, text))

    for snippet_offset, snippet in search_snippets:
        # Check for numeric pattern in snippet
        num_match = re.search(
            r"\b([+-]?(?:\d+(?:\.\d*)?|\.\d+)\s*(?:mg/dL|g/dL|mL|L|kg|mg|mcg|%|years|days)?)\b",
            snippet,
            re.IGNORECASE,
        )
        if num_match:
            candidate_str = num_match.group(1).strip()
            # Verify candidate has at least one digit
            if any(c.isdigit() for c in candidate_str):
                parsed = parse_and_validate_typed_value(
                    candidate_str,
                    text,
                    expected_type="numeric",
                )
                if parsed["valid"]:
                    abs_start = snippet_offset + num_match.start(1)
                    abs_end = snippet_offset + num_match.end(1)
                    sent_start, sent_end = find_sentence_bounds(text, abs_start, abs_end)
                    parsed["found"] = True
                    parsed["engine"] = engine_label
                    parsed["start"] = abs_start
                    parsed["end"] = abs_end
                    parsed["sentence_start"] = sent_start
                    parsed["sentence_end"] = sent_end
                    parsed["concept"] = concept
                    parsed["evidence_context"] = evidence_context
                    return parsed

        # Check for date pattern
        date_match = re.search(r"\b(\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{4})\b", snippet)
        if date_match:
            candidate_str = date_match.group(1).strip()
            parsed = parse_and_validate_typed_value(
                candidate_str,
                text,
                expected_type="date",
            )
            if parsed["valid"]:
                abs_start = snippet_offset + date_match.start(1)
                abs_end = snippet_offset + date_match.end(1)
                sent_start, sent_end = find_sentence_bounds(text, abs_start, abs_end)
                parsed["found"] = True
                parsed["engine"] = engine_label
                parsed["start"] = abs_start
                parsed["end"] = abs_end
                parsed["sentence_start"] = sent_start
                parsed["sentence_end"] = sent_end
                parsed["concept"] = concept
                parsed["evidence_context"] = evidence_context
                return parsed

    return None


def extract_typed_attribute_llm(
    concept: Dict[str, Any],
    target_record: Dict[str, Any],
    evidence_context: Dict[str, Any],
    llm_config: Dict[str, Any],
    prompt_snapshot: Optional[Dict[str, Any]] = None,
    engine_label: str = "typed_llm",
) -> Optional[Dict[str, Any]]:
    """Extracts a typed attribute from evidence passage using the active LLM backend."""
    import credentials
    from settings import NoRedirect

    text = evidence_context.get("text", "")
    if not text:
        return None

    col_name = concept.get("name") or target_record.get("column_name", "")
    expected_type = concept.get("expected_type", "any")
    expected_unit = concept.get("expected_unit")
    bounds = concept.get("bounds")

    system_template = (
        prompt_snapshot.get("system_template")
        if prompt_snapshot and prompt_snapshot.get("system_template")
        else DEFAULT_TYPED_SYSTEM_TEMPLATE
    )

    # Compile known context from other non-null attributes of the target row if available
    row_ctx = target_record.get("row_context") or {}

    user_prompt = (
        f"Target Column / Concept: {col_name}\n"
        f"Expected Data Type: {expected_type}"
        + (f" (Expected Unit: {expected_unit})" if expected_unit else "")
        + f"\nTarget Record Known Attributes: {json.dumps(row_ctx, default=str)}\n\n"
        f"Evidence Passage:\n\"\"\"{text}\"\"\"\n\n"
        "Extract the exact value and return valid JSON with schema:\n"
        "{\n"
        '  "found": true | false,\n'
        '  "raw_quoted": "exact verbatim string from passage",\n'
        '  "normalized_value": number | string | null,\n'
        '  "value_type": "numeric" | "date" | "unit_quantity" | "string",\n'
        '  "unit": "standard unit symbol or null",\n'
        '  "attribution_status": "attributed" | "negated" | "hypothetical" | "wrong_subject" | "unresolved",\n'
        '  "attribution_rationale": "short explanation"\n'
        "}"
    )

    if concept.get('seeds'):
        user_prompt += '\nObserved seed values (hints only; never evidence): ' + json.dumps([v.get('value') for v in concept['seeds'][:20]])
    messages = [
        {"role": "system", "content": system_template},
        {"role": "user", "content": user_prompt},
    ]

    from relationship_probe import structured_request
    import llm
    cfg = dict(llm_config)
    cfg['temperature'] = (prompt_snapshot or {}).get('temperature', cfg.get('temperature'))
    schema = llm.obj({
        'found': {'type':'boolean'}, 'raw_quoted': {'type':'string'},
        'value_type': {'type':'string','enum':['numeric','date','unit_quantity','string']},
        'unit': {'type':['string','null']},
        'attribution_status': {'type':'string','enum':['attributed','negated','hypothetical','wrong_subject','unresolved']},
        'attribution_rationale': {'type':'string'},
    })
    check = (prompt_snapshot or {}).get('_check', lambda: None)
    counter = (prompt_snapshot or {}).get('_on_llm_call', lambda: None)
    check(); counter()
    if cfg.get('provider') == 'huggingface':
        parsed_llm = structured_request(cfg, messages, schema, cfg.get('timeout_seconds',0), check)
    else:
        parsed_llm = llm.request_cancellable({'operation':'typed_attribute','config':cfg,'messages':messages,
            'schema':schema,'timeout':cfg.get('timeout_seconds',0)},check)
    if not isinstance(parsed_llm, dict) or type(parsed_llm.get('found')) is not bool:
        raise ValueError('Invalid typed extraction response: expected found boolean')
    if not parsed_llm.get("found", True):
        return None

    raw_quoted = str(parsed_llm.get("raw_quoted") or "").strip()
    if not raw_quoted:
        return None

    eff_type = expected_type if expected_type != "any" else parsed_llm.get("value_type")
    eff_unit = expected_unit or parsed_llm.get("unit")

    val = parse_and_validate_typed_value(
        raw_quoted,
        text,
        expected_type=eff_type,
        expected_unit=eff_unit,
        bounds=bounds,
    )

    llm_attr = parsed_llm.get("attribution_status")
    if llm_attr not in ("attributed", "negated", "hypothetical", "wrong_subject", "unresolved"):
        raise ValueError("Invalid attribution status from LLM")
    if llm_attr != "attributed" and val["attribution_status"] == "attributed":
        val["attribution_status"] = llm_attr
        if parsed_llm.get("attribution_rationale"):
            val["attribution_rationale"] = parsed_llm["attribution_rationale"]

    start_pos = text.find(raw_quoted)
    if start_pos != -1:
        end_pos = start_pos + len(raw_quoted)
    else:
        start_pos = 0
        end_pos = len(raw_quoted)

    sent_start, sent_end = find_sentence_bounds(text, start_pos, end_pos)

    val["found"] = True
    val["engine"] = engine_label
    val["start"] = start_pos
    val["end"] = end_pos
    val["sentence_start"] = sent_start
    val["sentence_end"] = sent_end
    val["concept"] = concept
    val["evidence_context"] = evidence_context
    return val


def extract_typed_attribute(
    concept: Dict[str, Any],
    target_record: Dict[str, Any],
    evidence_context: Dict[str, Any],
    engine_label: str = "heuristic",
    store: Any = None,
    prompt_snapshot: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """Dispatches extraction to LLM or deterministic engine based on engine mode and reachability."""
    if engine_label == 'typed_llm':
        if not store: raise ValueError('Typed LLM extraction requires a configured lake')
        cfg = (prompt_snapshot or {}).get('_llm_config')
        if cfg is None:
            active, cfg = is_llm_active(store)
            if not active: raise ValueError('Configure an LLM provider and model in Settings before Typed LLM or Hybrid extraction')
        return extract_typed_attribute_llm(concept,target_record,evidence_context,cfg,
            prompt_snapshot=prompt_snapshot,engine_label=engine_label)
    if engine_label != 'heuristic': raise ValueError('Unknown typed extraction engine')
    return extract_typed_attribute_deterministic(concept,target_record,evidence_context,engine_label='heuristic')


def calculate_telemetry(store: Any, run_id: str) -> Dict[str, Any]:
    """Measures disk use, retrieval coverage, validation quality, acceptance rate, and evidence compression."""
    with store.db() as db:
        run_row = db.execute("SELECT * FROM augmentation_runs WHERE id=?", (run_id,)).fetchone()
        if not run_row:
            return {}

        prop_rows = db.execute("SELECT data, decision FROM augmentation_proposals WHERE run_id=?", (run_id,)).fetchall()
        view_rows = db.execute("SELECT data FROM augmentation_views WHERE run_id=?", (run_id,)).fetchall()

        total_proposals = len(prop_rows)
        props = [json.loads(r["data"]) for r in prop_rows]

        # 1. Disk usage calculation (rough SQLite row content size)
        run_bytes = len(str(dict(run_row)))
        prop_bytes = sum(len(r["data"]) for r in prop_rows)
        view_bytes = sum(len(r["data"]) for r in view_rows)
        total_disk_bytes = run_bytes + prop_bytes + view_bytes

        # 2. Retrieval coverage: targets with >= 1 evidence context
        targets_set = {p.get("target_id") for p in props if p.get("target_id")}
        targets_with_evidence = {
            p.get("target_id") for p in props if p.get("evidence") and p.get("evidence", {}).get("text")
        }
        retrieval_coverage = (
            round(len(targets_with_evidence) / len(targets_set), 4) if targets_set else 0.0
        )

        # 3. Extraction quality: proposals that are valid and attributed
        valid_attributed = [
            p for p in props
            if p.get("attribution", {}).get("status") == "attributed"
            and p.get("typed_data", {}).get("validation", "valid") == "valid"
        ]
        extraction_quality = (
            round(len(valid_attributed) / total_proposals, 4) if total_proposals else 0.0
        )

        # 4. Proposal acceptance
        accepted = [p for p in props if p.get("decision") == "accepted"]
        reviewed = [p for p in props if p.get("decision") in ("accepted", "rejected")]
        acceptance_rate = (
            round(len(accepted) / len(reviewed), 4) if reviewed else 0.0
        )

        # 5. Shared evidence compression
        evidence_keys = set()
        for p in props:
            ev = p.get("evidence")
            if ev and isinstance(ev, dict):
                k = (ev.get("document", ""), ev.get("start", 0), ev.get("end", 0))
                evidence_keys.add(k)
        evidence_compression_ratio = (
            round(total_proposals / len(evidence_keys), 2) if evidence_keys else 1.0
        )

        # 6. Engines breakdown
        engines_counter: Dict[str, int] = {}
        for p in props:
            eng = p.get("engine", "thor")
            engines_counter[eng] = engines_counter.get(eng, 0) + 1

        telemetry = {
            "run_id": run_id,
            "disk_use_bytes": total_disk_bytes,
            "disk_use_formatted": f"{total_disk_bytes / 1024:.1f} KB" if total_disk_bytes < 1048576 else f"{total_disk_bytes / 1048576:.2f} MB",
            "total_targets": len(targets_set),
            "targets_with_evidence": len(targets_with_evidence),
            "retrieval_coverage": retrieval_coverage,
            "retrieval_coverage_percent": f"{retrieval_coverage * 100:.1f}%",
            "total_proposals": total_proposals,
            "valid_attributed_count": len(valid_attributed),
            "extraction_quality": extraction_quality,
            "extraction_quality_percent": f"{extraction_quality * 100:.1f}%",
            "accepted_count": len(accepted),
            "reviewed_count": len(reviewed),
            "acceptance_rate": acceptance_rate,
            "acceptance_rate_percent": f"{acceptance_rate * 100:.1f}%",
            "unique_evidence_spans": len(evidence_keys),
            "evidence_compression_ratio": evidence_compression_ratio,
            "engines_breakdown": engines_counter,
        }
        return telemetry
