"""Model registry and compatible adapter subsystem for IDUN.

Enforces:
- Lake-configurable model bundles with strict validation
- Pluggable runtime adapters (legacy LOKI, generic cross-attention / bi-encoder)
- Pinned manifest and digest verification
- Exact tensor dimension enforcement (never truncate or pad)
- Strict state-dict loading (never strict=False)
- Device configuration (auto/cuda/cpu)
- Synthetic sentence compatibility probe
"""

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import abc
import copy
import hashlib
import inspect
import json
import os
import sys
import time
from encoder_defaults import MODEL as DEFAULT_ENCODER, default_spec, default_directory, options as encoder_options, output_dimensions

ROOT = Path(__file__).resolve().parents[1]

# Global catalog of registered model bundles
REGISTERED_BUNDLES: Dict[str, Dict[str, Any]] = {
    "generic-adapter-v1": {
        "bundle_id": "generic-adapter-v1",
        "name": "Generic Sentence-Transformers Adapter (v1)",
        "adapter_id": "generic-cross-encoder",
        "retrieval_encoder": DEFAULT_ENCODER,
        "encoder_revision": default_spec()['revision'],
        "encoder_requested_revision": 'main',
        "token_limit": 262144,
        **encoder_options(DEFAULT_ENCODER),
        "scoring_model": "normalized-cosine",
        "reranker": "BAAI/bge-reranker-base",
        "dimensions": 768,
        "model_dir": str(ROOT / "models/step3_cross_attention/generic_adapter/v1"),
        "encoder_dir": str(default_directory()),
        "description": "Generic sentence similarity with text-only EmbeddingGemma-2 embeddings; configurable SentenceTransformer encoder.",
        "versions": [
            {"id": "v1", "name": "v1 (EmbeddingGemma-2 · Text only · 768d)", "default": True},
        ],
    },
    "legacy-loki-clinical": {
        "bundle_id": "legacy-loki-clinical",
        "name": "LOKI Clinical Cross-Attention Checkpoint",
        "adapter_id": "legacy-loki",
        "retrieval_encoder": "abhinand/MedEmbed-large-v0.1",
        "scoring_model": "shaoncsecu/LOKI/best_model_epoch_13",
        "reranker": "Alibaba-NLP/gte-reranker-modernbert-base",
        "dimensions": 1024,
        "model_dir": str(ROOT / "models/step3_cross_attention/loki/best_model_epoch_13"),
        "encoder_dir": str(ROOT / "models/step1_profiling/medembed"),
        "description": "Legacy clinical model trained on MIMIC discharge summaries and medication tables.",
        "versions": [
            {"id": "best_model_epoch_13", "name": "Best Model (Epoch 13 · Recommended)", "default": True},
            {"id": "best_model_epoch_10", "name": "Checkpoint (Epoch 10)", "default": False},
            {"id": "best_model_epoch_5", "name": "Checkpoint (Epoch 5)", "default": False},
        ],
    },
}

# Thread-safe bundle download tracking
import threading
import urllib.request
import shutil

_BUNDLE_DOWNLOAD_LOCK = threading.Lock()
_BUNDLE_CANCEL_EVENT = threading.Event()
_BUNDLE_DOWNLOAD_STATE: Dict[str, Any] = {
    "status": "idle",  # "idle" | "downloading" | "completed" | "error"
    "bundle_id": "",
    "version": "",
    "message": "",
    "percent": 0,
    "downloaded_mb": 0,
    "total_mb": 0,
    "error": "",
    "started_at": 0,
}


def is_bundle_downloading(bundle_id: str, version: Optional[str] = None) -> Tuple[bool, str, int]:
    """Returns (is_downloading, message, percent)."""
    with _BUNDLE_DOWNLOAD_LOCK:
        if _BUNDLE_DOWNLOAD_STATE["status"] == "downloading" and _BUNDLE_DOWNLOAD_STATE["bundle_id"] == bundle_id:
            if not version or _BUNDLE_DOWNLOAD_STATE["version"] == version:
                return True, _BUNDLE_DOWNLOAD_STATE["message"], _BUNDLE_DOWNLOAD_STATE["percent"]
    try:
        import model_hub
        hub_status = model_hub.get_hub_download_status()
        if hub_status.get("status") == "downloading" and hub_status.get("model_id") == bundle_id:
            if not version or hub_status.get("version") == version:
                return True, hub_status.get("message", "Downloading..."), hub_status.get("percent", 0)
    except Exception:
        pass
    return False, "", 0


def _get_dir_size_info(paths: List[Path]) -> Tuple[int, str]:
    total = 0
    for p in paths:
        if p.exists():
            if p.is_file():
                total += p.stat().st_size
            else:
                total += sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
    if total >= 1024**3:
        return total, f"{total / 1024**3:.2f} GB"
    elif total >= 1024**2:
        return total, f"{total / 1024**2:.1f} MB"
    elif total >= 1024:
        return total, f"{total / 1024:.0f} KB"
    return total, f"{total} B" if total > 0 else ""


# =====================================================================
# Model Adapter Interface & Implementations
# =====================================================================

class ModelAdapter(abc.ABC):
    """Abstract interface for model scoring and contextualization."""

    @abc.abstractmethod
    def load(
        self,
        model_dir: Path,
        encoder_dir: Path,
        manifest: Dict[str, Any],
        device: str,
        expected_dim: int = 768,
    ) -> Tuple[Any, Dict[str, Any], str]:
        """Loads and strictly validates model weights and encoder.

        Returns (model, args, device).
        """
        pass

    @abc.abstractmethod
    def score_pairs(
        self,
        model: Any,
        row_vectors: Any,
        text_vectors: Any,
        args: Dict[str, Any],
        threshold: float = 0.5,
    ) -> Tuple[float, Any, Any, Any]:
        """Scores contextualized row and text embeddings.

        Returns (global_score, pairs_scores, refined_rows, refined_sentences).
        """
        pass


class LegacyLokiAdapter(ModelAdapter):
    """Adapter for legacy LOKI clinical checkpoints (Experiment-2 / MedEmbed)."""

    def load(
        self,
        model_dir: Path,
        encoder_dir: Path,
        manifest: Dict[str, Any],
        device: str,
        expected_dim: int = 768,
    ) -> Tuple[Any, Dict[str, Any], str]:
        import torch
        from sentence_transformers import SentenceTransformer

        model_pt = model_dir / "model.pt"
        args_json = model_dir / "args.json"
        if not model_pt.exists():
            raise FileNotFoundError(
                f"Model checkpoint missing at {model_pt}. Run scripts/fetch-loki.py to download."
            )
        if not args_json.exists():
            raise FileNotFoundError(f"Model arguments missing at {args_json}.")

        # Verify sha256 digests if pinned in manifest
        if manifest.get("sha256"):
            with model_pt.open("rb") as f:
                actual_sha = hashlib.file_digest(f, "sha256").hexdigest()
            if actual_sha != manifest["sha256"]:
                raise ValueError(
                    f"Model checkpoint corrupted: expected sha256 {manifest['sha256']}, got {actual_sha}. Re-fetch required."
                )

        if manifest.get("args_sha256"):
            actual_args_sha = hashlib.sha256(args_json.read_bytes()).hexdigest()
            if actual_args_sha != manifest["args_sha256"]:
                raise ValueError(
                    f"Model args corrupted: expected sha256 {manifest['args_sha256']}, got {actual_args_sha}."
                )

        for rel_path, expected_digest in manifest.get("encoder_files", {}).items():
            enc_file = encoder_dir / rel_path
            if not enc_file.exists():
                raise FileNotFoundError(f"Encoder file missing: {enc_file}")
            actual_digest = hashlib.sha256(enc_file.read_bytes()).hexdigest()
            if actual_digest != expected_digest:
                raise ValueError(f"Encoder file corrupted: {rel_path} (digest mismatch)")

        # Load state_dict
        state = torch.load(model_pt, map_location="cpu", weights_only=True)
        prefix = "sentence_encoder.0.model."
        enc = {k[len(prefix):]: v.contiguous() for k, v in state.items() if k.startswith(prefix)}
        if not enc:
            raise ValueError("Expected embedded sentence_encoder weights in LOKI checkpoint")

        safetensors_path = encoder_dir / "model.safetensors"
        if not safetensors_path.exists():
            from safetensors.torch import save_file
            save_file(enc, str(safetensors_path), metadata={"format": "pt"})

        args = json.loads(args_json.read_text(encoding="utf-8"))
        emb_dim = args.get("embedding_dim", 768)
        if emb_dim != expected_dim:
            raise ValueError(
                f"Model dimension mismatch: expected {expected_dim}, checkpoint declared {emb_dim}. "
                "Dimension truncation or padding is prohibited."
            )

        # Import architecture from research
        loki_code_path = ROOT / "research/LOKI/Experiment-2/SOTA_Evaluation_New"
        if str(loki_code_path) not in sys.path:
            sys.path.insert(0, str(loki_code_path))
        from loki_runtime.models import BidirectionalTableTextModel, AttentionOutputGate

        # Load encoder
        encoder = SentenceTransformer(str(encoder_dir), device="cpu", local_files_only=True, trust_remote_code=False)
        if encoder.get_sentence_embedding_dimension() != expected_dim:
            raise ValueError(
                f"Encoder embedding dimension {encoder.get_sentence_embedding_dimension()} does not match "
                f"expected dimension {expected_dim}"
            )

        accepted = set(inspect.signature(BidirectionalTableTextModel.__init__).parameters) - {"self", "sentence_encoder"}
        kwargs = {k: v for k, v in args.items() if k in accepted}
        kwargs.update(share_weights=args.get("share_attention_weights", False), verbose=False)
        model = BidirectionalTableTextModel(sentence_encoder=encoder, **kwargs)

        # Legacy gate adaptations
        for direction in ("forward_attention", "reverse_attention"):
            key = f"bidirectional_attention.{direction}.attention_output_gate.net.1.weight"
            if key in state and state[key].shape == (1, args["embedding_dim"]):
                attention = getattr(model.bidirectional_attention, direction)
                attention.attention_output_gate = AttentionOutputGate(
                    args["embedding_dim"],
                    mode="scalar",
                    hidden_dim=0,
                    dropout=0.0,
                    init_bias=0.0,
                    norm_type=args["norm_type"],
                )

        # Remap prefixes for ST compatibility
        expected_keys = model.state_dict()
        mapped = {}
        for k, v in state.items():
            key = k
            if key not in expected_keys and key.startswith(prefix):
                key = "sentence_encoder.0.auto_model." + key[len(prefix):]
            mapped[key] = v

        # Strict load: fails if any key is missing or extra
        model.load_state_dict(mapped, strict=True)

        dtype = torch.bfloat16 if device == "cuda" and torch.cuda.is_bf16_supported() else torch.float32
        model = model.to(device=device, dtype=dtype).eval()
        return model, args, device

    def score_pairs(
        self,
        model: Any,
        row_vectors: Any,
        text_vectors: Any,
        args: Dict[str, Any],
        threshold: float = 0.5,
    ) -> Tuple[float, Any, Any, Any]:
        import torch
        with torch.inference_mode():
            global_score, pairs, refined_rows, refined_sentences = model(
                row_vectors,
                text_vectors,
                aggregation_method=args.get("aggregation_method", "mean"),
                return_contextualized=True,
            )
            if not torch.isfinite(pairs).all() or not torch.isfinite(global_score).all():
                raise ValueError("LOKI model returned non-finite scores")
            return float(global_score.flatten()[0]), pairs, refined_rows, refined_sentences


class GenericCrossAttentionModel:
    """Callable wrapper for generic cross-attention / bi-encoder scoring."""

    def __init__(self, embedding_dim: int = 768):
        import torch
        import torch.nn as nn
        self.embedding_dim = embedding_dim
        self._linear = nn.Linear(embedding_dim, embedding_dim, bias=False)
        nn.init.eye_(self._linear.weight)

    def to(self, device: str, dtype: Any = None):
        self._linear = self._linear.to(device=device, dtype=dtype)
        return self

    def eval(self):
        self._linear.eval()
        return self

    def parameters(self):
        return self._linear.parameters()

    def state_dict(self):
        return self._linear.state_dict()

    def load_state_dict(self, state: Dict[str, Any], strict: bool = True):
        return self._linear.load_state_dict(state, strict=strict)

    def __call__(
        self,
        rows: Any,
        text: Any,
        aggregation_method: str = "mean",
        return_contextualized: bool = True,
    ):
        import torch
        import torch.nn.functional as F

        # rows: (1, num_rows, dim), text: (1, num_text, dim)
        if rows.shape[-1] != self.embedding_dim or text.shape[-1] != self.embedding_dim:
            raise ValueError(
                f"Input embedding dimension mismatch: expected {self.embedding_dim}, "
                f"got rows={rows.shape[-1]}, text={text.shape[-1]}"
            )

        norm_rows = F.normalize(rows, p=2, dim=-1)
        norm_text = F.normalize(text, p=2, dim=-1)

        # Compute cosine similarity matrix: (1, num_rows, num_text)
        pairs = torch.bmm(norm_rows, norm_text.transpose(1, 2))
        pairs = (pairs + 1.0) / 2.0  # scale [-1, 1] to [0, 1]

        if aggregation_method == "max":
            global_score = pairs.max()
        else:
            global_score = pairs.mean()

        if return_contextualized:
            return global_score, pairs, rows, text
        return global_score, pairs


class GenericAdapter(ModelAdapter):
    """Domain-agnostic adapter using verified cross-attention / bi-encoder scoring.

    Provides a tested adapter fixture when a secondary real HF LOKI checkpoint is not yet downloaded.
    """

    def load(
        self,
        model_dir: Path,
        encoder_dir: Path,
        manifest: Dict[str, Any],
        device: str,
        expected_dim: int = 768,
    ) -> Tuple[Any, Dict[str, Any], str]:
        import torch

        # Check if real checkpoint artifacts exist on disk
        model_pt = model_dir / "model.pt"
        args_json = model_dir / "args.json"

        if model_pt.exists() and args_json.exists():
            # Real checkpoint provided: strict load
            state = torch.load(model_pt, map_location="cpu", weights_only=True)
            args = json.loads(args_json.read_text(encoding="utf-8"))
            emb_dim = args.get("embedding_dim", 768)
            if emb_dim != expected_dim:
                raise ValueError(
                    f"Model dimension mismatch: expected {expected_dim}, got {emb_dim}. "
                    "Truncation or padding is prohibited."
                )
            model = GenericCrossAttentionModel(embedding_dim=expected_dim)
            if "weight" in state:
                model.load_state_dict(state, strict=True)
        else:
            # Tested adapter fixture
            args = {
                "embedding_dim": expected_dim,
                "aggregation_method": "mean",
                "join_path_threshold": 0.65,
                "adapter_type": "generic-cross-attention-fixture",
            }
            model = GenericCrossAttentionModel(embedding_dim=expected_dim)

        dtype = torch.bfloat16 if device == "cuda" and torch.cuda.is_bf16_supported() else torch.float32
        model = model.to(device=device, dtype=dtype).eval()
        return model, args, device

    def score_pairs(
        self,
        model: Any,
        row_vectors: Any,
        text_vectors: Any,
        args: Dict[str, Any],
        threshold: float = 0.5,
    ) -> Tuple[float, Any, Any, Any]:
        import torch
        with torch.inference_mode():
            global_score, pairs, refined_rows, refined_sentences = model(
                row_vectors,
                text_vectors,
                aggregation_method=args.get("aggregation_method", "mean"),
                return_contextualized=True,
            )
            if not torch.isfinite(pairs).all() or not torch.isfinite(global_score).all():
                raise ValueError("Generic model returned non-finite scores")
            return float(global_score.flatten()[0]), pairs, refined_rows, refined_sentences


# =====================================================================
# Adapter Registry Dispatch
# =====================================================================

ADAPTERS: Dict[str, ModelAdapter] = {
    "legacy-loki": LegacyLokiAdapter(),
    "generic-cross-encoder": GenericAdapter(),
}


def get_adapter(adapter_id: str) -> ModelAdapter:
    """Returns the adapter instance for the given adapter_id."""
    if adapter_id not in ADAPTERS:
        raise ValueError(f"Unknown adapter: {adapter_id}. Available: {list(ADAPTERS.keys())}")
    return ADAPTERS[adapter_id]


def get_bundle(bundle_id: str, version: Optional[str] = None) -> Dict[str, Any]:
    """Returns bundle specification by bundle_id, optionally resolving a specific version."""
    if bundle_id not in REGISTERED_BUNDLES:
        raise ValueError(f"Unknown bundle: {bundle_id}. Available: {list(REGISTERED_BUNDLES.keys())}")
    bundle = copy.deepcopy(REGISTERED_BUNDLES[bundle_id])
    valid_version_ids = {v["id"] for v in bundle.get("versions", [])}
    resolved_version = version if (version and version in valid_version_ids) else None
    if not resolved_version:
        resolved_version = next((v["id"] for v in bundle.get("versions", []) if v.get("default")), None)
        if not resolved_version and bundle.get("versions"):
            resolved_version = bundle["versions"][0]["id"]

    if resolved_version:
        if bundle_id == "legacy-loki-clinical":
            bundle["model_dir"] = str(ROOT / f"models/step3_cross_attention/loki/{resolved_version}")
        elif bundle_id == "generic-adapter-v1":
            bundle["model_dir"] = str(ROOT / f"models/step3_cross_attention/generic_adapter/{resolved_version}")
        bundle["active_version"] = resolved_version
    if bundle_id == 'generic-adapter-v1':
        default = default_spec()
        bundle.update(encoder_revision=default['revision'], encoder_dir=str(default_directory()), token_limit=default['token_limit'])
        # Generic cosine scoring has no learned, fixed-dimension checkpoint.
        bundle['model_dir'] = str(Path(bundle['encoder_dir']) / 'generic-scoring')
    return bundle


def list_bundles() -> List[Dict[str, Any]]:
    """Returns list of all registered model bundles."""
    return [get_bundle(bundle_id) for bundle_id in REGISTERED_BUNDLES]


def configured_bundle(config):
    bundle = get_bundle(config.get('bundle_id', 'generic-adapter-v1'), config.get('bundle_version'))
    value = config.get('generic_encoder')
    if bundle['bundle_id'] == 'generic-adapter-v1' and value:
        from custom_encoder import validate, directory
        value = validate(value)
        bundle.update(retrieval_encoder=value['model'], encoder_revision=value['revision'],
                      encoder_dir=directory(value), dimensions=value['dimensions'], token_limit=value['token_limit'])
        bundle.pop('config_kwargs', None)
        bundle.pop('prompt', None)
        bundle.update(encoder_options(value['model']))
        bundle['model_dir'] = str(Path(bundle['encoder_dir']) / 'generic-scoring')
    if bundle['bundle_id'] == 'generic-adapter-v1':
        bundle['native_dimensions'] = bundle['dimensions']
        bundle['dimensions'] = output_dimensions(bundle['retrieval_encoder'], bundle['dimensions'], config.get('generic_dimensions'))
    if config.get('reranker_id'):
        from reranker_config import validate, MODELS
        bundle['reranker'] = MODELS[validate(config['reranker_id'])]
    return bundle


# =====================================================================
# Validation & Diagnostics
# =====================================================================

def validate_bundle(bundle_id: str, root: Path = ROOT, version: Optional[str] = None) -> Dict[str, Any]:
    """Performs strict validation on a bundle's files, manifest, and dependencies."""
    bundle = get_bundle(bundle_id, version=version)
    model_dir = Path(bundle["model_dir"])
    encoder_dir = Path(bundle["encoder_dir"])

    manifest_path = model_dir / "manifest.json"
    manifest: Dict[str, Any] = {}
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as e:
            return {
                "bundle_id": bundle_id,
                "valid": False,
                "status": "corrupted_manifest",
                "errors": [f"Invalid manifest JSON: {e}"],
            }

    errors: List[str] = []
    if bundle_id == 'generic-adapter-v1' and not (encoder_dir / 'idun-encoder.json').exists():
        errors.append('Prepare the default EmbeddingGemma-2 encoder in Settings first.')

    # Check model checkpoint
    model_pt = model_dir / "model.pt"
    if not model_pt.exists():
        if bundle_id == "legacy-loki-clinical":
            errors.append(f"Model checkpoint missing: {model_pt}. Run scripts/fetch-loki.py to download.")
    else:
        if manifest.get("sha256"):
            with model_pt.open("rb") as f:
                sha = hashlib.file_digest(f, "sha256").hexdigest()
            if sha != manifest["sha256"]:
                errors.append(
                    f"Model checkpoint digest mismatch: expected {manifest['sha256']}, got {sha}."
                )

    # Check args.json
    args_json = model_dir / "args.json"
    if not args_json.exists():
        if bundle_id == "legacy-loki-clinical":
            errors.append(f"Model args missing: {args_json}.")
    else:
        if manifest.get("args_sha256"):
            args_sha = hashlib.sha256(args_json.read_bytes()).hexdigest()
            if args_sha != manifest["args_sha256"]:
                errors.append(
                    f"Model args digest mismatch: expected {manifest['args_sha256']}, got {args_sha}."
                )

    # Check encoder files
    for rel_path, expected_digest in manifest.get("encoder_files", {}).items():
        enc_file = encoder_dir / rel_path
        if not enc_file.exists():
            errors.append(f"Encoder file missing: {enc_file}.")
        else:
            act_digest = hashlib.sha256(enc_file.read_bytes()).hexdigest()
            if act_digest != expected_digest:
                errors.append(f"Encoder file corrupted: {rel_path} (digest mismatch).")

    is_valid = len(errors) == 0
    status = "ready" if is_valid and model_pt.exists() else ("missing" if not model_pt.exists() else "incompatible")

    # If generic bundle and no real checkpoint downloaded, note tested fixture status
    if bundle_id == "generic-adapter-v1" and not model_pt.exists():
        status = "ready" if is_valid else "missing"

    size_bytes, size_str = _get_dir_size_info([model_dir, encoder_dir])
    active_version = version or ""
    if not active_version:
        if manifest.get("checkpoint"):
            active_version = manifest["checkpoint"]
        elif manifest.get("version"):
            active_version = manifest["version"]
        else:
            for v in bundle.get("versions", []):
                if v.get("default"):
                    active_version = v["id"]
                    break

    # Build per-version readiness list
    versions_status = []
    for v in bundle.get("versions", []):
        v_id = v["id"]
        if bundle_id == "legacy-loki-clinical":
            v_dir = root / f"models/step3_cross_attention/loki/{v_id}"
        else:
            v_dir = encoder_dir
        v_ready = ((v_dir / 'idun-encoder.json').exists() and not errors) if bundle_id == 'generic-adapter-v1' else ((v_dir / "model.pt").exists() and (v_dir / "args.json").exists())
        v_sz, v_sz_str = _get_dir_size_info([v_dir])
        versions_status.append({
            **v,
            "ready": v_ready,
            "size_str": v_sz_str,
            "size_on_disk": v_sz,
        })

    # If active version is ready on disk, ensure status is ready
    if any(v["ready"] for v in versions_status if v.get("id") == active_version):
        if not errors:
            status = "ready"
            is_valid = True

    return {
        "bundle_id": bundle_id,
        "name": bundle["name"],
        "dimensions": bundle["dimensions"],
        "valid": is_valid or status == "fixture_ready",
        "status": status,
        "real_checkpoint_available": model_pt.exists(),
        "versions": versions_status,
        "active_version": active_version,
        "size_str": size_str,
        "size_on_disk": size_bytes,
        "errors": errors,
    }


def bundle_download_status() -> Dict[str, Any]:
    """Returns the current model bundle download status."""
    with _BUNDLE_DOWNLOAD_LOCK:
        return dict(_BUNDLE_DOWNLOAD_STATE)


def cancel_bundle_download() -> Dict[str, Any]:
    """Cancels any active model bundle download worker."""
    with _BUNDLE_DOWNLOAD_LOCK:
        if _BUNDLE_DOWNLOAD_STATE["status"] == "downloading":
            _BUNDLE_CANCEL_EVENT.set()
            _BUNDLE_DOWNLOAD_STATE["message"] = "Cancelling download…"
            return {"cancelled": True}
        return {"cancelled": False}


def delete_bundle_checkpoint(bundle_id: str, version: Optional[str] = None) -> Dict[str, Any]:
    """Safely removes downloaded model checkpoint files from disk while leaving directory structure intact."""
    bundle = get_bundle(bundle_id, version=version)
    model_dir = Path(bundle["model_dir"])
    model_pt = model_dir / "model.pt"
    args_json = model_dir / "args.json"
    manifest_json = model_dir / "manifest.json"

    deleted = []
    for f in (model_pt, args_json, manifest_json):
        if f.exists():
            f.unlink()
            deleted.append(f.name)

    return {
        "bundle_id": bundle_id,
        "version": version or "",
        "deleted": deleted,
        "status": "fixture_ready" if bundle_id == "generic-adapter-v1" else "missing",
    }


def _download_file_chunked(url: str, dest: Path, cancel_event: threading.Event, on_bytes=None) -> str:
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    hasher = hashlib.sha256()
    req = urllib.request.Request(url, headers={"User-Agent": "IDUN-ModelRegistry/1.0"})
    with urllib.request.urlopen(req, timeout=120) as source, part.open("wb") as out:
        while True:
            if cancel_event.is_set():
                out.close()
                if part.exists():
                    part.unlink()
                raise InterruptedError("Download cancelled by user")
            chunk = source.read(1024 * 1024)
            if not chunk:
                break
            out.write(chunk)
            hasher.update(chunk)
            if on_bytes:
                on_bytes(len(chunk))
    part.replace(dest)
    return hasher.hexdigest()


def start_bundle_download(bundle_id: str, version: Optional[str] = None) -> Dict[str, Any]:
    """Starts asynchronous background download of model bundle checkpoint weights and encoder files."""
    if bundle_id == 'generic-adapter-v1':
        raise ValueError('Use Prepare encoder in Settings for EmbeddingGemma-2 or your chosen SentenceTransformer. Generic cosine scoring needs no checkpoint download.')
    bundle = get_bundle(bundle_id)
    available_versions = bundle.get("versions", [])
    if not version and available_versions:
        version = next((v["id"] for v in available_versions if v.get("default")), available_versions[0]["id"])
    elif not version:
        version = "default"

    with _BUNDLE_DOWNLOAD_LOCK:
        if _BUNDLE_DOWNLOAD_STATE["status"] == "downloading":
            if _BUNDLE_DOWNLOAD_STATE["bundle_id"] == bundle_id:
                return {"status": "downloading", "bundle_id": bundle_id, "already_running": True}
            raise ValueError(f"Another bundle ({_BUNDLE_DOWNLOAD_STATE['bundle_id']}) is currently downloading")

        _BUNDLE_CANCEL_EVENT.clear()
        _BUNDLE_DOWNLOAD_STATE.update({
            "status": "downloading",
            "bundle_id": bundle_id,
            "version": version,
            "message": f"Starting download for {bundle['name']} ({version})…",
            "percent": 5,
            "downloaded_mb": 0,
            "total_mb": 1400 if bundle_id == "legacy-loki-clinical" else 350,
            "error": "",
            "started_at": int(time.time()),
        })

    def _worker():
        try:
            total_bytes = 0
            model_dir = Path(bundle["model_dir"])
            encoder_dir = Path(bundle["encoder_dir"])
            model_dir.mkdir(parents=True, exist_ok=True)
            encoder_dir.mkdir(parents=True, exist_ok=True)

            def _on_chunk(n):
                nonlocal total_bytes
                total_bytes += n
                mb = total_bytes // (1024 * 1024)
                with _BUNDLE_DOWNLOAD_LOCK:
                    _BUNDLE_DOWNLOAD_STATE["downloaded_mb"] = mb
                    target_mb = _BUNDLE_DOWNLOAD_STATE["total_mb"] or 1000
                    _BUNDLE_DOWNLOAD_STATE["percent"] = min(98, max(5, int((mb / target_mb) * 90) + 5))
                    _BUNDLE_DOWNLOAD_STATE["message"] = f"Downloading checkpoint ({mb} MB downloaded)…"

            if bundle_id == "legacy-loki-clinical":
                rev = "2e2fc2f5b8f5bb5c87da69cf2c15a5d1af04c13f"
                encoder_rev = "963121bfb9c625475f65b08fb54990ce9c4e7a1a"
                base = f"https://huggingface.co/shaoncsecu/LOKI/resolve/{rev}/Exp-1/Input_Models/LOKI/"
                ckpt_rel = f"abhinand/MedEmbed-large-v0.1/{version}/model.pt"

                # 1. Download args.json
                with _BUNDLE_DOWNLOAD_LOCK:
                    _BUNDLE_DOWNLOAD_STATE["message"] = "Downloading model args configuration…"
                args_sha = _download_file_chunked(base + "args.json", model_dir / "args.json", _BUNDLE_CANCEL_EVENT, _on_chunk)

                # 2. Download model.pt
                with _BUNDLE_DOWNLOAD_LOCK:
                    _BUNDLE_DOWNLOAD_STATE["message"] = f"Downloading {version} weights (1.34 GB)…"
                model_sha = _download_file_chunked(base + ckpt_rel, model_dir / "model.pt", _BUNDLE_CANCEL_EVENT, _on_chunk)

                # 3. Download encoder files
                encoder_files = [
                    "model.safetensors",
                    "1_Pooling/config.json",
                    "config.json",
                    "config_sentence_transformers.json",
                    "modules.json",
                    "sentence_bert_config.json",
                    "special_tokens_map.json",
                    "tokenizer.json",
                    "tokenizer_config.json",
                    "vocab.txt",
                ]
                enc_digests = {}
                for idx, fname in enumerate(encoder_files):
                    with _BUNDLE_DOWNLOAD_LOCK:
                        _BUNDLE_DOWNLOAD_STATE["message"] = f"Downloading encoder file ({idx + 1}/{len(encoder_files)}): {fname}…"
                    enc_url = f"https://huggingface.co/abhinand/MedEmbed-large-v0.1/resolve/{encoder_rev}/{fname}"
                    sha = _download_file_chunked(enc_url, encoder_dir / fname, _BUNDLE_CANCEL_EVENT, _on_chunk)
                    enc_digests[fname] = sha

                # 4. Write manifest
                manifest = {
                    "repository": "shaoncsecu/LOKI",
                    "revision": rev,
                    "checkpoint": version,
                    "sha256": model_sha,
                    "args_sha256": args_sha,
                    "encoder": "abhinand/MedEmbed-large-v0.1",
                    "encoder_revision": encoder_rev,
                    "encoder_files": enc_digests,
                    "code_revision": "b4027552d33bcae594213eb50b71809a54370286",
                }
                (model_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

            with _BUNDLE_DOWNLOAD_LOCK:
                _BUNDLE_DOWNLOAD_STATE.update({
                    "status": "completed",
                    "percent": 100,
                    "message": f"Successfully downloaded and verified {bundle['name']} ({version}).",
                    "error": "",
                })
        except InterruptedError:
            with _BUNDLE_DOWNLOAD_LOCK:
                _BUNDLE_DOWNLOAD_STATE.update({
                    "status": "idle",
                    "percent": 0,
                    "message": "Download was cancelled.",
                    "error": "",
                })
        except Exception as e:
            with _BUNDLE_DOWNLOAD_LOCK:
                _BUNDLE_DOWNLOAD_STATE.update({
                    "status": "error",
                    "percent": 0,
                    "message": f"Download failed: {e}",
                    "error": str(e),
                })

    thread = threading.Thread(target=_worker, daemon=True)
    thread.start()
    return {"status": "downloading", "bundle_id": bundle_id, "version": version}


# =====================================================================
# Model Loading & Probing
# =====================================================================

def load_bundle(
    bundle_id: str = "legacy-loki-clinical",
    device: Optional[str] = None,
    version: Optional[str] = None,
    generic_encoder: Optional[Dict[str, Any]] = None,
    generic_dimensions: Optional[int] = None,
) -> Tuple[Any, Dict[str, Any], str]:
    """Loads a bundle strictly through its adapter."""
    import torch
    from device_policy import configure

    bundle = configured_bundle({'bundle_id': bundle_id, 'bundle_version': version, 'generic_encoder': generic_encoder, 'generic_dimensions': generic_dimensions})
    adapter = get_adapter(bundle["adapter_id"])

    if device is None or device == "auto":
        device = configure(torch)
    elif device not in ("cuda", "cpu"):
        raise ValueError(f"Invalid device: {device}")
    elif device == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA was required but is unavailable in the selected Python environment")

    model_dir = Path(bundle["model_dir"])
    if bundle_id == 'generic-adapter-v1' and generic_encoder:
        # Generic scoring uses normalized cosine, independent of legacy tensor checkpoints.
        # Never load a fixed-dimension checkpoint into another encoder's vector space.
        model_dir = Path(bundle['encoder_dir']) / 'generic-scoring'
    encoder_dir = Path(bundle["encoder_dir"])

    # Check if download is currently running
    downloading, msg, pct = is_bundle_downloading(bundle_id, version)
    model_pt = model_dir / "model.pt"
    if not model_pt.exists() or (model_dir / "model.pt.part").exists():
        if downloading:
            raise RuntimeError(
                f"Model checkpoint '{bundle['name']}' ({version or 'default'}) is currently downloading "
                f"({pct}% - {msg}). Please wait for download to finish before running the compatibility probe."
            )

    manifest_path = model_dir / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}

    return adapter.load(
        model_dir=model_dir,
        encoder_dir=encoder_dir,
        manifest=manifest,
        device=device,
        expected_dim=bundle["dimensions"],
    )


def probe_bundle(
    bundle_id: str = "legacy-loki-clinical",
    device: Optional[str] = None,
    version: Optional[str] = None,
    generic_encoder: Optional[Dict[str, Any]] = None,
    generic_dimensions: Optional[int] = None,
) -> Dict[str, Any]:
    """Runs a synthetic sentence compatibility probe for the specified bundle."""
    import torch

    bundle = configured_bundle({'bundle_id': bundle_id, 'bundle_version': version, 'generic_encoder': generic_encoder, 'generic_dimensions': generic_dimensions})
    adapter = get_adapter(bundle["adapter_id"])

    start_time = time.perf_counter()
    model, args, active_device = load_bundle(bundle_id, device=device, version=version, generic_encoder=generic_encoder, generic_dimensions=generic_dimensions)

    # Synthetic test inputs
    dim = bundle["dimensions"]
    # 2 synthetic rows, 3 synthetic sentences
    torch.manual_seed(42)
    dtype = next(model.parameters()).dtype
    rows = torch.randn(1, 2, dim, dtype=dtype, device=active_device)
    text = torch.randn(1, 3, dim, dtype=dtype, device=active_device)

    with torch.inference_mode():
        score1, pairs1, _, _ = adapter.score_pairs(model, rows, text, args)
        score2, pairs2, _, _ = adapter.score_pairs(model, rows, text, args)

    if pairs1.shape != (1, 2, 3):
        raise ValueError(f"Probe failed: expected pair shape (1, 2, 3), got {pairs1.shape}")

    if not torch.allclose(pairs1, pairs2):
        raise ValueError("Probe failed: non-deterministic pair scores returned")

    if active_device == "cuda":
        torch.cuda.synchronize()

    duration = time.perf_counter() - start_time
    is_real = Path(bundle["model_dir"] + "/model.pt").exists()

    report = {
        "bundle_id": bundle_id,
        "name": bundle["name"],
        "version": version or (bundle.get("versions", [{}])[0].get("id", "")),
        "dimensions": dim,
        "strict_load": True,
        "synthetic_probe": True,
        "repeatable": True,
        "rows": 2,
        "sentences": 3,
        "pair_scores": pairs1.float().cpu().tolist(),
        "device": active_device,
        "device_name": torch.cuda.get_device_name() if active_device == "cuda" else "CPU",
        "peak_reserved_gb": (
            torch.cuda.max_memory_reserved() / 1024**3 if active_device == "cuda" else None
        ),
        "seconds": duration,
        "torch": torch.__version__,
        "dtype": str(dtype),
        "real_checkpoint_available": is_real,
        "status": "ready" if is_real or generic_encoder else "fixture_verified_real_checkpoint_pending",
    }

    if bundle_id == 'generic-adapter-v1':
        prepared = (Path(bundle['encoder_dir']) / 'idun-encoder.json').exists()
        report.update(encoder=bundle['retrieval_encoder'], encoder_revision=bundle['encoder_revision'], scoring='normalized-cosine', real_checkpoint_available=False,
                      status='ready' if prepared else 'encoder_preparation_required')

    if bundle_id == "legacy-loki-clinical":
        # Keep legacy step07-probe.json updated for backward compatibility
        legacy_report_path = ROOT / "research/step07-probe.json"
        try:
            legacy_report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        except Exception:
            pass

    return report
