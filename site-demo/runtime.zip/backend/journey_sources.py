"""Version-specific raw source inspection; no profiling, projection or inference."""
import json


def read(store, asset_id, version, offset=0):
    if not version or type(offset) is not int or offset < 0:
        raise ValueError('A source version and nonnegative offset are required')
    with store.lock, store.db() as db:
        asset = db.execute('SELECT name FROM assets WHERE id=?', (asset_id,)).fetchone()
        first = db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1', (asset_id,version)).fetchone()
        if not asset or not first:
            raise KeyError('This source version is no longer available; it cannot be replaced by a newer version')
        value = json.loads(first['data'])
        if isinstance(value, list):
            total = db.execute('SELECT count(*) FROM records WHERE asset_id=? AND version=? AND idx>1', (asset_id,version)).fetchone()[0]
            rows = db.execute('SELECT idx,data FROM records WHERE asset_id=? AND version=? AND idx>1 ORDER BY idx LIMIT 20 OFFSET ?', (asset_id,version,offset)).fetchall()
            return {'kind':'table','name':asset['name'],'version':version,'offset':offset,'limit':20,'total':total,
                    'columns':value,'rows':[{'index':r['idx'],'cells':json.loads(r['data'])} for r in rows]}
        total = db.execute('SELECT max(end) FROM records WHERE asset_id=? AND version=?', (asset_id,version)).fetchone()[0] or 0
        end = min(total,offset+8000)
        chunks = db.execute('SELECT start,end,data FROM records WHERE asset_id=? AND version=? AND end>? AND start<? ORDER BY idx', (asset_id,version,offset,end)).fetchall()
        text = ''.join(json.loads(r['data'])[max(offset,r['start'])-r['start']:min(end,r['end'])-r['start']] for r in chunks)
        return {'kind':'document','name':asset['name'],'version':version,'offset':offset,'end':end,'limit':8000,'total':total,'text':text}
