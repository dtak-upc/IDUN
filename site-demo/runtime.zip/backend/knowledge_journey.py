"""Read a pinned KG contribution, never synchronize or infer new graph facts."""
import json
import knowledge as kg


def contribution(store, query):
    run, assertion, revision = (query.get(k, [''])[0] for k in ('run', 'assertion', 'projection'))
    if not run or not assertion or not revision:
        raise ValueError('Choose a saved assertion, run and projection')
    with store.lock, store.db() as db:
        cached = db.execute('SELECT revision,data FROM kg_auto_runs WHERE run=?', (run,)).fetchone()
        if not cached or cached['revision'] != revision:
            raise ValueError('This projection changed or was removed. Reopen Data Journey.')
        saved = db.execute('SELECT data FROM kg_auto_instances WHERE run=? AND id=?', (run, assertion)).fetchone()
        if not saved:
            raise KeyError('This assertion is not part of the selected run projection')
        meta, item = json.loads(cached['data']), json.loads(saved['data'])
        live = db.execute('SELECT data FROM integration_plans WHERE id=?', (run,)).fetchone()
        current = bool(live and kg.digest(json.loads(live['data'])) == meta.get('input_revision'))
        origins = item.get('integration_origins', [])
        # Older projections can recover candidates only from the exact input revision.
        if not origins and current:
            from semantic import rows
            keys = set(item.get('origin_row_keys', []))
            origins = [origin(row) for row in rows(json.loads(live['data']))
                       if keys.intersection(row.get('origin_row_keys', []))]
        return {'run': run, 'title': meta['title'], 'projection': revision,
                'input_revision': meta.get('input_revision'), 'integration_current': current,
                'integration_available': bool(live), 'origins': origins,
                'relation': item['relation'], 'subject': item['subject'], 'object': item['object'],
                'document': item.get('document'), 'evidence': item.get('evidence', []),
                'notice': '' if origins else 'Candidate identifiers were not recorded in this older projection. The saved records and evidence below remain pinned; newer Integration results are not substituted.'}


def origin(row):
    return {'candidate': row.get('candidate'), 'relation': row['relation'],
            'direction': row.get('integration_direction', row.get('direction', 'undirected')),
            'left_record': row.get('left_record'), 'right_record': row.get('right_record'),
            'evidence': [p.get('evidence') for p in row.get('evidence', [])],
            'origin_row_keys': row.get('origin_row_keys', [])}


def layers(store, query):
    import knowledge_auto
    runs = query.get('runs', [''])[0].split(',') if query.get('runs', [''])[0] else []
    with store.lock:
        graph = knowledge_auto.view(store, runs)
        if graph['revision'] != query.get('revision', [''])[0]:
            raise ValueError('Graph changed. Reopen Data Journey.')
        versions = {layer['run']: layer['revision'] for layer in graph['layers']}
        items = []
        with store.db() as db:
            if not db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_augmentation_layers'").fetchone():
                return {'items': [], 'active_claims': 0}
            for row in db.execute('SELECT data FROM kg_augmentation_layers ORDER BY id'):
                layer = json.loads(row['data'])
                if layer['runs'] != sorted(runs): continue
                source_available = bool(db.execute('SELECT 1 FROM augmentation_runs WHERE id=?', (layer['augmentation'],)).fetchone()) if db.execute("SELECT 1 FROM sqlite_master WHERE name='augmentation_runs'").fetchone() else False
                graph_current = layer['projections'] == versions
                items.append({'title': layer['title'], 'count': layer['count'], 'manual': layer.get('manual', 0),
                              'enabled': layer['enabled'], 'source_available': source_available,
                              'graph_current': graph_current, 'active': bool(layer['enabled'] and graph_current)})
        return {'items': items, 'active_claims': sum(l['count'] for l in items if l['active'])}
