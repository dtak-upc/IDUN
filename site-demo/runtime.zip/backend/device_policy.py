"""Shared device policy for model subprocesses."""
import os

def configure(torch):
 preference=os.environ.get('IDUN_DEVICE','auto')
 if preference not in ('auto','cuda','cpu'):raise ValueError('Invalid inference device policy')
 available=torch.cuda.is_available()
 if preference=='cuda' and not available:raise ValueError('CUDA was required but is unavailable in the selected Python environment')
 device='cuda' if preference!='cpu' and available else 'cpu'
 if device=='cuda':
  torch.cuda.reset_peak_memory_stats()
 return device
