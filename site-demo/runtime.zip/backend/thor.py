"""Lake-scoped THOR settings and automatic, versioned seed preparation."""
import copy,hashlib,json,math,re,sys,time,uuid
from collections import Counter
import augmentation,inference,settings

DEFAULTS={'python':'','vector_model':'en_core_web_lg','parser_model':'en_core_web_trf','language':'en','device':'cpu','threshold':80,'top_k':1,'seed_limit':128}

def digest(data):return hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def config(store,data=None):
    path=store.root/'thor_config.json'
    with store.lock:
        if data is not None:
            if not isinstance(data,dict) or set(data)!=set(DEFAULTS):raise ValueError('Unexpected THOR settings')
            data=copy.deepcopy(data)
            data['python']=settings.python_path(data['python'])
            for key in ('vector_model','parser_model'):
                if not isinstance(data[key],str) or not data[key].strip() or len(data[key])>2048:raise ValueError('Choose an installed model package or local model directory')
                data[key]=data[key].strip()
            if data['language']!='en':raise ValueError('Current THOR adapter supports English; other language adapters are not implemented')
            if data['device'] not in ('cpu','cuda'):raise ValueError('Choose CPU or CUDA')
            for key,lo,hi in [('threshold',1,100),('top_k',1,10),('seed_limit',1,10000)]:
                if type(data[key]) is not int or not lo<=data[key]<=hi:raise ValueError(f'{key} must be an integer between {lo} and {hi}')
            temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,indent=2),encoding='utf-8');temp.replace(path)
        value={**DEFAULTS,**(json.loads(path.read_text(encoding='utf-8')) if path.exists() else {})}
    return {'config':value,'effective_python':value['python'] or settings.runtime(store)['python']}


def build_inputs(store,scope='source',run_id='',table_id=None):
    # Preparation scans projected rows; no model loads, ground truth, filenames or
    # directory membership are used to derive concepts or subjects.
    with store.lock:
        effective=config(store);projection=augmentation.policy(store)
        report=augmentation.assess(store,scope,run_id)
        allowed={(t['id'],t['version']) for t in report['tables'] if not table_id or t['id']==table_id}
        with store.db() as db:
            mask=inference.identifier_mask(db,projection.get('exclude_identifiers',[]))
            jobs=db.execute("SELECT j.asset_id,j.version,a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.status='ready'").fetchall()
        concepts=[];subjects=[];sources=[];issues=[]
        for job in jobs:
            if not job['name'].lower().endswith('.csv') or (job['asset_id'],job['version']) not in allowed:continue
            columns=None;values=[];rows=0;offset=0;original_indices=[]
            while True:
                part=inference.prepare(store,job['asset_id'],offset,_mask=mask,projection_policy=projection,limit=100)
                if part['provenance']['version']!=job['version']:raise ValueError('Source changed during preparation')
                if columns is None:
                    columns=part['payload']['columns'];original_indices=part['provenance']['column_indices'];values=[{} for _ in columns]
                for cells,record in zip(part['payload']['rows'],part['provenance']['records']):
                    rows+=1
                    for index,value in enumerate(cells):
                        if not value or '█' in value:continue
                        key=value.casefold()
                        item=values[index].setdefault(key,{'value':value,'count':0,'record_id':record['record_id'],'column':original_indices[index]})
                        item['count']+=1
                offset+=len(part['payload']['rows'])
                if offset>=part['total']:break
                if not part['payload']['rows']:raise ValueError('Source preparation stopped before all rows')
            report_table=next(t for t in report['tables'] if t['id']==job['asset_id'] and t['version']==job['version'])
            anchor_candidates=[]
            for index,name in enumerate(columns or []):
                known=list(values[index].values())
                numeric=sum(v['count'] for v in known if re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|\d{4}-\d{2}-\d{2}(?:[T ].*)?',v['value'].strip()))
                observed=sum(v['count'] for v in known)
                kind=augmentation.column_kind(Counter(observed=observed,numeric_or_date=numeric) if observed else Counter(),name)
                # Ranking by count is deterministic, bounded, and exposes truncation.
                seeds=sorted(known,key=lambda v:(-v['count'],v['value'].casefold()))[:effective['config']['seed_limit']] if kind=='qualitative' else []
                col=next((c for c in report_table['columns'] if c['name']==name),None)
                missing=col['missing'] if col else 0
                cid=digest([job['asset_id'],job['version'],original_indices[index]])
                concepts.append({'id':cid,'source':job['asset_id'],'version':job['version'],'column':original_indices[index],
                    'table_name':job['name'],'name':name,'kind':kind,'missing':missing,'seeds':seeds,'unique_observed':len(known),
                    'omitted_seeds':max(0,len(known)-len(seeds)) if kind=='qualitative' else 0})
                if kind=='qualitative' and observed==rows and len(known)==rows and rows>1:
                    anchor_candidates.append({'column':original_indices[index],'concept':cid,'name':name})
            subjects.append({'source':job['asset_id'],'version':job['version'],'candidates':anchor_candidates,
                'status':'provisional' if len(anchor_candidates)==1 else 'ambiguous' if anchor_candidates else 'unresolved'})
            sources.append({'id':job['asset_id'],'version':job['version'],'rows':rows})
        for c in concepts:
            if c['kind'] == 'no_seeds':
                matches = [
                    {'source': other['source'], 'version': other['version'], 'column': other['column'], 'seeds': len(other['seeds'])}
                    for other in concepts
                    if other['id'] != c['id'] and other['name'].strip().casefold() == c['name'].strip().casefold() and other['seeds']
                ]
                c['cold_start'] = {
                    'strategy': 'candidate_equivalent_found' if matches else 'unresolved',
                    'candidates': matches
                }
            else:
                c['cold_start'] = None
        present={(s['id'],s['version']) for s in sources}
        for aid,version in sorted(allowed-present):issues.append({'source':aid,'version':version,'reason':'Historical source version is unavailable; no current replacement used'})
        manifest={'adapter':'thor-phrases-v1','scope':scope,'lake_id':getattr(store,'lake_id',store.root.name),
            'base_run_id':run_id if scope=='integration' else None,'base_revision':report['revision'],
            'projection_policy':copy.deepcopy(projection),'runtime':effective,'concepts':concepts,'subjects':subjects,
            'sources':sources,'issues':issues,'document_scope':'selected-run evidence (compiled at extraction)' if scope=='integration' else 'indexed retrieval (compiled at extraction)',
            'counts':{'concepts':len(concepts),'seeds':sum(len(c['seeds']) for c in concepts),
                'seeded_gap_cells':sum(c['missing'] for c in concepts if c['seeds']),
                'seedless_gap_cells':sum(c['missing'] for c in concepts if c['kind']=='no_seeds'),
                'omitted_seeds':sum(c['omitted_seeds'] for c in concepts)},
            'status':'prepared','attribution':'not_verified','created':time.time()}
        manifest['fingerprint']=digest({k:v for k,v in manifest.items() if k!='created'})
        return manifest


def prepare(store,scope='source',run_id='',table_id=None):
    with store.lock:
        manifest=build_inputs(store,scope,run_id,table_id)
        with store.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS thor_preparations(id TEXT PRIMARY KEY,data TEXT)')
            db.execute('INSERT OR IGNORE INTO thor_preparations VALUES(?,?)',(manifest['fingerprint'],json.dumps(manifest)))
            manifest=json.loads(db.execute('SELECT data FROM thor_preparations WHERE id=?',(manifest['fingerprint'],)).fetchone()['data'])
        if table_id is None:
            import augmentation_workspace
            augmentation_workspace.prepared(store,manifest)
        return manifest


def status(store):
    import thor_adapter
    effective=config(store)
    pkgs=thor_adapter.versions()
    return {
        'adapter': thor_adapter.VERSION,
        'packages': pkgs,
        'ready': all(bool(v) for v in pkgs.values()),
        'config': effective['config'],
        'effective_python': effective['effective_python']
    }

