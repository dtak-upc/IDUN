"""Read-only preparation boundary. No model loading, annotations or source-pair input."""
from pathlib import Path
import hashlib
import json
import re

POLICY = 'model-input-v1'
HIDDEN = {'subject_id', 'hadm_id'}
MAX_IDENTIFIERS = 1000000
DEFAULT_NULL_TOKENS = {'', '__doc2db_null__', 'null', 'none', 'na', 'n/a', '[null]'}


def normalized(value):
    return value.lstrip('\ufeff').strip().lower()


def resolve_cell_value(val, null_tokens=None):
    """Resolves a raw cell value according to null-token and escaped-literal rules.

    Returns (resolved_value, is_null).
    - If val starts with a backslash escaping a recognized null token (e.g. '\\__DOC2DB_NULL__'),
      it is unescaped and treated as a genuine literal string (is_null=False).
    - If val matches a recognized null token (case-insensitive, stripped), it is treated as null (is_null=True).
    - Otherwise, returns (val, False).
    """
    if not isinstance(val, str):
        return val, False
    tokens = set(t.lower() for t in (null_tokens if null_tokens is not None else DEFAULT_NULL_TOKENS))
    stripped = val.strip()
    if stripped.startswith('\\'):
        unescaped = stripped[1:]
        if unescaped.lower() in tokens:
            return unescaped, False
    if stripped.lower() in tokens:
        return '', True
    return val, False


def suggest_technical_identifiers(columns, sample_rows=None):
    """Suggests likely technical surrogate IDs (e.g., id, *_id, uuid, hex sequences).

    Avoids suggesting content-bearing columns like 'name', 'person_name', 'date',
    'code', 'title', 'category', etc.
    """
    content_words = {'name', 'first', 'last', 'date', 'time', 'code', 'title', 'category', 'type', 'desc', 'description', 'label', 'city', 'state', 'country', 'text', 'notes'}
    suggestions = []
    for col in columns:
        norm = normalized(col)
        if norm in HIDDEN:
            suggestions.append(col)
            continue
        if any(w in norm.split('_') for w in content_words):
            continue
        if re.search(r'(?:^|_)id$|^id$|^uuid$|^guid$|^key$|(?:^|_)key$', norm):
            suggestions.append(col)
    return suggestions


def table_columns(header, excluded_identifiers=None):
    if not isinstance(header, list) or not header or any(not isinstance(c, str) or not c.strip() or c.strip().isdigit() for c in header):
        raise ValueError('CSV first record cannot be treated as a header; header resolution is required')
    excluded = set(HIDDEN)
    if excluded_identifiers:
        excluded.update(normalized(x) for x in excluded_identifiers)
    included = [i for i, c in enumerate(header) if normalized(c) not in excluded]
    if len({normalized(header[i]) for i in included}) != len(included):
        raise ValueError('Duplicate non-identifier columns require header resolution')
    if not included:
        raise ValueError('No model-visible columns remain')
    return included


def identifier_mask(db, excluded_identifiers=None):
    # Global lake scan: dataset membership and source paths never restrict matching.
    hidden_names = set(HIDDEN)
    if excluded_identifiers:
        hidden_names.update(normalized(x) for x in excluded_identifiers)
    values = set()
    for job in db.execute("SELECT j.asset_id,j.version FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.status='ready' AND lower(a.name) LIKE '%.csv'").fetchall():
        first = db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1', (job['asset_id'], job['version'])).fetchone()
        header = json.loads(first['data'])
        hidden = [i for i, c in enumerate(header) if normalized(c) in hidden_names]
        if not hidden:
            continue
        for r in db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx>1', (job['asset_id'], job['version'])):
            row = json.loads(r['data'])
            if len(row) != len(header):
                raise ValueError('Identifier-bearing CSV has unresolved field counts')
            for i in hidden:
                value = row[i].strip()
                if value:
                    if len(value) > 128:
                        raise ValueError('Identifier value exceeds preparation limit')
                    values.add(value)
                if len(values) > MAX_IDENTIFIERS:
                    raise ValueError('Identifier inventory exceeds 1,000,000 values; partitioned identifier preparation is required')
    token_ids = all(re.fullmatch(r'\w+', v) for v in values)
    if not token_ids and len(values) > 10000:
        raise ValueError('Complex identifier inventory exceeds 10,000 values')
    known = re.compile(r'\w+') if token_ids else (re.compile(r'(?<!\w)(?:' + '|'.join(re.escape(v) for v in sorted(values, key=lambda v: (-len(v), v))) + r')(?!\w)') if values else None)
    patterns = [r'\b' + re.escape(h) + r'\b\s*[:=]\s*[\w-]+' for h in sorted(hidden_names, key=len, reverse=True)]
    labeled = re.compile('|'.join(patterns), re.IGNORECASE) if patterns else None

    def mask(text):
        # Same-length replacements keep original code-point references valid.
        if labeled:
            text = labeled.sub(lambda m: '█' * len(m.group()), text)
        return known.sub(lambda m: '█' * len(m.group()) if not token_ids or m.group() in values else m.group(), text) if known else text

    mask.policy_key = hashlib.sha256((json.dumps(sorted(hidden_names)) + json.dumps(sorted(values))).encode()).hexdigest()
    return mask


def prepare(store, aid, offset=0, _mask=None, projection_policy=None, limit=20):
    if projection_policy is None:
        try:
            cfg_path = store.root / "lake_config.json"
            if cfg_path.exists():
                cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
                projection_policy = cfg.get("projection_policy", {})
            else:
                import lake_config
                projection_policy = lake_config.DEFAULT_PROJECTION_POLICY
        except Exception:
            projection_policy = {}
    excluded_identifiers = projection_policy.get("exclude_identifiers", [])
    null_tokens = projection_policy.get("null_tokens", DEFAULT_NULL_TOKENS)

    with store.lock, store.db() as db:
        db.execute('BEGIN')  # One catalog/version snapshot, including the ID inventory.
        job = db.execute("SELECT j.*,a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.asset_id=? AND j.status='ready'", (aid,)).fetchone()
        if not job:
            raise KeyError('Ready source not found')
        mask = _mask or identifier_mask(db, excluded_identifiers=excluded_identifiers)
        csv = job['name'].lower().endswith('.csv')
        columns = []
        included = []
        header = []
        if csv:
            header = json.loads(db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1', (aid, job['version'])).fetchone()['data'])
            included = table_columns(header, excluded_identifiers=excluded_identifiers)
            columns = [mask(header[i]) for i in included]
        rows = db.execute('SELECT * FROM records WHERE asset_id=? AND version=? AND idx>? ORDER BY idx LIMIT ? OFFSET ?', (aid, job['version'], 1 if csv else 0, limit, offset)).fetchall()
        content = []
        mapping = []
        for r in rows:
            value = json.loads(r['data'])
            if csv:
                if len(value) != len(header):
                    raise ValueError('CSV row has unresolved field counts; no payload emitted')
                row_cells = []
                for i in included:
                    resolved, is_null = resolve_cell_value(value[i], null_tokens)
                    row_cells.append("" if is_null else mask(resolved))
                content.append(row_cells)
            else:
                neighbors = db.execute('SELECT idx,data FROM records WHERE asset_id=? AND version=? AND idx BETWEEN ? AND ? ORDER BY idx', (aid, job['version'], r['idx'] - 1, r['idx'] + 1)).fetchall()
                before = ''
                after = ''
                for neighbor in neighbors:
                    if neighbor['idx'] < r['idx']:
                        before = json.loads(neighbor['data'])[-512:]
                    if neighbor['idx'] > r['idx']:
                        after = json.loads(neighbor['data'])[:512]
                content.append(mask(before + value + after)[len(before):len(before) + len(value)])
            mapping.append({'record_id': f"{aid}:{job['version']}:{r['idx']}", 'index': r['idx'], 'start': r['start'], 'end': r['end']})
        if sum(len(json.dumps(v, ensure_ascii=False)) for v in content) > 2 * 1024 * 1024:
            raise ValueError('Preparation page exceeds 2 MiB; smaller streaming batches are required')
        payload = {'columns': columns, 'rows': content} if csv else {'chunks': content}
        return {
            'policy': POLICY,
            'payload': payload,
            'provenance': {'asset_id': aid, 'version': job['version'], 'records': mapping, 'column_indices': included},
            'payload_sha256': hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest(),
            'offset': offset,
            'total': max(0, job['records'] - (1 if csv else 0)),
            'excluded_columns': len(header) - len(included),
            'header_policy': 'Provisional first-record header; not inferred schema' if csv else None,
            'notice': 'Preparation preview only. No model has run. Text chunks are not sentence segmentation.'
        }

def readiness(store):
    root = Path(__file__).resolve().parents[1]
    import lake_config
    import model_registry

    cfg_path = store.root / "lake_config.json"
    if cfg_path.exists():
        lake_cfg = lake_config.read_lake_config(store)
        active_bundle_id = lake_cfg.get("bundle_id", "generic-adapter-v1")
    else:
        active_bundle_id = "legacy-loki-clinical"
    bundle_val = model_registry.validate_bundle(active_bundle_id)
    bundle_info = model_registry.configured_bundle(lake_cfg) if cfg_path.exists() else model_registry.get_bundle(active_bundle_id)
    if cfg_path.exists() and active_bundle_id == 'generic-adapter-v1' and lake_cfg.get('generic_encoder'):
        bundle_val = {'valid': True, 'status': 'ready'}

    report_path = root / "research/step07-probe.json"
    probe = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else None
    thor_path = root / "research/step07-thor-probe.json"
    thor = json.loads(thor_path.read_text(encoding="utf-8")) if thor_path.exists() else None
    with store.db() as db:
        counts = {r["status"]: r["n"] for r in db.execute("SELECT status,count(*) n FROM jobs GROUP BY status")}

    if bundle_val.get("valid"):
        bundle_status = "Live contextual adapter available in Discover"
    elif bundle_val.get("status") == "fixture_ready":
        bundle_status = "Tested adapter fixture available; alternative real checkpoint pending"
    else:
        errs = "; ".join(bundle_val.get("errors", []))
        bundle_status = f"Checkpoint loading verification pending: {errs}" if errs else "Checkpoint loading verification pending"

    return {
        "policy": POLICY,
        "bundle_id": active_bundle_id,
        "bundle_name": bundle_info.get("name"),
        "ready_sources": counts.get("ready", 0),
        "unfinished_sources": sum(n for s, n in counts.items() if s != "ready"),
        "inference_enabled": False,
        "engines": [
            {
                "name": bundle_info.get("name", "LOKI"),
                "bundle_id": active_bundle_id,
                "status": bundle_status,
            },
            {
                "name": "THOR",
                "status": (
                    "Recorded language-pipeline probes passed; extraction adapter pending"
                    if thor
                    else "Language-pipeline verification pending"
                ),
            },
            {
                "name": "LLM integration",
                "status": "Local/API provider not configured",
            },
        ],
        "memory": {
            "target_vram_gb": 6,
            "optional_vram_gb": 16,
            "measured_peak_vram_gb": probe.get("peak_reserved_gb") if probe else None,
        },
        "import_policy": "Manual selection only",
        "input_policy": (
            "Identifier columns excluded; known identifier values and explicit ID labels masked. "
            "Paths and dataset grouping remain outside model payloads."
        ),
    }
