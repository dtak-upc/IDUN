"""Conservative types from projected values; no string parsing or imputation."""
import math


def value_type(value):
    if value is None or isinstance(value, str) and not value.strip():return None
    if isinstance(value, bool):return 'boolean'
    if isinstance(value, (int, float)):
        return 'number' if isinstance(value, int) or math.isfinite(value) else 'unknown'
    if isinstance(value, str):return 'string'
    return 'unknown'


def observe(types, columns, cells):
    for column, cell in zip(columns, cells):
        kind=value_type(cell)
        if kind:types.setdefault(column, set()).add(kind)


def declared(kinds):
    return next(iter(kinds)) if len(kinds)==1 else 'unknown'


def aligned(columns, record):
    # Absent projected columns remain None in examples only; original records
    # retain their column/cell arrays so queries distinguish absent from null.
    values=dict(zip(record['columns'], record['cells']))
    return [values.get(column) for column in columns]
