"""Batch-durable scalar score cache. No source passages are stored here."""
import hashlib
import json
import math
import sqlite3
from contextlib import closing


def predict_cached(pairs, predict, database, model_key, progress=lambda n: None):
    keys = [hashlib.sha256(json.dumps([model_key, p], ensure_ascii=False).encode()).hexdigest() for p in pairs]
    with closing(sqlite3.connect(database)) as db:
        db.execute('CREATE TABLE IF NOT EXISTS scores(key TEXT PRIMARY KEY,value REAL NOT NULL)')
        results = [None] * len(pairs)
        for i, key in enumerate(keys):
            row = db.execute('SELECT value FROM scores WHERE key=?', (key,)).fetchone()
            if row:
                results[i] = row[0]
        reused = sum(v is not None for v in results)
        progress(reused)
        missing = [i for i, v in enumerate(results) if v is None]
        for start in range(0, len(missing), 8):
            indices = missing[start:start + 8]
            values = list(predict([pairs[i] for i in indices]))
            if len(values) != len(indices) or any(not math.isfinite(float(v)) or not 0 <= float(v) <= 1 for v in values):
                raise ValueError('Invalid reranker scores')
            for i, value in zip(indices, values):
                results[i] = float(value)
                db.execute('INSERT OR REPLACE INTO scores VALUES(?,?)', (keys[i], float(value)))
            db.commit()
            progress(reused + min(start + 8, len(missing)))
    return results, reused
