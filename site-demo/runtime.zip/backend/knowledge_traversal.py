"""Bounded breadth-first witness paths; no inferred relationships or record merges."""
import json
import sqlite3
import time
import threading
import uuid
from collections import deque
import knowledge_auto as auto
import knowledge_bridges as bridges
import knowledge_identity as identity
import knowledge_path_patterns as patterns
import knowledge as kg
import knowledge_overlays as overlays


def prepare_pattern(store,graph,runs,body,max_steps=4):
    pattern=patterns.compile(graph,body.get('start') or {},body.get('pattern'),body.get('pattern_mode','exact'),max_steps=max_steps)
    if any(s['condition_prepared'] and s['condition_prepared']['values_mode']=='reviewed' for s in pattern['steps']):
        pattern['token']=kg.digest([pattern['token'],[l for l in overlays.read(store) if l['runs']==sorted(runs)]])
    if any(s.get('kind')=='identity' for s in pattern['steps']):
        import knowledge_entity_keys as keys
        pattern['token']=kg.digest([pattern['token'],identity.read(store),keys.read(store)])
    return pattern


def preview(store,body):
    runs=auto.selected(body)
    with store.lock:
        graph=auto.view(store,runs)
        if graph['revision']!=body.get('revision'):raise ValueError('Query graph changed; preview the path again')
        pattern=prepare_pattern(store,graph,runs,body)
        return {k:pattern[k] for k in ('token','summary','mode')}

_requests={}
_guard=threading.Lock()


def request_key(store,body):
    token=body.get('request_id')
    if not isinstance(token,str):raise ValueError('Traversal request ID is required')
    try:uuid.UUID(token)
    except ValueError:raise ValueError('Invalid traversal request ID')
    return (str(store.root),token)


def cancel(store,body):
    key=request_key(store,body)
    with _guard:
        event=_requests.get(key)
        if event:event.set()
    return {'status':'cancelling' if event else 'not_running'}


def integer(body,name,default,low,high):
    value=body.get(name,default)
    if type(value) is not int or not low<=value<=high:raise ValueError(f'{name} must be between {low} and {high}')
    return value


def node(record):return (record['id'],record['concept_id'])


def summary(record):return {k:record[k] for k in ('id','concept_id','label','source','row')}


def projected_record(db,runs,target,history_refs=None):
    scope=','.join('?' for _ in runs);parts=[];args=[]
    table='kg_auto_instances';where=f'run IN ({scope})';scope_args=list(runs)
    if history_refs is not None:
        table='kg_projection_history_items';where='('+' OR '.join('(run=? AND revision=?)' for _ in history_refs)+')';scope_args=[v for pair in history_refs.items() for v in pair]
    for side in ('subject','object'):
        parts.append(f"SELECT run,json_extract(data,'$.{side}') record FROM {table} WHERE {where} AND json_extract(data,'$.{side}.id')=? AND json_extract(data,'$.{side}.concept_id')=?")
        args.extend([*scope_args,target['id'],target['concept_id']])
    rows=list(db.execute('SELECT DISTINCT run,record FROM ('+' UNION ALL '.join(parts)+') ORDER BY run,record',args))
    if not rows:raise ValueError('Reviewed identity endpoint is unavailable')
    return json.loads(rows[0]['record']),[{'run_id':run} for run in sorted({r['run'] for r in rows})]


def route(store,body):
    runs=auto.selected(body);depth=integer(body,'depth',2,1,4);limit=integer(body,'limit',20,1,100);budget=integer(body,'budget',500,10,5000)
    if type(body.get('identities',False)) is not bool:raise ValueError('Choose whether to use reviewed identities')
    start=body.get('start')
    if not isinstance(start,dict) or any(not isinstance(start.get(k),str) or not start[k] for k in ('id','concept_id')):raise ValueError('Choose a starting record and concept')
    key=request_key(store,body);event=threading.Event()
    with _guard:
        if key in _requests:raise ValueError('Traversal request is already running')
        _requests[key]=event
    try:
        with store.lock:
            graph=auto.view(store,runs)
            if graph['revision']!=body.get('revision'):raise ValueError('Query graph changed; choose a starting record again')
            pattern=None
            if 'pattern' in body:
                if body.get('identities'):raise ValueError('Typed patterns currently use assertion steps only')
                pattern=prepare_pattern(store,graph,runs,body)
                if body.get('preview_token')!=pattern['token']:raise ValueError('Preview the current path pattern before executing')
                depth=len(pattern['steps'])
            return explore(store,graph,runs,start,depth,limit,budget,body.get('identities',False),event,pattern)
    finally:
        with _guard:_requests.pop(key,None)


def explore(store,graph,runs,start,depth,limit,budget,use_identities,event=None,pattern=None,history_refs=None,deadline=None):
    deadline=deadline if deadline is not None else time.monotonic()+10;edges={e['id']:e for e in graph['relationships']};labels={c['id']:c['label'] for c in graph['concepts']};scope=','.join('?' for _ in runs)
    cancelled=lambda:event is not None and event.is_set()
    table='kg_auto_instances';where=f'run IN ({scope})';scope_args=runs
    if history_refs is not None:
        table='kg_projection_history_items'
        where='('+' OR '.join('(run=? AND revision=?)' for _ in history_refs)+')'
        scope_args=[v for pair in history_refs.items() for v in pair]
        if use_identities or (pattern and any(s.get('kind')=='identity' or (s['condition_prepared'] and s['condition_prepared']['values_mode']=='reviewed') for s in pattern['steps'])):
            raise ValueError('Checkpoint traversal uses captured assertions and original values only')
    origin=(start['id'],start['concept_id']);queue=deque([(origin,[])]);seen={(origin,0) if pattern else origin};destinations=set();results=[];work=0;stop=None;identity_edges={}
    explicit_identity=pattern and any(s.get('kind')=='identity' for s in pattern['steps'])
    if use_identities or explicit_identity:
        if len(identity.read(store))>budget:raise ValueError('Too many identity decisions for this work budget. Increase the budget or use assertion-only traversal.')
        try:page=bridges.inspect(store,graph,runs,limit=budget,interrupted=lambda:cancelled() or time.monotonic()>=deadline)
        except sqlite3.OperationalError as e:
            if 'interrupted' not in str(e):raise
            page={'items':[]};stop='cancelled' if cancelled() else 'time_limit'
        # Only current explicitly accepted links; never candidates or transitive closure.
        for link in page['items']:
            if link['reason']!='ready':continue
            a,b=link['records'];concept=link['concept']
            for source,target in ((a,b),(b,a)):
                identity_edges.setdefault((source['id'],concept),[]).append({'kind':'identity','id':link['id'],'relation':'Reviewed identity','reviewed_key':link['key'],'source':dict(source,concept_id=concept),'target':dict(target,concept_id=concept)})
            if cancelled() or time.monotonic()>=deadline:
                stop='cancelled' if cancelled() else 'time_limit';break
    with store.db() as db:
        db.set_progress_handler(lambda:cancelled() or time.monotonic()>=deadline,1000)
        try:
            present=db.execute(f"SELECT data FROM {table} WHERE {where} AND ((json_extract(data,'$.subject.id')=? AND json_extract(data,'$.subject.concept_id')=?) OR (json_extract(data,'$.object.id')=? AND json_extract(data,'$.object.concept_id')=?)) LIMIT 1",[*scope_args,*origin,*origin]).fetchone()
            if not present:raise ValueError('Starting record is outside this query scope')
            while queue and not stop:
                if cancelled():stop='cancelled';break
                current,path=queue.popleft()
                if len(path)>=depth:continue
                remaining=budget-work
                if remaining<=0:stop='work_budget';break
                identity_step=pattern and pattern['steps'][len(path)].get('kind')=='identity'
                ids=[] if identity_step else [r[0] for r in db.execute(f"SELECT DISTINCT id FROM {table} WHERE {where} AND ((json_extract(data,'$.subject.id')=? AND json_extract(data,'$.subject.concept_id')=?) OR (json_extract(data,'$.object.id')=? AND json_extract(data,'$.object.concept_id')=?)) ORDER BY id LIMIT ?",[*scope_args,*current,*current,remaining+1])]
                candidates=[]
                if history_refs is None:assertions=list(auto.grouped_instances(db,runs,ids[:remaining]))
                else:
                    assertions=[]
                    if ids:
                        grouped={}
                        for row in db.execute(f"SELECT run,data FROM {table} WHERE {where} AND id IN ("+','.join('?' for _ in ids[:remaining])+') ORDER BY id,run',[*scope_args,*ids[:remaining]]):
                            a=json.loads(row['data']);item=grouped.setdefault(a['id'],dict(a,contributions=[]))
                            item['contributions'].append({'run_id':row['run'],'run_title':a['run_title'],'evidence':a['evidence']})
                        assertions=list(grouped.values())
                for assertion in assertions:
                    for side in ('subject','object'):assertion[side]['concept']=labels.get(assertion[side]['concept_id'],assertion[side].get('concept','Unavailable concept'))
                condition=pattern['steps'][len(path)]['condition_prepared'] if pattern else None
                if condition and condition['values_mode']=='reviewed':overlays.annotate(store,graph,runs,assertions,interrupted=lambda:cancelled() or time.monotonic()>=deadline)
                for assertion in assertions:
                    import knowledge_temporal_query as temporal
                    assertion['contributions']=temporal.filter_contributions(assertion,pattern.get('temporal') if pattern else None)
                    if not assertion['contributions']:continue
                    edge=edges.get(assertion['edge'])
                    if not edge:continue
                    a,b=assertion['subject'],assertion['object']
                    if a['concept_id']!=edge['source']:a,b=b,a
                    explanation={}
                    if pattern:
                        matched=patterns.match(pattern,len(path),edge,a,b,current)
                        if not matched:continue
                        target,explanation=matched
                        if condition:
                            witnesses=patterns.condition_matches(target,condition)
                            if not witnesses:continue
                            explanation['attribute_matches']=witnesses
                    elif node(a)==current:target=b
                    elif node(b)==current and edge['direction']!='directed':target=a
                    else:continue
                    candidates.append({'kind':'assertion','id':assertion['id'],'edge':edge['id'],'relation':explanation.get('relationship',edge['label']),'direction':edge['direction'],
                        'target':summary(target),'contributions':assertion['contributions'],**explanation})
                work+=min(len(ids),remaining)
                overflow=len(ids)>remaining
                identity_candidates=sorted(identity_edges.get(current,[]),key=lambda s:s['id']) if not pattern or identity_step else []
                for candidate in candidates+identity_candidates:
                    step=dict(candidate)
                    if step['kind']=='identity':
                        if work>=budget:stop='work_budget';break
                        work+=1
                        if pattern and step['target']['concept_id'] not in pattern['steps'][len(path)]['targets']:continue
                        if condition:
                            target_record,contributions=projected_record(db,runs,step['target'])
                            target_record['concept']=labels.get(target_record['concept_id'],'Unavailable concept')
                            if condition['values_mode']=='reviewed':
                                overlays.annotate(store,graph,runs,[{'subject':target_record,'object':{'id':'','concept_id':''},'contributions':contributions}],interrupted=lambda:cancelled() or time.monotonic()>=deadline)
                            witnesses=patterns.condition_matches(target_record,condition)
                            if not witnesses:continue
                            step['attribute_matches']=witnesses
                    target=node(step['target'])
                    state=(target,len(path)+1) if pattern else target
                    all_candidates=bool(pattern and pattern.get('all_candidates') and depth==1)
                    if state in seen and not all_candidates:continue
                    seen.add(state);witness=[*path,step]
                    if (not pattern or len(witness)==depth) and (target not in destinations or all_candidates):
                        destinations.add(target);results.append({'record':step['target'],'steps':witness})
                    queue.append((target,witness))
                    if len(results)>=limit:stop='result_limit';break
                if overflow and not stop:stop='work_budget'
                if time.monotonic()>=deadline and not stop:stop='time_limit'
        except sqlite3.OperationalError as e:
            if 'interrupted' not in str(e):raise
            stop='cancelled' if cancelled() else 'time_limit'
        finally:db.set_progress_handler(None,0)
    return {'revision':graph['revision'],'scope':runs,'items':results,'returned':len(results),'examined':work,'depth':depth,'limit':limit,'budget':budget,
        'identities':use_identities,'truncated':bool(stop),'stop':stop,'pattern':pattern['summary'] if pattern else None,
        'semantics':'One witness per destination matching every ordered pattern step; not all possible paths.' if pattern else 'One shortest path per record/concept within the selected hop depth; not all possible paths.'}
