"""Cheap, revision-guarded inspection of the published Discovery boundary.

Never invokes score scans, retrieval, candidate construction or model inference.
"""
import json
import discovery
from evidence_storage import decode


def _current(store, revision=None):
    state = discovery.status(store)
    if state['status'] != 'ready':
        raise ValueError('Discovery evidence is unavailable or stale; prepare current evidence first')
    if revision is not None and revision != state['revision']:
        raise ValueError('Prepared evidence changed; reload the handoff before inspecting it')
    return state


def summary(store):
    with store.lock:
        state = discovery.status(store)
        if state['status'] != 'ready':
            return {'available': False, 'status': state['status']}
        prepared = bool(state.get('evidence_filter')) or not state.get('matrix')
        return {'available': True, 'status': 'prepared' if prepared else 'scores_only',
                'revision': state['revision'], 'matrix': state.get('matrix'),
                'scope': state.get('scope'), 'sources': state.get('sources', []),
                'policy': state.get('evidence_filter'), 'retention_policy': state.get('retention_policy'),
                'counts': state.get('summary', {}), 'coverage': state.get('coverage', {}),
                'receipt': state.get('handoff') if prepared else None,
                'consumer': 'Integration uses the published atomic links to construct and rank row-pair candidates. Shared-span paths are an inspection view, not the Integration candidate budget.'}


def inspect(store, body):
    offset, limit = body.get('offset', 0), body.get('limit', 12)
    if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 50:
        raise ValueError('Use a nonnegative offset and page size 1–50')
    kind = body.get('kind', 'links')
    if kind not in ('links', 'paths'):
        raise ValueError('Choose published links or shared-span paths')
    if not isinstance(body.get('revision'), str) or not body['revision']:
        raise ValueError('A published evidence revision is required')
    with store.lock:
        state = _current(store, body['revision'])
        if state.get('matrix') and not state.get('evidence_filter'):
            raise ValueError('Scores are saved but evidence has not been prepared')
        table = 'discovery_links' if kind == 'links' else 'discovery_bridges'
        with store.db() as db:
            total = db.execute('SELECT count(*) FROM ' + table).fetchone()[0]
            rows = db.execute('SELECT data FROM ' + table + ' ORDER BY score DESC,id LIMIT ? OFFSET ?',
                              (limit, offset)).fetchall()
            items = [decode(row['data']) for row in rows]
            if kind == 'paths':
                # Both endpoints come from this revision, never from a newer or pinned run.
                for item in items:
                    for side in ('left', 'right'):
                        link = db.execute('SELECT data FROM discovery_links WHERE id=?', (item[side],)).fetchone()
                        if not link:
                            raise ValueError('Published path endpoint is unavailable')
                        item[side] = decode(link['data'])
        return {'revision': state['revision'], 'kind': kind, 'total': total,
                'offset': offset, 'limit': limit, 'items': items}
