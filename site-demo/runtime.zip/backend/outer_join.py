"""Stage 11.E: Partial and Outer Integration Views.

Existing positive relationship outputs are inner-like evidence joins, not SQL key
equality joins. Outer retention is a materialization operator that offers matched-only,
preserve-left, and preserve-both policies per explicit relation/table-pair scope.

Unmatched rows retain their source cells and receive a null counterpart. The relation
stays unestablished with an explicit reason (not_searched, budget_limited, no_candidate,
reviewed_unresolved, or reviewed_negative). Outer-induced nulls are preserved separately
from missing original attributes.
"""

import collections
import copy
import csv
import hashlib
import io
import json
import logging
import re
import time
from typing import Any, Dict, List, Optional, Set, Tuple

import inference
import integration

logger = logging.getLogger("idun.outer_join")

POLICIES = ("matched-only", "preserve-left", "preserve-both")
DEFAULT_POLICY = "matched-only"

UNESTABLISHED_REASONS = (
    "reviewed_negative",
    "reviewed_unresolved",
    "budget_limited",
    "no_candidate",
    "not_searched",
)

NOTICE = (
    "Absence of a discovered link is not proof of no relationship. "
    "Outer retention preserves unmatched source rows without asserting nonexistent relationships."
)


def _scope_id(relation: str, left_id: str, right_id: str) -> str:
    raw = f"{relation}:{left_id}:{right_id}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _extract_table_id_from_record(record_id: str) -> str:
    if not record_id:
        return ""
    # Format may be asset_id:version:idx or table_name:row-idx
    parts = record_id.split(":")
    return parts[0]


def _get_table_meta(store: Any, table_ident: str) -> Dict[str, Any]:
    """Retrieve column names, row count, and version for a source table."""
    with store.db() as db:
        job = db.execute(
            "SELECT j.asset_id, j.version, a.name FROM jobs j JOIN assets a ON a.id=j.asset_id "
            "WHERE j.status='ready' AND (j.asset_id=? OR a.name=?)",
            (table_ident, table_ident),
        ).fetchone()

        if job:
            aid = job["asset_id"]
            version = job["version"]
            name = job["name"]
            first = db.execute(
                "SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1",
                (aid, version),
            ).fetchone()
            cols = json.loads(first["data"]) if first else []
            import lake_config
            projection=lake_config.read_lake_config(store).get('projection_policy', {})
            indices=inference.table_columns(cols,projection.get('exclude_identifiers',[]))
            mask=inference.identifier_mask(db,projection.get('exclude_identifiers',[]))
            cols=[mask(cols[i]) for i in indices]
            count_row = db.execute(
                "SELECT count(*) as cnt FROM records WHERE asset_id=? AND version=? AND idx>1",
                (aid, version),
            ).fetchone()
            rows_count = count_row["cnt"] if count_row else 0
            return {
                "id": aid,
                "name": name,
                "version": version,
                "columns": cols,
                "projection_indices": indices,
                "total_rows": rows_count,
            }

    return {
        "id": table_ident,
        "name": table_ident,
        "version": "1",
        "columns": [],
        "total_rows": 0,
    }


def _get_all_source_records(store: Any, table_meta: Dict[str, Any], cases: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Fetch all rows for a table from SQLite records or fallback to cases."""
    records = []
    aid = table_meta.get("id")
    version = table_meta.get("version")
    name = table_meta.get("name")

    with store.db() as db:
        if aid and db.execute("SELECT 1 FROM sqlite_master WHERE name='records'").fetchone():
            rows_cursor = db.execute(
                "SELECT idx, data FROM records WHERE asset_id=? AND version=? AND idx>1 ORDER BY idx",
                (aid, version),
            ).fetchall()
            import lake_config
            projection=lake_config.read_lake_config(store).get('projection_policy', {})
            mask=inference.identifier_mask(db,projection.get('exclude_identifiers',[]))
            indices=table_meta.get('projection_indices')
            for r in rows_cursor:
                cells = json.loads(r["data"])
                if indices is not None:
                    if any(i>=len(cells) for i in indices):continue
                    projected=[]
                    for i in indices:
                        value,missing=inference.resolve_cell_value(cells[i],projection.get('null_tokens',inference.DEFAULT_NULL_TOKENS))
                        projected.append('' if missing else mask(value))
                    cells=projected
                idx = r["idx"]
                rid = f"{aid}:{version}:{idx}"
                records.append({
                    "record_id": rid,
                    "row_index": idx,
                    "cells": cells,
                    "name_record_id": f"{name}:row-{idx}" if name else rid,
                })

    if not records and cases:
        # Fallback to reconstructing rows from cases if DB records are not present (e.g., test fixtures)
        seen = set()
        for c in cases:
            for side in ("left", "right"):
                side_info = c.get(side, {})
                src = side_info.get("source", "")
                rec = side_info.get("record", {})
                rid = rec.get("record_id", "")
                if (src == name or src == aid or rid.startswith(table_meta["id"])) and rid and rid not in seen:
                    seen.add(rid)
                    records.append({
                        "record_id": rid,
                        "row_index": len(records) + 2,
                        "cells": rec.get("cells", []),
                        "name_record_id": rid,
                    })

    return records


def discover_scopes(store: Any, plan_id: str) -> List[Dict[str, Any]]:
    """Discover all distinct (relation, left_table, right_table) scopes in an integration plan."""
    plan = integration.get(store, plan_id)
    output_rows = plan.get("output", [])
    cases = plan.get("cases", [])

    # Map candidate cases for fast source lookup
    case_by_cand = {c.get("candidate"): c for c in cases if c.get("candidate")}

    scopes_dict = {}
    for r in output_rows:
        rel = r.get("relation")
        if not rel or rel in ("NEGATIVE", "UNRESOLVED"):
            continue

        cand = r.get("candidate")
        c = case_by_cand.get(cand, {})
        left_src = c.get("left", {}).get("source") or _extract_table_id_from_record(r.get("left_record", ""))
        right_src = c.get("right", {}).get("source") or _extract_table_id_from_record(r.get("right_record", ""))

        if not left_src or not right_src:
            continue

        s_id = _scope_id(rel, left_src, right_src)
        if s_id not in scopes_dict:
            left_meta = _get_table_meta(store, left_src)
            right_meta = _get_table_meta(store, right_src)

            # If columns were empty from DB, infer from output row
            if not left_meta["columns"] and r.get("left_columns"):
                left_meta["columns"] = r["left_columns"]
            if not right_meta["columns"] and r.get("right_columns"):
                right_meta["columns"] = r["right_columns"]

            # If total_rows is 0, count cases for this source
            if left_meta["total_rows"] == 0:
                left_meta["total_rows"] = len({
                    c2.get("left", {}).get("record", {}).get("record_id")
                    for c2 in cases if c2.get("left", {}).get("source") == left_src
                })
            if right_meta["total_rows"] == 0:
                right_meta["total_rows"] = len({
                    c2.get("right", {}).get("record", {}).get("record_id")
                    for c2 in cases if c2.get("right", {}).get("source") == right_src
                })

            scopes_dict[s_id] = {
                "scope_id": s_id,
                "relation": rel,
                "left_table": left_meta,
                "right_table": right_meta,
                "matched_left_records": set(),
                "matched_right_records": set(),
                "matched_rows": [],
                "is_self_join": left_src == right_src,
            }

        sc = scopes_dict[s_id]
        if r.get("left_record"):
            sc["matched_left_records"].add(r["left_record"])
        if r.get("right_record"):
            sc["matched_right_records"].add(r["right_record"])
        sc["matched_rows"].append(r)

    results = []
    for s_id, sc in scopes_dict.items():
        left_m = sc["left_table"]
        right_m = sc["right_table"]
        m_left_cnt = len(sc["matched_left_records"])
        m_right_cnt = len(sc["matched_right_records"])

        # Update total rows if matched rows exceed recorded count
        left_total = max(left_m["total_rows"], m_left_cnt)
        right_total = max(right_m["total_rows"], m_right_cnt)

        results.append({
            "scope_id": s_id,
            "relation": sc["relation"],
            "left_table": {
                "id": left_m["id"],
                "name": left_m["name"],
                "version": left_m["version"],
                "columns": left_m["columns"],
                "projection_indices": left_m.get("projection_indices"),
                "total_rows": left_total,
                "matched_rows": m_left_cnt,
                "unmatched_rows": max(0, left_total - m_left_cnt),
            },
            "right_table": {
                "id": right_m["id"],
                "name": right_m["name"],
                "version": right_m["version"],
                "columns": right_m["columns"],
                "projection_indices": right_m.get("projection_indices"),
                "total_rows": right_total,
                "matched_rows": m_right_cnt,
                "unmatched_rows": max(0, right_total - m_right_cnt),
            },
            "matched_pairs_count": len(sc["matched_rows"]),
            "is_self_join": sc["is_self_join"],
        })

    return sorted(results, key=lambda x: (x["relation"], x["left_table"]["name"], x["right_table"]["name"]))


def discovered_record_ids(store, table_ids):
    """Read compressed evidence once per selected table pair, not once per row."""
    from evidence_storage import decode
    with store.db() as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='discovery_links'").fetchone():return set()
        columns={r[1] for r in db.execute('PRAGMA table_info(discovery_links)')}
        where=' WHERE table_id IN ('+','.join('?' for _ in table_ids)+')' if table_ids and 'table_id' in columns else ''
        args=list(table_ids) if where else []
        if 'record_id' in columns:
            return {r[0] for r in db.execute('SELECT record_id FROM discovery_links'+where,args)}
        return {decode(r[0]).get('record_id') for r in db.execute('SELECT data FROM discovery_links'+where,args)}


def determine_unestablished_reason(
    store: Any,
    plan: Dict[str, Any],
    record_id: str,
    table_name: str,
    counterpart_table_name: str,
    candidate_cases_for_record: List[Dict[str, Any]],
    discovered_records=None,
) -> str:
    """Determine why a source row was not integrated into a relationship.

    Categories:
    - reviewed_negative: Candidate was formed and model/curation decided NEGATIVE.
    - reviewed_unresolved: Candidate was formed but decided UNRESOLVED or abstained.
    - budget_limited: Candidates existed in discovery or pool, but were omitted/filtered.
    - no_candidate: Record participated in discovery, but had no candidate bridge with counterpart.
    - not_searched: Record was not part of candidate generation or discovery.
    """
    # 1. Check decisions for candidates involving this record with the counterpart table
    decisions_by_cand = {d.get("candidate"): d for d in plan.get("decisions", [])}

    matching_cases = []
    for c in candidate_cases_for_record:
        c_left_src = c.get("left", {}).get("source", "")
        c_right_src = c.get("right", {}).get("source", "")
        if counterpart_table_name in (c_left_src, c_right_src):
            matching_cases.append(c)

    if matching_cases:
        # Check decisions
        has_negative = False
        has_unresolved = False
        has_budget = False

        for c in matching_cases:
            if c.get("noise") or c.get("score", 1.0) < 0.2:
                has_budget = True

            dec = decisions_by_cand.get(c.get("candidate"))
            if dec:
                rels = dec.get("relations", [])
                p_decs = dec.get("path_decisions", [])
                if "NEGATIVE" in rels or any(pd.get("relationship") == "NEGATIVE" for pd in p_decs):
                    has_negative = True
                elif dec.get("status") in ("abstain", "unresolved") or "UNRESOLVED" in rels or any(pd.get("relationship") == "UNRESOLVED" for pd in p_decs):
                    has_unresolved = True

        if has_negative:
            return "reviewed_negative"
        if has_unresolved:
            return "reviewed_unresolved"
        if has_budget:
            return "budget_limited"

        return "reviewed_unresolved"

    # 2. Check if the record participated in any candidates at all (in this plan)
    if candidate_cases_for_record:
        return "no_candidate"

    # 3. Discovery record identities live inside encoded link payloads.
    if discovered_records is None:
        discovered_records = discovered_record_ids(store, [record_id.rsplit(':', 2)[0]])
    if record_id in discovered_records:
        return "no_candidate"

    # 4. Check coverage pool limits in plan
    coverage = plan.get("coverage", {})
    if coverage.get("pool_omitted", 0) > 0 or coverage.get("ce_filtered", 0) > 0:
        return "budget_limited"

    return "not_searched"


def materialize_outer_view(
    store: Any,
    plan_id: str,
    policy: str = DEFAULT_POLICY,
    scope_id: Optional[str] = None,
    relation: Optional[str] = None,
    left_table: Optional[str] = None,
    right_table: Optional[str] = None,
    augmentation_run_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Execute outer retention materialization for a given plan, policy, and scope."""
    if policy not in POLICIES:
        raise ValueError(f"Unknown policy '{policy}'. Must be one of: {', '.join(POLICIES)}")

    plan = integration.get(store, plan_id)
    all_scopes = discover_scopes(store, plan_id)
    if not all_scopes:
        raise ValueError("No relationships found in this integration plan to materialize")

    # Select target scope
    target_scope = None
    if scope_id:
        for sc in all_scopes:
            if sc["scope_id"] == scope_id:
                target_scope = sc
                break
        if not target_scope:
            raise KeyError(f"Scope '{scope_id}' not found in plan '{plan_id}'")
    elif relation and left_table and right_table:
        for sc in all_scopes:
            if (sc["relation"] == relation and
                left_table in (sc["left_table"]["id"], sc["left_table"]["name"]) and
                right_table in (sc["right_table"]["id"], sc["right_table"]["name"])):
                target_scope = sc
                break
        if not target_scope:
            raise KeyError(f"Scope for relation '{relation}' ({left_table} -> {right_table}) not found")
    else:
        # Default to first scope if not specified
        target_scope = all_scopes[0]

    rel_name = target_scope["relation"]
    left_meta = target_scope["left_table"]
    right_meta = target_scope["right_table"]
    discovered_records = discovered_record_ids(store, [left_meta["id"], right_meta["id"]])
    output_rows = plan.get("output", [])
    cases = plan.get("cases", [])

    # Map candidate cases by record id for unestablished reasoning
    cases_by_left_rec = collections.defaultdict(list)
    cases_by_right_rec = collections.defaultdict(list)
    for c in cases:
        l_rec = c.get("left", {}).get("record", {}).get("record_id")
        r_rec = c.get("right", {}).get("record", {}).get("record_id")
        if l_rec:
            cases_by_left_rec[l_rec].append(c)
        if r_rec:
            cases_by_right_rec[r_rec].append(c)

    # Load accepted THOR proposals if augmentation_run_id is specified
    thor_proposals_by_cell = {}
    proposal_scope = "integration"
    if augmentation_run_id:
        with store.db() as db:
            if db.execute("SELECT 1 FROM sqlite_master WHERE name='augmentation_runs'").fetchone():
                origin=db.execute('SELECT scope FROM augmentation_runs WHERE id=?',(augmentation_run_id,)).fetchone()
                if origin:proposal_scope=origin['scope']
            if db.execute("SELECT 1 FROM sqlite_master WHERE name='augmentation_proposals'").fetchone():
                rows = db.execute(
                    "SELECT data FROM augmentation_proposals WHERE run_id=? AND decision='accepted'",
                    (augmentation_run_id,),
                ).fetchall()
                for r in rows:
                    p = json.loads(r["data"])
                    target = p.get("target", {})
                    rid = target.get("record_id")
                    c_idx = target.get("column_index")
                    if rid is not None and c_idx is not None:
                        thor_proposals_by_cell[(rid, c_idx)] = p

    def proposal_for_cell(rid, index, columns, meta, alias=None):
        physical=meta.get('projection_indices') or list(range(len(columns)))
        key=physical[index] if proposal_scope=='source' and index<len(physical) else index
        prop=thor_proposals_by_cell.get((rid,key)) or (thor_proposals_by_cell.get((alias,key)) if alias else None)
        if prop and prop.get('target',{}).get('column_name',columns[index])!=columns[index]:return None
        return prop

    # 1. Filter matched rows for this scope
    matched_rows = []
    matched_left_rids = set()
    matched_right_rids = set()

    for r in output_rows:
        if r.get("relation") == rel_name:
            cand = r.get("candidate")
            c = next((c for c in cases if c.get("candidate") == cand), None)
            l_src = c.get("left", {}).get("source") if c else _extract_table_id_from_record(r.get("left_record", ""))
            r_src = c.get("right", {}).get("source") if c else _extract_table_id_from_record(r.get("right_record", ""))

            if (l_src in (left_meta["id"], left_meta["name"]) and
                r_src in (right_meta["id"], right_meta["name"])):
                l_rid = r.get("left_record", "")
                r_rid = r.get("right_record", "")
                matched_left_rids.add(l_rid)
                matched_right_rids.add(r_rid)

                # Annotate missing original indices
                l_cells = list(r.get("left_cells") or [])
                r_cells = list(r.get("right_cells") or [])
                l_missing = [i for i, v in enumerate(l_cells) if v is None or v == ""]
                r_missing = [i for i, v in enumerate(r_cells) if v is None or v == ""]

                # Apply THOR augmentations to matched row if present
                l_augs = []
                for i in l_missing:
                    prop = proposal_for_cell(l_rid,i,r.get("left_columns",[]),left_meta)
                    if prop and prop.get("proposed_value") is not None and prop.get("proposed_value") != "":
                        l_augs.append({
                            "column_index": i,
                            "column_name": r.get("left_columns", [])[i] if i < len(r.get("left_columns", [])) else f"col_{i}",
                            "value": prop["proposed_value"],
                            "original": l_cells[i],
                            "proposal_id": prop["id"],
                        })
                        l_cells[i] = prop["proposed_value"]

                r_augs = []
                for i in r_missing:
                    prop = proposal_for_cell(r_rid,i,r.get("right_columns",[]),right_meta)
                    if prop and prop.get("proposed_value") is not None and prop.get("proposed_value") != "":
                        r_augs.append({
                            "column_index": i,
                            "column_name": r.get("right_columns", [])[i] if i < len(r.get("right_columns", [])) else f"col_{i}",
                            "value": prop["proposed_value"],
                            "original": r_cells[i],
                            "proposal_id": prop["id"],
                        })
                        r_cells[i] = prop["proposed_value"]

                row_copy = copy.deepcopy(r)
                row_copy.update({
                    "retention_status": "matched",
                    "left_cells": l_cells,
                    "right_cells": r_cells,
                    "left_missing_indices": l_missing,
                    "right_missing_indices": r_missing,
                    "is_outer_left_null": False,
                    "is_outer_right_null": False,
                    "unestablished_reason": None,
                    "left_augmentations": l_augs,
                    "right_augmentations": r_augs,
                    "role_direction": "matched_pair",
                })
                matched_rows.append(row_copy)

    # 2. Outer retention processing
    unmatched_left_rows = []
    unmatched_right_rows = []
    reasons_breakdown = collections.defaultdict(int)

    left_cols = left_meta["columns"]
    right_cols = right_meta["columns"]

    if policy in ("preserve-left", "preserve-both"):
        all_left_records = _get_all_source_records(store, left_meta, cases)
        for rec in all_left_records:
            rid = rec["record_id"]
            name_rid = rec["name_record_id"]
            if rid not in matched_left_rids and name_rid not in matched_left_rids:
                cells = list(rec["cells"])
                l_missing = [i for i, v in enumerate(cells) if v is None or v == ""]

                # Apply THOR augmentations to retained left row if available
                l_augs = []
                for i in l_missing:
                    prop = proposal_for_cell(rid,i,left_cols,left_meta,name_rid)
                    if prop and prop.get("proposed_value") is not None and prop.get("proposed_value") != "":
                        l_augs.append({
                            "column_index": i,
                            "column_name": left_cols[i] if i < len(left_cols) else f"col_{i}",
                            "value": prop["proposed_value"],
                            "original": cells[i],
                            "proposal_id": prop["id"],
                        })
                        cells[i] = prop["proposed_value"]

                cand_cases = cases_by_left_rec.get(rid, []) or cases_by_left_rec.get(name_rid, [])
                reason = determine_unestablished_reason(
                    store, plan, rid, left_meta["id"], right_meta["id"], cand_cases, discovered_records
                )
                reasons_breakdown[reason] += 1

                unmatched_left_rows.append({
                    "candidate": f"OUTER:{rid}",
                    "cluster": None,
                    "relation": None,
                    "direction": "unestablished",
                    "left_record": rid,
                    "right_record": None,
                    "left_columns": left_cols,
                    "right_columns": right_cols,
                    "left_cells": cells,
                    "right_cells": [None] * len(right_cols),
                    "left_value": cells[0] if cells else None,
                    "right_value": None,
                    "record_a_record": rid,
                    "record_b_record": None,
                    "record_a_cells": cells,
                    "record_b_cells": [None] * len(right_cols),
                    "left_missing_indices": l_missing,
                    "right_missing_indices": list(range(len(right_cols))),
                    "is_outer_left_null": False,
                    "is_outer_right_null": True,
                    "retention_status": "unmatched_left",
                    "unestablished_reason": reason,
                    "evidence_quote": None,
                    "evidence_count": 0,
                    "evidence": [],
                    "left_augmentations": l_augs,
                    "right_augmentations": [],
                    "role_direction": "left_only",
                })

    if policy == "preserve-both":
        all_right_records = _get_all_source_records(store, right_meta, cases)
        for rec in all_right_records:
            rid = rec["record_id"]
            name_rid = rec["name_record_id"]
            if rid not in matched_right_rids and name_rid not in matched_right_rids:
                cells = list(rec["cells"])
                r_missing = [i for i, v in enumerate(cells) if v is None or v == ""]

                # Apply THOR augmentations to retained right row if available
                r_augs = []
                for i in r_missing:
                    prop = proposal_for_cell(rid,i,right_cols,right_meta,name_rid)
                    if prop and prop.get("proposed_value") is not None and prop.get("proposed_value") != "":
                        r_augs.append({
                            "column_index": i,
                            "column_name": right_cols[i] if i < len(right_cols) else f"col_{i}",
                            "value": prop["proposed_value"],
                            "original": cells[i],
                            "proposal_id": prop["id"],
                        })
                        cells[i] = prop["proposed_value"]

                cand_cases = cases_by_right_rec.get(rid, []) or cases_by_right_rec.get(name_rid, [])
                reason = determine_unestablished_reason(
                    store, plan, rid, right_meta["id"], left_meta["id"], cand_cases, discovered_records
                )
                reasons_breakdown[reason] += 1

                unmatched_right_rows.append({
                    "candidate": f"OUTER:{rid}",
                    "cluster": None,
                    "relation": None,
                    "direction": "unestablished",
                    "left_record": None,
                    "right_record": rid,
                    "left_columns": left_cols,
                    "right_columns": right_cols,
                    "left_cells": [None] * len(left_cols),
                    "right_cells": cells,
                    "left_value": None,
                    "right_value": cells[0] if cells else None,
                    "record_a_record": None,
                    "record_b_record": rid,
                    "record_a_cells": [None] * len(left_cols),
                    "record_b_cells": cells,
                    "left_missing_indices": list(range(len(left_cols))),
                    "right_missing_indices": r_missing,
                    "is_outer_left_null": True,
                    "is_outer_right_null": False,
                    "retention_status": "unmatched_right",
                    "unestablished_reason": reason,
                    "evidence_quote": None,
                    "evidence_count": 0,
                    "evidence": [],
                    "left_augmentations": [],
                    "right_augmentations": r_augs,
                    "role_direction": "right_only",
                })

    all_materialized_rows = matched_rows + unmatched_left_rows + unmatched_right_rows

    return {
        "plan_id": plan_id,
        "policy": policy,
        "scope": target_scope,
        "counts": {
            "matched_rows": len(matched_rows),
            "unmatched_left": len(unmatched_left_rows),
            "unmatched_right": len(unmatched_right_rows),
            "total_rows": len(all_materialized_rows),
            "unique_matched_left_records": len(matched_left_rids),
            "unique_matched_right_records": len(matched_right_rids),
            "reasons_breakdown": dict(reasons_breakdown),
        },
        "columns": {
            "left_columns": left_cols,
            "right_columns": right_cols,
        },
        "rows": all_materialized_rows,
        "notice": NOTICE,
    }


def export_outer_csv(
    store: Any,
    plan_id: str,
    policy: str = DEFAULT_POLICY,
    scope_id: Optional[str] = None,
    relation: Optional[str] = None,
    left_table: Optional[str] = None,
    right_table: Optional[str] = None,
    augmentation_run_id: Optional[str] = None,
) -> bytes:
    """Export outer integration materialization as CSV with explicit provenance and outer null markers."""
    view = materialize_outer_view(
        store,
        plan_id,
        policy=policy,
        scope_id=scope_id,
        relation=relation,
        left_table=left_table,
        right_table=right_table,
        augmentation_run_id=augmentation_run_id,
    )

    out = io.StringIO(newline="")
    # Write provenance header
    out.write("# IDUN Outer Integration Materialization\n")
    out.write(f"# Plan ID: {plan_id}\n")
    out.write(f"# Policy: {policy}\n")
    out.write(f"# Relation: {view['scope']['relation']}\n")
    out.write(f"# Table Scope: Left={view['scope']['left_table']['name']} Right={view['scope']['right_table']['name']}\n")
    out.write(f"# Notice: {view['notice']}\n")

    writer = csv.writer(out)

    left_cols = view["columns"]["left_columns"]
    right_cols = view["columns"]["right_columns"]

    headers = (
        ["Pair_ID", "Retention_Status", "Left_Record"]
        + [f"L.{c}" for c in left_cols]
        + ["Relation", "Direction"]
        + [f"R.{c}" for c in right_cols]
        + ["Right_Record", "Unestablished_Reason", "Outer_Induced_Null", "Evidence_Quote", "Enriched_Provenance"]
    )
    writer.writerow(headers)

    for r in view["rows"]:
        is_outer_null = "RIGHT" if r.get("is_outer_right_null") else "LEFT" if r.get("is_outer_left_null") else "NONE"
        l_cells_formatted = [
            "[OUTER_NULL]" if r.get("is_outer_left_null") else (c if c is not None else "")
            for c in r.get("left_cells", [])
        ]
        r_cells_formatted = [
            "[OUTER_NULL]" if r.get("is_outer_right_null") else (c if c is not None else "")
            for c in r.get("right_cells", [])
        ]

        # Enriched provenance summary
        l_augs = r.get("left_augmentations", [])
        r_augs = r.get("right_augmentations", [])
        aug_desc = []
        for a in l_augs:
            aug_desc.append(f"L.{a['column_name']}='{a['value']}'")
        for a in r_augs:
            aug_desc.append(f"R.{a['column_name']}='{a['value']}'")
        aug_str = ", ".join(aug_desc) if aug_desc else "baseline"

        row_vals = (
            [r.get("candidate", ""), r.get("retention_status", ""), r.get("left_record") or ""]
            + l_cells_formatted
            + [r.get("relation") or "UNESTABLISHED", r.get("direction") or ""]
            + r_cells_formatted
            + [
                r.get("right_record") or "",
                r.get("unestablished_reason") or "",
                is_outer_null,
                r.get("evidence_quote") or "",
                aug_str,
            ]
        )
        writer.writerow(row_vals)

    return out.getvalue().encode("utf-8-sig")
