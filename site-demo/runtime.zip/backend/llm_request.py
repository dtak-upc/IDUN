"""Private pipe-only worker; never writes prompts, responses or credentials to disk."""
try:
    import truststore
    truststore.inject_into_ssl()
except Exception:
    pass

import json
import sys
import llm

if __name__ == '__main__':
    try:
        request = json.load(sys.stdin)
        if request.get('operation') in ('typed_attribute', 'knowledge_schema'):
            from relationship_probe import structured_request
            output = structured_request(request['config'],request['messages'],request['schema'],request['timeout'])
        elif request.get('operation') == 'relationship_probe':
            from relationship_probe import probe_single_pair
            output = probe_single_pair(request['config'], request['sample'], request['timeout'])
        elif request.get('operation') == 'relationship_equivalence':
            from relationship_equivalence import generate
            output = generate(request['config'], request['predicates'], request['timeout'])
        else:
            output = llm.generate(request['config'], request['case'], request['timeout'], schema_config=request.get('schema_config'), correction=request.get('correction'))
        result = {'result': output}
    except Exception as error:
        result = {'error': str(error)}
        if isinstance(error, llm.InvalidCompletion):
            result.update(kind='invalid_completion', response=error.response)
    sys.stdout.buffer.write(json.dumps(result).encode('utf-8'))
