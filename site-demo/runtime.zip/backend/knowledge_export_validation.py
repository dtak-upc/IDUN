"""Offline, read-only checks for IDUN's exported T-Box and A-Box.

Requires the optional evaluation extra. No model, API or database access.
Only expanded JSON-LD is accepted: remote contexts are never resolved.
"""
import json
from pathlib import Path

from rdflib import Graph, Literal, Namespace, RDF, RDFS, OWL
from rdflib.compare import isomorphic

V = Namespace('urn:idun:vocab:')
PROV = Namespace('http://www.w3.org/ns/prov#')


def parse_export(content, fmt):
    if fmt == 'jsonld':
        payload = json.loads(content)
        def check(value):
            if isinstance(value, dict):
                if '@context' in value:
                    raise ValueError('Use expanded IDUN JSON-LD without contexts; no remote resolution is allowed')
                for child in value.values():
                    check(child)
            elif isinstance(value, list):
                for child in value:
                    check(child)
        check(payload)
        fmt = 'json-ld'
    elif fmt != 'ttl':
        raise ValueError('Choose ttl or jsonld')
    return Graph().parse(data=content, format=fmt)


def read_export(path):
    path = Path(path)
    return parse_export(path.read_text(encoding='utf-8'), path.suffix.lstrip('.').lower())


def validate(tbox, abox):
    """Check IDUN export contracts, not ontology truth or clinical correctness."""
    issues = []
    classes = set(tbox.subjects(RDF.type, OWL.Class))
    properties = set(tbox.subjects(RDF.type, OWL.ObjectProperty))
    attributes = set(tbox.subjects(RDF.type, OWL.DatatypeProperty))
    assertions = set(abox.subjects(RDF.type, V.Assertion))
    contributions = set(abox.subjects(RDF.type, V.Contribution))
    records = set(abox.subjects(V.sourceRecord, None))
    runs = set(abox.subjects(RDF.type, PROV.Entity))

    def fail(code, subject):
        issues.append({'code': code, 'subject': str(subject)})

    for subject in classes | properties | attributes:
        if not list(tbox.objects(subject, RDFS.label)):
            fail('missing_schema_label', subject)
    for subject in tbox.subjects(V.sourceRecord, None):
        fail('instance_in_tbox', subject)
    for prop in properties:
        directions = list(tbox.objects(prop, V.direction))
        if len(directions) != 1 or str(directions[0]) not in ('directed', 'unspecified', 'bidirectional'):
            fail('invalid_schema_direction', prop)
            continue
        if str(directions[0]) == 'directed':
            for endpoint in (RDFS.domain, RDFS.range):
                values = list(tbox.objects(prop, endpoint))
                if len(values) != 1 or values[0] not in classes:
                    fail('invalid_schema_endpoint', prop)
        else:
            if not set(tbox.objects(prop, V.endpointConcept)) <= classes or not list(tbox.objects(prop, V.endpointConcept)):
                fail('invalid_schema_endpoint', prop)
    for record in records:
        if not set(abox.objects(record, RDF.type)) & classes:
            fail('record_class_missing_from_tbox', record)
    for assertion in assertions:
        relations = list(abox.objects(assertion, V.relationship))
        if len(relations) != 1 or relations[0] not in properties:
            fail('assertion_relationship_missing_from_tbox', assertion)
            continue
        prop = relations[0]
        direction = str(tbox.value(prop, V.direction))
        if list(abox.objects(assertion, V.direction)) != [Literal(direction)]:
            fail('assertion_direction_mismatch', assertion)
        if direction == 'unspecified':
            endpoints = set(abox.objects(assertion, V.endpoint))
            if len(endpoints) != 2 or not endpoints <= records:
                fail('invalid_undirected_endpoints', assertion)
            if any(abox.objects(assertion, RDF.subject)) or any(abox.objects(assertion, RDF.predicate)) or any(abox.objects(assertion, RDF.object)):
                fail('fabricated_direction', assertion)
        else:
            subjects = list(abox.objects(assertion, RDF.subject))
            objects = list(abox.objects(assertion, RDF.object))
            if len(subjects) != 1 or len(objects) != 1 or not set(subjects + objects) <= records:
                fail('invalid_directed_endpoints', assertion)
                continue
            if list(abox.objects(assertion, RDF.predicate)) != [prop] or (subjects[0], prop, objects[0]) not in abox:
                fail('missing_predicate_triple', assertion)
            if direction == 'bidirectional' and (objects[0], prop, subjects[0]) not in abox:
                fail('missing_reverse_triple', assertion)
            if direction == 'directed':
                for record, endpoint in ((subjects[0], RDFS.domain), (objects[0], RDFS.range)):
                    if tbox.value(prop, endpoint) not in set(abox.objects(record, RDF.type)):
                        fail('assertion_endpoint_class_mismatch', assertion)
        if not set(abox.objects(assertion, PROV.wasDerivedFrom)) & runs:
            fail('missing_run_provenance', assertion)
        if not list(abox.objects(assertion, V.evidenceMetadata)):
            fail('missing_evidence_provenance', assertion)
    for contribution in contributions:
        if not set(abox.objects(contribution, V.assertion)) <= assertions or not list(abox.objects(contribution, V.assertion)):
            fail('dangling_contribution', contribution)
        if not set(abox.objects(contribution, PROV.wasDerivedFrom)) & runs:
            fail('missing_contribution_run', contribution)
    return {'valid': not issues, 'issues': issues, 'counts': {
        'concepts': len(classes), 'relationships': len(properties), 'attributes': len(attributes),
        'records': len(records), 'assertions': len(assertions), 'contributions': len(contributions),
        'runs': len(runs), 'schema_triples': len(tbox), 'instance_triples': len(abox)},
        'scope': 'IDUN RDF structure and provenance only; not semantic or gold-label accuracy'}


def equivalent(first, second):
    return isomorphic(first, second)
