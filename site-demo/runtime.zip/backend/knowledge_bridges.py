"""Read-only diagnostics for explicit identity bridges in a pinned query scope."""
import json
import knowledge as kg
import knowledge_entity_keys as keys
import knowledge_identity as identity


def inspect(store, graph, runs, start=0, limit=20, interrupted=None):
    saved=[link for link in identity.read(store) if link['status']=='accepted']
    counts={'ready':0,'outside_scope':0,'stale_key':0,'stale_projection':0,'missing_record':0,'inconsistent_record':0,'changed_key':0}
    if not saved:return {'revision':kg.digest([graph['revision'],saved]),'scope':runs,'total':0,'offset':start,'limit':limit,'counts':counts,'cross_run':0,'items':[]}
    definitions={k['id']:k for k in keys.read(store)}
    record_ids=json.dumps(sorted({rid for link in saved for rid in link['records']}))
    scope=','.join('?' for _ in runs)
    parts=[];args=[]
    for side in ('subject','object'):
        parts.append(f"SELECT run,id assertion,json_extract(data,'$.{side}') record FROM kg_auto_instances WHERE run IN ({scope}) AND json_extract(data,'$.{side}.id') IN (SELECT value FROM json_each(?))")
        args.extend([*runs,record_ids])
    # Group endpoints in SQL; do not load the full assertion lake into Python.
    with store.db() as db:
        if interrupted:db.set_progress_handler(interrupted,1000)
        observations={ (r['rid'],r['concept']):dict(r) for r in db.execute("""
            SELECT json_extract(record,'$.id') rid,json_extract(record,'$.concept_id') concept,
            count(DISTINCT assertion) assertions,group_concat(DISTINCT run) runs,min(record) record,
            count(DISTINCT json_array(json_extract(record,'$.columns'),json_extract(record,'$.cells'))) variants
            FROM ("""+' UNION ALL '.join(parts)+') GROUP BY rid,concept',args)}
    items=[]
    for link in saved:
        if link['status']!='accepted':continue
        key=link['key'];definition=definitions.get(key['id'])
        reason='ready'
        if sorted(runs)!=key['runs']:reason='outside_scope'
        elif definition!=key:reason='stale_key'
        elif keys.stale(key,graph,runs):reason='stale_projection'
        records=[];values=[]
        for rid in link['records']:
            row=observations.get((rid,key['concept']))
            fallback=next((r for r in link['summaries'] if r['id']==rid),{'id':rid,'label':'Unavailable record','source':'Unavailable source','row':None})
            if row:
                record=json.loads(row['record'])
                records.append({'id':rid,'label':record['label'],'source':record['source'],'row':record['row'],'runs':row['runs'].split(','),'assertions':row['assertions']})
                values.append(keys.key_value(row['record'],key['attributes']))
            else:records.append(dict(fallback,runs=[],assertions=0))
        if reason=='ready':
            if len(records)!=2 or any((rid,key['concept']) not in observations for rid in link['records']):reason='missing_record'
            elif any(observations[(rid,key['concept'])]['variants']!=1 for rid in link['records']):reason='inconsistent_record'
            elif len(values)!=2 or None in values or values[0]!=values[1]:reason='changed_key'
        counts[reason]+=1
        items.append({'id':link['id'],'concept':key['concept'],'key':{'id':key['id'],'attributes':[a['name'] for a in key['attributes']]},'reason':reason,'records':records,
            'cross_run':reason=='ready' and any(a!=b for a in records[0]['runs'] for b in records[1]['runs'])})
    items.sort(key=lambda x:(x['reason']!='ready',x['id']))
    return {'revision':kg.digest([graph['revision'],saved]),'scope':runs,'total':len(items),'offset':start,'limit':limit,
        'counts':counts,'cross_run':sum(i['cross_run'] for i in items),'items':items[start:start+limit]}


def route(store,body):
    import knowledge_auto as auto
    runs=auto.selected(body)
    with store.lock:
        graph=auto.view(store,runs)
        if graph['revision']!=body.get('revision'):raise ValueError('Query graph changed; refresh bridge diagnostics')
        return inspect(store,graph,runs,identity.offset(body))
