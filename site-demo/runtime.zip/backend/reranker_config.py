"""Lake-specific neural reranker selections; no silent replacement of explicit choices."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODELS = {
    'bge-reranker-base': 'BAAI/bge-reranker-base',
    'gte-reranker-modernbert-base': 'Alibaba-NLP/gte-reranker-modernbert-base',
}


def validate(value):
    if value is not None and (not isinstance(value, str) or value not in MODELS):
        raise ValueError('Choose a supported neural reranker from Step 2')
    return value


def resolve(value):
    validate(value)
    if value == 'gte-reranker-modernbert-base':
        candidates = [ROOT / 'models/step2_discovery/gte-reranker',
                      ROOT / 'models/step2_discovery/gte-reranker-modernbert-base',
                      ROOT / '.idun/models/gte-reranker']
    else:
        candidates = [ROOT / 'models/step2_discovery/bge-reranker-base']
    for path in candidates:
        if any((path / filename).is_file() for filename in ('model.safetensors', 'pytorch_model.bin')):
            return str(path), MODELS[value]
    raise ValueError(f'Selected reranker {MODELS[value]} is not downloaded. Download it in Settings → Step 2; IDUN will not substitute another model.')


def fingerprint(path, name):
    files = []
    for filename in ('config.json', 'model.safetensors', 'pytorch_model.bin', 'tokenizer.json', 'tokenizer_config.json'):
        item = Path(path) / filename
        if item.is_file():
            stat = item.stat()
            files.append((filename, stat.st_size, stat.st_mtime_ns))
    return [name, files]
