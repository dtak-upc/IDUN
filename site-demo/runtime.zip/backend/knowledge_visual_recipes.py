"""Lake-local visual query recipes. Saving never executes or stores answers."""
import json
import time
import uuid
import knowledge as kg
import knowledge_visual_query as visual

def setup(store):
    with store.db() as db:db.execute('CREATE TABLE IF NOT EXISTS kg_visual_recipes(id TEXT PRIMARY KEY, updated REAL, data TEXT NOT NULL)')

def route(store,action,body):
    setup(store)
    with store.lock:
        if action=='visual-query-context':
            graph,runs,refs,snapshot=visual.context(store,body)
            return {'graph':graph,'runs':runs,'checkpoint':snapshot and {k:snapshot[k] for k in ('id','title','recorded')}}
        with store.db() as db:
            if action=='saved-visual-queries':
                offset=body.get('offset',0);search=body.get('search','')
                if type(offset) is not int or not 0<=offset<=1000000 or not isinstance(search,str) or len(search)>100:raise ValueError('Invalid query catalog page')
                where="instr(lower(json_extract(data,'$.title')),lower(?))>0"
                total=db.execute('SELECT count(*) FROM kg_visual_recipes WHERE '+where,(search,)).fetchone()[0]
                items=[json.loads(r['data']) for r in db.execute('SELECT data FROM kg_visual_recipes WHERE '+where+' ORDER BY updated DESC,id LIMIT 10 OFFSET ?',(search,offset))]
                return {'items':[{k:r[k] for k in ('id','title','updated','version')} for r in items],'total':total,'offset':offset,'limit':10}
            existing=None
            if body.get('id'):
                row=db.execute('SELECT data FROM kg_visual_recipes WHERE id=?',(body['id'],)).fetchone()
                if not row:raise ValueError('Saved query not found')
                existing=json.loads(row['data'])
            if action=='get-saved-visual-query':
                if not existing:raise ValueError('Select a saved query')
                graph,runs,refs,snapshot=visual.context(store,existing['query'])
                stale=graph['revision']!=existing['query']['revision']
                return dict(existing,graph=graph,runs=runs,stale=stale)
            if existing and body.get('version')!=existing['version']:raise ValueError('Saved query changed; reload before editing')
            if action=='remove-saved-visual-query':
                if not existing:raise ValueError('Select a saved query')
                db.execute('DELETE FROM kg_visual_recipes WHERE id=?',(existing['id'],));return {'removed':existing['id']}
            title=body.get('title','')
            if not isinstance(title,str) or not 1<=len(title.strip())<=100:raise ValueError('Enter a query name of 1–100 characters')
            if action=='rename-saved-visual-query':
                if not existing:raise ValueError('Select a saved query')
                recipe=dict(existing,title=title.strip())
            elif action=='save-visual-query':
                query=body.get('query')
                if not isinstance(query,dict) or len(json.dumps(query))>100000:raise ValueError('Query recipe is too large or invalid')
                allowed=('runs','checkpoint','revision','concept','pattern','pattern_mode','start_condition','comparisons','role_labels','budget','limit','start_limit','temporal')
                query={k:query[k] for k in allowed if k in query}
                preview=visual.route(store,'preview-visual-path',query)
                if preview['token']!=body.get('preview_token'):raise ValueError('Preview the current query before saving')
                from knowledge_traversal import integer
                for name,default,low,high in [('budget',1000,10,5000),('limit',20,1,100),('start_limit',100,1,1000)]:integer(query,name,default,low,high)
                recipe={'id':existing['id'] if existing else str(uuid.uuid4()),'title':title.strip(),'query':query}
            else:raise ValueError('Unknown saved query operation')
            recipe.update(updated=time.time(),version=str(uuid.uuid4()))
            db.execute('INSERT OR REPLACE INTO kg_visual_recipes VALUES(?,?,?)',(recipe['id'],recipe['updated'],json.dumps(recipe)))
            return recipe
