"""Local lake registry. Legacy bytes stay in place; new lakes get separate stores."""
from contextlib import closing
import json
import sqlite3
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path


class LakePool:
    def __init__(self, ingest, inference):
        self.ingest, self.inference = ingest, inference

    def submit(self, fn, *args, **kwargs):
        pool = self.ingest if fn.__name__ == 'parse' else self.inference
        return pool.submit(fn, *args, **kwargs)


class Lakes:
    def __init__(self, root, factory):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.factory, self.lock, self.stores = factory, threading.RLock(), {}
        self.path = self.root / 'lakes.json'
        self.inference = ThreadPoolExecutor(max_workers=1, thread_name_prefix='lake-inference')
        self.ingest = ThreadPoolExecutor(max_workers=2, thread_name_prefix='lake-ingest')
        if self.path.exists():
            self.entries = json.loads(self.path.read_text(encoding='utf-8'))['lakes']
        else:
            catalog = self.root / 'catalog.sqlite3'
            if catalog.exists():
                backup = self.root / 'backups' / 'before-lakes.sqlite3'
                backup.parent.mkdir(exist_ok=True)
                if not backup.exists():
                    with closing(sqlite3.connect(catalog)) as source, closing(sqlite3.connect(backup)) as target:
                        source.backup(target)
            self.entries = [{'id': str(uuid.uuid4()), 'name': 'Existing lake' if catalog.exists() else 'My first lake', 'legacy': True, 'created': time.time()}]
            self._save()
        self.default = self.resolve(self.entries[0]['id'])

    def _save(self):
        temporary = self.path.with_suffix('.tmp')
        temporary.write_text(json.dumps({'version': 1, 'lakes': self.entries}, indent=2), encoding='utf-8')
        temporary.replace(self.path)

    def resolve(self, lake_id):
        with self.lock:
            entry = next((e for e in self.entries if e['id'] == lake_id), None)
            if not entry:
                raise KeyError('Lake not found')
            if lake_id not in self.stores:
                directory = self.root if entry['legacy'] else self.root / 'lakes' / str(uuid.UUID(lake_id))
                store = self.factory(directory)
                store.pool.shutdown()
                store.pool = LakePool(self.ingest, self.inference)
                store.settings_root = self.root
                store.lake_id = lake_id
                store.registry = self
                from profiling import upgrade_projection_metadata
                upgrade_projection_metadata(store)
                self.stores[lake_id] = store
            return self.stores[lake_id]

    def listing(self):
        with self.lock:
            result = []
            for e in self.entries:
                store = self.resolve(e['id'])
                with store.db() as db:
                    files = db.execute("SELECT COUNT(*) FROM jobs WHERE status='ready'").fetchone()[0]
                result.append({**e, 'files': files})
            return {'lakes': result, 'default_id': self.entries[0]['id']}

    def write(self, data, lake_id=None):
        name = data.get('name')
        if not isinstance(name, str) or not name.strip() or len(name) > 120:
            raise ValueError('Lake name must contain 1–120 characters')
        with self.lock:
            if lake_id:
                self.resolve(lake_id)
                entry = next(e for e in self.entries if e['id'] == lake_id)
                entry['name'] = name.strip()
            else:
                entry = {'id': str(uuid.uuid4()), 'name': name.strip(), 'legacy': False, 'created': time.time()}
                self.entries.append(entry)
            self._save()
            return dict(entry)

    def removal_preview(self, lake_id):
        with self.lock:
            store = self.resolve(lake_id)
            with store.lock, store.db() as db:
                if any(getattr(store,k,False) for k in ('profile_active','discovery_active','integration_active','knowledge_active','storage_active')):
                    raise ValueError('Finish or cancel active lake jobs before removal')
                jobs = [tuple(r) for r in db.execute('SELECT id,status,updated FROM jobs ORDER BY id')]
                if any(r[1] not in ('ready','failed','cancelled','interrupted') for r in jobs):
                    raise ValueError('Finish or cancel file uploads before removing this lake')
                has_runs = db.execute("SELECT 1 FROM sqlite_master WHERE name='integration_plans'").fetchone()
                runs = [tuple(r) for r in db.execute('SELECT id,data FROM integration_plans ORDER BY id')] if has_runs else []
                entry = next(e for e in self.entries if e['id']==lake_id)
                import hashlib
                token=hashlib.sha256(json.dumps([entry,jobs,runs],sort_keys=True).encode()).hexdigest()
                return {'id':lake_id,'name':entry['name'],'files':len(jobs),'runs':len(runs),'token':token}

    def remove(self, lake_id, data):
        import gc, shutil
        with self.lock:
            store=self.resolve(lake_id)
            with store.lock:
                preview=self.removal_preview(lake_id)
                if data.get('token')!=preview['token'] or data.get('name')!=preview['name']:
                    raise ValueError('Lake changed; review removal again and enter its exact name')
                entry=next(e for e in self.entries if e['id']==lake_id)
                # The legacy root also owns shared models/settings and other lakes.
                names=('catalog.sqlite3','catalog.sqlite3-wal','catalog.sqlite3-shm','blobs','pending','vectors.lance','backups')
                candidates=[self.root/n for n in names] if entry['legacy'] else [self.root/'lakes'/str(uuid.UUID(lake_id))]
                for path in candidates:
                    expected=self.root if entry['legacy'] else (self.root/'lakes').resolve()
                    if path.resolve().parent!=expected or path.is_symlink():
                        raise ValueError('Unsafe lake storage path')
                if hasattr(store,'_vectors'): del store._vectors
                gc.collect()
                with store.db() as db:
                    if db.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()[0]:
                        raise ValueError('Lake has active readers; retry removal')
                trash=self.root/'removed-lakes'/uuid.uuid4().hex
                trash.mkdir(parents=True)
                moved=[]
                old_entries=self.entries[:]
                try:
                    for path in candidates:
                        if path.exists():
                            dest=trash/path.name;path.rename(dest);moved.append((path,dest))
                    self.entries=[e for e in self.entries if e['id']!=lake_id]
                    if not self.entries:
                        self.entries=[{'id':str(uuid.uuid4()),'name':'My first lake','legacy':False,'created':time.time()}]
                    self._save()
                except Exception:
                    self.entries=old_entries
                    for original,dest in reversed(moved):dest.rename(original)
                    raise
                store.removed=True
                self.stores.pop(lake_id,None)
                self.default=self.resolve(self.entries[0]['id'])
                pending=False
                try:
                    if trash.resolve().parent != (self.root/'removed-lakes').resolve():raise ValueError('Unsafe cleanup path')
                    shutil.rmtree(trash)
                except OSError:pending=True
                return {**preview,'removed':True,'cleanup_pending':pending,'next_lake':dict(self.entries[0])}

    def busy(self):
        for store in self.stores.values():
            if any(getattr(store, k, False) for k in ('profile_active', 'discovery_active', 'integration_active', 'knowledge_active', 'storage_active')):
                return True
            with store.db() as db:
                if db.execute("SELECT 1 FROM jobs WHERE status NOT IN ('ready','failed','cancelled','interrupted') LIMIT 1").fetchone():
                    return True
        return False

    def close(self):
        for store in self.stores.values():
            for stage in ('profile', 'discovery', 'integration', 'knowledge'):
                event = getattr(store, stage + '_cancel', None)
                if event:
                    event.set()
        for store in self.stores.values():
            graph_thread = getattr(store, 'knowledge_thread', None)
            if graph_thread: graph_thread.join()
            thread = getattr(store, 'storage_thread', None)
            if thread: thread.join()
        self.inference.shutdown(wait=True)
        self.ingest.shutdown(wait=True)
