"""Strict offline LOKI loader, delegating to model_registry for strict offline loading."""
from pathlib import Path
import os, sys
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
import torch
import model_registry

ROOT = Path(__file__).resolve().parents[1]

def load(bundle_id: str = "legacy-loki-clinical", device_override: str = None, version: str = None, generic_encoder=None, generic_dimensions=None):
    """Loads model strictly through model_registry adapter."""
    return model_registry.load_bundle(bundle_id=bundle_id, device=device_override, version=version, generic_encoder=generic_encoder, generic_dimensions=generic_dimensions)
