"""Evaluator-only schema comparison with explicit reviewed semantic mappings.

Never imports gold terms into model prompts or writes to a lake. Unknown mappings
are reported as unevaluated, not counted as incorrect predictions.
"""
import hashlib
from rdflib import RDF, RDFS, OWL, URIRef
from knowledge_export_validation import V


def fingerprint(graph):
    # IDUN schema export and supported gold terms use named nodes/literals.
    values = sorted(' '.join(term.n3() for term in triple) for triple in graph)
    return hashlib.sha256('\n'.join(values).encode('utf-8')).hexdigest()


def inventory(graph):
    def terms(kind):
        return [{'id': str(subject), 'label': str(graph.value(subject, RDFS.label) or subject),
                 'domains': sorted(str(x) for x in graph.objects(subject, RDFS.domain)),
                 'ranges': sorted(str(x) for x in graph.objects(subject, RDFS.range))}
                for subject in sorted(set(graph.subjects(RDF.type, kind)), key=str)]
    return {'concepts': terms(OWL.Class), 'relationships': terms(OWL.ObjectProperty)}


def mapping_template(predicted, gold):
    p, g = inventory(predicted), inventory(gold)
    return {'version': 1, 'predicted_sha256': fingerprint(predicted), 'gold_sha256': fingerprint(gold),
            'reviewer': '', 'coverage_note': '', 'training_overlap_note': '',
            'gold_scope': {kind: [x['id'] for x in g[kind]] for kind in g},
            'concepts': [{'predicted': x['id'], 'label': x['label'], 'status': 'unknown', 'gold': None} for x in p['concepts']],
            'relationships': [{'predicted': x['id'], 'label': x['label'], 'status': 'unknown', 'gold': None} for x in p['relationships']],
            'gold_inventory': g}


def metrics(tp, fp, fn):
    return {'true_positive': tp, 'false_positive': fp, 'false_negative': fn,
            'precision': tp / (tp + fp) if tp + fp else None,
            'recall': tp / (tp + fn) if tp + fn else None,
            'f1': 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else None}


def evaluate(predicted, gold, review):
    if review.get('version') != 1:
        raise ValueError('Unsupported schema evaluation mapping version')
    for name, graph in [('predicted', predicted), ('gold', gold)]:
        if review.get(name + '_sha256') != fingerprint(graph):
            raise ValueError(name + ' schema changed; prepare and review a new mapping')
    if not str(review.get('reviewer', '')).strip() or not str(review.get('coverage_note', '')).strip():
        raise ValueError('Provide reviewer and coverage_note before scoring')
    p, g = inventory(predicted), inventory(gold)
    mappings, unknown, unmatched, scopes = {}, {}, {}, {}
    for kind in ('concepts', 'relationships'):
        predicted_ids = {x['id'] for x in p[kind]}
        gold_ids = {x['id'] for x in g[kind]}
        scope = review.get('gold_scope', {}).get(kind)
        if not isinstance(scope, list) or len(set(scope)) != len(scope) or not set(scope) <= gold_ids:
            raise ValueError('Invalid gold_scope for ' + kind)
        scopes[kind] = set(scope)
        entries = review.get(kind)
        if not isinstance(entries, list):
            raise ValueError('Missing mapping list for ' + kind)
        ids = [x.get('predicted') for x in entries]
        if len(set(ids)) != len(ids) or set(ids) != predicted_ids:
            raise ValueError('Mappings must cover every predicted ' + kind + ' exactly once')
        mappings[kind], unknown[kind], unmatched[kind] = {}, [], []
        for entry in entries:
            status, target, source = entry.get('status'), entry.get('gold'), entry['predicted']
            if status == 'matched':
                if target not in scopes[kind]:
                    raise ValueError('Matched gold term must belong to the reviewed scope')
                mappings[kind][source] = target
            elif status in ('unknown', 'unmatched') and target is None:
                (unknown if status == 'unknown' else unmatched)[kind].append(source)
            else:
                raise ValueError('Use matched with a gold IRI, or unknown/unmatched with null gold')
    cm, rm = mappings['concepts'], mappings['relationships']
    found_classes = set(cm.values())
    found_relations = set(rm.values())
    endpoint_results, directions, skipped = [], [], []
    for prop, target in rm.items():
        uri, gold_uri = URIRef(prop), URIRef(target)
        domains = list(gold.objects(gold_uri, RDFS.domain))
        ranges = list(gold.objects(gold_uri, RDFS.range))
        direction = str(predicted.value(uri, V.direction) or 'unspecified')
        endpoints = (list(predicted.objects(uri, RDFS.domain)) + list(predicted.objects(uri, RDFS.range))
                     if direction == 'directed' else list(predicted.objects(uri, V.endpointConcept)))
        if len(domains) != 1 or len(ranges) != 1 or len(endpoints) != 2:
            skipped.append({'predicted': prop, 'reason': 'Unsupported or missing endpoint declaration'})
            continue
        if any(str(e) not in cm for e in endpoints):
            skipped.append({'predicted': prop, 'reason': 'Endpoint concept is not mapped'})
            continue
        mapped = [cm[str(e)] for e in endpoints]
        expected = [str(domains[0]), str(ranges[0])]
        # Schema connectivity is evaluated independently of uncertain direction.
        correct = sorted(mapped) == sorted(expected)
        endpoint_results.append({'predicted': prop, 'gold': target, 'correct': correct,
                                 'mapped_endpoints': mapped, 'gold_endpoints': expected})
        if direction == 'directed':
            directions.append({'predicted': prop, 'correct': mapped == expected})
        elif direction == 'bidirectional':
            directions.append({'predicted': prop, 'correct': correct and (gold_uri, RDF.type, OWL.SymmetricProperty) in gold})
    return {'version': 1, 'reviewer': review['reviewer'], 'coverage_note': review['coverage_note'],
            'training_overlap_note': review.get('training_overlap_note', ''),
            'predicted_sha256': review['predicted_sha256'], 'gold_sha256': review['gold_sha256'],
            'counts': {'predicted': {k: len(p[k]) for k in p}, 'gold_scope': {k: len(scopes[k]) for k in scopes}},
            'concept_terms': metrics(len(found_classes), len(unmatched['concepts']), len(scopes['concepts'] - found_classes)),
            'relationship_terms': metrics(len(found_relations), len(unmatched['relationships']), len(scopes['relationships'] - found_relations)),
            'unevaluated': unknown, 'reviewed_unmatched': unmatched,
            'duplicates': {k: len(mappings[k]) - len(set(mappings[k].values())) for k in mappings},
            'endpoints': {'correct': sum(x['correct'] for x in endpoint_results), 'evaluated': len(endpoint_results),
                          'items': endpoint_results, 'skipped': skipped},
            'directions': {'correct': sum(x['correct'] for x in directions), 'evaluated': len(directions),
                           'accuracy': sum(x['correct'] for x in directions) / len(directions) if directions else None,
                           'items': directions},
            'interpretation': 'Reviewed schema-term coverage only; not instance accuracy, query accuracy or held-out generalization.'}
