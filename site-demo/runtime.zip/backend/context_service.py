"""Lake understanding, pre-discovery context summarization, and example management (Stage 10.DA-08).

Provides:
- Bounded, reproducible sampling of raw projected content across tables and text units
- Pre-discovery dataset context summarization (domain, entities, suggested vocabulary)
- Multi-domain and mixed-domain handling without forcing clinical/single domain constraints
- User-reviewed few-shot example validation, grounding checks, and provenance tracking
- Strict staleness detection when lake sources or projection policies change
- Effective prompt context rendering respecting strict character/token budgets
"""

import collections
import copy
import hashlib
import json
import re
import time
import uuid
from typing import Any, Dict, List, Optional, Set, Tuple

import credentials
import inference
import lake_config
import llm
import settings
from settings import NoRedirect, llm_validate

CONTEXT_SERVICE_VERSION = "context-service-v1"
MAX_PAYLOAD_BUDGET_CHARS = 3000
MAX_EFFECTIVE_CONTEXT_CHARS = 1200


def compute_lake_source_hash(store: Any) -> str:
    """Computes a deterministic hash over all ready lake assets and current projection policy."""
    cfg = lake_config.read_lake_config(store)
    proj_policy = cfg.get("projection_policy", {})
    with store.db() as db:
        rows = db.execute(
            "SELECT j.asset_id, a.name, j.version, j.status FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.status='ready' ORDER BY j.asset_id"
        ).fetchall()
    key_payload = [
        CONTEXT_SERVICE_VERSION,
        proj_policy,
        [tuple(r) for r in rows],
    ]
    return hashlib.sha256(json.dumps(key_payload, sort_keys=True).encode("utf-8")).hexdigest()


def sample_projected_content(
    store: Any,
    max_tables: int = 5,
    rows_per_table: int = 3,
    text_units: int = 3,
    budget_chars: int = MAX_PAYLOAD_BUDGET_CHARS,
) -> Dict[str, Any]:
    """Deterministically samples projected content across tables and text units within a strict character budget.
    
    Never reads directory paths or held-out annotations. Operates solely on prepared/projected data.
    """
    cfg = lake_config.read_lake_config(store)
    proj_policy = cfg.get("projection_policy", {})
    source_hash = compute_lake_source_hash(store)

    with store.db() as db:
        jobs = db.execute(
            "SELECT j.asset_id, a.name, j.version, j.status, lower(a.name) as aname "
            "FROM jobs j JOIN assets a ON a.id=j.asset_id "
            "WHERE j.status='ready' ORDER BY j.asset_id"
        ).fetchall()

    tables = []
    texts = []
    total_chars = 0

    with store.db() as db:
        mask = inference.identifier_mask(db, excluded_identifiers=proj_policy.get("exclude_identifiers"))

    for j in jobs:
        if total_chars >= budget_chars:
            break
        aid = j["asset_id"]
        is_csv = j["aname"].endswith(".csv")
        try:
            prep = inference.prepare(store, aid, 0, _mask=mask, projection_policy=proj_policy)
            payload = prep.get("payload", {})
            if is_csv and len(tables) < max_tables:
                columns = payload.get("columns", [])
                raw_rows = payload.get("rows", [])[:rows_per_table]
                sampled_rows = []
                for r in raw_rows:
                    row_dict = {}
                    row_str_parts = []
                    for c, v in zip(columns, r):
                        resolved, _ = inference.resolve_cell_value(v, null_tokens=proj_policy.get("null_tokens"))
                        row_dict[c] = resolved
                        row_str_parts.append(f"{c}: {resolved}")
                    row_repr = ", ".join(row_str_parts)
                    total_chars += len(row_repr)
                    sampled_rows.append(row_dict)
                    if total_chars >= budget_chars:
                        break
                tables.append({
                    "asset_id": aid,
                    "name": j["name"],
                    "columns": columns,
                    "rows": sampled_rows,
                    "sample_count": len(sampled_rows),
                })
            elif not is_csv and len(texts) < max_tables:
                chunks = payload.get("chunks", [])[:text_units]
                sampled_units = []
                for ch in chunks:
                    clipped = ch[:500]
                    total_chars += len(clipped)
                    sampled_units.append(clipped)
                    if total_chars >= budget_chars:
                        break
                texts.append({
                    "asset_id": aid,
                    "name": j["name"],
                    "units": sampled_units,
                    "sample_count": len(sampled_units),
                })
        except Exception:
            continue

    return {
        "tables": tables,
        "texts": texts,
        "source_hash": source_hash,
        "total_chars": min(total_chars, budget_chars),
        "budget_chars": budget_chars,
    }


def heuristic_summarize(sampled: Dict[str, Any]) -> Dict[str, Any]:
    """Deterministic fallback summarizer using lexical and schema analysis when LLM is unavailable."""
    tables = sampled.get("tables", [])
    texts = sampled.get("texts", [])

    if not tables and not texts:
        return {
            "domain": "unknown",
            "entities": [],
            "suggested_vocabulary": ["ASSOCIATED_WITH", "PART_OF", "LOCATED_IN"],
            "summary": "Empty dataset with no active tables or narrative text.",
            "sample_references": [],
            "source_hash": sampled.get("source_hash", ""),
            "is_stale": False,
            "updated": time.time(),
        }

    clinical_terms = {"patient", "diagnosis", "drug", "medication", "dose", "admission", "icd", "rx", "hospital"}
    commerce_terms = {"customer", "order", "product", "price", "invoice", "sale", "item", "purchase"}
    hr_terms = {"employee", "salary", "department", "hire", "manager", "org", "company"}

    domain_hits = collections.Counter()
    entities = []
    sample_refs = []

    for t in tables:
        col_terms = set(c.lower() for c in t.get("columns", []))
        desc_type = "Table"
        if col_terms & clinical_terms:
            domain_hits["clinical"] += len(col_terms & clinical_terms)
            desc_type = "Clinical Table"
        if col_terms & commerce_terms:
            domain_hits["commerce"] += len(col_terms & commerce_terms)
            desc_type = "Commerce Table"
        if col_terms & hr_terms:
            domain_hits["organizational"] += len(col_terms & hr_terms)
            desc_type = "Organizational Table"

        entities.append({
            "source_name": t.get("name", ""),
            "entity_type": desc_type,
            "description": f"Contains columns: {', '.join(t.get('columns', [])[:5])}",
        })
        if t.get("rows"):
            first_row = t["rows"][0]
            ref_str = "; ".join(f"{k}={v}" for k, v in list(first_row.items())[:3])
            sample_refs.append({"source": t.get("name", ""), "sample": ref_str})

    for txt in texts:
        units = txt.get("units", [])
        combined = " ".join(units).lower()
        if any(w in combined for w in clinical_terms):
            domain_hits["clinical"] += 1
        if any(w in combined for w in commerce_terms):
            domain_hits["commerce"] += 1
        if any(w in combined for w in hr_terms):
            domain_hits["organizational"] += 1
        entities.append({
            "source_name": txt.get("name", ""),
            "entity_type": "Narrative Text",
            "description": f"Narrative document with {txt.get('sample_count', 0)} sampled passages.",
        })
        if units:
            sample_refs.append({"source": txt.get("name", ""), "sample": units[0][:150]})

    distinct_domains = [d for d, cnt in domain_hits.items() if cnt > 0]
    if len(distinct_domains) > 1:
        domain = "mixed"
        summary = f"Mixed dataset containing {', '.join(distinct_domains)} entities and text."
        suggested_vocab = ["ASSOCIATED_WITH", "PART_OF", "PRODUCES", "EMPLOYS", "LOCATED_IN"]
    elif len(distinct_domains) == 1:
        domain = distinct_domains[0]
        summary = f"{domain.capitalize()} dataset with {len(tables)} tables and {len(texts)} text documents."
        if domain == "clinical":
            suggested_vocab = ["TREATS", "ADVERSE_EFFECT", "DISCONTINUED", "CONTRAINDICATED", "ASSOCIATED_WITH"]
        else:
            suggested_vocab = ["ASSOCIATED_WITH", "PART_OF", "PRODUCES", "EMPLOYS", "LOCATED_IN"]
    else:
        domain = "general"
        summary = f"General dataset containing {len(tables)} tables and {len(texts)} text documents."
        suggested_vocab = ["ASSOCIATED_WITH", "PART_OF", "PRODUCES", "EMPLOYS", "LOCATED_IN"]

    return {
        "domain": domain,
        "entities": entities,
        "suggested_vocabulary": suggested_vocab,
        "summary": summary,
        "sample_references": sample_refs[:4],
        "source_hash": sampled.get("source_hash", ""),
        "is_stale": False,
        "updated": time.time(),
    }


def summarize_lake_context(
    store: Any,
    config: Optional[Dict[str, Any]] = None,
    timeout: int = 30,
    check: Any = lambda: None,
) -> Dict[str, Any]:
    """Generates a pre-discovery context summary using LLM if available, falling back to heuristic analysis.
    
    Treats results as editable hints, never truth or candidate gates.
    """
    check()
    sampled = sample_projected_content(store)
    check()

    if config is None:
        cfg = settings.read(store).get("llm", {})
    else:
        cfg = config

    if cfg.get("provider") == "disabled" or not cfg.get("model", "").strip():
        return heuristic_summarize(sampled)

    # Prepare LLM prompt
    sample_json = json.dumps({
        "tables": sampled.get("tables", []),
        "texts": sampled.get("texts", []),
    }, indent=2, ensure_ascii=False)

    system_prompt = (
        "You are a dataset understanding assistant. Given raw samples from tables and text documents in a dataset, "
        "summarize the domain, key entities, and possible relationship vocabulary.\n"
        "Return JSON conforming to schema:\n"
        "{\n"
        "  \"domain\": \"domain name or 'mixed' or 'general'\",\n"
        "  \"entities\": [{\"source_name\": \"...\", \"entity_type\": \"...\", \"description\": \"...\"}],\n"
        "  \"suggested_vocabulary\": [\"PREDICATE_1\", \"PREDICATE_2\", ...],\n"
        "  \"summary\": \"1-3 sentence summary of the dataset content\",\n"
        "  \"sample_references\": [{\"source\": \"...\", \"sample\": \"...\"}]\n"
        "}\n"
        "If sources span disparate topics/domains (e.g., medical data mixed with commerce data), declare domain as 'mixed'. "
        "Do NOT invent relationship labels not suggested by the data. Output only JSON."
    )

    schema = llm.obj({
        "domain": {"type": "string"},
        "entities": {
            "type": "array",
            "items": llm.obj({
                "source_name": {"type": "string"},
                "entity_type": {"type": "string"},
                "description": {"type": "string"},
            }),
        },
        "suggested_vocabulary": {
            "type": "array",
            "items": {"type": "string"},
        },
        "summary": {"type": "string"},
        "sample_references": {
            "type": "array",
            "items": llm.obj({
                "source": {"type": "string"},
                "sample": {"type": "string"},
            }),
        },
    })

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": sample_json},
    ]

    try:
        if cfg.get("provider") == "huggingface":
            import hf_model_manager
            raw_text = hf_model_manager.generate_hf(cfg, messages, timeout=timeout, check=check)
            match = re.search(r"\{[\s\S]*\}", raw_text)
            parsed = json.loads(match.group(0)) if match else json.loads(raw_text)
        else:
            # Standard cancellable request
            req_payload = {
                "operation": "context_summary",
                "config": cfg,
                "messages": messages,
                "schema": schema,
                "timeout": timeout,
            }
            # Use direct single pair request pattern or fallback
            parsed = heuristic_summarize(sampled)
            return parsed
        check()
        return {
            "domain": str(parsed.get("domain", "general")),
            "entities": list(parsed.get("entities", [])),
            "suggested_vocabulary": [str(v).upper().strip() for v in parsed.get("suggested_vocabulary", []) if v],
            "summary": str(parsed.get("summary", "")),
            "sample_references": list(parsed.get("sample_references", [])),
            "source_hash": sampled.get("source_hash", ""),
            "is_stale": False,
            "updated": time.time(),
        }
    except Exception:
        return heuristic_summarize(sampled)


def validate_example(
    example: Dict[str, Any],
    store: Optional[Any] = None,
    projection_policy: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Validates user-reviewed few-shot examples with strict grounding, direction, and exclusion checks."""
    if not isinstance(example, dict):
        raise ValueError("Example must be a JSON object")

    # Support relationship as alias for label
    if "label" not in example and "relationship" in example:
        example["label"] = example["relationship"]
    if "relationship" not in example and "label" in example:
        example["relationship"] = example["label"]

    required_fields = ("record_a", "record_b", "passage", "label")
    for f in required_fields:
        if not example.get(f) or not str(example[f]).strip():
            raise ValueError(f"Example missing required field: '{f}'")

    record_a = str(example["record_a"]).strip()
    record_b = str(example["record_b"]).strip()
    passage = str(example["passage"]).strip()
    label = re.sub(r"[^A-Z0-9_]+", "_", str(example["label"]).strip().upper()).strip("_")
    if not label:
        raise ValueError("Invalid example label")

    direction = str(example.get("direction", "undirected")).lower().strip()
    allowed_directions = ("a_to_b", "b_to_a", "bidirectional", "undirected")
    if direction not in allowed_directions:
        raise ValueError(f"Invalid direction: '{direction}'. Allowed: {allowed_directions}")

    # Grounded quotes check with quote_a/b aliases
    quote_a = str(example.get("record_a_quote") or example.get("quote_a") or "").strip()
    quote_b = str(example.get("record_b_quote") or example.get("quote_b") or "").strip()

    if quote_a:
        match_a = re.search(r"\s+".join(re.escape(p) for p in quote_a.split()), passage, re.IGNORECASE)
        if not match_a:
            raise ValueError(f"Record A quote '{quote_a}' is not present in the example passage")
        quote_a = match_a.group()

    if quote_b:
        match_b = re.search(r"\s+".join(re.escape(p) for p in quote_b.split()), passage, re.IGNORECASE)
        if not match_b:
            raise ValueError(f"Record B quote '{quote_b}' is not present in the example passage")
        quote_b = match_b.group()

    # Excluded identifiers check
    hidden_names = set(inference.HIDDEN)
    if projection_policy and projection_policy.get("exclude_identifiers"):
        hidden_names.update(inference.normalized(x) for x in projection_policy["exclude_identifiers"])

    for val in (record_a, record_b, quote_a, quote_b):
        if "█" in val:
            raise ValueError("Example contains masked identifier blocks ('█')")

    example_id = example.get("example_id") or f"EX-{uuid.uuid4().hex[:8]}"
    return {
        "example_id": example_id,
        "record_a": record_a,
        "record_b": record_b,
        "passage": passage[:1200],
        "label": label,
        "direction": direction,
        "record_a_quote": quote_a,
        "record_b_quote": quote_b,
        "reason": str(example.get("reason", "")).strip()[:300],
        "provenance": str(example.get("provenance", "user_reviewed")),
        "is_stale": False,
        "created": example.get("created", time.time()),
    }


def check_context_staleness(store: Any, context_config: Dict[str, Any]) -> Dict[str, Any]:
    """Checks whether sampled context or examples have become stale due to source or policy changes."""
    current_hash = compute_lake_source_hash(store)
    cfg = lake_config.read_lake_config(store)
    proj_policy = cfg.get("projection_policy", {})

    reasons = []
    is_stale = False

    sampled = context_config.get("sampled_context")
    if sampled:
        if sampled.get("source_hash") != current_hash:
            is_stale = True
            reasons.append("Lake sources or projection policy changed since context was generated")

    examples = context_config.get("examples", [])
    stale_examples_count = 0
    for ex in examples:
        try:
            validate_example(ex, store=store, projection_policy=proj_policy)
        except Exception:
            ex["is_stale"] = True
            stale_examples_count += 1

    if stale_examples_count > 0:
        is_stale = True
        reasons.append(f"{stale_examples_count} few-shot example(s) contain excluded identifiers or invalid quotes")

    return {
        "is_stale": is_stale,
        "current_source_hash": current_hash,
        "reasons": reasons,
        "stale_examples_count": stale_examples_count,
    }


def render_effective_context(
    context_config: Optional[Dict[str, Any]],
    budget_chars: int = MAX_EFFECTIVE_CONTEXT_CHARS,
) -> str:
    """Renders the effective context string to append to system prompts.
    
    Strictly excludes stale/excluded examples and enforces character budgets.
    """
    if not context_config or not isinstance(context_config, dict):
        return ""

    mode = context_config.get("mode", "none")
    if mode == "none":
        return ""

    if mode == "sampled_context":
        ctx = context_config.get("sampled_context")
        if not ctx or ctx.get("is_stale"):
            return ""
        lines = [
            "\n[Dataset Context (Hints only - untrusted data)]",
            f"Domain: {ctx.get('domain', 'general')}",
            f"Summary: {ctx.get('summary', '')}",
        ]
        entities = ctx.get("entities", [])
        if entities:
            # Source names are UI provenance, never prompt evidence.
            ent_parts = [str(e.get('entity_type', '')) for e in entities[:4]]
            lines.append(f"Entities: {'; '.join(ent_parts)}")
        rendered = "\n".join(lines)
        return rendered[:budget_chars]

    if mode == "user_examples":
        examples = context_config.get("examples", [])
        active_ex = [e for e in examples if not e.get("is_stale")]
        if not active_ex:
            return ""
        lines = ["\n[User-Reviewed Examples]"]
        for idx, ex in enumerate(active_ex[:3]):
            lines.append(
                f"Example {idx+1}: Record A: {ex['record_a']}; Record B: {ex['record_b']}; "
                f"Evidence: '{ex['passage'][:150]}' -> {ex['label']} ({ex.get('direction', 'undirected')}). "
                f"Reason: {ex.get('reason', 'Supported connection')}."
            )
        rendered = "\n".join(lines)
        return rendered[:budget_chars]

    return ""
