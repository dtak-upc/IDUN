"""Read-only recorded-view differences, never inferred fact withdrawal."""
import json
import sqlite3
import threading
import time
import knowledge as kg
import knowledge_checkpoints as checkpoints
import knowledge_traversal as traversal


def load(db,id):
    if not isinstance(id,str) or not id:raise ValueError('Choose two saved views')
    row=db.execute('SELECT data FROM kg_query_checkpoints WHERE id=?',(id,)).fetchone()
    if not row:raise ValueError('Saved view was removed; reload the view list')
    snapshot=json.loads(row['data'])
    if not checkpoints.available(db,snapshot):raise ValueError('A selected view has unavailable source projections; current data will not be substituted')
    return snapshot


def scoped_sql(snapshot):
    refs=json.dumps([{'run':run,'revision':rev} for run,rev in snapshot['projections'].items()])
    return "SELECT h.id,h.run,h.edge,h.data FROM json_each(?) refs JOIN kg_projection_history_items h ON h.run=json_extract(refs.value,'$.run') AND h.revision=json_extract(refs.value,'$.revision')",refs


def schema_changes(left,right):
    result=[]
    for family,fields in [('concepts',('label','definition','attributes')),('relationships',('label','source','target','direction')),('alignments',('source','target','kind','stale')),('property_alignments',('source','target','kind','stale')),('attribute_alignments',('attributes','stale'))]:
        a={v['id']:v for v in left['graph'].get(family,[])};b={v['id']:v for v in right['graph'].get(family,[])}
        for id in sorted(set(a)|set(b)):
            before={k:a[id].get(k) for k in fields} if id in a else None
            after={k:b[id].get(k) for k in fields} if id in b else None
            if before==after:continue
            result.append({'id':id,'family':family,'kind':'only_right' if before is None else 'only_left' if after is None else 'changed',
                           'label':(b.get(id) or a[id]).get('label',family.replace('_',' ').removesuffix('s')),
                           'left':describe(left,family,a[id]) if id in a else None,'right':describe(right,family,b[id]) if id in b else None})
    return result


def describe(snapshot,family,value):
    graph=snapshot['graph'];names={c['id']:c['label'] for c in graph['concepts']}
    names.update({e['id']:e['label'] for e in graph['relationships']})
    names.update({a['id']:a['name'] for a in graph.get('attributes',[])})
    if family=='concepts':return {'label':value['label'],'definition':value.get('definition',''),'attributes':[f"{a['name']}: {a['datatype']}" for a in value.get('attributes',[])]}
    if family=='relationships':return {'label':value['label'],'source':names.get(value['source'],'Unavailable concept'),'target':names.get(value['target'],'Unavailable concept'),'direction':value['direction']}
    if family=='attribute_alignments':return {'attributes':[f"{names.get(a['concept'],'Unavailable concept')} · {a['name']}: {a['datatype']}" for a in value['attributes']],'stale':bool(value.get('stale'))}
    return {'kind':value.get('kind',''),'source':names.get(value['source'],'Unavailable schema item'),'target':names.get(value['target'],'Unavailable schema item'),'stale':bool(value.get('stale'))}


def assertion(db,snapshot,id):
    sql,refs=scoped_sql(snapshot)
    rows=db.execute('SELECT run,data FROM ('+sql+') WHERE id=? ORDER BY run',(refs,id));item=None
    for row in rows:
        a=json.loads(row['data'])
        if item is None:item=dict(a,contributions=[])
        item['contributions'].append({'run_title':a['run_title'],'evidence':a['evidence']})
    if item is None:return None
    edge=next(e for e in snapshot['graph']['relationships'] if e['id']==item['edge'])
    if item['subject']['concept_id']!=edge['source']:item['subject'],item['object']=item['object'],item['subject']
    item.update(relation=edge['label'],direction=edge['direction'])
    labels={c['id']:c['label'] for c in snapshot['graph']['concepts']}
    for side in ('subject','object'):item[side]['concept']=labels[item[side]['concept_id']]
    return {k:item[k] for k in ('id','relation','direction','subject','object','contributions')}


def route(store,body):
    checkpoints.setup(store)
    offset=traversal.integer(body,'offset',0,0,1000000)
    category=body.get('category','only_right');view=body.get('view','assertions')
    if category not in ('only_left','only_right','shared','support_changed'):raise ValueError('Choose a comparison category')
    if view not in ('assertions','schema'):raise ValueError('Choose assertion or schema differences')
    key=traversal.request_key(store,body);event=threading.Event()
    with traversal._guard:
        if key in traversal._requests:raise ValueError('Comparison request is already running')
        traversal._requests[key]=event
    try:
        with store.lock,store.db() as db:
            deadline=time.monotonic()+10
            db.set_progress_handler(lambda:event.is_set() or time.monotonic()>=deadline,1000)
            db.create_function('kg_evidence_digest',1,lambda raw:kg.digest(json.loads(raw or '[]')),deterministic=True)
            try:
                if event.is_set():raise ValueError('Comparison cancelled')
                left=load(db,body.get('left'));right=load(db,body.get('right'))
                if left['id']==right['id']:raise ValueError('Choose two different saved views')
                ls,la=scoped_sql(left);rs,ra=scoped_sql(right)
                # Compare original run/evidence contributions deterministically; labels are schema differences.
                cte='WITH lraw AS ('+ls+'), rraw AS ('+rs+'''),
                    l AS (SELECT id,json_group_array(json_object('run',run,'evidence',kg_evidence_digest(json_extract(data,'$.evidence')))) support FROM (SELECT * FROM lraw ORDER BY id,run) GROUP BY id),
                    r AS (SELECT id,json_group_array(json_object('run',run,'evidence',kg_evidence_digest(json_extract(data,'$.evidence')))) support FROM (SELECT * FROM rraw ORDER BY id,run) GROUP BY id),
                    differences AS (
                      SELECT l.id,CASE WHEN r.id IS NULL THEN 'only_left' WHEN l.support<>r.support THEN 'support_changed' ELSE 'shared' END category FROM l LEFT JOIN r ON l.id=r.id
                      UNION ALL SELECT r.id,'only_right' category FROM r LEFT JOIN l ON r.id=l.id WHERE l.id IS NULL
                    ) '''
                counts={k:0 for k in ('only_left','only_right','shared','support_changed')}
                for row in db.execute(cte+'SELECT category,count(*) count FROM differences GROUP BY category',(la,ra)):counts[row['category']]=row['count']
                counts['shared']+=counts['support_changed']
                deltas=schema_changes(left,right);items=[]
                if view=='schema':total=len(deltas);items=deltas[offset:offset+25]
                else:
                    condition="category IN ('shared','support_changed')" if category=='shared' else 'category=?'
                    args=[la,ra]+([] if category=='shared' else [category])
                    total=counts[category]
                    for row in db.execute(cte+'SELECT id,category FROM differences WHERE '+condition+' ORDER BY id LIMIT 25 OFFSET ?',[*args,offset]):
                        if event.is_set() or time.monotonic()>=deadline:raise ValueError('Comparison cancelled' if event.is_set() else 'Comparison exceeded ten seconds; choose smaller saved views')
                        items.append({'id':row['id'],'kind':row['category'],'left':assertion(db,left,row['id']) if row['category']!='only_right' else None,'right':assertion(db,right,row['id']) if row['category']!='only_left' else None})
                if event.is_set() or time.monotonic()>=deadline:raise ValueError('Comparison cancelled' if event.is_set() else 'Comparison exceeded ten seconds; choose smaller saved views')
                return {'left':metadata(left),'right':metadata(right),'same_runs':set(left['projections'])==set(right['projections']),
                        'counts':counts,'schema_total':len(deltas),'items':items,'total':total,'offset':offset,'limit':25,'view':view,'category':category}
            except sqlite3.OperationalError as e:
                if 'interrupted' not in str(e):raise
                raise ValueError('Comparison cancelled' if event.is_set() else 'Comparison exceeded ten seconds; choose smaller saved views') from e
            finally:db.set_progress_handler(None,0)
    finally:
        with traversal._guard:traversal._requests.pop(key,None)


def metadata(snapshot):
    return {**{k:snapshot[k] for k in ('id','title','recorded')},'runs':[l['title'] for l in snapshot['graph']['layers']]}
