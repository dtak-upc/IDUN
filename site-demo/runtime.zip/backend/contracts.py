"""IDUN neutral contracts and legacy adapters (Stage 10.DA-01).

Defines versioned neutral data structures for records, pair candidates, evidence paths,
relation decisions, and integration runs. Provides backward-compatible read adapters
for legacy v5.1 clinical runs.
"""
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Any, Tuple, Literal
import json
import re

CONTRACT_VERSION = "idun-contracts-v1"
LEGACY_VERSION_V5_1 = "semantic-joins-v5.1"

# Direction vocabulary
Direction = Literal["A_TO_B", "B_TO_A", "SYMMETRIC", "UNSPECIFIED"]
VALID_DIRECTIONS = {"A_TO_B", "B_TO_A", "SYMMETRIC", "UNSPECIFIED"}

# Basis vocabulary
Basis = Literal["text_supported", "inferred", "insufficient"]
VALID_BASES = {"text_supported", "inferred", "insufficient"}

# Support state vocabulary
SupportState = Literal["include", "abstain", "conflict"]
VALID_SUPPORT_STATES = {"include", "abstain", "conflict"}


def reverse_direction(direction: str) -> str:
    """Reverses the semantic direction when Record A and Record B are swapped."""
    if direction == "A_TO_B":
        return "B_TO_A"
    elif direction == "B_TO_A":
        return "A_TO_B"
    elif direction in ("SYMMETRIC", "UNSPECIFIED"):
        return direction
    raise ValueError(f"Unknown direction: {direction}")


def canonical_pair_order(rec_a: "RecordRef", rec_b: "RecordRef") -> Tuple["RecordRef", "RecordRef", bool]:
    """Deterministically orders two RecordRefs by (source, record_id).

    Returns:
        (canonical_a, canonical_b, swapped)
    """
    key_a = (rec_a.source, rec_a.record_id)
    key_b = (rec_b.source, rec_b.record_id)
    if key_a <= key_b:
        return rec_a, rec_b, False
    else:
        return rec_b, rec_a, True


@dataclass
class RecordRef:
    """Opaque reference to a source row for provenance and display."""
    source: str
    record_id: str
    row_index: int
    columns: List[str]
    cells: List[str]
    name: str = ""
    version: str = ""
    anchor_column: Optional[int] = None
    summary: Optional[str] = None

    def __post_init__(self):
        if not self.summary:
            if self.anchor_column is not None and 0 <= self.anchor_column < len(self.cells):
                self.summary = self.cells[self.anchor_column]
            elif self.cells:
                # Default display summary: first non-empty cell
                self.summary = next((c for c in self.cells if c.strip()), self.cells[0])
            else:
                self.summary = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source": self.source,
            "name": self.name,
            "version": self.version,
            "record_id": self.record_id,
            "row_index": self.row_index,
            "columns": list(self.columns),
            "cells": list(self.cells),
            "anchor_column": self.anchor_column,
            "summary": self.summary,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RecordRef":
        return cls(
            source=str(data["source"]),
            record_id=str(data["record_id"]),
            row_index=int(data["row_index"]),
            columns=list(data.get("columns", [])),
            cells=list(data.get("cells", [])),
            name=str(data.get("name", "")),
            version=str(data.get("version", "")),
            anchor_column=data.get("anchor_column"),
            summary=data.get("summary"),
        )


@dataclass
class EvidencePath:
    """Grounded evidence path linking Record A and Record B via a mediator document."""
    evidence_id: str
    left_link: str
    right_link: str
    start: int
    end: int
    text: str
    score: float
    context_start: Optional[int] = None
    context_end: Optional[int] = None
    context_text: Optional[str] = None
    ce_score: Optional[float] = None
    anchors: Optional[List[Dict[str, Any]]] = None

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "evidence_id": self.evidence_id,
            "left_link": self.left_link,
            "right_link": self.right_link,
            "start": self.start,
            "end": self.end,
            "text": self.text,
            "score": self.score,
        }
        if self.context_start is not None:
            d["context_start"] = self.context_start
        if self.context_end is not None:
            d["context_end"] = self.context_end
        if self.context_text is not None:
            d["context_text"] = self.context_text
        if self.ce_score is not None:
            d["ce_score"] = self.ce_score
        if self.anchors is not None:
            d["anchors"] = self.anchors
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvidencePath":
        return cls(
            evidence_id=str(data.get("evidence_id", data.get("evidence", "E1"))),
            left_link=str(data.get("left_link", data.get("left", ""))),
            right_link=str(data.get("right_link", data.get("right", ""))),
            start=int(data["start"]),
            end=int(data["end"]),
            text=str(data.get("text", "")),
            score=float(data.get("score", 0.0)),
            context_start=data.get("context_start"),
            context_end=data.get("context_end"),
            context_text=data.get("context_text"),
            ce_score=data.get("ce_score"),
            anchors=data.get("anchors"),
        )


@dataclass
class PairCandidate:
    """Candidate pair composed of Record A and Record B sharing mediator text evidence."""
    candidate_id: str
    record_a: RecordRef
    record_b: RecordRef
    document: str
    document_name: str
    paths: List[EvidencePath]
    score: float = 0.0
    cluster: Optional[int] = None
    noise: Optional[bool] = None
    point: Optional[List[float]] = None

    def canonical_identity(self) -> Tuple[str, str, str]:
        """Returns deterministic canonical (record_min_id, record_max_id, document) tuple."""
        key_a = (self.record_a.source, self.record_a.record_id)
        key_b = (self.record_b.source, self.record_b.record_id)
        if key_a <= key_b:
            return (self.record_a.record_id, self.record_b.record_id, self.document)
        else:
            return (self.record_b.record_id, self.record_a.record_id, self.document)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "record_a": self.record_a.to_dict(),
            "record_b": self.record_b.to_dict(),
            "document": self.document,
            "document_name": self.document_name,
            "paths": [p.to_dict() for p in self.paths],
            "score": self.score,
            "cluster": self.cluster,
            "noise": self.noise,
            "point": self.point,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PairCandidate":
        # Support neutral keys record_a/record_b as well as legacy left/right
        rec_a_data = data.get("record_a", data.get("left"))
        rec_b_data = data.get("record_b", data.get("right"))
        if not rec_a_data or not rec_b_data:
            raise ValueError("PairCandidate requires record_a and record_b (or legacy left/right)")

        # Handle legacy left/right record shape where record is nested under "record"
        if "record" in rec_a_data and isinstance(rec_a_data["record"], dict):
            rec_a = RecordRef(
                source=rec_a_data["source"],
                name=rec_a_data.get("name", ""),
                version=rec_a_data.get("version", ""),
                record_id=rec_a_data["record"]["record_id"],
                row_index=rec_a_data["record"]["index"],
                columns=rec_a_data.get("columns", []),
                cells=rec_a_data["record"].get("cells", []),
                anchor_column=rec_a_data.get("anchor_column"),
            )
        else:
            rec_a = RecordRef.from_dict(rec_a_data)

        if "record" in rec_b_data and isinstance(rec_b_data["record"], dict):
            rec_b = RecordRef(
                source=rec_b_data["source"],
                name=rec_b_data.get("name", ""),
                version=rec_b_data.get("version", ""),
                record_id=rec_b_data["record"]["record_id"],
                row_index=rec_b_data["record"]["index"],
                columns=rec_b_data.get("columns", []),
                cells=rec_b_data["record"].get("cells", []),
                anchor_column=rec_b_data.get("anchor_column"),
            )
        else:
            rec_b = RecordRef.from_dict(rec_b_data)

        paths = [EvidencePath.from_dict(p) for p in data.get("paths", [])]
        return cls(
            candidate_id=str(data.get("candidate_id", data.get("candidate", "P1"))),
            record_a=rec_a,
            record_b=rec_b,
            document=str(data.get("document", "")),
            document_name=str(data.get("document_name", "")),
            paths=paths,
            score=float(data.get("score", 0.0)),
            cluster=data.get("cluster"),
            noise=data.get("noise"),
            point=data.get("point"),
        )


@dataclass
class RelationDecision:
    """Specific relationship decision for an evidence path with direction and grounding."""
    evidence_id: str
    relationship: str
    direction: Direction = "A_TO_B"
    basis: Basis = "text_supported"
    reason: str = ""
    quote_a: str = ""
    quote_b: str = ""

    def __post_init__(self):
        if self.direction not in VALID_DIRECTIONS:
            raise ValueError(f"Invalid direction '{self.direction}'. Must be one of {VALID_DIRECTIONS}")
        if self.basis not in VALID_BASES:
            raise ValueError(f"Invalid basis '{self.basis}'. Must be one of {VALID_BASES}")
        if len(self.reason) > 1200:
            raise ValueError("Reason must be at most 1200 characters")
        if len(self.quote_a) > 1000 or len(self.quote_b) > 1000:
            raise ValueError("Grounding quotes must be at most 1000 characters")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "evidence_id": self.evidence_id,
            "relationship": self.relationship,
            "direction": self.direction,
            "basis": self.basis,
            "reason": self.reason,
            "quote_a": self.quote_a,
            "quote_b": self.quote_b,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RelationDecision":
        # Neutral quotes quote_a/quote_b with legacy fallback to diagnosis_quote/medication_quote
        quote_a = data.get("quote_a", data.get("diagnosis_quote", ""))
        quote_b = data.get("quote_b", data.get("medication_quote", ""))

        # Map legacy basis 'clinical_inference' -> 'inferred'
        basis = data.get("basis", "text_supported")
        if basis == "clinical_inference":
            basis = "inferred"

        direction = data.get("direction", "A_TO_B")

        return cls(
            evidence_id=str(data.get("evidence_id", data.get("evidence", "E1"))),
            relationship=str(data["relationship"]).strip().upper(),
            direction=direction,
            basis=basis,
            reason=str(data.get("reason", "")),
            quote_a=str(quote_a),
            quote_b=str(quote_b),
        )


@dataclass
class CaseDecision:
    """Aggregated decisions for a single PairCandidate."""
    candidate_id: str
    status: SupportState
    relations: List[str]
    reason: str
    validation: str
    path_decisions: List[RelationDecision]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "candidate_id": self.candidate_id,
            "status": self.status,
            "relations": list(self.relations),
            "reason": self.reason,
            "validation": self.validation,
            "path_decisions": [d.to_dict() for d in self.path_decisions],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CaseDecision":
        status = data.get("status", "abstain")
        if status not in VALID_SUPPORT_STATES:
            raise ValueError(f"Invalid status '{status}'. Must be one of {VALID_SUPPORT_STATES}")
        return cls(
            candidate_id=str(data.get("candidate_id", data.get("candidate", "P1"))),
            status=status,
            relations=list(data.get("relations", [])),
            reason=str(data.get("reason", "")),
            validation=str(data.get("validation", "")),
            path_decisions=[RelationDecision.from_dict(pd) for pd in data.get("path_decisions", [])],
        )


# =====================================================================
# Legacy Adapters (v5.1 Clinical Runs -> Neutral Contract)
# =====================================================================

def adapt_legacy_case(legacy_case: Dict[str, Any]) -> PairCandidate:
    """Adapts a v5.1 legacy clinical case (with left=diagnosis, right=medication) to a PairCandidate."""
    return PairCandidate.from_dict(legacy_case)


def adapt_legacy_decision(legacy_decision: Dict[str, Any]) -> CaseDecision:
    """Adapts a v5.1 legacy decision dictionary to a CaseDecision."""
    return CaseDecision.from_dict(legacy_decision)


def adapt_legacy_row(legacy_row: Dict[str, Any]) -> Dict[str, Any]:
    """Adapts a materialized v5.1 row to a neutral joined row structure with direction."""
    row = dict(legacy_row)
    # Neutral value names
    if "record_a_value" not in row and "left_value" in row:
        row["record_a_value"] = row["left_value"]
    if "record_b_value" not in row and "right_value" in row:
        row["record_b_value"] = row["right_value"]
    if "direction" not in row:
        row["direction"] = "A_TO_B"
    return row


def adapt_legacy_plan(legacy_plan: Dict[str, Any]) -> Dict[str, Any]:
    """Provides a neutral view of a legacy v5.1 integration plan without mutating original bytes."""
    plan = copy.deepcopy(legacy_plan)
    if "cases" in plan:
        adapted_cases = []
        for c in plan["cases"]:
            try:
                adapted_cases.append(adapt_legacy_case(c).to_dict())
            except Exception:
                adapted_cases.append(c)
        plan["cases_neutral"] = adapted_cases

    if "decisions" in plan:
        adapted_decisions = []
        for d in plan["decisions"]:
            try:
                adapted_decisions.append(adapt_legacy_decision(d).to_dict())
            except Exception:
                adapted_decisions.append(d)
        plan["decisions_neutral"] = adapted_decisions

    if "output" in plan:
        plan["output"] = [adapt_legacy_row(r) for r in plan["output"]]

    return plan


import copy
