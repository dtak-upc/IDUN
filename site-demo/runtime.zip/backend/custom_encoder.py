"""Prepare and validate SentenceTransformer encoders in the selected runtime."""
import json
import os
import subprocess
from pathlib import Path
from encoder_defaults import MODEL, key, options, worker_python

ROOT = Path(__file__).resolve().parents[1]


def validate(value):
    if not value:
        return None
    if not isinstance(value, dict):
        raise ValueError('Choose and prepare a SentenceTransformer encoder first')
    receipt = ROOT / 'models/custom-encoders' / key(value.get('model'), value.get('revision')) / 'idun-encoder.json'
    if not receipt.exists():
        raise ValueError('Encoder is not prepared on this machine. Use Prepare encoder in Settings.')
    saved = json.loads(receipt.read_text(encoding='utf-8'))
    if any(value.get(k) != saved.get(k) for k in ('model', 'revision', 'dimensions', 'token_limit')):
        raise ValueError('Encoder configuration does not match its validated receipt')
    if any(saved.get(k) != v for k, v in options(value.get('model')).items()):
        raise ValueError('Prepare the text-only encoder again; its embedding policy has changed.')
    result = {k: saved[k] for k in ('model', 'revision', 'dimensions', 'token_limit')}
    if saved.get('requested_revision'):
        result['requested_revision'] = saved['requested_revision']
    return result


def directory(value):
    return str(ROOT / 'models/custom-encoders' / key(value['model'], value['revision']))


def prepare(store, body):
    from settings import runtime, worker_env
    model = str(body.get('model', '')).strip()
    revision = str(body.get('revision') or 'main').strip()
    if not model or len(model) > 256 or len(revision) > 128:
        raise ValueError('Enter a Hugging Face model ID and revision')
    selected = runtime(store)['python']
    if model == MODEL:
        setup = subprocess.run([selected, '-B', str(ROOT / 'scripts/setup-embedding-runtime.py')],
                               capture_output=True, text=True, encoding='utf-8', env=worker_env(store),
                               creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        if setup.returncode:
            raise ValueError('Text embedding runtime setup failed: ' + setup.stderr[-1800:])
    result = subprocess.run([worker_python(model, selected), str(ROOT / 'scripts/prepare-encoder.py'), model, revision],
                            capture_output=True, text=True, encoding='utf-8', env=worker_env(store),
                            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
    if result.returncode:
        raise ValueError('Encoder preparation failed: ' + result.stderr[-1800:])
    return validate(json.loads(result.stdout.strip().splitlines()[-1]))
