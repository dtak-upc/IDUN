"""Faithful THOR phrase extraction. Imported only in the selected model worker."""
import hashlib
import importlib.metadata
import json
from difflib import SequenceMatcher
from pathlib import Path

VERSION = 'thor-phrases-v1'
REQUIRED = ('spacy', 'spaczz', 'nltk')


def versions():
    result = {}
    for package in REQUIRED:
        try: result[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError: result[package] = None
    return result


def tree_hash(root):
    digest = hashlib.sha256()
    for path in sorted(Path(root).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            digest.update(path.relative_to(root).as_posix().encode())
            with path.open('rb') as stream:
                for chunk in iter(lambda: stream.read(1024*1024), b''): digest.update(chunk)
    return digest.hexdigest()


def ranking(semantic_percent, words, seed_words, phrase, seed):
    union = set(words) | set(seed_words)
    overlap = len(set(words) & set(seed_words)) / len(union) if union else 0.0
    semantic = float(semantic_percent) / 100
    if not 0 <= semantic <= 1: raise ValueError('Invalid matcher similarity')
    character = SequenceMatcher(None, phrase, seed).ratio()
    return {'semantic': semantic, 'word_overlap': overlap, 'character': character,
            'combined': (semantic + overlap + character) / 3}


class Extractor:
    def __init__(self, config):
        packages = versions()
        missing = [name for name,value in packages.items() if not value]
        if missing: raise ValueError('Missing THOR packages in selected Python: ' + ', '.join(missing))
        import spacy
        from spaczz.matcher import SimilarityMatcher
        from nltk.stem import PorterStemmer
        if config['language'] != 'en':
            raise ValueError('This THOR adapter currently supports English Porter stemming only; select a compatible adapter for another language')
        if config['device'] == 'cuda': spacy.require_gpu()
        else: spacy.require_cpu()
        # spacy.load resolves installed packages/local paths, never downloads models.
        self.vectors = spacy.load(config['vector_model'])
        self.parser = self.vectors if config['parser_model'] == config['vector_model'] else spacy.load(config['parser_model'])
        if self.vectors.lang != config['language'] or self.parser.lang != config['language']:
            raise ValueError('Model language does not match configured language')
        if not self.vectors.vocab.vectors_length: raise ValueError('The vector model must provide static word vectors')
        if 'parser' not in self.parser.pipe_names: raise ValueError('The parser model must provide dependency parsing')
        self.matcher_type, self.stemmer, self.config = SimilarityMatcher, PorterStemmer(), dict(config)
        self.manifest = {'adapter': VERSION, 'packages': packages, 'language': config['language'],
                         'device':config['device'], 'models':{}}
        for role, model in [('vectors', self.vectors), ('parser', self.parser)]:
            self.manifest['models'][role] = {'name':model.meta.get('name'), 'version':model.meta.get('version'),
                'sha256':tree_hash(model.path), 'components':model.pipe_names}

    def check_attribution(self, doc, sentence, phrase_start, phrase_end, target_subject=None, other_subjects=None):
        tokens = [t for t in sentence if max(t.idx, phrase_start) < min(t.idx + len(t.text), phrase_end)]
        if not tokens:
            tokens = [t for t in sentence if t.idx >= phrase_start][:1] or list(sentence)[:1]

        sent_tokens = list(sentence)
        first_token_idx = tokens[0].i if tokens else 0
        window = [t for t in sent_tokens if t.i < first_token_idx and not t.is_punct][-5:]
        window_texts = [t.text.lower() for t in window]
        window_str = ' '.join(window_texts)

        # 1. Negation detection
        for t in tokens:
            if t.dep_ == 'neg' or any(c.dep_ == 'neg' for c in t.children):
                return {'status': 'negated', 'rationale': f"Negated via dependency in '{sentence.text.strip()}'"}
            if t.head and any(c.dep_ == 'neg' for c in t.head.children):
                return {'status': 'negated', 'rationale': f"Governing verb '{t.head.text}' is negated in '{sentence.text.strip()}'"}
            if t.head and t.head.lemma_.lower() in {'deny', 'exclude', 'lack'}:
                return {'status': 'negated', 'rationale': f"Governing verb '{t.head.text}' expresses negation in '{sentence.text.strip()}'"}

        if any(cue in window_str for cue in ('negative for', 'ruled out', 'no evidence of', 'absence of', 'denies', 'without', 'no ')):
            return {'status': 'negated', 'rationale': f"Negated by context '{window_str}' in '{sentence.text.strip()}'"}
        if window_texts and window_texts[-1] in ('no', 'without', 'not'):
            return {'status': 'negated', 'rationale': f"Negated by preceding token '{window_texts[-1]}' in '{sentence.text.strip()}'"}

        # 2. Hypothetical / Speculative detection
        hyp_cues = {'possible', 'possibly', 'suspected', 'suspect', 'evaluate', 'rule_out', 'consider', 'presumed', 'presumptive', 'unlikely', 'potential', 'questionable'}
        for t in tokens:
            if t.head and any(c.dep_ == 'aux' and c.tag_ == 'MD' and c.lemma_.lower() in {'might', 'may', 'could', 'would'} for c in t.head.children):
                return {'status': 'hypothetical', 'rationale': f"Governed by modal auxiliary in '{sentence.text.strip()}'"}
        if any(cue in window_str for cue in ('possible', 'suspected', 'evaluate for', 'rule out', 'consider', 'presumed', 'risk of')):
            return {'status': 'hypothetical', 'rationale': f"Hypothetical or speculative context ('{window_str}') in '{sentence.text.strip()}'"}
        if any(t.lemma_.lower() in hyp_cues for t in window):
            return {'status': 'hypothetical', 'rationale': f"Speculative cue in context in '{sentence.text.strip()}'"}

        # 3. Subject attribution
        kinship = {'mother', 'father', 'parent', 'parents', 'brother', 'sister', 'sibling', 'siblings', 'maternal', 'paternal', 'child', 'son', 'daughter', 'spouse', 'husband', 'wife', 'partner', 'donor', 'roommate', 'friend', 'family', 'aunt', 'uncle', 'grandmother', 'grandfather'}
        other_set = set(kinship) | {str(s).strip().lower() for s in (other_subjects or [])}
        target_str = str(target_subject).strip().lower() if target_subject else None

        for t in sent_tokens:
            if t.dep_ in ('nsubj', 'nsubjpass', 'csubj', 'poss') or (t.dep_ == 'compound' and t.head.dep_ in ('nsubj', 'nsubjpass', 'poss')):
                text_low = t.text.lower()
                lemma_low = t.lemma_.lower()
                if (text_low in other_set or lemma_low in other_set) and (not target_str or text_low not in target_str):
                    return {'status': 'wrong_subject', 'rationale': f"Attributed to different subject ('{t.text}') in '{sentence.text.strip()}'"}

        if target_str:
            target_mentioned = any(target_str in t.text.lower() for t in sent_tokens)
            generic_patient = any(t.text.lower() in {'patient', 'pt', 'he', 'she', 'they', 'individual'} for t in sent_tokens)
            if target_mentioned:
                return {'status': 'attributed', 'rationale': f"Attributed to target subject '{target_subject}'"}
            elif generic_patient:
                return {'status': 'attributed', 'rationale': f"Attributed to record via linked patient evidence"}

        return {'status': 'attributed', 'rationale': "Attributed to target record via supported evidence"}

    def extract(self, text, concepts, target_subject=None, other_subjects=None, check_attribution=False):
        matcher = self.matcher_type(self.vectors.vocab, min_r2=self.config['threshold'])
        seeds = {}
        for concept in concepts:
            values = list(dict.fromkeys(s['value'].lower() for s in concept['seeds']))
            if not values: continue
            seeds[concept['id']] = concept['seeds']
            matcher.add(concept['id'], [self.vectors(v) for v in values])
        doc = self.parser(text)
        result = []
        for sentence in doc.sents:
            for chunk in sentence.noun_chunks:
                start,end=chunk.start,chunk.end
                while start<end and doc[start].is_stop:start+=1
                while start<end and doc[end-1].is_stop:end-=1
                if start==end:continue
                span=doc[start:end]
                # Tokenize original spelling first. Lowercasing is only for scoring.
                # This avoids the notebook's assumption that parser/vector token indices match.
                original=self.vectors.make_doc(span.text)
                lowered=span.text.lower()
                lower_map=[]
                for i,char in enumerate(span.text):lower_map.extend([i]*len(char.lower()))
                phrase=self.vectors(lowered)
                candidates=[]
                for cid,first,last,ratio,pattern in matcher(phrase):
                    cid=str(cid)
                    if cid not in seeds:
                        try: cid=self.vectors.vocab.strings[int(cid)]
                        except (ValueError, KeyError): pass
                    if cid not in seeds: continue
                    matched=phrase[first:last]
                    if not matched or matched.text=="'s":continue
                    a=lower_map[matched.start_char];b=lower_map[matched.end_char-1]+1
                    absolute_start=span.start_char+a;absolute_end=span.start_char+b
                    matched_seed=str(pattern)
                    references=[s for s in seeds[cid] if s['value'].lower()==matched_seed.lower()]
                    if not references:raise ValueError('Matcher returned an unknown seed')
                    stem=lambda tokens:[self.stemmer.stem(t.text.lower()) for t in tokens if not t.is_punct]
                    scores=ranking(ratio,stem(matched),stem(self.vectors(matched_seed)),matched.text,matched_seed)
                    attr_info = self.check_attribution(doc, sentence, absolute_start, absolute_end, target_subject, other_subjects) if check_attribution else {'status':'unresolved','rationale':'Attribution verification not requested'}
                    candidates.append({'concept':cid,'value':text[absolute_start:absolute_end],
                        'start':absolute_start,'end':absolute_end,'sentence_start':sentence.start_char,
                        'sentence_end':sentence.end_char,'seed':references[0], 'scores':scores,
                        'attribution':attr_info['status'], 'attribution_rationale':attr_info['rationale'],
                        'status':'attributed' if attr_info['status']=='attributed' else 'flagged' if attr_info['status'] in ('negated','hypothetical','wrong_subject') else 'concept_candidate'})
                candidates.sort(key=lambda c:(-c['scores']['combined'],c['concept'],c['start'],c['end']))
                result.extend(candidates[:self.config['top_k']])
        return result
