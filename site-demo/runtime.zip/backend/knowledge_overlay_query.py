"""Overlay-aware predicates with original-cell and per-claim witnesses."""
import json
import knowledge_attribute_query as query


def active_layers(store,graph,runs):
    with store.db() as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_augmentation_layers'").fetchone():return []
        layers=[json.loads(r['data']) for r in db.execute('SELECT data FROM kg_augmentation_layers')]
    versions={l['run']:l['revision'] for l in graph['layers']}
    return [l['id'] for l in layers if l['enabled'] and l['runs']==sorted(runs) and l['projections']==versions]


def claim_match(prepared,value,datatype,unit):
    if prepared['operator'] in ('present','missing'):return prepared['predicate'](value)
    if prepared['resolved'][0]['datatype'].casefold() in query.NUMERIC:
        if unit or (datatype or '').casefold() not in query.NUMERIC:return False
    return prepared['predicate'](value)


def sql_claim_match(prepared,value,kind,datatype,unit):
    if kind in ('array','object') and prepared['operator'] not in ('present','missing'):return False
    if kind in ('true','false'):value=kind=='true'
    return claim_match(prepared,value,datatype,unit)


def claim_exists(test):
    return """EXISTS (SELECT 1 FROM kg_augmentation_claims claim
        JOIN json_each(json_extract(claim.data,'$.bindings')) binding
        WHERE claim.layer IN (SELECT value FROM json_each(?))
        AND json_extract(claim.data,'$.record')=json_extract(record.value,'$.id')
        AND json_extract(claim.data,'$.column')=col.value
        AND json_extract(binding.value,'$.run')=kg_auto_instances.run
        AND json_extract(binding.value,'$.concept')=json_extract(record.value,'$.concept_id')
        AND """+test+')'


def sql_filter(prepared,layers):
    original="kg_attribute_match(cell.value,cell.type)=1"
    claim=claim_exists("kg_overlay_match(json_extract(claim.data,'$.value'),json_type(claim.data,'$.value'),json_extract(claim.data,'$.datatype'),json_extract(claim.data,'$.unit'))=1")
    params=[json.dumps(prepared['resolved'])]
    if prepared['operator']=='missing':
        present=claim_exists("kg_missing(json_extract(claim.data,'$.value'))=0")
        test=original+' AND NOT '+present
    else:test='('+original+' OR '+claim+')'
    params.append(json.dumps(layers))
    return """ AND EXISTS (SELECT 1 FROM json_each(?) attr
        JOIN json_each(json_array(json_extract(kg_auto_instances.data,'$.subject'),json_extract(kg_auto_instances.data,'$.object'))) record
        ON json_extract(record.value,'$.concept_id')=json_extract(attr.value,'$.concept')
        JOIN json_each(json_extract(record.value,'$.columns')) col ON col.value=json_extract(attr.value,'$.name')
        JOIN json_each(json_extract(record.value,'$.cells')) cell ON cell.key=col.key
        WHERE """+test+')',params


def matches(assertion,prepared):
    originals=query.matches(assertion,prepared);result=[]
    for match in originals:
        record=assertion[match['side']]
        claims=[c for c in record.get('augmentation_claims',[]) if c['column']==match['name']]
        if prepared['operator']=='missing' and any(c['value'] is not None and (not isinstance(c['value'],str) or c['value'].strip()) for c in claims):continue
        result.append(dict(match,origin='original'))
    if prepared['operator']=='missing':return result
    for side in ('subject','object'):
        record=assertion[side]
        for attribute in prepared['resolved']:
            if attribute['concept']!=record['concept_id']:continue
            for claim in record.get('augmentation_claims',[]):
                if claim['column']!=attribute['name'] or not claim_match(prepared,claim['value'],claim['datatype'],claim.get('unit')):continue
                result.append({'side':side,'column_index':record['columns'].index(claim['column']),'id':attribute['id'],'name':attribute['name'],
                    'concept_label':record['concept'],'value':claim['value'],'via':attribute['via'],'origin':claim['origin'],
                    'claim':claim['id'],'layer':claim['layer'],'layer_title':claim['layer_title'],'grounding':claim['grounding'],'unit':claim.get('unit')})
    return result


def coverage(store,runs,prepared,layers):
    # Count versioned projected cells once. Multiple distinct original values are
    # uncertain cells, excluded from before/after missingness counts.
    params=[json.dumps(prepared['resolved'])]
    present=claim_exists("kg_missing(json_extract(claim.data,'$.value'))=0") if layers else '0'
    if layers:params.append(json.dumps(layers))
    scope=','.join('?' for _ in runs);params.extend(runs)
    sql="""WITH observations AS (SELECT json_extract(record.value,'$.id') rid,
        json_extract(record.value,'$.concept_id') concept,col.value attribute,
        json_array(cell.type,cell.value) original,
        kg_missing(cell.value) missing,
        """+present+""" supplied
        FROM kg_auto_instances JOIN json_each(?) attr
        JOIN json_each(json_array(json_extract(kg_auto_instances.data,'$.subject'),json_extract(kg_auto_instances.data,'$.object'))) record
        ON json_extract(record.value,'$.concept_id')=json_extract(attr.value,'$.concept')
        JOIN json_each(json_extract(record.value,'$.columns')) col ON col.value=json_extract(attr.value,'$.name')
        JOIN json_each(json_extract(record.value,'$.cells')) cell ON cell.key=col.key
        WHERE kg_auto_instances.run IN ("""+scope+""")), cells AS (
        SELECT rid,concept,attribute,count(DISTINCT original) variants,min(missing) missing,max(supplied) supplied
        FROM observations GROUP BY rid,concept,attribute)
        SELECT count(*) total,coalesce(sum(variants>1),0) uncertain,
        coalesce(sum(variants=1 AND missing),0) original_missing,
        coalesce(sum(variants=1 AND missing AND NOT supplied),0) reviewed_missing,
        coalesce(sum(variants=1 AND missing AND supplied),0) filled FROM cells"""
    # SELECT placeholder for supplied precedes the attr placeholder in SQL.
    if layers:params[0],params[1]=params[1],params[0]
    with store.db() as db:
        db.create_function('kg_missing',1,lambda value:value is None or isinstance(value,str) and not value.strip(),deterministic=True)
        return dict(db.execute(sql,params).fetchone())
