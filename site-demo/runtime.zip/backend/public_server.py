"""Anonymous demo gateway. Loopback only; publish through a named HTTPS tunnel.

Never points at the research Store. Visitors get independent catalogs and blobs.
"""
import argparse
import hashlib
import json
import mimetypes
import re
import secrets
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from http.cookies import SimpleCookie
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from server import Handler, Store

ROOT = Path(__file__).resolve().parents[1]
COOKIE = "idun_visitor"


class DemoPool:
    def __init__(self, ingest, inference):
        self.ingest, self.inference = ingest, inference

    def submit(self, fn, *args, **kwargs):
        # Existing job state/cancellation stays with its visitor Store. One model
        # executor serializes profiling, LOKI and integration across all visitors.
        executor = self.ingest if getattr(fn, "__name__", "") == "parse" else self.inference
        return executor.submit(fn, *args, **kwargs)


class VisitorStore(Store):
    def create(self, data):
        with self.lock:
            with self.db() as db:
                count, size = db.execute("SELECT COUNT(*),COALESCE(SUM(size),0) FROM jobs").fetchone()
                existing = db.execute("SELECT 1 FROM jobs WHERE id=?", (data.get("id", ""),)).fetchone()
            if not existing and (count >= 100 or type(data.get("size")) is not int or size + data["size"] > 100 * 1024**2):
                raise ValueError("Demo workspace limit: 100 files and 100 MiB total")
            return super().create(data)


class Visitors:
    def __init__(self, root, config, max_visitors=20):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.config, self.max_visitors = config, max_visitors
        self.lock = threading.RLock()
        self.stores = {}
        self.ingest = ThreadPoolExecutor(max_workers=2, thread_name_prefix="demo-ingest")
        self.inference = ThreadPoolExecutor(max_workers=1, thread_name_prefix="demo-inference")

    def resolve(self, token, create=False):
        with self.lock:
            valid = bool(token and re.fullmatch(r"[a-f0-9]{64}", token))
            key = hashlib.sha256(token.encode()).hexdigest() if valid else ""
            directory = self.root / key if key else None
            if not directory or not (directory / "visitor.json").is_file():
                if not create:
                    raise ValueError("Open the demo homepage to start a workspace")
                if len(list(self.root.glob("*/visitor.json"))) >= self.max_visitors:
                    raise ValueError("Demo capacity reached; please try again after the host resets visitor capacity")
                token = secrets.token_hex(32)
                key = hashlib.sha256(token.encode()).hexdigest()
                directory = self.root / key
                directory.mkdir()
                (directory / "visitor.json").write_text(json.dumps({"created": time.time()}), encoding="utf-8")
            if key not in self.stores:
                store = VisitorStore(directory)
                store.pool.shutdown()
                store.pool = DemoPool(self.ingest, self.inference)
                (directory / "settings.json").write_text(json.dumps(self.config), encoding="utf-8")
                self.stores[key] = store
            return token, self.stores[key]

    def close(self):
        for store in self.stores.values():
            for name in ("profile_cancel", "discovery_cancel", "integration_cancel"):
                event = getattr(store, name, None)
                if event:
                    event.set()
        self.inference.shutdown(cancel_futures=True)
        self.ingest.shutdown(cancel_futures=True)


class PublicHandler(Handler):
    @property
    def store(self):
        return self.visitor_store

    def allowed(self):
        origin = self.server.origin
        host = self.headers.get("Host", "")
        if host != urlsplit(origin).netloc:
            return False
        incoming = self.headers.get("Origin")
        return incoming == origin if self.command != "GET" else incoming in (None, origin)

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; worker-src 'self' blob:; frame-ancestors 'none'; base-uri 'self'")
        if getattr(self, "visitor_cookie", None):
            secure = "; Secure" if self.server.origin.startswith("https:") else ""
            self.send_header("Set-Cookie", f"{COOKIE}={self.visitor_cookie}; Path=/; HttpOnly; SameSite=Strict; Max-Age=604800{secure}")
        super().end_headers()

    def route(self, method):
        self.connection.settimeout(30)
        if not self.allowed():
            return self.reply(403, {"error": "Demo origin required"})
        path = urlsplit(self.path).path
        if path.startswith("/api/v1/settings"):
            return self.reply(403, {"error": "Settings are managed by the demo host"})
        try:
            if path.startswith("/api/") or path in ("/", "/index.html"):
                cookie = SimpleCookie(self.headers.get("Cookie", ""))
                token = cookie[COOKIE].value if COOKIE in cookie else None
                resolved, self.visitor_store = self.server.visitors.resolve(token, create=method == "GET" and path in ("/", "/index.html"))
                if resolved != token:
                    self.visitor_cookie = resolved
                if method != "GET":
                    with self.store.lock:
                        now = time.monotonic()
                        requests = [t for t in getattr(self.store, "demo_requests", []) if now-t < 60]
                        if len(requests) >= 120:
                            return self.reply(429, {"error": "Please wait before sending more requests"})
                        self.store.demo_requests = requests + [now]
                        if path in ("/api/v1/profile", "/api/v1/discovery", "/api/v1/integration", "/api/v1/integration/schema/probe"):
                            runs = [t for t in getattr(self.store, "demo_runs", []) if now-t < 3600]
                            if len(runs) >= 6:
                                return self.reply(429, {"error": "Demo allowance: six inference starts per hour per workspace"})
                            self.store.demo_runs = runs + [now]
            if path.startswith("/api/"):
                if self.headers.get("Transfer-Encoding"):
                    return self.reply(400, {"error": "Content-Length required"})
                return super().route(method)
            if method != "GET":
                return self.reply(405, {"error": "Method not allowed"})
            dist = ROOT / "web/dist"
            # Only built, immutable frontend assets; never serve project files.
            if path in ("/", "/index.html"):
                file = dist / "index.html"
                body = file.read_bytes().replace(b"<head>", b'<head><meta name="idun-mode" content="public">')
                content_type = "text/html; charset=utf-8"
            elif re.fullmatch(r"/assets/[A-Za-z0-9_.-]+", path):
                file = dist / path.lstrip("/")
                body = file.read_bytes()
                content_type = mimetypes.guess_type(file)[0] or "application/octet-stream"
            else:
                return self.reply(404, {"error": "Not found"})
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
        except (ValueError, KeyError):
            self.reply(400, {"error": "Workspace unavailable or capacity reached. Open the homepage or contact the demo host."})
        except FileNotFoundError:
            self.reply(404, {"error": "Build the demo frontend before starting"})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--origin", required=True)
    parser.add_argument("--port", type=int, default=8790)
    args = parser.parse_args()
    origin = urlsplit(args.origin)
    if origin.scheme not in ("http", "https") or not origin.netloc or origin.path or origin.query or origin.fragment:
        parser.error("Origin must be a scheme and hostname without a path")
    config = json.loads((ROOT / ".idun/settings.json").read_text(encoding="utf-8"))
    server = ThreadingHTTPServer(("127.0.0.1", args.port), PublicHandler)
    server.origin = args.origin
    server.visitors = Visitors(ROOT / ".idun/visitors", config)
    print(f"IDUN visitor server on loopback port {args.port}; public origin {args.origin}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        server.visitors.close()


if __name__ == "__main__":
    main()
