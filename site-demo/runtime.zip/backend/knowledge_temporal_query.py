"""Contribution-level valid-time filters; unknown boundaries are not timeless."""
import datetime
import re
import time
import knowledge_validity as validity

def date(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):raise ValueError('Use a calendar date YYYY-MM-DD')
    try:datetime.date.fromisoformat(value)
    except ValueError as e:raise ValueError('Invalid calendar date') from e
    return value

def prepare(store,graph,body,snapshot=None):
    raw=body.get('temporal')
    if raw is None:return None
    if not isinstance(raw,dict) or raw.get('mode') not in ('at','overlap','simultaneous'):raise ValueError('Choose valid on a date or overlaps a date range')
    result={'mode':raw['mode'],'start':date(raw.get('start'))}
    if raw['mode'] in ('overlap','simultaneous'):
        result['end']=date(raw.get('end'))
        if result['end']<=result['start']:raise ValueError('Exclusive range end must be after its start')
    reviews={}
    with store.db() as db:
        if snapshot:
            for run,items in snapshot.get('validity',{}).items():
                reviews[run]={assertion:validity.captured(db,snapshot,run,assertion) for assertion in items}
        else:
            refs={l['run']:l['revision'] for l in graph.get('layers',[])}
            for run,items in validity.capture(db,refs).items():
                reviews[run]={assertion:validity.latest(db,run,refs[run],assertion) for assertion in items}
    result['reviews']=reviews
    return result

def matches(review,query):
    if not review or review.get('status')!='reviewed' or not review.get('interval'):return False
    interval=review['interval'];start=interval['start'];end=interval['end']
    if start['mode']=='unknown' or end['mode']=='unknown':return False
    low=start.get('date') if start['mode']=='date' else None
    high=end.get('date') if end['mode']=='date' else None
    if query['mode']=='at':return (low is None or low<=query['start']) and (high is None or query['start']<high)
    return (low is None or low<query['end']) and (high is None or query['start']<high)

def filter_contributions(assertion,query):
    if not query:return assertion['contributions']
    return [dict(c,validity=query['reviews'][c['run_id']][assertion['id']]) for c in assertion['contributions'] if matches(query['reviews'].get(c['run_id'],{}).get(assertion['id']),query)]


def advance(windows,step,budget,event,deadline):
    """Intersect interval unions, never their convex hull or a contribution product."""
    intervals=[];work=0
    def charge():
        nonlocal work
        if event.is_set():return 'cancelled'
        if time.monotonic()>=deadline:return 'time_limit'
        if work>=budget:return 'work_budget'
        work+=1
    for c in step.get('contributions',[]):
        reason=charge()
        if reason:return [],work,reason
        interval=c['validity']['interval']
        low=interval['start'].get('date') if interval['start']['mode']=='date' else None
        high=interval['end'].get('date') if interval['end']['mode']=='date' else None
        # Input windows are bounded by the user's requested range.
        for start,end in windows:
            reason=charge()
            if reason:return [],work,reason
            a=max(start,low) if low else start;b=min(end,high) if high else end
            if a<b:intervals.append((a,b))
    merged=[]
    for start,end in sorted(intervals):
        reason=charge()
        if reason:return [],work,reason
        if merged and start<=merged[-1][1]:merged[-1]=(merged[-1][0],max(end,merged[-1][1]))
        else:merged.append((start,end))
    return merged,work,None


def intervals(windows):return [{'start':a,'end':b,'semantics':'start-inclusive/end-exclusive'} for a,b in windows]
