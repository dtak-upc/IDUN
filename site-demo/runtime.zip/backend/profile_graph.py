"""Versioned candidate metadata and server-side scope previews; no inference side effects."""
import hashlib
import json
import math

import profiling

VERSION = 'candidate-graph-v1'


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def setup(db):
    db.executescript('''
        CREATE TABLE IF NOT EXISTS candidate_graph_state(id INTEGER PRIMARY KEY, revision TEXT, generation TEXT, data TEXT);
        CREATE TABLE IF NOT EXISTS candidate_graph_nodes(id TEXT PRIMARY KEY, kind TEXT, data TEXT);
        CREATE TABLE IF NOT EXISTS candidate_graph_edges(id TEXT PRIMARY KEY, table_id TEXT, document_id TEXT, score REAL, data TEXT);
        CREATE INDEX IF NOT EXISTS candidate_graph_score ON candidate_graph_edges(score DESC,id);
        CREATE INDEX IF NOT EXISTS candidate_graph_table ON candidate_graph_edges(table_id,score DESC,id);
        CREATE INDEX IF NOT EXISTS candidate_graph_document ON candidate_graph_edges(document_id,score DESC,id);
    ''')


def ensure(store):
    state = profiling.status(store)
    if state['status'] != 'ready' or (state.get('job') or {}).get('status') in ('queued','running','cancelling'):
        raise ValueError('A current, completed profile is required for candidate exploration')
    with store.db() as db:
        setup(db)
        saved = db.execute('SELECT * FROM candidate_graph_state WHERE id=1').fetchone()
        if saved and saved['revision'] == state.get('revision') and json.loads(saved['data']).get('version') == VERSION:
            return json.loads(saved['data'])
    report = profiling.read(store)
    if report['status'] != 'ready': raise ValueError('Profile changed; reload candidate exploration')
    # Failed projection can leave kind unset; still expose that isolated source.
    sources = {s['asset_id']:{**s,'kind':s.get('kind') or ('csv' if s['name'].lower().endswith('.csv') else 'txt' if s['name'].lower().endswith('.txt') else 'unknown')} for s in report['sources']}
    edges = []
    for c in report['candidates']:
        table, doc = sources.get(c['table']),sources.get(c['text'])
        if not table or not doc or table['kind'] != 'csv' or doc['kind'] != 'txt':
            raise ValueError('Profile contains an invalid table-document candidate')
        if not isinstance(c['score'], (int,float)) or not math.isfinite(c['score']):
            raise ValueError('Profile contains a non-finite score')
        edge_id = digest([table['asset_id'],table['version'],doc['asset_id'],doc['version']])
        edges.append({**c,'id':edge_id,'table_name':table['name'],'document_name':doc['name'],
                      'table_version':table['version'],'document_version':doc['version']})
    edges.sort(key=lambda e:e['id'])
    if len({e['id'] for e in edges}) != len(edges): raise ValueError('Duplicate profile pair')
    generation = digest([str(getattr(store,'lake_id',store.root.resolve())),VERSION,report.get('version'),sorted(sources.items()),edges])
    connected = {e[k] for e in edges for k in ('table','text')}
    meta = dict(generation=generation, version=VERSION, nodes=len(sources), edges=len(edges),
                tables=sum(s['kind']=='csv' for s in sources.values()),documents=sum(s['kind']=='txt' for s in sources.values()),
                isolated_sources=len(set(sources)-connected), retrieval=report.get('summary',{}), method=report.get('method'),
                notice='Approximate profiled candidates, not verified links. Scores are not probabilities. Reverse top-K ranks existing edges only.')
    with store.db() as db:
        db.execute('DELETE FROM candidate_graph_nodes'); db.execute('DELETE FROM candidate_graph_edges')
        db.executemany('INSERT INTO candidate_graph_nodes VALUES(?,?,?)',[(s['asset_id'],s['kind'],json.dumps(s)) for s in sources.values()])
        db.executemany('INSERT INTO candidate_graph_edges VALUES(?,?,?,?,?)',[(e['id'],e['table'],e['text'],e['score'],json.dumps(e)) for e in edges])
        db.execute('INSERT OR REPLACE INTO candidate_graph_state VALUES(1,?,?,?)',(state.get('revision'),generation,json.dumps(meta)))
    return meta


def resolve(db, recipe):
    if not isinstance(recipe,dict): raise ValueError('Recipe must be an object')
    allowed={'mode','min_score','max_score','tables','documents','search','top_documents','top_tables','combine','pairs','include','exclude'}
    if set(recipe)-allowed: raise ValueError('Unknown selection option')
    mode=recipe.get('mode','all')
    if mode not in ('all','query','explicit'): raise ValueError('Invalid selection mode')
    if mode != 'query' and set(recipe)&{'min_score','max_score','tables','documents','search','top_documents','top_tables','combine'}:
        raise ValueError('Filters require query mode')
    if mode != 'explicit' and 'pairs' in recipe: raise ValueError('Picked pairs require explicit mode')
    lists={}
    for key in ('tables','documents','pairs','include','exclude'):
        values=recipe.get(key,[])
        if not isinstance(values,list) or len(values)>1000 or any(not isinstance(v,str) for v in values):
            raise ValueError(f'{key} must contain at most 1000 identifiers')
        lists[key]=sorted(set(values))
        for value in lists[key]:
            if key in ('tables','documents'):
                found=db.execute('SELECT 1 FROM candidate_graph_nodes WHERE id=? AND kind=?',(value,'csv' if key=='tables' else 'txt')).fetchone()
            else: found=db.execute('SELECT 1 FROM candidate_graph_edges WHERE id=?',(value,)).fetchone()
            if not found: raise ValueError('Unknown or wrong-kind source/pair in this lake generation')
    params=[]; filters=[]
    if mode == 'explicit':
        filters.append('id IN (SELECT value FROM json_each(?))');params.append(json.dumps(lists['pairs']))
    if mode == 'query':
        low,high=recipe.get('min_score',0),recipe.get('max_score',1)
        if any(type(x) not in (int,float) or not math.isfinite(x) or not 0<=x<=1 for x in (low,high)) or low>high:
            raise ValueError('Score range must be finite and within 0–1')
        filters.append('score BETWEEN ? AND ?');params.extend([low,high])
        for key,col in [('tables','table_id'),('documents','document_id')]:
            if key in recipe:
                filters.append(f'{col} IN (SELECT value FROM json_each(?))');params.append(json.dumps(lists[key]))
        search=recipe.get('search','')
        if not isinstance(search,str) or len(search)>200: raise ValueError('Search must be at most 200 characters')
        if search:
            filters.append("(instr(lower(json_extract(data,'$.table_name')),lower(?))>0 OR instr(lower(json_extract(data,'$.document_name')),lower(?))>0 OR instr(lower(json_extract(data,'$.shared_terms')),lower(?))>0)")
            params.extend([search]*3)
    ranks=[]
    for key,col in [('top_documents','table_rank'),('top_tables','document_rank')]:
        if key in recipe:
            k=recipe[key]
            if type(k) is not int or not 1<=k<=1000000: raise ValueError('Top-K must be a positive integer up to 1000000')
            ranks.append(f'{col} <= ?');params.append(k)
    combine=recipe.get('combine','intersection')
    if combine not in ('intersection','union'): raise ValueError('Invalid directional combination')
    rank_filter=(' AND ' if combine=='intersection' else ' OR ').join(ranks) or '1'
    sql=f'''WITH filtered AS (SELECT * FROM candidate_graph_edges WHERE {' AND '.join(filters) or '1'}),
        ranked AS (SELECT *,row_number() OVER(PARTITION BY table_id ORDER BY score DESC,id) table_rank,
        row_number() OVER(PARTITION BY document_id ORDER BY score DESC,id) document_rank FROM filtered),
        picked AS (SELECT id FROM ranked WHERE {rank_filter} UNION SELECT value FROM json_each(?)),
        selected AS (SELECT e.* FROM candidate_graph_edges e JOIN picked p ON e.id=p.id WHERE e.id NOT IN (SELECT value FROM json_each(?))) '''
    params.extend([json.dumps(lists['include']),json.dumps(lists['exclude'])])
    return sql,params


def query(store, body=None):
    body=body or {}
    if not isinstance(body,dict) or set(body)-{'generation','recipe','limit','cursor','selection_recipe','sort'}: raise ValueError('Invalid graph query')
    with store.lock:
        meta=ensure(store)
        if body.get('generation') != meta['generation']: raise ValueError('Candidate generation changed; reload and review the selection')
        limit=body.get('limit',50)
        if type(limit) is not int or not 1<=limit<=200: raise ValueError('Page size must be 1–200')
        recipe=body.get('recipe',{'mode':'all'})
        sort=body.get('sort','desc')
        if sort not in ('asc','desc'): raise ValueError('Sort must be asc or desc')
        recipe_key=digest([recipe,sort])
        cursor=body.get('cursor')
        with store.db() as db:
            sql,params=resolve(db,recipe)
            counts=dict(db.execute(sql+'SELECT count(*) pairs,count(DISTINCT table_id) tables,count(DISTINCT document_id) documents FROM selected',params).fetchone())
            counts['shared_documents']=db.execute(sql+'SELECT count(*) FROM (SELECT document_id FROM selected GROUP BY document_id HAVING count(DISTINCT table_id)>1)',params).fetchone()[0]
            where=''; page_args=[]
            if cursor:
                if not isinstance(cursor,dict) or cursor.get('generation')!=meta['generation'] or cursor.get('recipe')!=recipe_key: raise ValueError('Cursor belongs to another graph/query')
                score,edge_id=cursor.get('score'),cursor.get('id')
                if type(score) not in (float,int) or not math.isfinite(score) or not isinstance(edge_id,str): raise ValueError('Invalid cursor')
                where=f" WHERE score {'>' if sort=='asc' else '<'} ? OR (score = ? AND id > ?)";page_args=[score,score,edge_id]
            rows=db.execute(sql+'SELECT * FROM selected'+where+f' ORDER BY score {sort.upper()},id LIMIT ?',params+page_args+[limit+1]).fetchall()
            items=[json.loads(r['data']) for r in rows[:limit]]
            following=None
            if len(rows)>limit:
                last=rows[limit-1];following=dict(generation=meta['generation'],recipe=recipe_key,score=last['score'],id=last['id'])
            histogram=[dict(r) for r in db.execute(sql+'SELECT min(9,max(0,CAST(score*10 AS INTEGER))) bucket,count(*) count FROM selected GROUP BY bucket ORDER BY bucket',params)]
            selection_counts=None
            if 'selection_recipe' in body:
                selection_sql,selection_params=resolve(db,body['selection_recipe'])
                selection_counts=dict(db.execute(selection_sql+'SELECT count(*) pairs,count(DISTINCT table_id) tables,count(DISTINCT document_id) documents FROM selected',selection_params).fetchone())
                selection_counts['shared_documents']=db.execute(selection_sql+'SELECT count(*) FROM (SELECT document_id FROM selected GROUP BY document_id HAVING count(DISTINCT table_id)>1)',selection_params).fetchone()[0]
                selected_ids={r['id'] for r in db.execute(selection_sql+'SELECT id FROM selected WHERE id IN (SELECT value FROM json_each(?))',selection_params+[json.dumps([e['id'] for e in items])])}
                items=[{**e,'selected':e['id'] in selected_ids} for e in items]
        return dict(graph=meta,recipe=recipe,counts=counts,items=items,next_cursor=following,histogram=histogram,
                    selection_counts=selection_counts,
                    scope_applied=False,notice='Preview only. Commit this selection before passing its scope ID to Discovery.')


def overview(store):
    with store.lock:
        meta=ensure(store)
        return query(store,{'generation':meta['generation']})


def nodes(store, generation, after='', limit=100):
    if type(limit) is not int or not 1<=limit<=200: raise ValueError('Node page size must be 1–200')
    with store.lock:
        meta=ensure(store)
        if generation != meta['generation']: raise ValueError('Candidate generation changed; reload')
        with store.db() as db:
            rows=db.execute('SELECT id,data FROM candidate_graph_nodes WHERE id>? ORDER BY id LIMIT ?',(after,limit+1)).fetchall()
            items=[]
            for row in rows[:limit]:
                degree=db.execute('SELECT count(*) FROM candidate_graph_edges WHERE table_id=? OR document_id=?',(row['id'],row['id'])).fetchone()[0]
                source=json.loads(row['data'])
                items.append({k:source.get(k) for k in ('asset_id','name','kind','version','records','status','coverage','issues')} | {'degree':degree})
        return {'generation':generation,'total':meta['nodes'],'items':items,'next_after':rows[limit-1]['id'] if len(rows)>limit else None}


def inspect(store, kind, identifier, generation):
    with store.lock:
        meta=ensure(store)
        if generation!=meta['generation']: raise ValueError('Candidate generation changed; reload')
        table='candidate_graph_nodes' if kind=='nodes' else 'candidate_graph_edges'
        with store.db() as db:
            row=db.execute(f'SELECT data FROM {table} WHERE id=?',(identifier,)).fetchone()
        if not row: raise KeyError('Candidate source or pair not found')
        return {'generation':generation,'item':json.loads(row['data'])}
