"""Explicit recorded-view checkpoints; never infer historical fact validity."""
import json
import time
import uuid
import knowledge as kg
import knowledge_auto as auto
import knowledge_revisions as revisions


def setup(store):
    auto.setup(store)
    with store.db() as db:db.execute('CREATE TABLE IF NOT EXISTS kg_query_checkpoints(id TEXT PRIMARY KEY,recorded REAL,data TEXT NOT NULL)')


def available(db,snapshot):
    for run,revision in snapshot['projections'].items():
        row=db.execute('SELECT data FROM kg_projection_history WHERE run=? AND revision=?',(run,revision)).fetchone()
        if not row or not db.execute('SELECT 1 FROM integration_plans WHERE id=?',(run,)).fetchone():return False
        if any(not db.execute('SELECT 1 FROM assets WHERE id=?',(asset,)).fetchone() for asset in json.loads(row['data'])['assets']):return False
    return True


def catalog(store,offset=0):
    with store.db() as db:
        total=db.execute('SELECT count(*) FROM kg_query_checkpoints').fetchone()[0];items=[]
        for row in db.execute('SELECT * FROM kg_query_checkpoints ORDER BY recorded DESC,id LIMIT 20 OFFSET ?',(offset,)):
            s=json.loads(row['data']);items.append({'id':s['id'],'title':s['title'],'recorded':s['recorded'],'runs':len(s['projections']),'count':s['graph']['count'],'available':bool(available(db,s)),'revision':kg.digest(s)})
    return {'items':items,'total':total,'offset':offset,'limit':20}


def route(store,action,body):
    setup(store)
    offset=body.get('offset',0)
    if type(offset) is not int or not 0<=offset<=1000000:raise ValueError('Invalid checkpoint page')
    with store.lock:
        if action=='checkpoints':return catalog(store,offset)
        if action=='capture-checkpoint':
            runs=auto.selected(body)
            if not runs:raise ValueError('Select graph runs to capture')
            graph=auto.view(store,runs)
            if not graph['layers']:raise ValueError('Build a graph before capturing')
            if graph['revision']!=body.get('revision'):raise ValueError('Graph changed; refresh before capturing')
            title=body.get('title','')
            if not isinstance(title,str) or not 1<=len(title.strip())<=100:raise ValueError('Enter a checkpoint name of 1–100 characters')
            if kg._jobs.get(str(store.root),{}).get('status')=='running':raise ValueError('Wait for the graph task before capturing')
            snapshot={'id':str(uuid.uuid4()),'title':title.strip(),'recorded':time.time(),'graph':graph,'projections':{l['run']:l['revision'] for l in graph['layers']},'version':1}
            with store.db() as db:
                for run in runs:revisions.archive(db,run)
                import knowledge_validity
                snapshot['validity']=knowledge_validity.capture(db,snapshot['projections'])
                db.execute('INSERT INTO kg_query_checkpoints VALUES(?,?,?)',(snapshot['id'],snapshot['recorded'],json.dumps(snapshot)))
            return catalog(store)
        if action=='remove-checkpoint':
            with store.db() as db:
                row=db.execute('SELECT data FROM kg_query_checkpoints WHERE id=?',(body.get('id'),)).fetchone()
                if not row:raise ValueError('Query checkpoint not found')
                if body.get('revision')!=kg.digest(json.loads(row['data'])):raise ValueError('Checkpoint changed; reload before removing')
                db.execute('DELETE FROM kg_query_checkpoints WHERE id=?',(body['id'],))
            return catalog(store)
        with store.db() as db:
            row=db.execute('SELECT data FROM kg_query_checkpoints WHERE id=?',(body.get('id'),)).fetchone()
            if not row:raise ValueError('Query checkpoint not found')
            snapshot=json.loads(row['data'])
            if action not in ('query-checkpoint','preview-checkpoint-path','traverse-checkpoint'):raise ValueError('Unknown checkpoint operation')
            if not available(db,snapshot):raise ValueError('Checkpoint projections were removed; historical query unavailable. Current data will not be substituted.')
            if action!='query-checkpoint':return traverse(store,snapshot,action,body)
            graph=snapshot['graph'];concept=body.get('concept','');relationship=body.get('relationship','')
            if not isinstance(concept,str) or concept and concept not in {c['id'] for c in graph['concepts']}:raise ValueError('Choose a captured concept')
            if not isinstance(relationship,str) or relationship and relationship not in {e['id'] for e in graph['relationships']}:raise ValueError('Choose a captured relationship')
            clauses=[];args=[]
            for run,revision in snapshot['projections'].items():clauses.append('(run=? AND revision=?)');args.extend([run,revision])
            where='('+' OR '.join(clauses)+')'
            if concept:where+=" AND (json_extract(data,'$.subject.concept_id')=? OR json_extract(data,'$.object.concept_id')=?)";args.extend([concept,concept])
            if relationship:where+=' AND edge=?';args.append(relationship)
            total=db.execute('SELECT count(DISTINCT id) FROM kg_projection_history_items WHERE '+where,args).fetchone()[0]
            ids=[r[0] for r in db.execute('SELECT DISTINCT id FROM kg_projection_history_items WHERE '+where+' ORDER BY id LIMIT 25 OFFSET ?',[*args,offset])]
            items={}
            if ids:
                for row in db.execute('SELECT data FROM kg_projection_history_items WHERE '+where+' AND id IN ('+','.join('?' for _ in ids)+') ORDER BY id,run',[*args,*ids]):
                    a=json.loads(row['data']);item=items.setdefault(a['id'],dict(a,contributions=[]))
                    import knowledge_validity
                    item['contributions'].append({'run_title':a['run_title'],'evidence':a['evidence'],'validity':knowledge_validity.captured(db,snapshot,a['run_id'],a['id'])})
            edges={e['id']:e for e in graph['relationships']};labels={c['id']:c['label'] for c in graph['concepts']}
            for item in items.values():
                edge=edges[item['edge']]
                if item['subject']['concept_id']!=edge['source']:item['subject'],item['object']=item['object'],item['subject']
                item['relation']=edge['label'];item['direction']=edge['direction']
                for side in ('subject','object'):item[side]['concept']=labels[item[side]['concept_id']]
            return {'id':snapshot['id'],'title':snapshot['title'],'recorded':snapshot['recorded'],'graph':graph,'total':total,'items':list(items.values()),'offset':offset,'limit':25}


def traverse(store,snapshot,action,body):
    import threading
    import knowledge_traversal as traversal
    import knowledge_path_patterns as patterns
    graph=snapshot['graph'];start=body.get('start');pattern=None
    if graph['revision']!=body.get('revision'):raise ValueError('Captured schema changed; reload the checkpoint')
    if body.get('identities',False) is not False:raise ValueError('Identity links are not captured in this checkpoint')
    if 'pattern' in body:
        pattern=patterns.compile(graph,start,body['pattern'],body.get('pattern_mode','exact'))
        if any(s.get('kind')=='identity' or (s['condition_prepared'] and s['condition_prepared']['values_mode']=='reviewed') for s in pattern['steps']):
            raise ValueError('Checkpoint paths use captured assertions and original values only')
        pattern['token']=kg.digest([snapshot['id'],kg.digest(snapshot),pattern['token']])
    if action=='preview-checkpoint-path':
        if pattern is None:raise ValueError('Describe a path to preview')
        return {k:pattern[k] for k in ('token','summary','mode')}
    if not isinstance(start,dict) or any(not isinstance(start.get(k),str) or not start[k] for k in ('id','concept_id')):raise ValueError('Choose a captured starting record')
    depth=traversal.integer(body,'depth',2,1,4);limit=traversal.integer(body,'limit',20,1,100);budget=traversal.integer(body,'budget',500,10,5000)
    if pattern:
        if body.get('preview_token')!=pattern['token']:raise ValueError('Preview this checkpoint path before executing')
        depth=len(pattern['steps'])
    key=traversal.request_key(store,body);event=threading.Event()
    with traversal._guard:
        if key in traversal._requests:raise ValueError('Traversal request is already running')
        traversal._requests[key]=event
    try:
        result=traversal.explore(store,graph,list(snapshot['projections']),start,depth,limit,budget,False,event,pattern,history_refs=snapshot['projections'])
        result['checkpoint']={k:snapshot[k] for k in ('id','title','recorded')}
        return result
    finally:
        with traversal._guard:traversal._requests.pop(key,None)
