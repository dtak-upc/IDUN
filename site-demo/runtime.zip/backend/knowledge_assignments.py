"""Reviewed, run-scoped record classification overrides."""
import json
import uuid
import knowledge as kg


def read(store):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_assignment_edits(sequence INTEGER PRIMARY KEY AUTOINCREMENT,id TEXT UNIQUE,data TEXT)')
        return [json.loads(r['data']) for r in db.execute('SELECT data FROM kg_assignment_edits ORDER BY sequence')]


def mappings(edits,run,revision):
    result={}
    for e in edits:
        if e['status']=='accepted' and e['revisions'].get(run)==revision:
            for rid in e['records'].get(run,[]):result[rid]=e['target']
    return result


def records(store,graph,runs,concept,offset=None):
    if concept not in {c['id'] for c in graph['concepts']}:raise ValueError('Choose a visible concept')
    if not runs:return ([],0) if offset is not None else []
    scope=','.join('?' for _ in runs)
    parts=[];args=[]
    for side in ('subject','object'):
        parts.append(f"SELECT run,json_extract(data,'$.{side}') record FROM kg_auto_instances WHERE run IN ({scope}) AND json_extract(data,'$.{side}.concept_id')=?")
        args.extend([*runs,concept])
    query='SELECT run,record FROM ('+' UNION ALL '.join(parts)+") GROUP BY run,json_extract(record,'$.id')"
    with store.db() as db:
        total=db.execute('SELECT count(*) FROM ('+query+')',args).fetchone()[0] if offset is not None else 0
        query+=" ORDER BY run,json_extract(record,'$.id')"
        if offset is not None:query+=' LIMIT 25 OFFSET ?';args.append(offset)
        found=[]
        for row in db.execute(query,args):
            r=json.loads(row['record']);run=row['run']
            found.append({'key':kg.digest([run,r['id']]),'run':run,'id':r['id'],'source':r['source'],'row':r['row'],'label':r['label'],
                          'columns':r['columns'],'cells':r['cells'],'group':kg.digest([run,r['class_id']])})
    return (found,total) if offset is not None else found


def route(store,action,body):
    import knowledge_auto as auto
    import knowledge_revisions as revisions
    import knowledge_mapping_history as history
    runs=auto.selected(body)
    with store.lock:
        graph=auto.view(store,runs);edits=read(store)
        if body.get('revision')!=graph['revision']:raise ValueError('Graph changed; refresh and preview again')
        if action=='assignment-records':
            offset=body.get('offset',0)
            if type(offset) is not int or offset<0:raise ValueError('Invalid page')
            items,total=records(store,graph,runs,body.get('concept'),offset)
            return {'items':items,'total':total,'offset':offset,
                    'edits':[{'id':e['id'],'label':e['label']} for e in edits if e['status']=='accepted' and set(e['records'])<=set(runs)]}
        if any(l['update_available'] for l in graph['layers']):raise ValueError('Resolve pending Integration updates before correcting assignments')
        if kg._jobs.get(str(store.root),{}).get('status')=='running':raise ValueError('Wait for the current graph task')
        undo=action in ('preview-assignment-undo','apply-assignment-undo')
        if undo:
            item=next((e for e in edits if e['id']==body.get('id') and e['status']=='accepted'),None)
            if not item or not set(item['records'])<=set(runs):raise ValueError('Select all runs affected by this correction to undo it')
            if any(kg.load_plan(store,r)[1]!=v for r,v in item['revisions'].items()):raise ValueError('This correction belongs to an older Integration revision')
            candidate=dict(item,status='undone');new=[candidate if e['id']==item['id'] else e for e in edits]
        else:
            available=records(store,graph,runs,body.get('concept'))
            keys=body.get('records',[])
            if not isinstance(keys,list) or any(not isinstance(k,str) for k in keys):raise ValueError('Select records')
            selected=[r for r in available if r['key'] in keys]
            if len(selected)!=len(set(keys)) or not selected:raise ValueError('Choose records from this concept')
            if body.get('group') is True:
                groups={r['group'] for r in selected};selected=[r for r in available if r['group'] in groups]
            target=next((c for c in graph['concepts'] if c['id']==body.get('target')),None)
            if not target:
                name=body.get('name','').strip();definition=body.get('definition','').strip()
                if not 0<len(name)<=100 or not 0<len(definition)<=800 or any(ord(c)<32 for c in name):raise ValueError('Provide a new concept name and definition')
                if any(c['label'].casefold()==name.casefold() for c in graph['concepts']):raise ValueError('Choose the existing concept with this name')
                target={'id':'manual_'+kg.digest([name.casefold(),graph['revision']]),'label':name,'definition':definition,'attributes':[]}
            if target['id']==body.get('concept'):raise ValueError('Choose a different target concept')
            membership={}
            for r in selected:membership.setdefault(r['run'],[]).append(r['id'])
            candidate={'id':'pending','status':'accepted','records':membership,'revisions':{r:kg.load_plan(store,r)[1] for r in membership},
                       'target':target,'label':str(len(selected))+' record assignments → '+target['label']}
            new=[*edits,candidate]
        prepared=[];changes=[]
        with store.db() as db:
            names={r['id']:r['name'] for r in db.execute('SELECT id,name FROM assets')}
            for run in candidate['records']:
                plan,rev=kg.load_plan(store,run);refined=auto.knowledge_concepts.read(store,run,rev)
                overrides=mappings(new,run,rev)
                meta,items=auto.project_run(store,run,plan,rev,names,refined,overrides)
                old=[json.loads(r[0]) for r in db.execute('SELECT data FROM kg_auto_instances WHERE run=?',(run,))]
                oldedges={a['edge'] for a in old};newedges={a['edge'] for a in items}
                changes.append({'title':plan.get('title','Integration run'),'before':len(old),'after':len(items),
                                'old_edges':len(oldedges),'new_edges':len(newedges)})
                key=auto.assignment_key(auto.base_projection_key(rev,refined),overrides)
                prepared.append((run,key,meta,items))
        token=kg.digest([graph['revision'],candidate,prepared])
        preview={'token':token,'label':candidate['label'],'changes':changes,'records':sum(len(v) for v in candidate['records'].values())}
        if action in ('preview-assignment','preview-assignment-undo'):return preview
        if action not in ('apply-assignment','apply-assignment-undo') or token!=body.get('token'):raise ValueError('Preview changed; review again')
        with store.db() as db:
            history.setup(db)
            before=next((e for e in edits if e['id']==candidate['id']),None)
            if not undo:candidate['id']=str(uuid.uuid4())
            import time
            event={'before':before,'after':candidate,'runs':list(candidate['records']),'revision':graph['revision'],'label':candidate['label']}
            db.execute('INSERT INTO kg_mapping_events(recorded,family,mapping_id,action,data) VALUES(?,?,?,?,?)',(time.time(),'assignment',candidate['id'],'undo' if undo else 'accept',json.dumps(event)))
            if undo:db.execute('UPDATE kg_assignment_edits SET data=? WHERE id=?',(json.dumps(candidate),candidate['id']))
            else:db.execute('INSERT INTO kg_assignment_edits(id,data) VALUES(?,?)',(candidate['id'],json.dumps(candidate)))
            for run,key,meta,items in prepared:
                revisions.archive(db,run)
                db.execute('DELETE FROM kg_auto_instances WHERE run=?',(run,))
                db.executemany('INSERT INTO kg_auto_instances VALUES(?,?,?,?)',[(run,a['id'],a['edge'],json.dumps(a)) for a in items])
                db.execute('UPDATE kg_auto_runs SET revision=?,data=? WHERE run=?',(key,json.dumps(meta),run))
        return auto.view(store,runs)
