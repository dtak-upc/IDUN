"""Hugging Face Model Manager for IDUN.
Provides local model catalog, background snapshot downloading, disk cache management,
and in-process GPU/CPU inference using transformers.
"""

import os
import sys
import time
import json
import re
import threading
import logging
from typing import Dict, Any, List, Optional

# Suppress external torchao ABI compatibility warnings
logging.getLogger("torchao").setLevel(logging.ERROR)
os.environ.setdefault("TORCHAO_SKIP_LOADING_SO_FILES", "1")

try:
    import truststore
    truststore.inject_into_ssl()
except Exception:
    pass
import credentials



def patch_transformers_compatibility():
    """Ensures transformers 5.x is compatible with remote-code models (e.g. Phi-4/Phi-3.5)."""
    try:
        from typing import TypedDict
        import transformers.utils
        if not hasattr(transformers.utils, "LossKwargs"):
            class LossKwargs(TypedDict, total=False):
                pass
            transformers.utils.LossKwargs = LossKwargs

        import transformers.cache_utils
        if not hasattr(transformers.cache_utils, "SlidingWindowCache"):
            transformers.cache_utils.SlidingWindowCache = getattr(
                transformers.cache_utils, "DynamicCache", object
            )
        
        import transformers.modeling_utils
        orig_get_expanded = transformers.modeling_utils.PreTrainedModel.get_expanded_tied_weights_keys
        def safe_get_expanded(self, all_submodels=False):
            if hasattr(self, "_tied_weights_keys") and isinstance(self._tied_weights_keys, list):
                if len(self._tied_weights_keys) == 1:
                    self._tied_weights_keys = {self._tied_weights_keys[0]: "model.embed_tokens.weight"}
                elif len(self._tied_weights_keys) >= 2:
                    self._tied_weights_keys = {self._tied_weights_keys[0]: self._tied_weights_keys[1]}
                else:
                    self._tied_weights_keys = {}
            return orig_get_expanded(self, all_submodels=all_submodels)
        transformers.modeling_utils.PreTrainedModel.get_expanded_tied_weights_keys = safe_get_expanded
    except Exception:
        pass


patch_transformers_compatibility()


CURATED_MODELS = [
    {
        "repo_id": "Qwen/Qwen2.5-3B-Instruct",
        "name": "Qwen 2.5 (3B Instruct)",
        "params": "3.09B",
        "vram_estimate": "3.5 GB",
        "gated": False,
        "recommended": True,
        "description": "State-of-the-art small model with outstanding structured JSON adherence and clinical reasoning.",
    },
    {
        "repo_id": "Qwen/Qwen2.5-1.5B-Instruct",
        "name": "Qwen 2.5 (1.5B Instruct)",
        "params": "1.54B",
        "vram_estimate": "2.0 GB",
        "gated": False,
        "recommended": False,
        "description": "Ultra-lightweight and fast inference. Minimal VRAM footprint, ideal for rapid iterations.",
    },
    {
        "repo_id": "microsoft/Phi-3.5-mini-instruct",
        "name": "Phi 3.5 Mini (3.8B Instruct)",
        "params": "3.82B",
        "vram_estimate": "4.5 GB",
        "gated": False,
        "recommended": True,
        "description": "Microsoft's high-capability reasoning model with exceptional instruction and evidence grounding.",
    },
    {
        "repo_id": "google/gemma-2-2b-it",
        "name": "Gemma 2 (2B Instruct)",
        "params": "2.61B",
        "vram_estimate": "3.2 GB",
        "gated": True,
        "recommended": False,
        "description": "Google's compact, efficient model. Requires accepting Hugging Face license terms and setting HF_TOKEN.",
    },
    {
        "repo_id": "meta-llama/Llama-3.2-3B-Instruct",
        "name": "Llama 3.2 (3B Instruct)",
        "params": "3.21B",
        "vram_estimate": "4.0 GB",
        "gated": True,
        "recommended": False,
        "description": "Meta's highly capable 3B edge model. Requires accepting Hugging Face license and setting HF_TOKEN.",
    },
    {
        "repo_id": "meta-llama/Llama-3.2-1B-Instruct",
        "name": "Llama 3.2 (1B Instruct)",
        "params": "1.23B",
        "vram_estimate": "1.6 GB",
        "gated": True,
        "recommended": False,
        "description": "Ultra-compact 1B edge model with minimal resource requirements.",
    },
]

# Thread-safe download tracking state
_DOWNLOAD_LOCK = threading.Lock()
_DOWNLOAD_STATE = {
    "status": "idle",  # "idle" | "downloading" | "completed" | "error"
    "repo_id": "",
    "message": "",
    "percent": 0,
    "error": "",
    "started_at": 0,
}
_CANCEL_EVENT = threading.Event()

# Cached in-process model and tokenizer
_MODEL_LOCK = threading.Lock()
_EXECUTION_LOCK = threading.RLock()
_LOADED_MODEL = None
_LOADED_TOKENIZER = None
_LOADED_REPO_ID = ""


def get_cached_models_map() -> Dict[str, Dict[str, Any]]:
    """Scans Hugging Face Hub cache directory and returns a map of cached repos."""
    try:
        from huggingface_hub import scan_cache_dir
        info = scan_cache_dir()
        result = {}
        for repo in info.repos:
            if repo.repo_type == "model":
                file_names = []
                for rev in repo.revisions:
                    for f in rev.files:
                        file_names.append(f.file_name)
                is_pure_gguf = any(f.endswith(".gguf") for f in file_names) and not any(
                    f.endswith((".safetensors", ".bin", ".pt")) for f in file_names
                )
                result[repo.repo_id] = {
                    "size_on_disk": repo.size_on_disk,
                    "size_str": repo.size_on_disk_str,
                    "nb_files": repo.nb_files,
                    "last_modified": repo.last_modified,
                    "is_gguf": is_pure_gguf,
                    "format": "gguf" if is_pure_gguf else "transformers",
                }
        return result
    except Exception:
        return {}


def get_loaded_model() -> Dict[str, Any]:
    """Returns whether a model is currently loaded in memory/VRAM, its repo_id and allocated VRAM."""
    with _MODEL_LOCK:
        loaded = _LOADED_MODEL is not None
        repo_id = _LOADED_REPO_ID if loaded else ""
        vram_mb = 0
        if loaded:
            try:
                import torch
                if torch.cuda.is_available():
                    vram_mb = int(torch.cuda.memory_allocated() / (1024 * 1024))
            except Exception:
                pass
        return {
            "loaded": loaded,
            "repo_id": repo_id,
            "vram_mb": vram_mb,
        }


def _unload_model() -> Dict[str, Any]:
    """Unloads the currently loaded in-process model and tokenizer from memory and VRAM."""
    global _LOADED_MODEL, _LOADED_TOKENIZER, _LOADED_REPO_ID
    with _MODEL_LOCK:
        had_model = _LOADED_MODEL is not None
        prev_repo = _LOADED_REPO_ID
        if had_model:
            del _LOADED_MODEL
            del _LOADED_TOKENIZER
            _LOADED_MODEL = None
            _LOADED_TOKENIZER = None
            _LOADED_REPO_ID = ""
            import gc
            gc.collect()
            try:
                import torch
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                    if hasattr(torch.cuda, "ipc_collect"):
                        torch.cuda.ipc_collect()
            except Exception:
                pass
        return {"unloaded": had_model, "repo_id": prev_repo}


def list_models() -> List[Dict[str, Any]]:
    """Returns curated models with their disk download status, plus any extra cached models."""
    cached_map = get_cached_models_map()
    loaded_info = get_loaded_model()
    loaded_repo = loaded_info["repo_id"] if loaded_info["loaded"] else ""
    items = []
    seen = set()

    for m in CURATED_MODELS:
        repo_id = m["repo_id"]
        seen.add(repo_id)
        cached = cached_map.get(repo_id)
        items.append({
            **m,
            "format": "transformers",
            "compatible": True,
            "downloaded": cached is not None,
            "loaded": bool(loaded_repo and loaded_repo == repo_id),
            "size_str": cached["size_str"] if cached else "",
            "size_on_disk": cached["size_on_disk"] if cached else 0,
        })

    for repo_id, c in cached_map.items():
        if repo_id not in seen:
            is_gguf = c.get("is_gguf", False)
            items.append({
                "repo_id": repo_id,
                "name": repo_id.split("/")[-1],
                "params": "GGUF" if is_gguf else "Custom",
                "vram_estimate": "LM Studio" if is_gguf else "Unknown",
                "gated": False,
                "recommended": False,
                "format": c.get("format", "transformers"),
                "compatible": not is_gguf,
                "description": (
                    "GGUF model file detected in cache. GGUF format runs via LM Studio/Ollama; for Direct Hugging Face in-process execution, use a standard Transformers model."
                    if is_gguf
                    else "User downloaded custom model in local Hugging Face cache."
                ),
                "downloaded": True,
                "loaded": bool(loaded_repo and loaded_repo == repo_id),
                "size_str": c.get("size_str", ""),
                "size_on_disk": c.get("size_on_disk", 0),
            })

    return items


def download_status() -> Dict[str, Any]:
    """Returns the current background download status with live MB tracking."""
    from pathlib import Path
    with _DOWNLOAD_LOCK:
        state = dict(_DOWNLOAD_STATE)
        if state['status'] == 'downloading' and _CANCEL_EVENT.is_set():
            state['message'] = 'Cancelling download…'
            return state
    if state.get("status") == "downloading" and state.get("repo_id"):
        try:
            repo_folder = f"models--{state['repo_id'].replace('/', '--')}"
            cache_dir = Path.home() / ".cache" / "huggingface" / "hub" / repo_folder / "blobs"
            if cache_dir.exists():
                downloaded_mb = sum(f.stat().st_size for f in cache_dir.iterdir() if f.is_file()) // (1024 * 1024)
                target_mb = 3100 if ("1.5" in state["repo_id"] or "1B" in state["repo_id"]) else (6000 if ("3B" in state["repo_id"] or "3.8" in state["repo_id"] or "2b" in state["repo_id"].lower()) else 4500)
                pct = min(98, max(5, int((downloaded_mb / target_mb) * 92) + 5))
                state["percent"] = pct
                state["message"] = f"Downloading model files ({downloaded_mb} MB downloaded)..."
        except Exception:
            pass
    return state


def cancel_download() -> Dict[str, Any]:
    """Signals cancellation to the active download worker."""
    with _DOWNLOAD_LOCK:
        if _DOWNLOAD_STATE["status"] == "downloading":
            _CANCEL_EVENT.set()
            _DOWNLOAD_STATE["message"] = "Cancelling download…"
            return {"cancelled": True}
    return {"cancelled": False}


def download_active():
    with _DOWNLOAD_LOCK:
        return _DOWNLOAD_STATE['status'] == 'downloading'


def stop_download():
    cancel_download()
    deadline = time.monotonic() + 5
    while download_active():
        if time.monotonic() >= deadline:
            raise ValueError('Download is still stopping; retry shutdown shortly')
        time.sleep(.05)


def start_download(repo_id: str, key_env: str = "") -> Dict[str, Any]:
    """Starts asynchronous background download of a Hugging Face repository."""
    if not repo_id or not repo_id.strip():
        raise ValueError("Specify a valid Hugging Face repository ID")
    repo_id = repo_id.strip()
    token = credentials.resolve(key_env) if key_env else None

    with _DOWNLOAD_LOCK:
        if _DOWNLOAD_STATE["status"] == "downloading":
            if _DOWNLOAD_STATE["repo_id"] == repo_id:
                return {"status": "downloading", "repo_id": repo_id, "already_running": True}
            raise ValueError(f"Another model ({_DOWNLOAD_STATE['repo_id']}) is currently downloading")

        _CANCEL_EVENT.clear()
        _DOWNLOAD_STATE["status"] = "downloading"
        _DOWNLOAD_STATE["repo_id"] = repo_id
        _DOWNLOAD_STATE["percent"] = 5
        _DOWNLOAD_STATE["message"] = f"Connecting to Hugging Face for {repo_id}..."
        _DOWNLOAD_STATE["error"] = ""
        _DOWNLOAD_STATE["started_at"] = time.time()

    def _worker():
        process = None
        try:
            import subprocess
            from pathlib import Path
            with _DOWNLOAD_LOCK:
                _DOWNLOAD_STATE["message"] = f"Downloading model files for {repo_id}..."
                _DOWNLOAD_STATE["percent"] = 25

            process = subprocess.Popen([sys.executable, str(Path(__file__).with_name('hf_download.py'))],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            request = json.dumps({'repo_id': repo_id, 'token': token}).encode()
            while True:
                if _CANCEL_EVENT.is_set():
                    process.kill()
                    process.communicate()
                    break
                try:
                    output, _ = process.communicate(input=request, timeout=.1)
                    if process.returncode:
                        raise ValueError('Download worker stopped unexpectedly')
                    result = json.loads(output)
                    if result.get('error'):
                        raise ValueError(result['error'])
                    break
                except subprocess.TimeoutExpired:
                    request = None

            if _CANCEL_EVENT.is_set():
                with _DOWNLOAD_LOCK:
                    _DOWNLOAD_STATE["status"] = "idle"
                    _DOWNLOAD_STATE["message"] = "Download cancelled"
                return

            with _DOWNLOAD_LOCK:
                _DOWNLOAD_STATE["status"] = "completed"
                _DOWNLOAD_STATE["percent"] = 100
                _DOWNLOAD_STATE["message"] = f"Successfully downloaded {repo_id} to local cache"
        except Exception as e:
            if process is not None and process.poll() is None:
                process.kill()
                process.communicate()
            with _DOWNLOAD_LOCK:
                _DOWNLOAD_STATE["status"] = "error"
                _DOWNLOAD_STATE["error"] = str(e)
                _DOWNLOAD_STATE["message"] = f"Download failed: {e}"
        finally:
            if process is not None and process.poll() is None:
                process.kill()
                process.communicate()

    t = threading.Thread(target=_worker, daemon=True)
    t.start()
    return {"status": "downloading", "repo_id": repo_id}


def _delete_model(repo_id: str) -> Dict[str, Any]:
    """Deletes cached repository files from Hugging Face Hub cache."""
    try:
        if get_loaded_model().get("repo_id") == repo_id:
            unload_model()
        from huggingface_hub import scan_cache_dir
        info = scan_cache_dir()
        repo = next((r for r in info.repos if r.repo_id == repo_id), None)
        if not repo:
            return {"deleted": False, "message": "Model not found in cache"}

        strategy = info.delete_revisions(*[r.commit_hash for r in repo.revisions])
        strategy.execute()
        return {"deleted": True, "repo_id": repo_id}
    except Exception as e:
        raise ValueError(f"Failed to delete model from cache: {e}")


def delete_model(repo_id: str) -> Dict[str, Any]:
    if not _EXECUTION_LOCK.acquire(blocking=False):
        raise ValueError('Model is generating or loading; cancel its job before deleting models')
    try:
        with _DOWNLOAD_LOCK:
            if _DOWNLOAD_STATE['status'] == 'downloading':
                raise ValueError('Finish or cancel the download before deleting cached models')
            return _delete_model(repo_id)
    finally:
        _EXECUTION_LOCK.release()


def get_model_and_tokenizer(repo_id: str, token: Optional[str] = None):
    """Loads and caches the model and tokenizer in-process with device mapping."""
    global _LOADED_MODEL, _LOADED_TOKENIZER, _LOADED_REPO_ID

    token = token.strip() if (isinstance(token, str) and token.strip()) else None

    if repo_id.endswith("-GGUF") or ".gguf" in repo_id.lower():
        raise ValueError(
            f"'{repo_id}' is a GGUF format model file, which is designed for LM Studio or Ollama. "
            "To use this model, set your LLM Provider in Settings to 'LM Studio' or 'Ollama'. "
            "For Direct Hugging Face in-process inference, select a standard Transformers model (such as Qwen 2.5 or Phi 3.5) from the curated list in Settings."
        )

    with _MODEL_LOCK:
        if _LOADED_MODEL is not None and _LOADED_REPO_ID == repo_id:
            return _LOADED_MODEL, _LOADED_TOKENIZER

        patch_transformers_compatibility()
        import torch
        from transformers import AutoTokenizer, AutoModelForCausalLM

        # Free previously cached model from VRAM
        if _LOADED_MODEL is not None:
            del _LOADED_MODEL
            del _LOADED_TOKENIZER
            _LOADED_MODEL = None
            _LOADED_TOKENIZER = None
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        tokenizer = AutoTokenizer.from_pretrained(repo_id, token=token, trust_remote_code=False)

        has_cuda = torch.cuda.is_available()
        bnb_config = None
        if has_cuda:
            try:
                import bitsandbytes
                from transformers import BitsAndBytesConfig
                bnb_config = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch.float16,
                    bnb_4bit_quant_type="nf4",
                )
            except Exception:
                bnb_config = None

        dtype = torch.bfloat16 if has_cuda and torch.cuda.is_bf16_supported() else (torch.float16 if has_cuda else torch.float32)
        device_map = "auto" if has_cuda else "cpu"

        model = None
        load_errors = []
        for trust_remote in (False,):
            try:
                kwargs = {
                    "token": token,
                    "trust_remote_code": trust_remote,
                }
                if bnb_config is not None:
                    kwargs["quantization_config"] = bnb_config
                    kwargs["device_map"] = "auto"
                else:
                    kwargs["torch_dtype"] = dtype
                    kwargs["device_map"] = device_map

                model = AutoModelForCausalLM.from_pretrained(repo_id, **kwargs)
                break
            except Exception as e:
                load_errors.append(f"trust_remote={trust_remote}: {e}")
                bnb_config = None

        if model is None:
            raise RuntimeError(f"Failed to load model '{repo_id}': {'; '.join(load_errors)}")

        _LOADED_MODEL = model
        _LOADED_TOKENIZER = tokenizer
        _LOADED_REPO_ID = repo_id
        return _LOADED_MODEL, _LOADED_TOKENIZER


def _generate_hf(config, messages, check):
    """Executes in-process autoregressive generation using Hugging Face model."""
    repo_id = config.get("model", "").strip()
    if not repo_id:
        raise ValueError("Select a Hugging Face model in Settings to use local in-process inference")

    key_env = config.get("key_env", "")
    key = credentials.resolve(key_env) if key_env else None
    if not key or not str(key).strip():
        key = None
    else:
        key = str(key).strip()

    try:
        model, tokenizer = get_model_and_tokenizer(repo_id, token=key)
    except Exception as e:
        err = str(e)
        if "sentencepiece" in err.lower() or "tokenizer" in err.lower() or "gguf" in err.lower():
            raise ValueError(
                f"Failed to load '{repo_id}' for in-process inference: {err}. "
                "If this model is in GGUF format, switch Provider to LM Studio. "
                "For direct in-process execution, use a standard Transformers model (e.g. Qwen 2.5 or Phi 3.5)."
            )
        raise

    import torch

    prompt = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)

    max_tokens = int(config.get("max_output_tokens", 8192))
    if not 256 <= max_tokens <= 65536:
        raise ValueError("Output token allowance must be 256–65536")
    temp = config.get("temperature")
    top_p = config.get("top_p")

    gen_kwargs = {
        "max_new_tokens": max_tokens,
        "do_sample": bool(temp and temp > 0),
    }
    if temp and temp > 0:
        gen_kwargs["temperature"] = temp
    if top_p and top_p < 1.0:
        gen_kwargs["top_p"] = top_p

    if tokenizer.eos_token_id is not None:
        gen_kwargs["eos_token_id"] = tokenizer.eos_token_id
    if tokenizer.pad_token_id is not None:
        gen_kwargs["pad_token_id"] = tokenizer.pad_token_id
    elif tokenizer.eos_token_id is not None:
        gen_kwargs["pad_token_id"] = tokenizer.eos_token_id

    from transformers import StoppingCriteria, StoppingCriteriaList
    class JobControl(StoppingCriteria):
        def __call__(self, input_ids, scores, **kwargs):
            check()
            return False
    check()
    gen_kwargs['stopping_criteria'] = StoppingCriteriaList([JobControl()])
    with torch.no_grad():
        outputs = model.generate(**inputs, **gen_kwargs)
    check()

    generated_tokens = outputs[0][inputs.input_ids.shape[1]:]
    output_text = tokenizer.decode(generated_tokens, skip_special_tokens=True)
    return output_text



def unload_model() -> Dict[str, Any]:
    if not _EXECUTION_LOCK.acquire(blocking=False):
        raise ValueError('Model is generating or loading; cancel its job before unloading')
    try:
        return _unload_model()
    finally:
        _EXECUTION_LOCK.release()


def generate_hf(config: Dict[str, Any], messages: List[Dict[str, str]], timeout: int = 60, check=lambda: None) -> str:
    """Serialize model ownership; cancellation/deadline checks run between tokens."""
    if type(timeout) is not int or timeout < 0:
        raise ValueError('Timeout must be nonnegative; zero means unlimited')
    deadline = time.monotonic() + timeout if timeout else None
    def controlled():
        check()
        if deadline is not None and time.monotonic() >= deadline:
            raise TimeoutError('Hugging Face response deadline exceeded')
    controlled()
    while not _EXECUTION_LOCK.acquire(timeout=0.1):
        controlled()
    try:
        controlled()
        return _generate_hf(config, messages, controlled)
    finally:
        _EXECUTION_LOCK.release()
