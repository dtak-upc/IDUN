"""IDUN local ingestion API. Python >=3.11; vector dependencies in requirements-api.txt."""
from contextlib import contextmanager
import argparse
import sys
import codecs
import csv
import hashlib
import io
import json
import os
import re
import logging
from pathlib import Path
import sqlite3
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

# Suppress external torchao ABI compatibility warnings
logging.getLogger("torchao").setLevel(logging.ERROR)
os.environ.setdefault("TORCHAO_SKIP_LOADING_SO_FILES", "1")

try:
    import truststore
    truststore.inject_into_ssl()
except Exception:
    pass

from inference import readiness, prepare
import profiling
import discovery
import settings
import integration
import relationship_probe

PARSER = 'raw-v1'
MAX_FILE = 1024 * 1024 * 1024
ENCODINGS = {'auto', 'utf-8', 'utf-16le', 'utf-16be', 'windows-1252'}
TERMINAL = {'ready', 'failed', 'cancelled', 'interrupted'}

class Cancelled(Exception): pass

class Store:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root/'blobs').mkdir(exist_ok=True)
        (self.root/'pending').mkdir(exist_ok=True)
        self.dbpath = self.root/'catalog.sqlite3'
        self.pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix='ingest')
        self.lock = threading.RLock()
        with self.db() as db:
            db.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS assets(id TEXT PRIMARY KEY,name TEXT,path TEXT,created REAL);
            CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,asset_id TEXT,encoding TEXT,status TEXT,size INTEGER DEFAULT 0,received INTEGER DEFAULT 0,digest TEXT,version TEXT,records INTEGER DEFAULT 0,error TEXT,cancel INTEGER DEFAULT 0,created REAL,updated REAL);
            CREATE TABLE IF NOT EXISTS records(asset_id TEXT,version TEXT,idx INTEGER,start INTEGER,end INTEGER,data TEXT,PRIMARY KEY(asset_id,version,idx));
            CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,job_id TEXT,status TEXT,message TEXT,created REAL);
            ''')
            db.execute('CREATE TABLE IF NOT EXISTS datasets(id TEXT PRIMARY KEY,name TEXT,created REAL)')
            db.execute('CREATE TABLE IF NOT EXISTS removals(id TEXT PRIMARY KEY,asset_ids TEXT,files INTEGER,bytes INTEGER,created REAL)')
            if 'dataset_id' not in [r['name'] for r in db.execute('PRAGMA table_info(assets)')]:
                db.execute('ALTER TABLE assets ADD COLUMN dataset_id TEXT')
            legacy=str(uuid.uuid5(uuid.NAMESPACE_URL,'idun:legacy-imports'))
            if db.execute('SELECT 1 FROM assets WHERE dataset_id IS NULL LIMIT 1').fetchone():
                db.execute('INSERT OR IGNORE INTO datasets VALUES(?,?,?)',(legacy,'Earlier imports',time.time()))
                db.execute('UPDATE assets SET dataset_id=? WHERE dataset_id IS NULL',(legacy,))
            for r in db.execute("SELECT id FROM jobs WHERE status NOT IN ('ready','failed','cancelled','interrupted')").fetchall():
                self.transition(db,r['id'],'interrupted','Service restarted. Retry this job.')
        for p in (self.root/'pending').glob('*.part'):
            p.unlink()  # Only this service's opaque partial-upload files.
    @contextmanager
    def db(self):
        with self.lock:
            if getattr(self,'removed',False): raise KeyError('Lake has been removed')
            db=sqlite3.connect(self.dbpath,timeout=30)
            db.row_factory=sqlite3.Row
            try:
                with db:
                    yield db
            finally:
                db.close()
    def transition(self,db,jid,status,message=None):
        db.execute('UPDATE jobs SET status=?,error=?,updated=? WHERE id=?',(status,message,time.time(),jid))
        db.execute('INSERT INTO events(job_id,status,message,created) VALUES(?,?,?,?)',(jid,status,message,time.time()))
    def job(self,jid):
        with self.db() as db:
            row=db.execute('SELECT j.*,a.name,a.path,a.dataset_id FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.id=?',(jid,)).fetchone()
        if not row: raise KeyError('Job not found')
        return dict(row)
    def create(self,data):
        jid=str(uuid.UUID(data['id']))
        dataset_id=str(uuid.UUID(data.get('dataset_id',jid))); dataset_name=data.get('dataset_name','Manual import')
        if not isinstance(dataset_name,str) or not dataset_name.strip() or len(dataset_name)>120: raise ValueError('Dataset name must contain 1–120 characters')
        name=data['name']; path=data.get('path',name); encoding=data.get('encoding','auto'); size=data['size']
        if not isinstance(name,str) or not name.lower().endswith(('.csv','.txt')): raise ValueError('Only CSV and TXT files are supported')
        if not isinstance(path,str) or len(path)>4096 or len(name)>512: raise ValueError('Invalid source name/path')
        if encoding not in ENCODINGS: raise ValueError('Unsupported encoding')
        if type(size) is not int or not 0<size<=MAX_FILE: raise ValueError('File must be nonempty and at most 1 GiB')
        with self.lock,self.db() as db:
            existing=db.execute('SELECT id FROM jobs WHERE id=?',(jid,)).fetchone()
            if existing:
                old=self.job(jid)
                if (old['name'],old['path'],old['size'],old['encoding'],old['dataset_id'])!=(name,path,size,encoding,dataset_id): raise ValueError('Idempotency key already used for different input')
            else:
                aid=str(uuid.uuid4()); now=time.time()
                db.execute('INSERT OR IGNORE INTO datasets VALUES(?,?,?)',(dataset_id,dataset_name.strip(),now))
                db.execute('INSERT INTO assets(id,name,path,created,dataset_id) VALUES(?,?,?,?,?)',(aid,name,path,now,dataset_id))
                db.execute('INSERT INTO jobs(id,asset_id,encoding,status,size,created,updated) VALUES(?,?,?,?,?,?,?)',(jid,aid,encoding,'awaiting_upload',size,now,now))
                db.execute('INSERT INTO events(job_id,status,created) VALUES(?,?,?)',(jid,'awaiting_upload',now))
        return self.job(jid)
    def check_cancel(self,jid):
        if self.job(jid)['cancel']: raise Cancelled()
    def upload(self,jid,stream,length):
        with self.lock,self.db() as db:
            j=self.job(jid)
            if j['status']!='awaiting_upload': raise ValueError('Job is not awaiting upload; retry or inspect its current state')
            if length!=j['size']: raise ValueError('Content-Length differs from declared file size')
            self.transition(db,jid,'uploading')
        temp=self.root/'pending'/f'{jid}.part'; digest=hashlib.sha256(); received=0
        try:
            with temp.open('wb') as out:
                while received<length:
                    self.check_cancel(jid)
                    chunk=stream.read(min(65536,length-received))
                    if not chunk: raise ValueError('Upload ended before declared length')
                    out.write(chunk); digest.update(chunk); received+=len(chunk)
                    with self.db() as db: db.execute('UPDATE jobs SET received=?,updated=? WHERE id=?',(received,time.time(),jid))
                out.flush(); os.fsync(out.fileno())
            self.check_cancel(jid)
            sha=digest.hexdigest(); dest=self.root/'blobs'/sha
            with self.lock:
                if dest.exists(): temp.unlink()
                else: os.replace(temp,dest)
                with self.db() as db:
                    db.execute('UPDATE jobs SET digest=? WHERE id=?',(sha,jid)); self.transition(db,jid,'queued')
                self.pool.submit(self.parse,jid)
        except Cancelled:
            with self.db() as db: self.transition(db,jid,'cancelled','Cancelled during upload')
        except Exception as e:
            with self.db() as db: self.transition(db,jid,'failed',str(e))
        finally:
            if temp.exists(): temp.unlink()
        return self.job(jid)
    def parse(self,jid):
        try:
            self.check_cancel(jid); j=self.job(jid)
            raw=self.root/'blobs'/j['digest']
            with raw.open('rb') as f: prefix=f.read(65536)
            enc=j['encoding']
            if enc=='auto': enc='utf-16' if prefix.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig'
            version=hashlib.sha256(f"{j['digest']}:{enc}:{PARSER}".encode()).hexdigest()
            with self.db() as db:
                db.execute('DELETE FROM records WHERE asset_id=?',(j['asset_id'],))
                db.execute('UPDATE jobs SET version=?,records=0 WHERE id=?',(version,jid)); self.transition(db,jid,'parsing')
            idx=0; offset=0; batch=[]
            def add(data,start=None,end=None):
                nonlocal idx,batch
                self.check_cancel(jid); idx+=1
                batch.append((j['asset_id'],version,idx,start,end,json.dumps(data,ensure_ascii=False)))
                if len(batch)>=100: flush()
            def flush():
                nonlocal batch
                with self.db() as db:
                    db.executemany('INSERT INTO records VALUES(?,?,?,?,?,?)',batch)
                    db.execute('UPDATE jobs SET records=?,updated=? WHERE id=?',(idx,time.time(),jid))
                batch=[]
            if j['name'].lower().endswith('.csv'):
                sample=prefix.decode(enc,errors='ignore')
                try: delimiter=csv.Sniffer().sniff(sample,delimiters=',;\t|').delimiter
                except csv.Error: delimiter=','
                csv.field_size_limit(1024*1024)
                with raw.open('r',encoding=enc,newline='') as f:
                    for row in csv.reader(f,delimiter=delimiter,strict=True):
                        if len(row)>4096 or sum(map(len,row))>8*1024*1024: raise ValueError('CSV record exceeds 4096 fields or 8 MiB decoded text')
                        if any('\x00' in c for c in row): raise ValueError('NUL bytes in CSV; select the correct encoding')
                        add(row)
                if not idx: raise ValueError('CSV has no records')
            else:
                decoder=codecs.getincrementaldecoder(enc)(errors='strict')
                with raw.open('rb') as f:
                    while True:
                        chunk=f.read(65536); text=decoder.decode(chunk,final=not chunk)
                        if '\x00' in text: raise ValueError('NUL bytes in text; select the correct encoding')
                        for pos in range(0,len(text),4096):
                            part=text[pos:pos+4096]; add(part,offset,offset+len(part)); offset+=len(part)
                        if not chunk: break
                if not idx: raise ValueError('Text is empty after decoding')
            flush()
            with self.lock,self.db() as db:
                self.check_cancel(jid); self.transition(db,jid,'ready')
        except Cancelled:
            with self.db() as db: self.transition(db,jid,'cancelled','Parsing cancelled. Original bytes retained.')
        except Exception as e:
            with self.db() as db: self.transition(db,jid,'failed',f'{type(e).__name__}: {e}')
    def cancel(self,jid):
        with self.lock,self.db() as db:
            j=self.job(jid)
            if j['status'] in TERMINAL: return j
            db.execute('UPDATE jobs SET cancel=1 WHERE id=?',(jid,))
            if j['status']=='awaiting_upload': self.transition(db,jid,'cancelled','Cancelled before upload')
        return self.job(jid)
    def retry(self,jid,encoding=None):
        with self.lock,self.db() as db:
            j=self.job(jid)
            if j['status'] not in {'failed','cancelled','interrupted'}: raise ValueError('Only failed, cancelled or interrupted jobs can retry')
            if encoding is not None and encoding not in ENCODINGS: raise ValueError('Unsupported encoding')
            db.execute('UPDATE jobs SET cancel=0,encoding=?,records=0 WHERE id=?',(encoding or j['encoding'],jid))
            self.transition(db,jid,'queued' if j['digest'] else 'awaiting_upload')
        if j['digest']: self.pool.submit(self.parse,jid)
        return self.job(jid)
    def catalog(self,query='',offset=0,dataset=''):
        with self.db() as db:
            total=db.execute("SELECT COUNT(*) FROM jobs WHERE status='ready'").fetchone()[0]
            found=db.execute("SELECT COUNT(*) FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE status='ready' AND instr(lower(a.path),lower(?))>0 AND (?='' OR a.dataset_id=?)",(query,dataset,dataset)).fetchone()[0]
            rows=db.execute("SELECT j.*,a.name,a.path,a.dataset_id FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE status='ready' AND instr(lower(a.path),lower(?))>0 AND (?='' OR a.dataset_id=?) ORDER BY a.created,a.id LIMIT 25 OFFSET ?",(query,dataset,dataset,offset)).fetchall()
        return {'total':total,'matched':found,'offset':offset,'assets':[dict(r) for r in rows]}
    def datasets(self):
        with self.db() as db:
            rows=db.execute("SELECT d.id,d.name,COUNT(a.id) files,COALESCE(SUM(j.size),0) bytes FROM datasets d JOIN assets a ON a.dataset_id=d.id JOIN jobs j ON j.asset_id=a.id GROUP BY d.id ORDER BY d.created,d.id").fetchall()
        return {'datasets':[dict(r) for r in rows]}
    def removal_preview(self,data):
        dataset=data.get('dataset_id'); ids=data.get('asset_ids')
        if bool(dataset)==bool(ids): raise ValueError('Choose one dataset or explicit saved files')
        with self.db() as db:
            if dataset:
                dataset=str(uuid.UUID(dataset))
                rows=db.execute('SELECT a.id,a.name,a.path,a.dataset_id,j.digest,j.size,j.status,j.updated FROM assets a JOIN jobs j ON j.asset_id=a.id WHERE a.dataset_id=? ORDER BY a.id',(dataset,)).fetchall()
            else:
                if not isinstance(ids,list) or len(ids)>5000: raise ValueError('Select at most 5000 files at a time')
                ids=sorted(set(str(uuid.UUID(i)) for i in ids))
                rows=db.execute('SELECT a.id,a.name,a.path,a.dataset_id,j.digest,j.size,j.status,j.updated FROM assets a JOIN jobs j ON j.asset_id=a.id WHERE a.id IN ('+','.join('?' for _ in ids)+') ORDER BY a.id',ids).fetchall()
                if len(rows)!=len(ids): raise ValueError('Some selected files no longer exist. Refresh the catalog.')
            if not rows: raise ValueError('No saved files in this selection')
            if any(r['status'] not in TERMINAL for r in rows): raise ValueError('This selection has active ingestion jobs. Cancel them or wait for completion before removal.')
            selected={r['id'] for r in rows}; reclaim=0; shared=0
            for digest in {r['digest'] for r in rows if r['digest']}:
                owners={r['asset_id'] for r in db.execute('SELECT asset_id FROM jobs WHERE digest=?',(digest,))}
                if owners-selected: shared+=1
                else: reclaim+=next(r['size'] for r in rows if r['digest']==digest)
        token=hashlib.sha256(json.dumps([dict(r) for r in rows],sort_keys=True).encode()).hexdigest()
        return {'token':token,'files':len(rows),'bytes':sum(r['size'] for r in rows),'reclaimable_bytes':reclaim,'shared_blobs_retained':shared,'asset_ids':[r['id'] for r in rows],'sample_paths':[r['path'] for r in rows[:5]],'dataset_id':dataset}
    def remove(self,data):
        with self.lock:
            plan=self.removal_preview(data)
            if data.get('token')!=plan['token']: raise ValueError('Selection changed since preview. Review a fresh removal preview.')
            ids=plan['asset_ids']; placeholders=','.join('?' for _ in ids)
            with self.db() as db:
                digests=[r['digest'] for r in db.execute('SELECT DISTINCT digest FROM jobs WHERE asset_id IN ('+placeholders+') AND digest IS NOT NULL',ids)]
                db.execute('DELETE FROM events WHERE job_id IN (SELECT id FROM jobs WHERE asset_id IN ('+placeholders+'))',ids)
                if db.execute("SELECT 1 FROM sqlite_master WHERE name='lake_profile'").fetchone(): db.execute('DELETE FROM lake_profile')
                profiling.clear_removed(db,ids)
                discovery.remove_sources(db,ids)
                integration.remove_sources(db,ids)
                db.execute('DELETE FROM records WHERE asset_id IN ('+placeholders+')',ids)
                db.execute('DELETE FROM jobs WHERE asset_id IN ('+placeholders+')',ids)
                db.execute('DELETE FROM assets WHERE id IN ('+placeholders+')',ids)
                db.execute('DELETE FROM datasets WHERE id NOT IN (SELECT dataset_id FROM assets)')
                db.execute('INSERT INTO removals VALUES(?,?,?,?,?)',(str(uuid.uuid4()),json.dumps(ids),len(ids),plan['bytes'],time.time()))
            cleanup_pending=0
            if hasattr(self, '_vectors'):
                try: self._vectors.cleanup()
                except Exception: cleanup_pending+=1  # Active references already exclude removed sources.
            for digest in digests:
                with self.db() as db: referenced=db.execute('SELECT 1 FROM jobs WHERE digest=? LIMIT 1',(digest,)).fetchone()
                if not referenced:
                    if not re.fullmatch(r'[0-9a-f]{64}',digest): raise ValueError('Invalid stored content identity')
                    target=(self.root/'blobs'/digest).resolve()
                    if target.parent!=(self.root/'blobs').resolve(): raise ValueError('Invalid storage target')
                    try: target.unlink(missing_ok=True)
                    except OSError: cleanup_pending+=1
            return {**plan,'removed':len(ids),'cleanup_pending':cleanup_pending}
    def preview(self,aid,offset=0):
        with self.db() as db:
            j=db.execute("SELECT * FROM jobs WHERE asset_id=? AND status='ready'",(aid,)).fetchone()
            if not j: raise KeyError('Ready asset not found')
            rows=db.execute('SELECT * FROM records WHERE asset_id=? AND version=? ORDER BY idx LIMIT 20 OFFSET ?',(aid,j['version'],offset)).fetchall()
        items=[]
        for r in rows:
            value=json.loads(r['data']); clipped=False
            if isinstance(value,list):
                clipped=len(value)>12 or any(len(c)>240 for c in value[:12]); value=[c[:240] for c in value[:12]]
            items.append({'id':f"{aid}:{j['version']}:{r['idx']}",'index':r['idx'],'start':r['start'],'end':r['end'],'value':value,'clipped':clipped})
        return {'version':j['version'],'total':j['records'],'offset':offset,'records':items,'offsetUnit':'Unicode code points (decoded text; end exclusive)'}

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    @property
    def store(self): return getattr(self, "lake_store", self.server.store)
    def reply(self,code,data):
        body=json.dumps(data,ensure_ascii=False).encode(); self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(body); self.wfile.flush()
    def body(self,required=True):
        n=int(self.headers.get('Content-Length','0'))
        if n==0 and not required: return {}
        if not 0<n<=262144: raise ValueError('JSON body size invalid')
        raw=self.rfile.read(n)
        if not raw and not required: return {}
        return json.loads(raw)
    def allowed(self):
        origin=self.headers.get('Origin')
        if origin and origin not in {'http://127.0.0.1:5173','http://localhost:5173','http://127.0.0.1:8787'}: return False
        host=self.headers.get('Host','').split(':')[0]
        return host in {'127.0.0.1','localhost','[::1]'}
    def do_GET(self): self.route('GET')
    def do_POST(self): self.route('POST')
    def do_PUT(self): self.route('PUT')
    def route(self,method):
        try:
            if not self.allowed(): return self.reply(403,{'error':'Local origin required'})
            url=urlparse(self.path); parts=url.path.strip('/').split('/'); q=parse_qs(url.query)
            if parts[:2]!=['api','v1']: return self.reply(404,{'error':'Not found'})
            path=parts[2:]
            registry=getattr(self.server,'lakes',None)
            if registry:
                self.lake_store=self.server.store
                if path==['lakes']:
                    if method=='GET': return self.reply(200,registry.listing())
                    if method=='POST': return self.reply(201,registry.write(self.body()))
                if len(path)==2 and path[0]=='lakes' and method=='POST':
                    return self.reply(200,registry.write(self.body(),path[1]))
                if len(path)==3 and path[0]=='lakes' and path[2]=='removal-preview' and method=='POST':
                    return self.reply(200,registry.removal_preview(path[1]))
                if len(path)==3 and path[0]=='lakes' and path[2]=='remove' and method=='POST':
                    result=registry.remove(path[1],self.body())
                    self.server.store=registry.default
                    return self.reply(200,result)
                if len(path)==3 and path[0]=='lakes' and path[2]=='reset-preview' and method in ('GET','POST'):
                    import lake_reset
                    target_store=registry.resolve(path[1])
                    return self.reply(200,lake_reset.reset_preview(target_store))
                if len(path)==3 and path[0]=='lakes' and path[2]=='reset' and method=='POST':
                    import lake_reset
                    target_store=registry.resolve(path[1])
                    return self.reply(200,lake_reset.reset_lake(target_store,keep_sources=True))
                if len(path)>=3 and path[0]=='lakes':
                    self.lake_store=registry.resolve(path[1]);path=path[2:]
                    if path[0] in ('settings','health','lakes','session'):raise ValueError('Application endpoint cannot be lake-scoped')
                elif path and path[0] not in ('settings','health','session'):
                    raise ValueError('Select a data lake before accessing lake data')
                if method!='GET' and (getattr(self.server.store,'restarting',False) or getattr(self.server.store,'shutting_down',False)):raise ValueError('API restart or shutdown is in progress')
            if path==['storage'] and method=='GET': return self.reply(200,getattr(self.store,'storage_status',{'status':'idle'}))
            if getattr(self.store,'storage_active',False): return self.reply(503,{'error':'Lake storage maintenance is running; retry shortly'})
            if path==['storage','compact'] and method=='POST':
                import storage_compaction
                return self.reply(202,storage_compaction.start(self.store))
            if (path==['storage','reset-preview'] or path==['lake','reset-preview']) and method in ('GET','POST'):
                import lake_reset
                return self.reply(200,lake_reset.reset_preview(self.store))
            if (path==['storage','reset'] or path==['lake','reset']) and method=='POST':
                import lake_reset
                return self.reply(200,lake_reset.reset_lake(self.store,keep_sources=True))
            offset=max(0,min(100000000,int(q.get('offset',['0'])[0])))
            if method!='GET' and (getattr(self.store,'restarting',False) or getattr(self.store,'shutting_down',False)): return self.reply(503,{'error':'API restart or shutdown is in progress; reconnect shortly'})
            if method=='POST' and path==['settings','restart']:
                result=settings.request_restart(self.server)
                try: self.reply(202,result)
                finally: threading.Thread(target=self.server.shutdown,daemon=True).start()
                return
            if method=='POST' and (path==['settings','shutdown'] or path==['session','logout']):
                body=self.body(required=False) or {}
                result=settings.request_shutdown(self.server,force=bool(body.get('force')))
                self.close_connection=True
                self.reply(200,result)
                import time
                def _delayed_shutdown():
                    time.sleep(0.35)
                    self.server.shutdown()
                threading.Thread(target=_delayed_shutdown,daemon=True).start()
                return
            if method=='GET' and path==['augmentation','runs']:
                import augmentation
                return self.reply(200,augmentation.runs(self.store))
            if method=='GET' and path==['augmentation','assessment']:
                import augmentation_workspace
                return self.reply(200,augmentation_workspace.assess(self.store,q.get('scope',['source'])[0],q.get('run',[''])[0]))
            if method=='GET' and path==['augmentation','workspace']:
                import augmentation_workspace
                return self.reply(200,augmentation_workspace.read(self.store,q.get('scope',['source'])[0],q.get('run',[''])[0]))
            if method=='GET' and path==['augmentation','assessment','table']:
                import augmentation_gap_inspection
                return self.reply(200,augmentation_gap_inspection.inspect(self.store,{key:value[0] for key,value in q.items()}))
            if method=='POST' and path==['augmentation','runs','execute']:
                import augmentation
                b = self.body()
                scope = b.get('scope', 'integration' if b.get('run_id') else 'source')
                engine = b.get('engine', 'thor')
                if scope not in ('source', 'integration') or engine not in ('thor', 'typed_llm', 'hybrid'): raise ValueError('Invalid augmentation scope or engine')
                prompt_cfg = b.get('prompt_config')
                from augmentation_selection import validate
                selection = validate(b.get('selection'))
                if scope == 'source':
                    return self.reply(200, augmentation.execute_pre_integration(self.store, expand_retrieval=bool(b.get('expand_retrieval')), engine=engine, prompt_config=prompt_cfg, selection=selection))
                return self.reply(200, augmentation.execute_post_integration(self.store, b.get('run_id'), expand_retrieval=bool(b.get('expand_retrieval')), engine=engine, prompt_config=prompt_cfg, selection=selection))
            if method=='GET' and path==['augmentation','runs','list']:
                import augmentation
                return self.reply(200, augmentation.list_augmentation_runs(self.store, base_run_id=q.get('base_run_id', [None])[0]))
            if method=='GET' and len(path)==4 and path[:2]==['augmentation','runs'] and path[3]=='journey':
                import augmentation
                return self.reply(200, augmentation.journey(self.store, path[2], decision=q.get('decision', [None])[0], offset=int(q.get('offset', ['0'])[0])))
            if method=='GET' and len(path)==4 and path[:2]==['augmentation','runs'] and path[3]=='proposals':
                import augmentation
                return self.reply(200, augmentation.get_proposals(self.store, path[2], status=q.get('status', [None])[0], decision=q.get('decision', [None])[0], limit=int(q.get('limit', ['50'])[0]), offset=int(q.get('offset', ['0'])[0]), table_id=q.get('table_id', [None])[0], include_records=q.get('include_records', ['false'])[0] == 'true'))
            if method=='POST' and len(path)==4 and path[:2]==['augmentation','proposals'] and path[3]=='override':
                import augmentation
                b = self.body()
                return self.reply(200, augmentation.override_proposal(self.store, path[2], b.get('value'), b.get('accept', False)))
            if method=='POST' and len(path)==4 and path[:2]==['augmentation','proposals'] and path[3]=='decision':
                import augmentation
                b = self.body()
                return self.reply(200, augmentation.update_proposal_decision(self.store, path[2], b.get('decision'), b.get('reason')))
            if method=='POST' and len(path)==4 and path[:2]==['augmentation','runs'] and path[3]=='finalize':
                import augmentation
                return self.reply(200, augmentation.finalize_review(self.store, path[2]))
            if method=='POST' and len(path)==4 and path[:2]==['augmentation','runs'] and path[3]=='bulk-decision':
                import augmentation
                b = self.body()
                return self.reply(200, augmentation.bulk_proposal_decision(
                    self.store,
                    path[2],
                    b.get('action'),
                    proposal_ids=b.get('proposal_ids'),
                    table_id=b.get('table_id'),
                    column_name=b.get('column_name')
                ))
            if method=='GET' and len(path)==4 and path[:2]==['augmentation','runs'] and path[3]=='view':
                import augmentation
                return self.reply(200, augmentation.derived_view(self.store, path[2], table_id=q.get('table_id', [None])[0]))
            if method=='GET' and len(path)==4 and path[:2]==['augmentation','runs'] and path[3]=='neighborhoods':
                import augmentation
                return self.reply(200, augmentation.evaluate_candidate_neighborhoods(self.store, path[2]))
            if method=='POST' and len(path)==4 and path[:2]==['augmentation','runs'] and path[3]=='feedback-pass':
                import augmentation
                return self.reply(200, augmentation.execute_feedback_pass(self.store, path[2]))
            if method=='POST' and len(path)==4 and path[:2]==['augmentation','runs'] and path[3]=='document-pass':
                import augmentation_retry
                return self.reply(200, augmentation_retry.execute(self.store, path[2], self.body()))
            if method=='GET' and len(path)==4 and path[:2]==['augmentation','runs'] and path[3]=='export':
                import augmentation
                fmt = q.get('format', ['csv'])[0]
                table_id = q.get('table_id', [None])[0]
                relation = q.get('relation', [None])[0]
                payload = augmentation.export_derived_view(self.store, path[2], format=fmt, table_id=table_id, relation=relation)
                ct = 'text/csv; charset=utf-8' if fmt == 'csv' else 'application/json; charset=utf-8'
                ext = 'csv' if fmt == 'csv' else 'json'
                tag = f"-{relation.lower()}" if relation else (f"-{table_id}" if table_id else "")
                self.send_response(200)
                self.send_header('Content-Type', ct)
                self.send_header('Content-Disposition', f'attachment; filename="idun-derived-{path[2]}{tag}.{ext}"')
                self.send_header('Content-Length', str(len(payload)))
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(payload)
                return
            if method=='POST' and len(path)==4 and path[:2]==['augmentation','runs'] and path[3]=='delete':
                import augmentation
                return self.reply(200, augmentation.delete_run(self.store, path[2]))
            if method=='GET' and len(path)==3 and path[:2]==['augmentation','runs']:
                import augmentation
                return self.reply(200, augmentation.get_augmentation_run(self.store, path[2]))
            if method=='GET' and len(path)==4 and path[:2]==['augmentation','runs'] and path[3]=='telemetry':
                import typed_extraction
                return self.reply(200, typed_extraction.calculate_telemetry(self.store, path[2]))
            if method=='GET' and path==['augmentation','prompts','typed']:
                import typed_extraction
                return self.reply(200, typed_extraction.get_typed_prompt(self.store))
            if method=='POST' and path==['augmentation','prompts','typed']:
                import typed_extraction
                return self.reply(200, typed_extraction.save_typed_prompt(self.store, self.body()))
            if method=='GET' and path==['augmentation','status']:
                import thor_adapter
                s_cfg = settings.read(self.store)
                llm_cfg = s_cfg.get('llm', {})
                llm_active = llm_cfg.get('provider') not in ('disabled', '', None) and bool(llm_cfg.get('model', '').strip())
                thor_pkgs = thor_adapter.versions()
                thor_ready = all(bool(v) for v in thor_pkgs.values())
                return self.reply(200, {
                    'llm': {
                        'active': llm_active,
                        'provider': llm_cfg.get('provider', 'disabled'),
                        'model': llm_cfg.get('model', ''),
                        'base_url': llm_cfg.get('base_url', '')
                    },
                    'thor': {
                        'ready': thor_ready,
                        'packages': thor_pkgs
                    }
                })
            if method=='GET' and path==['thor','config']:
                import thor
                return self.reply(200,thor.config(self.store))
            if method=='POST' and path==['thor','config']:
                import thor
                return self.reply(200,thor.config(self.store,self.body()))
            if method=='GET' and path==['thor','status']:
                import thor
                return self.reply(200,thor.status(self.store))
            if method=='GET' and path==['thor','prepare']:
                import thor
                return self.reply(200,thor.prepare(self.store,q.get('scope',['source'])[0],q.get('run',[''])[0]))
            if method=='GET' and path==['integration']: return self.reply(200,integration.status(self.store))
            if method=='POST' and path==['integration']: return self.reply(202,integration.start(self.store,self.body()))
            if method=='POST' and path==['integration','cancel']: return self.reply(200,integration.cancel(self.store))
            if method=='GET' and path==['integration','schema']: return self.reply(200,integration.schema_settings(self.store))
            if method=='POST' and path==['integration','schema']: return self.reply(200,integration.schema_settings(self.store,self.body()))
            if method=='GET' and path==['integration','schema','defaults']: return self.reply(200,relationship_probe.get_default_schema(self.store))
            if method=='POST' and path==['integration','schema','probe']: return self.reply(202,relationship_probe.start(self.store,self.body(required=False)))
            if method=='GET' and len(path)==3 and path[0]=='integration' and path[2]=='journey':
                import integration_journey
                return self.reply(200,integration_journey.read(self.store,path[1],{k:v[0] for k,v in q.items()}))
            if method=='GET' and len(path)==2 and path[0]=='integration': return self.reply(200,integration.get(self.store,path[1]))
            if method=='POST' and len(path)==3 and path[0]=='integration' and path[2]=='rename': return self.reply(200,integration.rename_run(self.store,path[1],self.body()))
            if method=='POST' and len(path)==3 and path[0]=='integration' and path[2]=='relationships': return self.reply(200,integration.remap_relationships(self.store,path[1],self.body()))
            if method=='POST' and len(path)==3 and path[0]=='integration' and path[2]=='relationship-suggestions':
                import relationship_equivalence
                return self.reply(200,relationship_equivalence.review(self.store,path[1],self.body(required=False)))
            if method=='GET' and len(path)==3 and path[0]=='integration' and path[2]=='relationship-suggestions':
                import relationship_equivalence
                return self.reply(200,relationship_equivalence.saved(self.store,path[1]))
            if method=='POST' and len(path)==3 and path[0]=='integration' and path[2]=='remove': return self.reply(200,integration.remove_run(self.store,path[1]))
            if method=='POST' and len(path)==3 and path[0]=='integration' and path[2]=='materialize':
                b = self.body(required=False) or {}
                policy = b.get('policy', 'matched-only')
                scope_id = b.get('scope_id')
                aug_id = b.get('augmentation_run_id')
                return self.reply(200, integration.materialize(self.store, path[1], policy=policy, scope_id=scope_id, augmentation_run_id=aug_id))
            if method=='GET' and len(path)==3 and path[0]=='integration' and path[2]=='outer-scopes':
                import outer_join
                return self.reply(200, outer_join.discover_scopes(self.store, path[1]))
            if method=='GET' and len(path)==3 and path[0]=='integration' and path[2]=='outer-view':
                import outer_join
                policy = q.get('policy', ['matched-only'])[0]
                scope_id = q.get('scope_id', [None])[0]
                relation = q.get('relation', [None])[0]
                left_table = q.get('left_table', [None])[0]
                right_table = q.get('right_table', [None])[0]
                aug_id = q.get('augmentation_run_id', [None])[0]
                return self.reply(200, outer_join.materialize_outer_view(
                    self.store, path[1], policy=policy, scope_id=scope_id, relation=relation,
                    left_table=left_table, right_table=right_table, augmentation_run_id=aug_id
                ))
            if method=='GET' and len(path)==3 and path[0]=='integration' and path[2]=='diff': return self.reply(200,integration.diff(self.store,path[1],q.get('previous',[None])[0]))
            if method=='GET' and len(path)==3 and path[0]=='integration' and path[2]=='csv':
                relation = q.get("relation", [None])[0]
                policy = q.get("policy", ["matched-only"])[0]
                scope_id = q.get("scope_id", [None])[0]
                aug_id = q.get("augmentation_run_id", [None])[0]
                payload = integration.export_csv(self.store, path[1], relation=relation, policy=policy, scope_id=scope_id, augmentation_run_id=aug_id)
                self.send_response(200)
                self.send_header('Content-Type', 'text/csv; charset=utf-8')
                self.send_header('Content-Disposition', f'attachment; filename="idun-{policy}-{relation.lower() if relation else "integrated"}.csv"')
                self.send_header('Content-Length', str(len(payload)))
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(payload)
                return
            if method=='GET' and path==['settings','catalogs']:
                import lake_config
                return self.reply(200,lake_config.catalogs())
            if method=='GET' and path==['config']:
                import lake_config
                return self.reply(200,{'config':lake_config.read_lake_config(self.store),'catalogs':lake_config.catalogs()})
            if method=='POST' and path==['config']:
                import lake_config
                body=self.body()
                expected=body.get('expected_revision')
                return self.reply(200,lake_config.save_lake_config(self.store,body,expected_revision=expected))
            if method=='POST' and path==['config','preview']:
                import lake_config
                return self.reply(200,lake_config.config_impact_preview(self.store,self.body()))
            if method=='GET' and path==['settings','prompts']:
                import prompt_service
                return self.reply(200, prompt_service.DEFAULT_PROMPTS)
            if method=='GET' and len(path)==3 and path[0]=='settings' and path[1]=='prompts':
                import prompt_service
                p = prompt_service.DEFAULT_PROMPTS.get(path[2])
                if not p:
                    return self.reply(404, {'error': 'Prompt preset not found'})
                return self.reply(200, p)
            if method=='POST' and path==['settings','prompts','preview']:
                import prompt_service
                body = self.body()
                prompt_id = body.get('prompt_id', 'generic-evidence-v1')
                schema_cfg = body.get('schema_config')
                ctx_cfg = body.get('context_config')
                sample = body.get('sample_case')
                return self.reply(200, prompt_service.preview_prompt(prompt_id, schema_config=schema_cfg, sample_case=sample, context_config=ctx_cfg))
            if method=='POST' and path==['settings','prompts','validate']:
                import prompt_service
                body = self.body()
                template = body.get('template', '')
                try:
                    prompt_service.validate_template(template)
                    return self.reply(200, {'valid': True})
                except Exception as e:
                    return self.reply(400, {'valid': False, 'error': str(e)})
            if method=='GET' and path==['context']:
                import context_service, lake_config
                cfg = lake_config.read_lake_config(self.store)
                ctx_cfg = cfg.get("context_config", lake_config.DEFAULT_CONTEXT_CONFIG)
                staleness = context_service.check_context_staleness(self.store, ctx_cfg)
                return self.reply(200, {'context_config': ctx_cfg, 'staleness': staleness})
            if method=='POST' and path==['context', 'sample']:
                import context_service
                body = self.body(required=False) or {}
                sampled = context_service.sample_projected_content(
                    self.store,
                    max_tables=body.get('max_tables', 5),
                    rows_per_table=body.get('rows_per_table', 3),
                    text_units=body.get('text_units', 3),
                    budget_chars=body.get('budget_chars', 3000),
                )
                return self.reply(200, sampled)
            if method=='POST' and path==['context', 'summarize']:
                import context_service
                body = self.body(required=False) or {}
                summary = context_service.summarize_lake_context(
                    self.store,
                    config=body.get('config'),
                    timeout=body.get('timeout', 30),
                )
                return self.reply(200, summary)
            if method=='POST' and path==['context', 'examples', 'validate']:
                import context_service, lake_config
                cfg = lake_config.read_lake_config(self.store)
                body = self.body()
                try:
                    val = context_service.validate_example(body, store=self.store, projection_policy=cfg.get('projection_policy'))
                    return self.reply(200, {'valid': True, 'example': val})
                except Exception as e:
                    return self.reply(400, {'valid': False, 'error': str(e)})
            if method=='POST' and path==['context']:
                import lake_config
                body = self.body()
                saved = lake_config.save_lake_config(self.store, {'context_config': body}, expected_revision=body.get('expected_revision'))
                return self.reply(200, saved.get('context_config'))
            if method=='POST' and path==['context', 'preview']:
                import prompt_service, lake_config
                body = self.body(required=False) or {}
                cfg = lake_config.read_lake_config(self.store)
                prompt_id = body.get('prompt_id', cfg.get('prompt_id', 'generic-evidence-v1'))
                schema_cfg = body.get('schema_config', cfg.get('schema_config'))
                ctx_cfg = body.get('context_config', cfg.get('context_config'))
                sample = body.get('sample_case')
                return self.reply(200, prompt_service.preview_prompt(prompt_id, schema_config=schema_cfg, sample_case=sample, context_config=ctx_cfg))
            if method=='GET' and path==['settings']: return self.reply(200,settings.public(self.store))
            if method=='POST' and path==['settings']: return self.reply(200,settings.save(self.store,self.body()))
            if method=='POST' and path==['settings','runtime-probe']: return self.reply(200,settings.probe(self.body()))
            if method=='POST' and path==['settings','llm-test']: return self.reply(200,settings.test_llm(self.body()))
            if method=='GET' and path==['settings','models','bundles']:
                import model_registry
                bundles = model_registry.list_bundles()
                for b in bundles:
                    b['validation'] = model_registry.validate_bundle(b['bundle_id'])
                return self.reply(200, {'bundles': bundles})
            if method=='POST' and path==['settings','models','prepare-encoder']:
                import custom_encoder
                return self.reply(200, custom_encoder.prepare(self.store, self.body()))
            if method=='POST' and path==['settings','models','validate']:
                import model_registry
                body = self.body()
                bundle_id = body.get('bundle_id', 'generic-adapter-v1')
                version = body.get('version')
                return self.reply(200, model_registry.validate_bundle(bundle_id, version=version))
            if method=='POST' and path==['settings','models','probe']:
                import model_registry
                body = self.body(required=False) or {}
                bundle_id = body.get('bundle_id', 'generic-adapter-v1')
                device = body.get('device')
                version = body.get('version')
                return self.reply(200, model_registry.probe_bundle(bundle_id, device=device, version=version, generic_encoder=body.get('generic_encoder'), generic_dimensions=body.get('generic_dimensions')))
            if method=='POST' and path==['settings','models','download']:
                import model_registry
                body = self.body(required=False) or {}
                bundle_id = body.get('bundle_id', 'legacy-loki-clinical')
                version = body.get('version')
                return self.reply(202, model_registry.start_bundle_download(bundle_id, version=version))
            if method=='GET' and path==['settings','models','download','status']:
                import model_registry
                return self.reply(200, model_registry.bundle_download_status())
            if method=='POST' and path==['settings','models','download','cancel']:
                import model_registry
                return self.reply(200, model_registry.cancel_bundle_download())
            if method=='POST' and path==['settings','models','delete']:
                import model_registry
                body = self.body(required=False) or {}
                bundle_id = body.get('bundle_id', '')
                version = body.get('version')
                return self.reply(200, model_registry.delete_bundle_checkpoint(bundle_id, version=version))
            if method=='GET' and path==['settings','models','hub']:
                import model_hub
                return self.reply(200, model_hub.get_models_hub_status(self.store))
            if method=='POST' and path==['settings','models','hub','download']:
                import model_hub
                body = self.body(required=False) or {}
                return self.reply(202, model_hub.start_hub_download(body.get('step', ''), body.get('model_id', ''), version=body.get('version'), store=self.store))
            if method=='GET' and path==['settings','models','hub','status']:
                import model_hub
                return self.reply(200, model_hub.get_hub_download_status())
            if method=='POST' and path==['settings','models','hub','cancel']:
                import model_hub
                return self.reply(200, model_hub.cancel_hub_download())
            if method=='POST' and path==['settings','models','hub','delete']:
                import model_hub
                body = self.body(required=False) or {}
                return self.reply(200, model_hub.delete_hub_model(body.get('step', ''), body.get('model_id', ''), version=body.get('version')))
            if method=='GET' and path==['settings','hf','models']:
                import hf_model_manager
                return self.reply(200,{'models':hf_model_manager.list_models(),'loaded':hf_model_manager.get_loaded_model()})
            if method=='POST' and path==['settings','hf','unload']:
                import hf_model_manager
                return self.reply(200,hf_model_manager.unload_model())
            if method=='GET' and path==['settings','hf','loaded']:
                import hf_model_manager
                return self.reply(200,hf_model_manager.get_loaded_model())
            if method=='POST' and path==['settings','hf','download']:
                import hf_model_manager
                data=self.body()
                return self.reply(202,hf_model_manager.start_download(data.get('repo_id',''),data.get('key_env','')))
            if method=='GET' and path==['settings','hf','download','status']:
                import hf_model_manager
                return self.reply(200,hf_model_manager.download_status())
            if method=='POST' and path==['settings','hf','download','cancel']:
                import hf_model_manager
                return self.reply(200,hf_model_manager.cancel_download())
            if method=='POST' and path==['settings','hf','delete']:
                import hf_model_manager
                data=self.body()
                return self.reply(200,hf_model_manager.delete_model(data.get('repo_id','')))
            if method=='GET' and path==['inference','readiness']: return self.reply(200,readiness(self.store))
            if method=='GET' and len(path)==3 and path[:2]==['inference','inputs']: return self.reply(200,prepare(self.store,str(uuid.UUID(path[2])),offset))
            if path[:2]==['profile','graph']:
                import profile_graph
                if method=='GET' and len(path)==2: return self.reply(200,profile_graph.overview(self.store))
                if method=='GET' and path==['profile','graph','nodes']: return self.reply(200,profile_graph.nodes(self.store,q.get('generation',[''])[0],q.get('after',[''])[0],int(q.get('limit',['100'])[0])))
                if method=='POST' and path==['profile','graph','query']: return self.reply(200,profile_graph.query(self.store,self.body()))
                if method=='GET' and len(path)==4 and path[2] in ('nodes','edges'): return self.reply(200,profile_graph.inspect(self.store,path[2],path[3],q.get('generation',[''])[0]))
            if method=='GET' and path==['profile','status']: return self.reply(200,profiling.status(self.store))
            if method=='GET' and path==['profile']: return self.reply(200,profiling.read(self.store))
            if method=='POST' and path==['profile','cancel']: return self.reply(200,profiling.cancel(self.store))
            if method=='POST' and path==['profile']: return self.reply(200,profiling.start(self.store))
            if method=='POST' and path==['discovery','scope','describe']:
                import discovery_scope
                return self.reply(200,discovery_scope.read(self.store,self.body().get('id')))
            if method=='POST' and path==['discovery','scope','inspect']:
                import discovery_scope
                return self.reply(200,discovery_scope.inspect_handoff(self.store,self.body()))
            if method=='POST' and path in (['discovery','scope','preview'],['discovery','scope','commit']):
                import discovery_scope
                return self.reply(200,(discovery_scope.preview if path[-1]=='preview' else discovery_scope.commit)(self.store,self.body()))
            if method=='POST' and path==['discovery','scores','query']:
                import discovery_scores
                return self.reply(200,discovery_scores.query(self.store,self.body()))
            if method=='GET' and path==['discovery','handoff']:
                import discovery_handoff
                return self.reply(200,discovery_handoff.summary(self.store))
            if method=='POST' and path==['discovery','handoff','inspect']:
                import discovery_handoff
                return self.reply(200,discovery_handoff.inspect(self.store,self.body()))
            if method=='POST' and path==['discovery','filter']:
                return self.reply(202,discovery.start(self.store,{**self.body(),'operation':'filter'}))
            if path and path[0]=='knowledge':
                import knowledge
                return self.reply(200,knowledge.route(self.store,method,path[1:],self.body,q))
            if method=='GET' and path==['discovery']: return self.reply(200,discovery.status(self.store))
            if method=='POST' and path==['discovery']: return self.reply(202,discovery.start(self.store,self.body()))
            if method=='POST' and path==['discovery','cancel']: return self.reply(200,discovery.cancel(self.store))
            if method=='GET' and path==['discovery','workbench']: return self.reply(200,discovery.workbench(self.store,q.get('source',[''])[0],int(q.get('k',['5'])[0])))
            if method=='GET' and path==['discovery','workbench-links']: return self.reply(200,discovery.workbench_links(self.store,q.get('source',[''])[0],q.get('candidate',[''])[0],offset))
            if method=='GET' and len(path)==3 and path[:2]==['discovery','evidence']: return self.reply(200,discovery.evidence_context(self.store,path[2],q.get('companion',[None])[0]))
            if method=='GET' and path==['discovery','landscape']: return self.reply(200,discovery.landscape(self.store))
            if method=='GET' and path in (['discovery','links'],['discovery','bridges']): return self.reply(200,discovery.listing(self.store,path[1],offset,q.get('source',[''])[0]))
            if method=='GET' and len(path)==3 and path[:2]==['discovery','links']: return self.reply(200,discovery.link(self.store,path[2]))
            if method=='GET' and path==['health']: return self.reply(200,{'status':'ok','api':'v1','parser':PARSER,'process_id':os.getpid()})
            if method=='POST' and path==['jobs']: return self.reply(201,self.store.create(self.body()))
            if method=='GET' and path==['datasets']: return self.reply(200,self.store.datasets())
            if method=='POST' and path==['removals','preview']: return self.reply(200,self.store.removal_preview(self.body()))
            if method=='POST' and path==['removals','apply']: return self.reply(200,self.store.remove(self.body()))
            if method=='GET' and path==['jobs']:
                with self.store.db() as db: rows=db.execute('SELECT j.*,a.name,a.path,a.dataset_id FROM jobs j JOIN assets a ON a.id=j.asset_id ORDER BY j.updated DESC LIMIT 100').fetchall()
                return self.reply(200,{'jobs':[dict(r) for r in rows]})
            if len(path)>=2 and path[0]=='jobs':
                jid=str(uuid.UUID(path[1]))
                if method=='GET' and len(path)==2: return self.reply(200,self.store.job(jid))
                if method=='GET' and path[2:]==['events']:
                    self.store.job(jid)
                    with self.store.db() as db: events=db.execute('SELECT id,status,message,created FROM events WHERE job_id=? ORDER BY id DESC LIMIT 100',(jid,)).fetchall()
                    return self.reply(200,{'events':[dict(e) for e in events]})
                if method=='PUT' and path[2:]==['raw']:
                    if self.headers.get('Transfer-Encoding'): raise ValueError('Use Content-Length, not chunked transfer')
                    self.connection.settimeout(30)
                    return self.reply(200,self.store.upload(jid,self.rfile,int(self.headers.get('Content-Length','0'))))
                if method=='POST' and path[2:]==['cancel']: return self.reply(200,self.store.cancel(jid))
                if method=='POST' and path[2:]==['retry']: return self.reply(200,self.store.retry(jid,self.body().get('encoding')))
            if method=='GET' and path==['assets']: return self.reply(200,self.store.catalog(q.get('q',[''])[0],offset,q.get('dataset',[''])[0]))
            if method=='GET' and len(path)==3 and path[0]=='assets':
                aid=str(uuid.UUID(path[1]))
                if path[2]=='journey':
                    import journey_sources
                    return self.reply(200,journey_sources.read(self.store,aid,q.get('version',[''])[0],offset))
                if path[2]=='preview': return self.reply(200,self.store.preview(aid,offset))
                if path[2]=='raw':
                    with self.store.db() as db: j=db.execute('SELECT digest FROM jobs WHERE asset_id=?',(aid,)).fetchone()
                    if not j or not j['digest']: raise KeyError('Raw bytes unavailable')
                    f=self.store.root/'blobs'/j['digest']; self.send_response(200); self.send_header('Content-Type','application/octet-stream'); self.send_header('Content-Disposition','attachment; filename="source.bin"'); self.send_header('Content-Length',str(f.stat().st_size)); self.end_headers()
                    with f.open('rb') as src:
                        while chunk:=src.read(65536): self.wfile.write(chunk)
                    return
            return self.reply(404,{'error':'Not found'})
        except KeyError as e: self.reply(404,{'error':str(e)})
        except (ValueError,TypeError,json.JSONDecodeError) as e: self.reply(400,{'error':str(e)})
        except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError): pass
        except Exception as e: self.reply(500,{'error':f'{type(e).__name__}: {e}'})

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--storage',default=str(Path(__file__).resolve().parents[1]/'.idun')); parser.add_argument('--port',type=int,default=8787); args=parser.parse_args()
    from lakes import Lakes
    registry=Lakes(args.storage,Store); store=registry.default
    ThreadingHTTPServer.allow_reuse_address = True
    server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler); server.store=store; server.lakes=registry
    print(f'IDUN API http://127.0.0.1:{args.port} (local storage ready)',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        if getattr(store,'profile_active',False): store.profile_cancel.set()
        if getattr(store,'discovery_active',False): store.discovery_cancel.set()
        if getattr(store,'integration_active',False): store.integration_cancel.set()
        try:
            import hf_model_manager
            hf_model_manager.stop_download()
            hf_model_manager.unload_model()
        except Exception: pass
        server.server_close(); registry.close()
    if getattr(server,'restart_requested',False): sys.exit(75)
    sys.exit(0)
if __name__=='__main__': main()
