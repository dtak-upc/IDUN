"""Comprehensive Data Lake Reset and Storage Reclamation for IDUN.

Purges all derived indexes, vector caches, discovery links, and integration runs
while strictly preserving all original datasets, uploaded source files, parsed records,
and lake configurations.

Executes physical SQLite VACUUM and LanceDB directory removal to reclaim 100% of
freed disk and memory space.
"""

import json
import logging
import os
import shutil
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("idun.lake_reset")

DERIVED_TABLES = [
    "kg_assertions",
    "kg_snapshots",
    "kg_workspace",
    "kg_ontology",
    "kg_contributions",
    "kg_reviews",
    "kg_schema_drafts",
    # Profiling tables
    "lake_profile",
    "profile_cache",
    "profile_revision",
    "profile_job",
    # Retrieval & Vector metadata tables
    "retrieval_units",
    "retrieval_generations",
    "retrieval_buckets",
    # Discovery tables
    "discovery_links",
    "discovery_bridges",
    "discovery_cache",
    "discovery_report",
    "discovery_score_blocks",
    "discovery_job",
    # Integration & Semantic tables
    "integration_plans",
    "integration_rows",
    "integration_materialization_receipts",
    "integration_evidence",
    "integration_evidence_refs",
    "integration_job",
    "integration_schema",
    "semantic_labels",
    "semantic_rank_cache",
    "semantic_checkpoint",
    "relationship_probe_job",
    "relationship_suggestions",
    "augmentation_runs",
    "augmentation_proposals",
    "augmentation_views",
    "thor_preparations",
    "augmentation_workspaces",
]


def reset_lake(store: Any, keep_sources: bool = True) -> Dict[str, Any]:
    """Completely resets derived indexes, vector caches, and join-path candidates for a data lake.

    Preserves original uploaded files in blobs/, dataset and asset metadata, ingestion jobs,
    and parsed raw records.
    Reclaims disk space via PRAGMA wal_checkpoint(TRUNCATE) and VACUUM.
    """
    if not keep_sources:
        raise ValueError("reset_lake requires keep_sources=True to prevent accidental data loss")

    with store.lock:
        # 1. Cancel or verify active mutating jobs
        for flag, cancel_attr in [
            ("profile_active", "profile_cancel"),
            ("discovery_active", "discovery_cancel"),
            ("integration_active", "integration_cancel"),
            ("knowledge_active", "knowledge_cancel"),
            ("storage_active", None),
        ]:
            if getattr(store, flag, False):
                cancel_event = getattr(store, cancel_attr, None) if cancel_attr else None
                if cancel_event:
                    cancel_event.set()
                setattr(store, flag, False)

        db_path = getattr(store, "dbpath", store.root / "catalog.sqlite3")
        bytes_before = db_path.stat().st_size if db_path.exists() else 0
        vectors_dir = store.root / "vectors.lance"
        vectors_bytes_before = (
            sum(f.stat().st_size for f in vectors_dir.rglob("*") if f.is_file())
            if vectors_dir.exists()
            else 0
        )

        cleared_tables = {}

        # 2. Clear derived tables in SQLite
        with store.db() as db:
            existing = {
                r[0]
                for r in db.execute(
                    "SELECT name FROM sqlite_master WHERE type IN ('table', 'view')"
                ).fetchall()
            }

            for t in DERIVED_TABLES:
                if t in existing:
                    try:
                        count = db.execute(f'SELECT count(*) FROM "{t}"').fetchone()[0]
                        db.execute(f'DELETE FROM "{t}"')
                        cleared_tables[t] = count
                    except Exception as e:
                        logger.warning("Error clearing table %s: %s", t, e)

            # Drop FTS virtual table if present so shadow tables are cleanly removed
            if "retrieval_fts" in existing:
                try:
                    db.execute("DROP TABLE IF EXISTS retrieval_fts")
                    cleared_tables["retrieval_fts"] = "dropped"
                except Exception as e:
                    logger.warning("Error dropping retrieval_fts: %s", e)

        # 3. Purge LanceDB vector store on disk
        if hasattr(store, "_vectors_by_rep"):
            store._vectors_by_rep.clear()
        if hasattr(store, "_vectors"):
            del store._vectors

        if vectors_dir.exists():
            try:
                shutil.rmtree(vectors_dir, ignore_errors=True)
            except Exception as e:
                logger.warning("Error removing vectors.lance directory: %s", e)

        # 4. Remove scratch artifact files
        files_removed = []
        for scratch in ["idun.db", "backups"]:
            target = store.root / scratch
            if target.is_dir():
                shutil.rmtree(target, ignore_errors=True)
                files_removed.append(scratch)
            elif target.is_file():
                target.unlink(missing_ok=True)
                files_removed.append(scratch)

        # Clean pending temporary worker files
        pending_dir = store.root / "pending"
        if pending_dir.exists():
            for p in pending_dir.glob("*"):
                if not p.name.endswith(".part"):  # leave active chunk uploads alone
                    try:
                        p.unlink(missing_ok=True)
                        files_removed.append(f"pending/{p.name}")
                    except Exception:
                        pass

        # 5. Physical SQLite VACUUM and WAL Checkpoint to reclaim disk space
        if db_path.exists():
            try:
                conn = sqlite3.connect(db_path, timeout=60)
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                conn.execute("VACUUM")
                conn.close()
            except Exception as e:
                logger.warning("VACUUM warning: %s", e)

        bytes_after = db_path.stat().st_size if db_path.exists() else 0
        total_reclaimed = max(0, (bytes_before + vectors_bytes_before) - bytes_after)

        result = {
            "status": "ok",
            "lake_id": getattr(store, "lake_id", store.root.name),
            "reclaimed_bytes": total_reclaimed,
            "reclaimed_mb": round(total_reclaimed / (1024 * 1024), 2),
            "sqlite_bytes_before": bytes_before,
            "db_size_before_mb": round(bytes_before / (1024 * 1024), 2),
            "sqlite_bytes_after": bytes_after,
            "db_size_after_mb": round(bytes_after / (1024 * 1024), 2),
            "vectors_bytes_reclaimed": vectors_bytes_before,
            "vectors_mb_reclaimed": round(vectors_bytes_before / (1024 * 1024), 2),
            "cleared_tables": cleared_tables,
            "files_removed": files_removed,
            "keep_sources": keep_sources,
            "timestamp": time.time(),
        }
        return result


def selective_stage_invalidation(store: Any, invalidated_stages: List[str]) -> Dict[str, Any]:
    """Selectively purges only downstream stages when earlier stages remain valid."""
    stages = set(invalidated_stages)
    cleared = []

    with store.lock:
        if "indexing" in stages:
            return reset_lake(store, keep_sources=True)

        with store.db() as db:
            existing = {
                r[0]
                for r in db.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()
            }

            if "discovery" in stages:
                disc_tables = [
                    "discovery_links",
                    "discovery_bridges",
                    "discovery_cache",
                    "discovery_report",
    "discovery_score_blocks",
                    "discovery_job",
                ]
                for t in disc_tables:
                    if t in existing:
                        db.execute(f'DELETE FROM "{t}"')
                        cleared.append(t)
                stages.add("integration")

            if "integration" in stages:
                int_tables = [
                    "integration_plans",
                    "integration_rows",
                    "integration_evidence",
                    "integration_evidence_refs",
                    "integration_job",
                    "semantic_labels",
                    "semantic_rank_cache",
                    "semantic_checkpoint",
                    "relationship_probe_job",
                ]
                for t in int_tables:
                    if t in existing:
                        db.execute(f'DELETE FROM "{t}"')
                        cleared.append(t)

            try:
                db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            except Exception:
                pass

        return {
            "status": "ok",
            "invalidated_stages": list(stages),
            "cleared_tables": cleared,
            "timestamp": time.time(),
        }


def reset_preview(store: Any) -> Dict[str, Any]:
    """Provides a preview of data that will be cleared and storage that will be reclaimed."""
    with store.lock:
        db_path = getattr(store, "dbpath", store.root / "catalog.sqlite3")
        sqlite_bytes = db_path.stat().st_size if db_path.exists() else 0
        vectors_dir = store.root / "vectors.lance"
        vectors_bytes = (
            sum(f.stat().st_size for f in vectors_dir.rglob("*") if f.is_file())
            if vectors_dir.exists()
            else 0
        )

        counts = {}
        sources_count = 0
        records_count = 0

        with store.db() as db:
            existing = {
                r[0]
                for r in db.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()
            }
            if "assets" in existing:
                sources_count = db.execute("SELECT count(*) FROM assets").fetchone()[0]
            if "records" in existing:
                records_count = db.execute("SELECT count(*) FROM records").fetchone()[0]

            for t in ["lake_profile", "retrieval_units", "discovery_links", "discovery_bridges", "integration_plans"]:
                if t in existing:
                    counts[t] = db.execute(f'SELECT count(*) FROM "{t}"').fetchone()[0]
                else:
                    counts[t] = 0

        total_derived_rows = sum(counts.values())
        return {
            "lake_id": getattr(store, "lake_id", store.root.name),
            "sqlite_bytes": sqlite_bytes,
            "vectors_bytes": vectors_bytes,
            "total_bytes": sqlite_bytes + vectors_bytes,
            "db_bytes": sqlite_bytes,
            "db_size_mb": round(sqlite_bytes / (1024 * 1024), 2),
            "vector_bytes": vectors_bytes,
            "vector_size_mb": round(vectors_bytes / (1024 * 1024), 2),
            "total_derived_size_mb": round((sqlite_bytes + vectors_bytes) / (1024 * 1024), 2),
            "sources_count": sources_count,
            "records_count": records_count,
            "derived_counts": counts,
            "total_derived_rows": total_derived_rows,
        }
