"""Verified, reversible compaction of the current lake's discovery artifacts."""
import gzip
import hashlib
import json
import os
import re
import sqlite3
import threading
import uuid
from contextlib import closing
from pathlib import Path
from evidence_storage import encode, decode, retain, source_roles, POLICY


def reclaim_published(store, policy=None):
    """Reclaim superseded storage only after publication, under the lake lock.

    Saved integration runs own pinned evidence; these tables are never cleared.
    No automatic backup is created: reruns must not accumulate full lake copies.
    """
    from datetime import timedelta
    from vector_store import vectors
    with store.lock:
        if policy is not None:
            active = vectors(store, policy['policy_key'], policy['dimensions'])
            with store.db() as db:
                db.execute('DELETE FROM retrieval_generations WHERE policy_key IS NULL OR policy_key<>?', (policy['policy_key'],))
            active.cleanup()
            active.table.optimize(cleanup_older_than=timedelta(0))
            # Only retrieval vector tables are retired, never raw files or run evidence.
            for name in active.connection.table_names():
                if (name == 'units' or name.startswith('units_')) and name != active.table_name:
                    active.connection.drop_table(name)
            store._vectors_by_rep = {(active.representation_key, active.dimension): active}
            store._vectors = active
        with closing(sqlite3.connect(store.dbpath)) as db:
            db.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchall()
            db.execute('VACUUM')


def reclaim_after_publication(store, policy=None):
    # Publication is already committed. Maintenance failure must not disguise a
    # successful run as failed; log it for troubleshooting and retry on the next run.
    try:
        reclaim_published(store, policy)
        store.storage_cleanup_warning = None
    except Exception as error:
        import logging
        store.storage_cleanup_warning = str(error)
        logging.getLogger(__name__).warning('Published results retained; storage cleanup failed: %s', error)


def compact(store, progress=lambda **kw: None):
    with store.lock:
        target = store.root / 'catalog.compacting.sqlite3'
        original_bytes = store.dbpath.stat().st_size
        with store.db() as db:
            if db.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()[0]:
                raise ValueError('Database has active readers; retry compaction')
        with closing(sqlite3.connect(store.dbpath)) as source, closing(sqlite3.connect(target)) as dest:
            source.row_factory = sqlite3.Row
            progress(phase='Preparing isolated database copy')
            source.backup(dest)
            protected = set()
            def references(value):
                if isinstance(value, dict):
                    for v in value.values(): references(v)
                elif isinstance(value, list):
                    for v in value: references(v)
                elif isinstance(value, str) and re.fullmatch('[a-f0-9]{64}', value): protected.add(value)
            plans = source.execute('SELECT id,data FROM integration_plans').fetchall() if source.execute("SELECT 1 FROM sqlite_master WHERE name='integration_plans'").fetchone() else []
            for plan in plans: references(json.loads(plan['data']))
            for bridge in source.execute('SELECT data FROM discovery_bridges'):
                b = decode(bridge['data']); protected.update((b['left'], b['right']))
            # Published evidence is a processing boundary, not expendable cache.
            # Reapplying retention here can silently change the next Integration
            # candidate pool and invalidate the saved handoff counts.
            existing_protected = {r[0] for r in source.execute('SELECT id FROM discovery_links')}
            protected.update(existing_protected)
            profile = source.execute('SELECT data FROM lake_profile WHERE id=1').fetchone()
            if not profile: raise ValueError('No indexed lake to compact')
            roles = source_roles(json.loads(profile[0]))
            before_links = source.execute('SELECT count(*) FROM discovery_links').fetchone()[0]
            dest.execute('PRAGMA journal_mode=OFF')  # Only the disposable copy.
            dest.execute('DELETE FROM discovery_links')
            retained = 0; scored = 0; orphan = 0; missing_rows = 0
            total = source.execute('SELECT count(*) FROM discovery_cache').fetchone()[0]
            for i, row in enumerate(source.execute('SELECT key,data FROM discovery_cache')):
                context = retain(decode(row['data']), roles, protected)
                dest.execute('UPDATE discovery_cache SET data=? WHERE key=?',(encode(context),row['key']))
                for link in context['links']:
                    # Only republish evidence that belongs to the current result.
                    if source.execute('SELECT 1 FROM discovery_links WHERE id=?',(link['id'],)).fetchone():
                        dest.execute('INSERT OR IGNORE INTO discovery_links VALUES(?,?,?,?,?)',(link['id'],link['table'],link['text'],link['score'],encode(link)))
                        retained += 1; orphan += bool(link.get('one_sided'))
                scored += context.get('retention',{}).get('scored_links',len(context['links']))
                missing_rows += context['rows'] - len({l['record_id'] for l in context['links']})
                if i % 10 == 0:
                    dest.commit();progress(phase='Retaining join candidates',completed=i+1,total=total)
            # Existing plan/bridge references remain usable even if their cache was retired.
            for lid in existing_protected:
                row=source.execute('SELECT * FROM discovery_links WHERE id=?',(lid,)).fetchone()
                dest.execute('INSERT OR IGNORE INTO discovery_links VALUES(?,?,?,?,?)',(row['id'],row['table_id'],row['text_id'],row['score'],encode(decode(row['data']))))
            kept = dest.execute('SELECT count(*) FROM discovery_links').fetchone()[0]
            report_row = source.execute('SELECT data FROM discovery_report WHERE id=1').fetchone()
            if report_row:
                report=json.loads(report_row[0]);report['retention_policy']=POLICY
                report['storage']={'policy':POLICY,'scored_links':max(scored,before_links),'retained_links':kept,'pruned_links':before_links-kept}
                report['summary'].update(links=kept,one_sided=orphan,rows_without_links=missing_rows)
                dest.execute('UPDATE discovery_report SET data=? WHERE id=1',(json.dumps(report),))
            dest.commit()
            for plan in plans:
                if dest.execute('SELECT data FROM integration_plans WHERE id=?',(plan['id'],)).fetchone()[0] != plan['data']:
                    raise ValueError('Integration plan changed during compaction')
            for lid in existing_protected:
                if not dest.execute('SELECT 1 FROM discovery_links WHERE id=?',(lid,)).fetchone():
                    raise ValueError('Required evidence missing from compacted database')
            progress(phase='Reclaiming unused database pages')
            dest.execute('VACUUM')
            if dest.execute('PRAGMA integrity_check').fetchone()[0] != 'ok': raise ValueError('Compacted database integrity check failed')
            dest.execute('PRAGMA journal_mode=DELETE').fetchall()
        backup = store.root / 'backups/before-evidence-compaction.sqlite3.gz'
        backup.parent.mkdir(exist_ok=True)
        if backup.exists():
            backup = backup.with_name('before-evidence-compaction-' + uuid.uuid4().hex + '.sqlite3.gz')
        if not backup.exists():
            progress(phase='Saving compressed recovery backup')
            temporary=backup.with_suffix('.tmp'); original_hash=hashlib.sha256()
            with store.dbpath.open('rb') as src, gzip.open(temporary,'wb',compresslevel=1) as dst:
                while chunk:=src.read(1024*1024): original_hash.update(chunk);dst.write(chunk)
            digest=hashlib.sha256()
            with gzip.open(temporary,'rb') as src:
                while chunk:=src.read(1024*1024): digest.update(chunk)
            if digest.digest()!=original_hash.digest(): raise ValueError('Recovery backup verification failed')
            temporary.replace(backup)
        # All Store DB access is serialized by store.lock; readers cannot hold old WALs.
        for suffix in ('-wal','-shm'):
            Path(str(store.dbpath)+suffix).unlink(missing_ok=True)
        os.replace(target,store.dbpath)
        with closing(sqlite3.connect(store.dbpath)) as ready:
            ready.execute('PRAGMA journal_mode=WAL').fetchall()
        return {'before_bytes':original_bytes,'after_bytes':store.dbpath.stat().st_size,'backup_bytes':backup.stat().st_size,'backup_path':str(backup),'links_before':before_links,'links_after':kept,'protected_links':len(existing_protected)}


def start(store):
    with store.lock:
        if any(getattr(store,k,False) for k in ('profile_active','discovery_active','integration_active','storage_active')):
            raise ValueError('Wait for active lake jobs to finish')
        with store.db() as db:
            if db.execute("SELECT 1 FROM jobs WHERE status NOT IN ('ready','failed','cancelled','interrupted')").fetchone():raise ValueError('Finish file ingestion first')
        store.storage_active=True
        store.storage_status={'status':'running','phase':'Preparing compaction'}
    def update(**kw): store.storage_status.update(kw)
    def work():
        try: update(status='complete',phase='Compaction complete',**compact(store,update))
        except Exception as error: update(status='failed',phase=str(error))
        finally: store.storage_active=False
    store.storage_thread=threading.Thread(target=work,daemon=True,name='lake-compaction')
    store.storage_thread.start()
    return store.storage_status
