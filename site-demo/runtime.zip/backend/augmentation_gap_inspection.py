"""Inspect assessed missing cells without extraction or enrichment."""
import json
import augmentation
import augmentation_workspace
import inference


def inspect(store, query):
    scope,run=query.get('scope','source'),query.get('run','')
    offset=int(query.get('offset',0))
    if offset<0: raise ValueError('Use a nonnegative row offset')
    with store.lock:
        config={}
        assessment_run=query.get('assessment_run','')
        if assessment_run:
            with store.db() as db:
                saved=db.execute('SELECT scope,base_run_id,config FROM augmentation_runs WHERE id=?',(assessment_run,)).fetchone()
            if not saved:raise KeyError('Augmentation run is unavailable')
            if saved['scope']!=scope or (saved['base_run_id'] or '')!=run:raise ValueError('Assessment run does not match this scope')
            config=json.loads(saved['config'])
        report=config.get('journey_assessment') or augmentation_workspace.read(store,scope,run,include_manifest=False)['assessment']
        if not report or report['revision']!=query.get('revision'):
            raise ValueError('Assessment changed or is stale. Assess again before inspecting gaps.')
        table=next((t for t in report['tables'] if t['id']==query.get('table') and t['version']==query.get('version')),None)
        if not table: raise KeyError('Table is not part of this assessment')
        columns=table['columns']
        column=query.get('column','')
        focused=int(column) if column!='' else None
        if focused is not None and not any(c['index']==focused for c in columns):raise ValueError('Column is not part of this assessment')
        if query.get('missing_only','true') not in ('true','false'):raise ValueError('Choose missing rows or all assessed rows')
        missing_only=query.get('missing_only','true')=='true'
        expected_total=(next(c['missing'] for c in columns if c['index']==focused) if focused is not None else table.get('rows_with_gaps')) if missing_only else table['rows']
        tokens=config.get('journey_null_tokens',augmentation.policy(store).get('null_tokens',inference.DEFAULT_NULL_TOKENS))
        def missing(value):
            return value is None or (value=='' if scope=='integration' else inference.resolve_cell_value(value,tokens)[1])
        def row(index,cells):
            gaps=[c['index'] for c in columns if missing(cells[c['index']])]
            return {'index':index,'cells':[cells[c['index']] for c in columns],'missing':[c['index'] in gaps for c in columns]},gaps
        selected=[];total=0;seen=set()
        with store.db() as db:
            if scope=='source':
                header=db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1',(table['id'],table['version'])).fetchone()
                if not header:raise KeyError('The assessed source version is unavailable')
                width=len(json.loads(header['data']))
                # SQLite evaluates the same Python null-token policy. Only matching
                # page rows are transferred, rather than all source cells to the UI.
                def qualifies(raw):
                    cells=json.loads(raw)
                    if not isinstance(cells,list) or len(cells)!=width:return False
                    if not missing_only:return True
                    gaps=[c['index'] for c in columns if missing(cells[c['index']])]
                    return focused in gaps if focused is not None else bool(gaps)
                db.create_function('aug_gap_match',1,qualifies)
                args=(table['id'],table['version'])
                clause='asset_id=? AND version=? AND idx>1 AND aug_gap_match(data)'
                total=expected_total if expected_total is not None else db.execute('SELECT count(*) FROM records WHERE '+clause,args).fetchone()[0]
                records=db.execute('SELECT idx,data FROM records WHERE '+clause+' ORDER BY idx LIMIT 20 OFFSET ?',(*args,offset)).fetchall()
                selected=[row(r['idx'],json.loads(r['data']))[0] for r in records]
            else:
                import integration
                parent=db.execute('SELECT data,materialized FROM integration_plans WHERE id=?',(run,)).fetchone()
                if not parent:raise KeyError('Integration run is unavailable')
                if config.get('journey_assessment') and config.get('journey_input_revision')!=integration.content_revision(json.loads(parent['data'])):
                    raise ValueError('Integration changed since this assessment. Saved gap statistics remain available, but the original assessed row membership is unavailable.')
                outputs=(json.loads(r['data']) for r in db.execute('SELECT data FROM integration_rows WHERE plan_id=? ORDER BY idx',(run,))) if parent['materialized'] else integration.rows(json.loads(parent['data']))
                for output in outputs:
                    for side in ('left','right'):
                        rid=output.get(side+'_record','')
                        if not rid or rid in seen:continue
                        aid,version,index=rid.rsplit(':',2)
                        if (aid,version)!=(table['id'],table['version']):continue
                        seen.add(rid)
                        item,gaps=row(int(index),output[side+'_cells'])
                        if missing_only and not (focused in gaps if focused is not None else gaps):continue
                        if offset<=total<offset+20:selected.append(item)
                        total+=1
                    if len(selected)==20:break
                if expected_total is not None:total=expected_total
        return {'revision':report['revision'],'version':table['version'],'name':table['name'],'scope':scope,
                'columns':columns,'rows':selected,'total':total,'offset':offset,'limit':20,'assessed_rows':table['rows']}
