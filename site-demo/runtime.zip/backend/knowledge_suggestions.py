"""Bounded, persistent concept alignment assistance; never auto-accepts axioms."""
import json
import time
import threading
import uuid
import knowledge as kg
import knowledge_auto as auto
import knowledge_alignment as alignment
import knowledge_properties as properties
import knowledge_attributes as attributes
import knowledge_prompts as prompts


def setup(store):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_alignment_suggestions(id TEXT PRIMARY KEY,data TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS kg_alignment_batches(id TEXT PRIMARY KEY,data TEXT)')


def choices(graph,family):
    if family=="concept":return graph["concepts"]
    if family=="property":return graph["relationships"]
    if family=="attribute":return list(attributes.attributes(graph["concepts"]).values())
    raise ValueError("Choose concepts, relationships or attributes")


def signature(graph,ids,family="concept"):
    if family!="concept":return kg.digest([family,signature(graph,[]),graph["concepts"],[c for c in choices(graph,family) if c["id"] in ids]])
    return kg.digest([sorted((l['run'],l['revision']) for l in graph['layers']),
                      [c for c in graph['concepts'] if c['id'] in ids]])


def validate(result,ids,family="concept"):
    kinds={"concept":("equivalent","subclass"),"property":("equivalent","inverse"),"attribute":("equivalent",)}[family]
    values=result.get('suggestions') if isinstance(result,dict) else None
    if not isinstance(values,list) or len(values)>12:raise ValueError('Return at most 12 alignment suggestions')
    seen=set();out=[]
    for v in values:
        if not isinstance(v,dict):raise ValueError('Invalid alignment suggestion')
        s,t,k=v.get('source'),v.get('target'),v.get('kind')
        if s not in ids or t not in ids or s==t or k not in kinds:raise ValueError('Suggestion must reference two supplied concepts')
        if k!='subclass':s,t=sorted([s,t])
        if (s,t,k) in seen:raise ValueError('Duplicate suggestion')
        reason=v.get('reason')
        if not isinstance(reason,str) or not 1<=len(reason.strip())<=2000:raise ValueError('Provide a bounded reason')
        seen.add((s,t,k));out.append({'source':s,'target':t,'kind':k,'reason':reason.strip()})
    return out


def listing(store,runs):
    setup(store)
    accepted={a['id'] for module in (alignment,properties,attributes) for a in module.read(store) if a['status']=='accepted'}
    with store.db() as db:
        items=[json.loads(r[0]) for r in db.execute('SELECT data FROM kg_alignment_suggestions ORDER BY rowid DESC LIMIT 100')]
        batches=[json.loads(r[0]) for r in db.execute('SELECT data FROM kg_alignment_batches ORDER BY rowid DESC LIMIT 10')]
    scopes={};out=[]
    for item in items:
        key=tuple(item['runs']);stale=True
        if set(key)<=set(runs):
            if key not in scopes:
                try:scopes[key]=auto.view(store,list(key))
                except (ValueError,KeyError):scopes[key]=None
            g=scopes[key]
            stale=not g or signature(g,item['concept_ids'],item.get('family','concept'))!=item['signature']
        family=item.get('family','concept')
        aid=('axiom_'+kg.digest([item['kind'],item['source'],item['target']]) if family=='concept' else 'property_'+kg.digest([item['source'],item['target'],item['kind']]) if family=='property' else 'attribute_'+kg.digest(sorted([item['source'],item['target']])))
        out.append(dict(item,stale=bool(stale),accepted=aid in accepted))
    return {'items':out,'batches':batches}


def generate(store,body):
    import settings,llm,lake_config
    runs=auto.selected(body)
    family=body.get('family','concept')
    ids=body.get('concepts')
    if not isinstance(ids,list) or not 2<=len(ids)<=8 or any(not isinstance(i,str) for i in ids) or len(set(ids))!=len(ids):raise ValueError('Select 2–8 items')
    with store.lock:
        graph=auto.view(store,runs)
        if body.get('revision')!=graph['revision']:raise ValueError('Schema changed; refresh before requesting suggestions')
        lookup={c['id']:c for c in choices(graph,family)}
        if not set(ids)<=lookup.keys():raise ValueError('Choose visible items')
        if family=='property' and any(lookup[i]['direction']!='directed' for i in ids):raise ValueError('Set a single direction for selected relationships first')
        if any(l['update_available'] for l in graph['layers']):raise ValueError('Review pending Integration updates first')
        stamp=signature(graph,ids,family)
    prompt=prompts.effective(store,'alignment' if family=='concept' else family+'_alignment')
    config=dict(settings.read(store)['llm'])
    for k,v in lake_config.read_lake_config(store).get('llm_overrides',{}).items():
        if v is not None and k in config and k!='key_env':config[k]=v
    config=settings.llm_validate(config)
    if config['provider']=='disabled' or not config.get('model'):raise ValueError('Select an LLM in Settings')
    setup(store);key=str(store.root)
    with kg._guard:
        if kg._jobs.get(key,{}).get('status')=='running':raise ValueError('Wait for the current graph task')
        job={'kind':'alignment','status':'running','phase':'Comparing selected '+family+' items','cancel':threading.Event()};kg._jobs[key]=job
        store.knowledge_active=True;store.knowledge_cancel=job['cancel']
    def work():
        try:
            def check():
                if job['cancel'].is_set():raise InterruptedError('Alignment suggestions cancelled')
            from knowledge_mapping_examples import examples
            payload=[]
            for cid in ids:
                check();c=lookup[cid]
                item={'attributes':[c,c]} if family=='attribute' else {'source':cid,'target':cid}
                group=examples(store,graph,runs,family,item)[0]
                # Never send file paths, run names or source row identifiers.
                entry={k:c[k] for k in ('id','label','definition','attributes','name','datatype','direction') if k in c}
                if family=='property':
                    entry['source_concept']=next(x['label'] for x in graph['concepts'] if x['id']==c['source'])
                    entry['target_concept']=next(x['label'] for x in graph['concepts'] if x['id']==c['target'])
                if family=='attribute':entry['concept_label']=next(x['label'] for x in graph['concepts'] if x['id']==c['concept'])
                entry['examples']=[{'records':[{'label':r['label'],'concept':r.get('concept'),'fields':r['fields']} for r in sample['records']], 'evidence':sample['evidence']} for sample in group['samples'][:3]]
                payload.append(entry)
            if len(json.dumps(payload))>60000:raise ValueError('Selected concepts exceed the request budget; select fewer concepts')
            schema=llm.obj({'suggestions':{'type':'array','items':llm.obj({'source':{'type':'string'},'target':{'type':'string'},'kind':{'type':'string','enum':{'concept':['equivalent','subclass'],'property':['equivalent','inverse'],'attribute':['equivalent']}[family]},'reason':{'type':'string'}})}})
            messages=prompts.messages(prompt,{'concepts' if family=='concept' else family:payload})
            if config['provider']=='huggingface':
                from relationship_probe import structured_request
                result=structured_request(config,messages,schema,config['timeout_seconds'],check)
            else:result=llm.request_cancellable({'operation':'knowledge_schema','config':config,'messages':messages,'schema':schema,'timeout':config['timeout_seconds']},check)
            values=validate(result,ids,family);check()
            if family=="attribute":
                for v in values:
                    a,b=lookup[v["source"]],lookup[v["target"]]
                    if a["datatype"]!=b["datatype"] or a["datatype"] in ("unknown","conflicting",""):raise ValueError("Suggested attributes have incompatible declared types")
            batch={'id':uuid.uuid4().hex,'created':time.time(),'runs':runs,'concept_ids':ids,'family':family,'signature':stamp,'model':config['model'],'prompt':prompt,'count':len(values)}
            with store.lock,store.db() as db:
                check()
                if signature(auto.view(store,runs),ids,family)!=stamp:raise ValueError('Graph changed during inference; request new suggestions')
                db.execute('INSERT INTO kg_alignment_batches VALUES(?,?)',(batch['id'],json.dumps(batch)))
                for v in values:
                    sid=kg.digest([stamp,v['source'],v['target'],v['kind']])
                    item=dict(v,id=sid,batch=batch['id'],runs=runs,concept_ids=ids,family=family,signature=stamp,status='pending',events=[],
                              labels={c['id']:(c.get('label') or next(x['label'] for x in graph['concepts'] if x['id']==c['concept'])+' · '+c['name']) for c in choices(graph,family) if c['id'] in ids},model=config['model'])
                    # Repeated requests never erase decisions or replace their original rationale.
                    db.execute('INSERT OR IGNORE INTO kg_alignment_suggestions VALUES(?,?)',(sid,json.dumps(item)))
            job.update(status='completed',phase=f'{len(values)} alignment suggestions returned; review before applying')
        except InterruptedError as e:job.update(status='cancelled',phase=str(e))
        except Exception as e:job.update(status='failed',phase=str(e))
        finally:store.knowledge_active=False
    thread=threading.Thread(target=work,daemon=True);store.knowledge_thread=thread;thread.start()
    return {'status':'running'}


def route(store,action,body):
    if action=='suggest-alignments':return generate(store,body)
    if action=='cancel-alignments':
        with kg._guard:
            job=kg._jobs.get(str(store.root),{})
            if job.get('kind')!='alignment' or job.get('status')!='running':raise ValueError('No alignment request is running')
            job['cancel'].set()
        return {'status':'cancelling'}
    runs=auto.selected(body)
    with store.lock:
        state=listing(store,runs)
        if action=='alignment-suggestions':return state
        item=next((i for i in state['items'] if i['id']==body.get('id')),None)
        if not item:raise ValueError('Select a saved suggestion')
        if action=='decide-suggestion':
            status=body.get('status')
            if status not in ('pending','rejected','deferred'):raise ValueError('Choose reject, defer or reopen')
            item.pop('stale');item.pop('accepted');item['status']=status;item['events'].append({'status':status,'time':time.time()})
            with store.db() as db:db.execute('UPDATE kg_alignment_suggestions SET data=? WHERE id=?',(json.dumps(item),item['id']))
            return listing(store,runs)
        if item['stale']:raise ValueError('Suggestion scope changed; select its original runs or request new suggestions')
        if item['status']!='pending':raise ValueError('Reopen this suggestion before reviewing')
        if item['accepted']:raise ValueError('This mapping is already accepted')
        request={**body,'source':item['source'],'target':item['target'],'kind':item['kind']}
        if action not in ('preview-suggestion','apply-suggestion'):raise ValueError('Unknown suggestion action')
        family=item.get('family','concept')
        module,suffix={'concept':(alignment,'alignment'),'property':(properties,'property'),'attribute':(attributes,'attribute')}[family]
        return module.route(store,('preview-' if action=='preview-suggestion' else 'apply-')+suffix,request)
