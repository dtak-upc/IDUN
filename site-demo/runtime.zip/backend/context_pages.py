"""September 19 bounded multi-table context construction."""
import itertools


def table_blocks(tables, size=8):
    blocks = [tables[i:i + size] for i in range(0, len(tables), size)]
    yield from blocks


def page_schedule(counts):
    """Use the first 64 Cartesian page combinations, as in the working baseline.

    This bound does not guarantee full row or table-pair coverage. Callers report
    omitted combinations and actual evaluated rows rather than claiming coverage.
    """
    counts = tuple(max(1, n) for n in counts)
    if not counts:
        return []
    return list(itertools.islice(itertools.product(*(range(n) for n in counts)), 64))
