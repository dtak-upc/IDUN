"""Validated finite assertion patterns, reusing reviewed query alignment semantics."""
import json
import knowledge as kg
import knowledge_query_scope as scope
import knowledge_attribute_query as attributes
import knowledge_overlay_query as overlays


def prepare_condition(graph,raw):
    if raw is None:return None
    if isinstance(raw,dict) and 'all' in raw:
        leaves=raw['all']
        if not isinstance(leaves,list) or not 1<=len(leaves)<=64 or any(not isinstance(c,dict) or 'all' in c for c in leaves):raise ValueError('Choose one to 64 flat attribute conditions')
        conditions=[prepare_condition(graph,c) for c in leaves]
        owners=set(a['concept'] for a in conditions[0]['resolved'])
        for c in conditions[1:]:owners.intersection_update(a['concept'] for a in c['resolved'])
        if not owners:raise ValueError('All conditions must apply to the same record concept')
        return {'all':conditions,'resolved':[a for c in conditions for a in c['resolved'] if a['concept'] in owners],
                'values_mode':'reviewed' if any(c['values_mode']=='reviewed' for c in conditions) else 'original'}
    if not isinstance(raw,dict) or not isinstance(raw.get('attribute'),str) or not raw['attribute']:raise ValueError('Choose an attribute for the step condition')
    values={'attribute':raw['attribute'],'attribute_mode':raw.get('mode','exact'),'attribute_op':raw.get('operator','eq'),'attribute_value':raw.get('value',''),'attribute_values':raw.get('values','original')}
    if any(not isinstance(v,str) for v in values.values()):raise ValueError('Step condition fields must be text')
    return attributes.prepare(graph,{k:[v] for k,v in values.items()})


def condition_matches(record,prepared):
    if prepared is None:return None
    if 'all' in prepared:
        matched=[condition_matches(record,c) for c in prepared['all']]
        if any(not m for m in matched):return []
        # Multiple bounds on the same attribute/value source must agree on one observation.
        groups={}
        for i,c in enumerate(prepared['all']):groups.setdefault((c['selected'],c['mode'],c['values_mode']),[]).append(i)
        key=lambda m:(m['id'],m['column_index'],m.get('origin'),m.get('layer'),m.get('claim'),json.dumps(m.get('value'),sort_keys=True))
        for indexes in groups.values():
            common=set(key(m) for m in matched[indexes[0]])
            for i in indexes[1:]:common.intersection_update(key(m) for m in matched[i])
            if not common:return []
            for i in indexes:matched[i]=[m for m in matched[i] if key(m) in common]
        return [dict(m,condition_index=i) for i,items in enumerate(matched) for m in items]
    # Match only the reached endpoint, never the other side of the assertion.
    assertion={'subject':record,'object':{'concept_id':'','columns':[],'cells':[]}}
    if prepared['values_mode']=='reviewed':result=overlays.matches(assertion,prepared)
    else:result=[dict(m,origin='original') for m in attributes.matches(assertion,prepared)]
    claims={(c['layer'],c['id']):c for c in record.get('augmentation_claims',[])}
    return [dict(m,side='target',evidence=claims.get((m.get('layer'),m.get('claim')),{}).get('evidence') if m.get('origin')!='manual' else None) for m in result]


def compile(graph,start,steps,mode,max_steps=4):
    if mode not in ('exact','aligned'):raise ValueError('Choose exact or reviewed-aligned pattern matching')
    if not isinstance(steps,list) or not steps:raise ValueError('Choose at least one relationship step')
    if max_steps is not None and len(steps)>max_steps:raise ValueError(f'Choose one to {max_steps} path steps')
    concepts={c['id']:c for c in graph['concepts']};edges={e['id']:e for e in graph['relationships']}
    if not isinstance(start,dict) or any(not isinstance(start.get(k),str) or not start[k] for k in ('id','concept_id')) or start['concept_id'] not in concepts:raise ValueError('Choose a starting record and concept in this query scope')
    result=[];possible={start['concept_id']}
    for index,step in enumerate(steps):
        if isinstance(step,dict) and step.get('kind')=='identity':
            if not isinstance(step.get('target'),str) or step['target'] not in concepts:raise ValueError('Choose the concept for the reviewed identity step')
            targets={step['target']:[]};reachable=possible & set(targets)
            if not reachable:raise ValueError(f'Step {index+1} identity must stay within the current concept')
            condition=prepare_condition(graph,step.get('condition'))
            if condition and not reachable.intersection(a['concept'] for a in condition['resolved']):raise ValueError('Identity condition must apply to the reached concept')
            result.append({**step,'kind':'identity','direction':'either','condition_prepared':condition,'label':'Reviewed identity','target_label':concepts[step['target']]['label'],'relations':{},'targets':targets,'selected_direction':'undirected'})
            possible=reachable;continue
        if isinstance(step,dict) and step.get('kind','assertion')!='assertion':raise ValueError('Choose an assertion or reviewed identity step')
        if not isinstance(step,dict) or not isinstance(step.get('relationship'),str) or not isinstance(step.get('target'),str) or step['relationship'] not in edges or step['target'] not in concepts or step.get('direction') not in ('outgoing','incoming'):raise ValueError('Choose a relationship, target concept and outgoing/incoming direction for every step')
        selected=edges[step['relationship']]
        relations=scope.resolve_relationships(graph,selected['id'],mode)
        targets=scope.resolve(graph,step['target'],mode)
        reachable=set()
        for eid,match in relations.items():
            edge=edges[eid];source,target=edge['source'],edge['target']
            if match['reversed']:source,target=target,source
            if step['direction']=='incoming':source,target=target,source
            if selected['direction']!='directed':
                if source in possible and target in targets:reachable.add(target)
                if target in possible and source in targets:reachable.add(source)
            elif source in possible and target in targets:reachable.add(target)
        if not reachable:raise ValueError(f'Step {index+1} has no compatible schema connection. Check direction, target concept or reviewed matching.')
        condition=prepare_condition(graph,step.get('condition'))
        if condition:
            allowed={a['concept'] for a in condition['resolved']}
            reachable.intersection_update(allowed)
            if not reachable:raise ValueError(f'Step {index+1} condition does not apply to its reachable target concepts')
        result.append({**step,'condition_prepared':condition,'label':selected['label'],'target_label':concepts[step['target']]['label'],'relations':relations,'targets':targets,'selected_direction':selected['direction']})
        possible=reachable
    return {'steps':result,'mode':mode,'token':kg.digest([graph['revision'],start,steps,mode]),
        'summary':[{'kind':s.get('kind','assertion'),'relationship':s['label'],'direction':s['direction'],'target':s['target_label'],'relationship_matches':len(s['relations']),'concept_matches':len(s['targets']),
            'condition':describe_condition(graph,s['condition_prepared']) if s['condition_prepared'] else None} for s in result]}


def match(pattern,index,edge,a,b,current):
    step=pattern['steps'][index];mapping=step['relations'].get(edge['id'])
    if mapping is None:return None
    if mapping['reversed']:a,b=b,a
    if step['direction']=='incoming':a,b=b,a
    node=lambda r:(r['id'],r['concept_id'])
    if node(a)==current:target=b
    elif step['selected_direction']!='directed' and node(b)==current:target=a
    else:return None
    if target['concept_id'] not in step['targets']:return None
    return target,{'relationship':step['label'],'original_relationship':edge['label'],'relationship_mappings':mapping['via'],
        'reversed':mapping['reversed'],'concept_mappings':step['targets'][target['concept_id']],'pattern_direction':step['direction']}


def describe_condition(graph,prepared):
    if 'all' in prepared:return {'all':[describe_condition(graph,c) for c in prepared['all']]}
    return attributes.describe(graph,prepared)
