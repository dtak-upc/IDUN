"""Automatic Integration-derived T-Box/A-Box; direction approval is per predicate type."""
import json
import threading
import knowledge as kg
import knowledge_schema
import knowledge_concepts
import knowledge_datatypes as datatypes

VERSION = 'automatic-kg-v3'

def base_projection_key(revision,refined):
    return kg.digest([VERSION,revision,refined]) if refined else kg.digest([VERSION,revision])


def assignment_key(base,overrides):
    return kg.digest([base,overrides]) if overrides else base


def projection_key(store,run,revision):
    import knowledge_assignments as assignments
    refined=knowledge_concepts.read(store,run,revision)
    return assignment_key(base_projection_key(revision,refined),assignments.mappings(assignments.read(store),run,revision))


def setup(store):
    kg.setup(store)
    import knowledge_revisions
    knowledge_revisions.setup(store)
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_auto_runs(run TEXT PRIMARY KEY,revision TEXT,data TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS kg_auto_instances(run TEXT,id TEXT,edge TEXT,data TEXT,PRIMARY KEY(run,id))')
        for side in ('subject','object'):
            db.execute(f"CREATE INDEX IF NOT EXISTS kg_auto_{side}_record ON kg_auto_instances(run,json_extract(data,'$.{side}.concept_id'),json_extract(data,'$.{side}.id'))")
        db.execute('CREATE TABLE IF NOT EXISTS kg_auto_directions(type TEXT PRIMARY KEY,data TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS kg_concept_labels(id TEXT PRIMARY KEY,label TEXT NOT NULL)')


def selected(body):
    runs = body.get('runs', [])
    if not isinstance(runs, list) or any(not isinstance(r, str) for r in runs):
        raise ValueError('Select saved Integration runs')
    return list(dict.fromkeys(runs))


def sync(store, body, apply_concepts=False):
    setup(store)
    runs = selected(body)
    from semantic import rows
    with store.lock:
        for run in runs:
            plan, revision = kg.load_plan(store, run)
            key = projection_key(store,run,revision)
            refined = knowledge_concepts.read(store,run,revision)
            with store.db() as db:
                names = {r['id']:r['name'] for r in db.execute('SELECT id,name FROM assets')}
                cached = db.execute('SELECT revision,data FROM kg_auto_runs WHERE run=?',(run,)).fetchone()
                if cached and cached['revision']==key and not json.loads(cached['data']).get('projection_version'):
                    old=json.loads(cached['data']);old.update(input_revision=revision,projection_version=VERSION)
                    db.execute('UPDATE kg_auto_runs SET data=? WHERE run=?',(json.dumps(old),run))
                    continue
                if cached and not apply_concepts and set(json.loads(cached['data'])['assets']) <= set(names):
                    continue
            meta,instances=project_run(store,run,plan,revision,names,refined)
            with store.db() as db:
                if kg.load_plan(store,run)[1] != revision: raise ValueError('Integration changed; refresh the graph')
                import knowledge_revisions
                knowledge_revisions.archive(db,run)
                db.execute('DELETE FROM kg_auto_instances WHERE run=?',(run,))
                db.executemany('INSERT INTO kg_auto_instances VALUES(?,?,?,?)',[(run,a['id'],a['edge'],json.dumps(a)) for a in instances])
                db.execute('INSERT OR REPLACE INTO kg_auto_runs VALUES(?,?,?)',(run,key,json.dumps(meta)))
        with store.db() as db:
            db.execute('DELETE FROM kg_auto_instances WHERE run NOT IN (SELECT id FROM integration_plans)')
            db.execute('DELETE FROM kg_auto_runs WHERE run NOT IN (SELECT id FROM integration_plans)')
    return view(store,runs)

def project_run(store,run,plan,revision,names,refined,overrides=None):
    if overrides is None:
        import knowledge_assignments as assignments
        overrides=assignments.mappings(assignments.read(store),run,revision)
    from semantic import rows
    # Project saved Integration relationships. Discard saved
    # direction here, without rewriting the Integration run or its evidence.
    output = kg.project(store.lake_id,run,plan,[dict(r,direction='undirected',integration_direction=r.get('direction','undirected')) for r in rows(plan)],names)
    groups = []; observations_by_class = {}; examples_by_class = {}
    for assertion in output['assertions']:
        for side in ('subject','object'):
            record = assertion[side]; cid = record['class_id']
            datatypes.observe(observations_by_class.setdefault(cid, {}), record['columns'], record['cells'])
            examples = examples_by_class.setdefault(cid, [])
            if len(examples) < 3:examples.append(record)
    for c in output['classes']:
        examples = examples_by_class.get(c['id'], []); observations = observations_by_class.get(c['id'], {})
        groups.append({'source_class':c['id'],'columns':c['columns'],
                       'samples':[datatypes.aligned(c['columns'], e) for e in examples],'labels':[e['label'] for e in examples],
                       'datatypes':{column:datatypes.declared(observations.get(column, set())) for column in c['columns']}})
    mappings = knowledge_schema.seed(groups)
    concepts = {}; lookup = {}
    for m in mappings:
        signature = sorted(a['name'].casefold() for a in m['attributes'])
        ambiguous = m['concept'].casefold() in ('name','id','label','description','unclassified concept')
        cid = 'type_' + kg.digest([m['concept'].casefold(),signature,m['source_class'] if ambiguous else ''])
        lookup[m['source_class']] = cid
        concepts[cid] = {'id':cid,'label':m['concept'],'attributes':[{'name':a['name'],'datatype':a['datatype']} for a in m['attributes']]}
    edges = {}; instances = []
    for a in output['assertions']:
        for side in ('subject','object'):
            record = a[side]; record['concept_id']=lookup[record['class_id']]
            record['concept']=concepts[record['concept_id']]['label']
            semantic=refined.get('records',{}).get(record['id'])
            if semantic:
                cid='semantic_'+kg.digest(semantic['concept'].casefold())
                concept=concepts.setdefault(cid,{'id':cid,'label':semantic['concept'],'definition':semantic['definition'],'semantic':True,'attributes':[]})
                for column in record['columns']:
                    if not any(a['name']==column for a in concept['attributes']):concept['attributes'].append({'name':column,'datatype':'string'})
                record.update(concept_id=cid,concept=semantic['concept'],concept_reason=semantic['reason'])
            correction=overrides.get(record['id'])
            if correction:
                cid=correction['id'];concept=concepts.setdefault(cid,dict(correction,attributes=list(correction['attributes'])))
                for column in record['columns']:
                    if not any(x['name']==column for x in concept['attributes']):concept['attributes'].append({'name':column,'datatype':'string'})
                record.update(concept_id=cid,concept=concept['label'],concept_reason='Manually reviewed assignment')
        source,target=sorted([a['subject']['concept_id'],a['object']['concept_id']])
        eid='relation_'+kg.digest([a['relation'],source,target])
        edge=edges.setdefault(eid,{'id':eid,'label':a['relation'],'source':source,'target':target,'direction':'unspecified','count':0})
        edge['count']+=1
        a.update(edge=eid,run_id=run,run_title=plan.get('title','Integration run'),direction='unspecified')
        # Same versioned records, projection, curated predicate and mediator.
        # Different classifications or augmented values stay separate.
        records=sorted([(a[s]['id'],a[s]['concept_id'],a[s]['columns'],a[s]['cells']) for s in ('subject','object')])
        a['id']='shared_'+kg.digest([store.lake_id,records,eid,a['document_id'],a['document_versions']])
        instances.append(a)
    unique={}
    for a in instances:
        if a['id'] in unique:
            saved_keys=unique[a['id']].setdefault('origin_row_keys',[])
            saved_keys.extend(k for k in a.get('origin_row_keys',[]) if k not in saved_keys)
            origins=unique[a['id']].setdefault('integration_origins',[])
            origins.extend(o for o in a.get('integration_origins',[]) if o not in origins)
            for p in a['evidence']:
                if p not in unique[a['id']]['evidence']:unique[a['id']]['evidence'].append(p)
        else:unique[a['id']]=a
    instances=list(unique.values())
    for e in edges.values():e['count']=sum(a['edge']==e['id'] for a in instances)
    observations = {}; reviewed = {correction['id'] for correction in overrides.values()}
    for assertion in instances:
        for side in ('subject','object'):
            record = assertion[side]
            datatypes.observe(observations.setdefault(record['concept_id'], {}), record['columns'], record['cells'])
    for cid, concept in concepts.items():
        if cid in reviewed:continue
        for attribute in concept['attributes']:
            attribute['datatype'] = datatypes.declared(observations.get(cid, {}).get(attribute['name'], set()))
    used={a[s]['concept_id'] for a in instances for s in ('subject','object')}
    meta={'run':run,'title':plan.get('title','Integration run'),'concepts':[c for c in concepts.values() if c['id'] in used],
          'semantic':bool(refined),'concept_model':refined.get('model'),
          'relationships':list(edges.values()),'count':len(instances),
          'assets':list({a['document_id'] for a in instances}|{c['asset'] for c in output['classes']})}
    meta['input_revision']=revision
    meta['projection_version']=VERSION
    return meta,instances


def type_signature(label, edges):
    return kg.digest([label,sorted((e['id'],*sorted([e['source'],e['target']])) for e in edges)])


def view(store,runs):
    setup(store)
    concepts={};edges={};layers=[]
    with store.db() as db:
        names={r['id'] for r in db.execute('SELECT id FROM assets')}
        for run in runs:
            plan,revision=kg.load_plan(store,run)
            row=db.execute('SELECT revision,data FROM kg_auto_runs WHERE run=?',(run,)).fetchone()
            if not row: raise ValueError('Build the graph first')
            m=json.loads(row['data'])
            if not set(m['assets'])<=names: raise ValueError('A graph source was removed; refresh Integration first')
            layers.append({'run':run,'title':m['title'],'count':m['count'],'semantic':m.get('semantic',False),'revision':row['revision'],'input_revision':m.get('input_revision'),
                           'update_available':row['revision']!=projection_key(store,run,revision)})
            for c in m['concepts']:
                if c['id'] not in concepts:concepts[c['id']]=c
                else:
                    existing=concepts[c['id']]['attributes']
                    for attribute in c['attributes']:
                        if attribute not in existing:existing.append(attribute)
            for e in m['relationships']:
                if e['id'] in edges: edges[e['id']]['count']+=e['count']
                else: edges[e['id']]=e
        directions={r['type']:json.loads(r['data']) for r in db.execute('SELECT * FROM kg_auto_directions')}
        labels={r['id']:r['label'] for r in db.execute('SELECT * FROM kg_concept_labels')}
        unique=shared=0
        if runs:
            scope=','.join('?' for _ in runs)
            grouped=f'SELECT id,count(DISTINCT run) AS n FROM kg_auto_instances WHERE run IN ({scope}) GROUP BY id'
            stats=db.execute(f'SELECT count(*),coalesce(sum(n>1),0) FROM ({grouped})',runs).fetchone()
            unique,shared=stats[0],stats[1]
            for r in db.execute(f'SELECT edge,count(DISTINCT id) AS n FROM kg_auto_instances WHERE run IN ({scope}) GROUP BY edge',runs):
                edges[r['edge']]['count']=r['n']
            for layer in layers:
                only=db.execute(f'SELECT count(*) FROM kg_auto_instances a JOIN ({grouped}) g ON a.id=g.id WHERE a.run=? AND g.n=1',[*runs,layer['run']]).fetchone()[0]
                layer.update(exclusive=only,shared=layer['count']-only)
    import knowledge_relationship_editor
    declarations=knowledge_relationship_editor.declarations(store,runs,concepts)
    for edge in declarations:edges.setdefault(edge['id'],edge)
    for c in concepts.values():
        c['inferred_label']=c['label']
        c['label']=labels.get(c['id'],c['label'])
    types=[]
    for label in sorted({e['label'] for e in edges.values()}):
        group=[e for e in edges.values() if e['label']==label]
        signature=type_signature(label,group);saved=directions.get(label)
        valid=saved if saved and saved.get('signature')==signature else None
        if valid and valid['status']=='accepted':
            for proposal in valid['edges']:
                edge=edges[proposal['id']];direction=proposal['direction']
                if direction=='reverse': edge['source'],edge['target']=edge['target'],edge['source']
                edge['direction']={'forward':'directed','reverse':'directed','both':'bidirectional','undirected':'unspecified'}[direction]
        types.append({'label':label,'signature':signature,'proposal':dict(valid,revision=kg.digest(valid)) if valid else None})
    import knowledge_alignment
    import knowledge_mapping_history
    decisions=knowledge_alignment.read(store)
    import knowledge_properties
    import knowledge_attributes
    attribute_decisions=knowledge_attributes.read(store)
    attribute_alignments=knowledge_attributes.visible(attribute_decisions,list(concepts.values()))
    property_decisions=knowledge_properties.read(store)
    property_alignments=knowledge_properties.visible(property_decisions,list(edges.values()))
    alignments=[a for a in decisions if a['status']=='accepted' and a['source'] in concepts and a['target'] in concepts]
    return {'attribute_alignments':attribute_alignments,'attributes':list(knowledge_attributes.attributes(list(concepts.values())).values()),'property_alignments':property_alignments,'alignments':alignments,'revision':kg.digest([runs,layers,list(edges.values()),labels,decisions,property_decisions,attribute_decisions,knowledge_mapping_history.revision(store)]),'concepts':list(concepts.values()),
            'relationships':list(edges.values()),'layers':layers,'types':types,'count':unique,
            'contribution_count':sum(l['count'] for l in layers),'shared_count':shared}


def grouped_instances(db,runs,ids=None):
    """Stream one assertion at a time with all selected run/evidence contributions."""
    if not runs:return
    where='run IN ('+','.join('?' for _ in runs)+')';args=list(runs)
    if ids is not None:
        if not ids:return
        where+=' AND id IN ('+','.join('?' for _ in ids)+')';args.extend(ids)
    current=None;seen=set()
    for row in db.execute('SELECT data FROM kg_auto_instances WHERE '+where+' ORDER BY id,run',args):
        a=json.loads(row[0])
        if current is None or a['id']!=current['id']:
            if current is not None:yield current
            current=dict(a,evidence=[],contributions=[]);seen=set()
        current['contributions'].append({'run_id':a['run_id'],'run_title':a['run_title'],
            'assertion_id':a['id'],
            'evidence':a['evidence'],'original_labels':a.get('original_labels',[])})
        for p in a['evidence']:
            key=kg.digest(p)
            if key not in seen:current['evidence'].append(p);seen.add(key)
    if current is not None:yield current


def instances(store,query):
    with store.lock:
        return _instances(store,query)


def _instances(store,query):
    runs=query.get('runs',[''])[0].split(',') if query.get('runs',[''])[0] else []
    graph=view(store,runs)
    import knowledge_query_scope as query_scope
    mode=query.get('concept_mode',['exact'])[0]
    if mode not in ('exact','aligned'):raise ValueError('Choose exact or aligned concept matching')
    relationship_mode=query.get('relationship_mode',['exact'])[0]
    if relationship_mode not in ('exact','aligned'):raise ValueError('Choose exact or aligned relationship matching')
    requested_revision=query.get('revision',[''])[0]
    if requested_revision and requested_revision!=graph['revision']:raise ValueError('Query schema changed; refresh the instance view')
    if not runs: return {'items':[],'total':0,'offset':0,'limit':25}
    offset=max(0,int(query.get('offset',['0'])[0]));concept=query.get('concept',[''])[0];edge=query.get('relationship',[''])[0]
    paths=query_scope.resolve(graph,concept,mode)
    relationship_paths=query_scope.resolve_relationships(graph,edge,relationship_mode)
    import knowledge_attribute_query as attribute_query
    attribute_filter=attribute_query.prepare(graph,query)
    where='run IN ('+','.join('?' for _ in runs)+')';args=list(runs)
    assertion_ids=query.get('assertions',[''])[0]
    if assertion_ids:
        ids=list(dict.fromkeys(assertion_ids.split(',')))
        if len(ids)>5000 or any(not value or len(value)>200 for value in ids):raise ValueError('Choose valid assertion IDs')
        where+=' AND id IN (SELECT value FROM json_each(?))';args.append(json.dumps(ids))
    if concept:
        scope=json.dumps(list(paths))
        where+=" AND (json_extract(data,'$.subject.concept_id') IN (SELECT value FROM json_each(?)) OR json_extract(data,'$.object.concept_id') IN (SELECT value FROM json_each(?)))";args.extend([scope,scope])
    if edge:
        where+=' AND edge IN (SELECT value FROM json_each(?))';args.append(json.dumps(list(relationship_paths)))
    import knowledge_overlay_query as overlay_query
    overlay_layers=overlay_query.active_layers(store,graph,runs) if attribute_filter else []
    if attribute_filter:
        if attribute_filter['values_mode']=='reviewed' and overlay_layers:
            clause,attribute_args=overlay_query.sql_filter(attribute_filter,overlay_layers);where+=clause;args.extend(attribute_args)
        else:
            clause,attribute_args=attribute_query.sql_filter(attribute_filter);where+=clause;args.append(attribute_args)
    with store.db() as db:
        if attribute_filter:
            def cell_match(raw,kind):
                if kind in ('array','object') and attribute_filter['operator'] not in ('present','missing'):return False
                if kind in ('true','false'):raw=kind=='true'
                return attribute_filter['predicate'](raw)
            db.create_function('kg_attribute_match',2,cell_match,deterministic=True)
            db.create_function('kg_missing',1,lambda value:value is None or isinstance(value,str) and not value.strip(),deterministic=True)
            db.create_function('kg_overlay_match',4,lambda value,kind,datatype,unit:overlay_query.sql_claim_match(attribute_filter,value,kind,datatype,unit),deterministic=True)
        total=db.execute('SELECT count(DISTINCT id) FROM kg_auto_instances WHERE '+where,args).fetchone()[0]
        ids=[r[0] for r in db.execute('SELECT DISTINCT id FROM kg_auto_instances WHERE '+where+' ORDER BY id LIMIT 25 OFFSET ?',[*args,offset])]
        items=list(grouped_instances(db,runs,ids))
    edges={e['id']:e for e in graph['relationships']}
    labels={c['id']:c['label'] for c in graph['concepts']}
    for a in items:
        for side in ('subject','object'):a[side]['concept']=labels[a[side]['concept_id']]
        e=edges[a['edge']]
        if a['subject']['concept_id']!=e['source']:a['subject'],a['object']=a['object'],a['subject']
        a['direction']=e['direction']
        if relationship_mode=='aligned' and edge:
            match=relationship_paths[a['edge']]
            a['relationship_match']={'id':edge,'label':edges[edge]['label'],'matched_id':e['id'],'matched_label':e['label'],
                                     'original_direction':a['direction'], 'original_subject':a['subject']['id'],
                                     'original_object':a['object']['id'], **match}
            if match['reversed']:a['subject'],a['object']=a['object'],a['subject']
            a['direction']=edges[edge]['direction']
        if mode=='aligned' and concept:
            a['concept_matches']=[{'side':side,'id':a[side]['concept_id'],'label':a[side]['concept'],'via':paths[a[side]['concept_id']]} for side in ('subject','object') if a[side]['concept_id'] in paths]

    import knowledge_overlays
    knowledge_overlays.annotate(store,graph,runs,items)
    result={'items':items,'total':total,'offset':offset,'limit':25}
    if mode=='aligned':result['concept_scope']=query_scope.description(graph,concept,mode,paths)
    if relationship_mode=='aligned':result['relationship_scope']=query_scope.relationship_description(graph,edge,relationship_mode,relationship_paths)
    if attribute_filter:
        for a in items:a['attribute_matches']=overlay_query.matches(a,attribute_filter) if attribute_filter['values_mode']=='reviewed' else attribute_query.matches(a,attribute_filter)
        result['attribute_scope']=attribute_query.describe(graph,attribute_filter)
        result['attribute_scope']['coverage']=overlay_query.coverage(store,runs,attribute_filter,overlay_layers)
        result['attribute_scope']['active_layers']=len(overlay_layers)
    return result


def suggest(store,body):
    import settings,llm,lake_config
    import knowledge_prompts as prompts
    prompt=prompts.effective(store,'directions')
    runs=selected(body);graph=view(store,runs);label=body.get('type')
    group=[e for e in graph['relationships'] if e['label']==label]
    group=[dict(e,source=min(e['source'],e['target']),target=max(e['source'],e['target'])) for e in group]
    if not group:raise ValueError('Choose an existing relationship type')
    signature=type_signature(label,group)
    input_revisions=[kg.load_plan(store,r)[1] for r in runs]
    proposal_revision=next(t for t in graph['types'] if t['label']==label)['proposal']
    proposal_revision=proposal_revision.get('revision') if proposal_revision else None
    config=dict(settings.read(store)['llm'])
    for k,v in lake_config.read_lake_config(store).get('llm_overrides',{}).items():
        if v is not None and k in config and k!='key_env':config[k]=v
    config=settings.llm_validate(config)
    if config['provider']=='disabled' or not config.get('model'):raise ValueError('Select an LLM in Settings')
    key=str(store.root)
    with kg._guard:
        if kg._jobs.get(key,{}).get('status')=='running':raise ValueError('Wait for the current graph suggestion')
        job={'status':'running','phase':'Suggesting directions for '+label,'cancel':threading.Event()};kg._jobs[key]=job
        store.knowledge_active=True;store.knowledge_cancel=job['cancel']
    def work():
        try:
            def check():
                if job['cancel'].is_set():raise InterruptedError('Direction suggestion cancelled')
            samples=[]
            for e in group:
                page=instances(store,{'runs':[','.join(runs)],'relationship':[e['id']]})
                for a in page['items']:
                    if a['subject']['concept_id']!=e['source']:a['subject'],a['object']=a['object'],a['subject']
                samples.append({'id':e['id'],'source':e['source'],'target':e['target'],'examples':[
                    {'source':dict(zip(a['subject']['columns'],a['subject']['cells'])),
                     'target':dict(zip(a['object']['columns'],a['object']['cells'])),
                     'evidence':[(p.get('context_text') or p.get('text',''))[:1200] for p in a['evidence'][:2]]} for a in page['items'][:3]]})
            payload={'concepts':graph['concepts'],'relationship':label,'edges':samples}
            if len(json.dumps(payload))>60000:raise ValueError('Select fewer runs for this direction suggestion')
            schema=llm.obj({'edges':{'type':'array','items':llm.obj({'id':{'type':'string'},'direction':{'type':'string','enum':['forward','reverse','both','undirected']},'reason':{'type':'string'}})}})
            messages=prompts.messages(prompt,payload)
            if config['provider']=='huggingface':
                from relationship_probe import structured_request
                result=structured_request(config,messages,schema,config['timeout_seconds'],check)
            else:result=llm.request_cancellable({'operation':'knowledge_schema','config':config,'messages':messages,'schema':schema,'timeout':config['timeout_seconds']},check)
            check();values=result.get('edges') if isinstance(result,dict) else None
            validate_directions(values,group)
            with store.lock,store.db() as db:
                if [kg.load_plan(store,r)[1] for r in runs]!=input_revisions:raise ValueError('Integration changed; request a new suggestion')
                current=view(store,runs)
                current_proposal=next(t for t in current['types'] if t['label']==label)['proposal']
                if (current_proposal.get('revision') if current_proposal else None)!=proposal_revision:raise ValueError('Direction was edited while the LLM was working; your saved direction is retained')
                if type_signature(label,[e for e in current['relationships'] if e['label']==label])!=signature:raise ValueError('Schema changed; request a new suggestion')
                db.execute('INSERT OR REPLACE INTO kg_auto_directions VALUES(?,?)',(label,json.dumps({'signature':signature,'status':'suggested','edges':values,'model':config['model'],'prompt':prompt})))
            job.update(status='completed',phase='Direction suggestion ready')
        except Exception as e:job.update(status='failed',phase=str(e))
        finally:store.knowledge_active=False
    thread=threading.Thread(target=work,daemon=True);store.knowledge_thread=thread;thread.start()
    return {'status':'running'}


def validate_directions(values,group):
    if not isinstance(values,list) or len(values)!=len(group) or {v.get('id') for v in values if isinstance(v,dict)}!={e['id'] for e in group}:raise ValueError('Model must return each schema edge exactly once')
    for v in values:
        if v.get('direction') not in ('forward','reverse','both','undirected') or not isinstance(v.get('reason'),str) or not 0<len(v['reason'])<=2000:raise ValueError('Invalid direction suggestion')


def decide(store,body):
    runs=selected(body);label=body.get('type');status=body.get('status')
    if status not in ('accepted','dismissed'):raise ValueError('Choose accept or keep undirected')
    with store.lock,store.db() as db:
        graph=view(store,runs);row=db.execute('SELECT data FROM kg_auto_directions WHERE type=?',(label,)).fetchone()
        p=json.loads(row[0]) if row else None
        signature=type_signature(label,[e for e in graph['relationships'] if e['label']==label])
        if not p or p['signature']!=signature or p['signature']!=body.get('signature') or kg.digest(p)!=body.get('proposal_revision'):raise ValueError('Suggestion changed; refresh before approving')
        p['status']=status;db.execute('UPDATE kg_auto_directions SET data=? WHERE type=?',(json.dumps(p),label))
    return view(store,runs)


def override(store,body):
    """Explicit user directions use the same canonical endpoints as LLM proposals."""
    runs=selected(body);label=body.get('type')
    with store.lock,store.db() as db:
        graph=view(store,runs)
        group=[e for e in graph['relationships'] if e['label']==label]
        if not group:raise ValueError('Choose an existing relationship type')
        current=next(t for t in graph['types'] if t['label']==label)
        if current['signature']!=body.get('signature') or (current['proposal'] or {}).get('revision')!=body.get('proposal_revision'):
            raise ValueError('Direction changed; refresh before saving')
        values=body.get('edges')
        validate_directions(values,group)
        proposal={'signature':current['signature'],'status':'accepted','edges':values,'model':'Manual override','origin':'manual'}
        db.execute('INSERT OR REPLACE INTO kg_auto_directions VALUES(?,?)',(label,json.dumps(proposal)))
    return view(store,runs)


def rename_concept(store,body):
    runs=selected(body);cid=body.get('concept');label=body.get('label')
    if not isinstance(label,str) or not 0<len(label.strip())<=100 or any(ord(c)<32 for c in label):
        raise ValueError('Use a concept name of 1–100 characters without control characters')
    label=label.strip()
    with store.lock:
        graph=view(store,runs)
        if graph['revision']!=body.get('revision'):raise ValueError('Graph changed; refresh before renaming')
        concept=next((c for c in graph['concepts'] if c['id']==cid),None)
        if not concept:raise ValueError('Choose a concept in the selected graph')
        if any(c['id']!=cid and c['label'].casefold()==label.casefold() for c in graph['concepts']):
            raise ValueError('Another concept already uses this name; renaming does not merge concepts')
        with store.db() as db:
            if label==concept['inferred_label']:db.execute('DELETE FROM kg_concept_labels WHERE id=?',(cid,))
            else:db.execute('INSERT OR REPLACE INTO kg_concept_labels VALUES(?,?)',(cid,label))
    return view(store,runs)


def run_preview(store,body):
    from semantic import rows
    from collections import Counter
    with store.lock:
        plan,revision=kg.load_plan(store,body.get('run'))
        with store.db() as db:
            names={r['id']:r['name'] for r in db.execute('SELECT id,name FROM assets')}
        values=rows(plan)
        relations=Counter(str(r.get('relation','Unlabelled')) for r in values)
        # Source keys are record references, not entity identity assumptions.
        assets={str(r.get(side+'_record','')).split(':')[0] for r in values for side in ('left','right')}
        return {'revision':revision,'rows':len(values),'relationships':[{'name':k,'count':v} for k,v in relations.most_common()],
                'sources':sorted({names[a] for a in assets if a in names})}


def route(store,method,path,body,query):
    if method=='GET' and path==['contribution']:
        import knowledge_journey
        return knowledge_journey.contribution(store,query)
    if method=='GET' and path==['journey-layers']:
        import knowledge_journey
        return knowledge_journey.layers(store,query)
    if method=='POST' and len(path)==1 and path[0] in ('visual-query-context','saved-visual-queries','get-saved-visual-query','save-visual-query','rename-saved-visual-query','remove-saved-visual-query'):
        import knowledge_visual_recipes
        return knowledge_visual_recipes.route(store,path[0],body())
    if method=='POST' and path in (['preview-visual-path'],['visual-path']):
        import knowledge_visual_query
        return knowledge_visual_query.route(store,path[0],body())
    if method=='POST' and path in (['validity-record'],['save-validity'],['clear-validity']):
        import knowledge_validity
        return knowledge_validity.route(store,path[0],body())
    if method=='POST' and path==['compare-checkpoints']:
        import knowledge_checkpoint_comparison
        return knowledge_checkpoint_comparison.route(store,body())
    if method=='POST' and path in (['checkpoints'],['capture-checkpoint'],['query-checkpoint'],['remove-checkpoint'],['preview-checkpoint-path'],['traverse-checkpoint']):
        import knowledge_checkpoints
        return knowledge_checkpoints.route(store,path[0],body())
    if method=='POST' and path==['preview-path']:
        import knowledge_traversal
        return knowledge_traversal.preview(store,body())
    if method=='POST' and path==['cancel-traversal']:
        import knowledge_traversal
        return knowledge_traversal.cancel(store,body())
    if method=='POST' and path==['traverse']:
        import knowledge_traversal
        return knowledge_traversal.route(store,body())
    if method=='POST' and path in (['augmentation-layers'],['preview-augmentation-layer'],['apply-augmentation-layer'],['augmentation-claims'],['toggle-augmentation-layer'],['remove-augmentation-layer']):
        import knowledge_overlays
        return knowledge_overlays.route(store,path[0],body())
    if method=='POST' and path==['identity-bridges']:
        import knowledge_bridges
        return knowledge_bridges.route(store,body())
    if method=='POST' and path in (['identity-links'],['identity-candidates'],['identity-members'],['preview-identity'],['apply-identity'],['undo-identity']):
        import knowledge_identity
        return knowledge_identity.route(store,path[0],body())
    if method=='POST' and path in (['entity-keys'],['preview-entity-key'],['apply-entity-key'],['undo-entity-key']):
        import knowledge_entity_keys
        return knowledge_entity_keys.route(store,path[0],body())
    if method=='POST' and path==['run-preview']:return run_preview(store,body())
    if method=='POST' and path in (['suggest-alignments'],['cancel-alignments'],['alignment-suggestions'],['decide-suggestion'],['preview-suggestion'],['apply-suggestion']):
        import knowledge_suggestions
        return knowledge_suggestions.route(store,path[0],body())
    if path==['prompts'] and method=='GET':
        import knowledge_prompts
        return knowledge_prompts.catalog(store)
    if method=='POST' and path in (['preview-prompt'],['save-prompt']):
        import knowledge_prompts
        return knowledge_prompts.route(store,path[0],body())
    if method=='POST' and path in (['assignment-records'],['preview-assignment'],['apply-assignment'],['preview-assignment-undo'],['apply-assignment-undo']):
        import knowledge_assignments
        return knowledge_assignments.route(store,path[0],body())
    if method=='POST' and path==['mapping-history']:
        import knowledge_mapping_history
        return knowledge_mapping_history.history(store,body())
    if method=='POST' and path in (['preview-attribute'],['apply-attribute'],['undo-attribute']):
        import knowledge_attributes
        return knowledge_attributes.route(store,path[0],body())
    if method=='POST' and path in (['preview-property'],['apply-property'],['undo-property']):
        import knowledge_properties
        return knowledge_properties.route(store,path[0],body())
    if method=='POST' and path in (['preview-alignment'],['apply-alignment'],['undo-alignment']):
        import knowledge_alignment
        return knowledge_alignment.route(store,path[0],body())
    if method=='POST' and path in (['preview-relationship-edit'],['apply-relationship-edit']):
        import knowledge_relationship_editor
        return knowledge_relationship_editor.route(store,path[0],body())
    if method=='POST' and path==['rename-concept']:return rename_concept(store,body())
    if method=='POST' and path==['sync']:return sync(store,body())
    if method=='POST' and path in (['preview-update'],['apply-update'],['history'],['restore'],['preview-retention'],['apply-retention']):
        import knowledge_revisions
        return knowledge_revisions.route(store,path[0],body())
    if method=='POST' and path==['concepts']:return knowledge_concepts.refine(store,body())
    if method=='GET' and path==['instances']:return instances(store,query)
    if method=='POST' and path==['suggest']:return suggest(store,body())
    if method=='POST' and path==['direction']:return decide(store,body())
    if method=='POST' and path==['override']:return override(store,body())
    if method=='POST' and path==['export']:
        import knowledge_export
        return knowledge_export.export(store,body())
    raise KeyError('Unknown automatic graph operation')
