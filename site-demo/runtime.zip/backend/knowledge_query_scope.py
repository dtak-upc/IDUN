"""Explainable concept filtering using reviewed, visible class axioms only."""
from collections import deque


def resolve(graph, concept, mode):
    if mode not in ('exact', 'aligned'):
        raise ValueError('Choose exact or aligned concept matching')
    labels = {c['id']: c['label'] for c in graph['concepts']}
    if not concept or concept not in labels:
        return {}
    paths = {concept: []}
    if mode == 'exact':
        return paths
    adjacency = {}
    for a in sorted(graph.get('alignments', []), key=lambda a: a['id']):
        source, target = a['source'], a['target']
        if source not in labels or target not in labels or a.get('status', 'accepted') != 'accepted':
            continue
        # Querying a parent includes its children; querying a child never includes its parent.
        adjacency.setdefault(target, []).append((source, a))
        if a['kind'] == 'equivalent':
            adjacency.setdefault(source, []).append((target, a))
    queue = deque([concept])
    while queue:
        current = queue.popleft()
        for candidate, axiom in adjacency.get(current, []):
            if candidate in paths:
                continue
            paths[candidate] = [*paths[current], {
                'id': axiom['id'], 'kind': axiom['kind'],
                'source': axiom['source'], 'target': axiom['target'],
                'source_label': labels[axiom['source']], 'target_label': labels[axiom['target']],
            }]
            queue.append(candidate)
    return paths


def description(graph, concept, mode, paths):
    labels = {c['id']: c['label'] for c in graph['concepts']}
    return {'mode': mode, 'concept': concept, 'revision': graph['revision'],
            'resolved': [{'id': cid, 'label': labels[cid], 'via': path} for cid, path in paths.items()]}


def resolve_relationships(graph, relationship, mode):
    """Parity tracks whether a reviewed mapping reverses endpoint roles."""
    if mode not in ('exact', 'aligned'):
        raise ValueError('Choose exact or aligned relationship matching')
    edges = {e['id']: e for e in graph['relationships']}
    if not relationship or relationship not in edges:
        return {}
    matches = {relationship: {'reversed': False, 'via': []}}
    if mode == 'exact' or edges[relationship]['direction'] != 'directed':
        return matches
    adjacency = {}
    for a in sorted(graph.get('property_alignments', []), key=lambda a: a['id']):
        s, t = a['source'], a['target']
        if a.get('stale') or a.get('status', 'accepted') != 'accepted' or a['kind'] not in ('equivalent', 'inverse'):
            continue
        if s not in edges or t not in edges or any(edges[i]['direction'] != 'directed' for i in (s, t)):
            continue
        adjacency.setdefault(s, []).append((t, a))
        adjacency.setdefault(t, []).append((s, a))
    queue = deque([relationship])
    while queue:
        current = queue.popleft()
        for candidate, axiom in adjacency.get(current, []):
            reverse = matches[current]['reversed'] ^ (axiom['kind'] == 'inverse')
            if candidate in matches:
                if matches[candidate]['reversed'] != reverse:
                    raise ValueError('Reviewed relationship mappings have conflicting endpoint roles; review the mappings')
                continue
            matches[candidate] = {'reversed': reverse, 'via': [*matches[current]['via'], {
                'id': axiom['id'], 'kind': axiom['kind'], 'source': axiom['source'], 'target': axiom['target'],
                'source_label': edges[axiom['source']]['label'], 'target_label': edges[axiom['target']]['label'],
            }]}
            queue.append(candidate)
    return matches


def relationship_description(graph, relationship, mode, matches):
    edges = {e['id']: e for e in graph['relationships']}
    names = {c['id']: c['label'] for c in graph['concepts']}
    return {'mode': mode, 'relationship': relationship, 'revision': graph['revision'],
            'resolved': [{'id': eid, 'label': edges[eid]['label'],
                          'source_label': names[edges[eid]['source']], 'target_label': names[edges[eid]['target']], 'direction':edges[eid]['direction'],
                          **match} for eid, match in matches.items()]}
