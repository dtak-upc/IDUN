"""Durable assessment/preparation checkpoints, independent of extraction runs."""
import hashlib
import json
import time


def setup(db):
    db.execute('CREATE TABLE IF NOT EXISTS augmentation_workspaces(scope TEXT,base_run TEXT,signature TEXT,assessment TEXT,preparation TEXT,prep_signature TEXT,updated REAL,PRIMARY KEY(scope,base_run))')


def signature(store, scope, run):
    import augmentation
    if scope not in ('source', 'integration'):
        raise ValueError('Choose source or integration scope')
    with store.db() as db:
        if scope == 'source':
            content = [tuple(r) for r in db.execute("SELECT j.asset_id,j.version,a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.status='ready' ORDER BY a.name,a.id")]
        else:
            if not run:
                return None
            row = db.execute('SELECT data FROM integration_plans WHERE id=?', (run,)).fetchone()
            if not row:
                return None
            content = json.loads(row['data'])
    return hashlib.sha256(json.dumps([scope,content,augmentation.policy(store)],sort_keys=True).encode()).hexdigest()


def prep_signature(store, base):
    path = store.root / 'thor_config.json'
    config = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    with store.db() as db:
        sources = [tuple(r) for r in db.execute("SELECT asset_id,version FROM jobs WHERE status='ready' ORDER BY asset_id")]
    return hashlib.sha256(json.dumps([base,config,sources],sort_keys=True).encode()).hexdigest()


def assess(store, scope='source', run=''):
    import augmentation
    with store.lock:
        report = augmentation.assess(store,scope,run)
        base = signature(store,scope,run)
        with store.db() as db:
            setup(db)
            db.execute('INSERT OR REPLACE INTO augmentation_workspaces VALUES(?,?,?,?,?,?,?)',
                       (scope,run if scope=='integration' else '',base,json.dumps(report),None,None,time.time()))
        return report


def prepared(store, manifest):
    scope,run = manifest['scope'],manifest.get('base_run_id') or ''
    with store.lock:
        base = signature(store,scope,run)
        ps = prep_signature(store,base)
        with store.db() as db:
            setup(db)
            row = db.execute('SELECT signature,assessment FROM augmentation_workspaces WHERE scope=? AND base_run=?',(scope,run)).fetchone()
            if row and row['signature']==base and json.loads(row['assessment'])['revision']==manifest['base_revision']:
                db.execute('UPDATE augmentation_workspaces SET preparation=?,prep_signature=?,updated=? WHERE scope=? AND base_run=?',
                           (manifest['fingerprint'],ps,time.time(),scope,run))


def read(store, scope='source', run='', include_manifest=True):
    with store.lock:
        base = signature(store,scope,run)
        with store.db() as db:
            setup(db)
            row = db.execute('SELECT * FROM augmentation_workspaces WHERE scope=? AND base_run=?',(scope,run if scope=='integration' else '')).fetchone()
            if not row or not base or row['signature']!=base:
                return {'assessment':None,'manifest':None,'stale':bool(row)}
            manifest = None
            if include_manifest and row['preparation'] and row['prep_signature']==prep_signature(store,base):
                saved = db.execute('SELECT data FROM thor_preparations WHERE id=?',(row['preparation'],)).fetchone()
                manifest = json.loads(saved['data']) if saved else None
            return {'assessment':json.loads(row['assessment']),'manifest':manifest,'stale':False}
