"""SQLite FTS5 and LanceDB vector retrieval over projected passages.

Supports:
- Representation-aware encoder policy resolution
- Parameterized dimensions (384, 768, 1024)
- Representation-keyed vector table isolation
- Elimination of fixed module-level identity caches
"""
import hashlib
import json
import math
import os
import subprocess
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ENCODER_KEY = "medembed:963121bfb9c625475f65b08fb54990ce9c4e7a1a:loki-00a94bcd:512:lsh8043-16x8"


def get_encoder_policy(store: Any = None, bundle_id: Optional[str] = None) -> Dict[str, Any]:
    """Resolves encoder policy from store's lake config or explicit bundle_id."""
    import lake_config
    import model_registry

    if bundle_id:
        bundle = model_registry.get_bundle(bundle_id)
    elif store is not None:
        cfg = lake_config.read_lake_config(store)
        bundle = model_registry.configured_bundle(cfg)
    else:
        bundle = model_registry.get_bundle("generic-adapter-v1")

    dim = bundle.get("dimensions", 1024)
    encoder_name = bundle.get("retrieval_encoder", "unknown")
    token_limit = bundle.get("token_limit", 512)
    lsh_key = "lsh8043-16x8"
    norm = True

    encoder_identity = encoder_name + ('@' + bundle['encoder_revision'] if bundle.get('encoder_revision') else '')
    policy_str = f"{encoder_identity}:{dim}:{token_limit}:{lsh_key}:norm"
    from encoder_defaults import options
    settings = options(encoder_name)
    if settings:
        policy_str += ':' + json.dumps(settings, sort_keys=True)
    if bundle.get("bundle_id") == "legacy-loki-clinical":
        policy_key = "legacy"
    else:
        policy_key = hashlib.sha256(policy_str.encode("utf-8")).hexdigest()[:16]

    return {
        "bundle_id": bundle.get("bundle_id"),
        "encoder_name": encoder_name,
        "dimensions": dim,
        "native_dimensions": bundle.get('native_dimensions', dim),
        "token_limit": token_limit,
        "lsh_key": lsh_key,
        "normalization": norm,
        "policy_str": policy_str,
        "policy_key": policy_key,
        "encoder_dir": bundle.get("encoder_dir"),
    }


def encode(store: Any, texts: List[str], check: Any, policy: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not texts:
        return {"items": [], "truncated": 0}
    if len(texts) > 4096:
        raise ValueError("At most 4,096 new representative units per run; index smaller manual imports first")

    root = Path(__file__).resolve().parents[1]
    from settings import runtime, worker_env

    python = runtime(store)["python"]
    token = uuid.uuid4().hex
    base = store.root / "pending"
    request = base / (token + ".json")
    response = base / (token + ".result")
    log = base / (token + ".log")
    process = None
    progress_file = Path(str(response) + ".progress")
    last_count = -1

    if policy is None:
        policy = get_encoder_policy(store)
    from encoder_defaults import worker_python
    python = worker_python(policy['encoder_name'], python)

    req_payload = {
        "texts": texts,
        "encoder_name": policy['encoder_name'],
        "encoder_dir": policy.get("encoder_dir") or str(root / "models/step1_profiling/all-minilm"),
        "dimensions": policy["dimensions"],
        "native_dimensions": policy.get('native_dimensions', policy['dimensions']),
        "max_seq_length": policy["token_limit"],
    }

    try:
        request.write_text(json.dumps(req_payload), encoding="utf-8")
        with log.open("w", encoding="utf-8") as stderr:
            process = subprocess.Popen(
                [python, str(root / "scripts/embed-profile.py"), str(request), str(response)],
                stdout=stderr,
                stderr=stderr,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                env=worker_env(store),
            )
            deadline = time.monotonic() + 600
            while process.poll() is None:
                check()
                if progress_file.exists():
                    try:
                        count = int(progress_file.read_text(encoding="utf-8"))
                    except (ValueError, OSError):
                        count = last_count
                    if count != last_count:
                        callback = getattr(store, "profile_embedding_progress", None)
                        if callback:
                            callback(count)
                        last_count = count
                if time.monotonic() > deadline:
                    raise ValueError("Embedding worker exceeded ten-minute budget")
                time.sleep(0.1)

        if process.returncode:
            detail = ""
            try:
                if log.exists():
                    lines = [
                        l.strip()
                        for l in log.read_text(encoding="utf-8", errors="replace").splitlines()
                        if l.strip()
                    ]
                    if lines:
                        detail = ": " + lines[-1]
            except Exception:
                pass
            raise ValueError(f"Local encoder failed{detail}; verify the Step 07 model environment and artifacts")

        result = json.loads(response.read_text(encoding="utf-8"))
        if len(result["items"]) != len(texts):
            raise ValueError("Incomplete encoder response")
        for item in result["items"]:
            if (
                len(item["vector"]) != policy["dimensions"]
                or len(item["codes"]) != 16
                or not all(math.isfinite(v) for v in item["vector"])
            ):
                raise ValueError(
                    f"Invalid encoder response: expected {policy['dimensions']}-dim finite vector, got {len(item['vector'])}"
                )
        return result
    finally:
        if process and process.poll() is None:
            process.kill()
            process.wait()
        for p in (request, response, log, progress_file):
            p.unlink(missing_ok=True)


class Index:
    def __init__(self, store: Any, policy: Optional[Dict[str, Any]] = None):
        self.store = store
        self.policy = policy or get_encoder_policy(store)

    def setup(self) -> None:
        with self.store.lock:
            with self.store.db() as db:
                db.executescript("""
                CREATE TABLE IF NOT EXISTS retrieval_units(id TEXT PRIMARY KEY, asset_id TEXT, kind TEXT, data TEXT);
                CREATE INDEX IF NOT EXISTS retrieval_source ON retrieval_units(asset_id);
                CREATE VIRTUAL TABLE IF NOT EXISTS retrieval_fts USING fts5(unit_id UNINDEXED, asset_id UNINDEXED, content);
                CREATE TABLE IF NOT EXISTS retrieval_buckets(bucket TEXT, unit_id TEXT, PRIMARY KEY(bucket, unit_id));
                CREATE TABLE IF NOT EXISTS retrieval_generations(asset_id TEXT, generation TEXT, policy_key TEXT, PRIMARY KEY(asset_id, policy_key));
                """)
                gen_cols = [r["name"] for r in db.execute("PRAGMA table_info(retrieval_generations)")]
                if "policy_key" not in gen_cols:
                    db.execute("ALTER TABLE retrieval_generations ADD COLUMN policy_key TEXT")
                    db.execute("UPDATE retrieval_generations SET policy_key='legacy' WHERE policy_key IS NULL")

                legacy = db.execute("SELECT DISTINCT asset_id FROM retrieval_units WHERE json_type(data, '$.vector')='array'").fetchall()

            if legacy:
                from contextlib import closing
                import sqlite3

                backup = self.store.root / "backups/before-lancedb.sqlite3"
                backup.parent.mkdir(exist_ok=True)
                if not backup.exists():
                    temporary = backup.with_suffix(".tmp")
                    with closing(sqlite3.connect(self.store.dbpath)) as src, closing(sqlite3.connect(temporary)) as dst:
                        src.backup(dst)
                    temporary.replace(backup)

                for source in legacy:
                    with self.store.db() as db:
                        rows = db.execute(
                            "SELECT * FROM retrieval_units WHERE asset_id=? ORDER BY CAST(substr(id, instr(id,':')+1) AS INTEGER)",
                            (source["asset_id"],),
                        ).fetchall()
                        units = [json.loads(r["data"]) for r in rows]
                        self.replace(db, {"asset_id": source["asset_id"], "kind": rows[0]["kind"]}, units)

    def replace(self, db: Any, source: Dict[str, Any], units: List[Dict[str, Any]]) -> None:
        from vector_store import vectors

        aid = source["asset_id"]
        v = vectors(self.store, representation_key=self.policy["policy_key"], dimension=self.policy["dimensions"])
        generation = v.stage(aid, source.get("kind", "unknown"), units)

        db.execute("DELETE FROM retrieval_fts WHERE asset_id=?", (aid,))
        db.execute("DELETE FROM retrieval_buckets WHERE unit_id IN (SELECT id FROM retrieval_units WHERE asset_id=?)", (aid,))
        db.execute("DELETE FROM retrieval_units WHERE asset_id=?", (aid,))
        db.execute("DELETE FROM retrieval_generations WHERE asset_id=? AND (policy_key=? OR policy_key IS NULL)", (aid, self.policy["policy_key"]))
        db.execute("INSERT OR REPLACE INTO retrieval_generations VALUES(?,?,?)", (aid, generation, self.policy["policy_key"]))

        for i, unit in enumerate(units):
            uid = f"{aid}:{i}"
            metadata = {k: v for k, v in unit.items() if k not in ("vector", "codes")}
            metadata["vector_id"] = f"{generation}:{i}"
            metadata["policy_key"] = self.policy["policy_key"]
            db.execute(
                "INSERT INTO retrieval_units VALUES(?,?,?,?)",
                (uid, aid, source["kind"], json.dumps(metadata)),
            )
            if source["kind"] == "txt":
                db.execute("INSERT INTO retrieval_fts(unit_id, asset_id, content) VALUES(?,?,?)", (uid, aid, unit["text"]))

    def profile_units(self, db: Any, asset_id: str):
        """Read the published profiling generation, excluding Discovery-only units.

        Unit IDs are opaque. Source positions order records/passages, while the
        generation and encoder policy identify which embeddings profiling owns.
        """
        return db.execute(
            """SELECT u.id, u.data FROM retrieval_units u
               JOIN retrieval_generations g ON g.asset_id=u.asset_id
               WHERE u.asset_id=? AND g.policy_key=?
                 AND json_extract(u.data, '$.policy_key')=g.policy_key
                 AND substr(json_extract(u.data, '$.vector_id'), 1, length(g.generation)+1)=g.generation||':'
               ORDER BY COALESCE(json_extract(u.data, '$.record_index'),
                                 json_extract(u.data, '$.start'), 0), u.id""",
            (asset_id, self.policy['policy_key']),
        ).fetchall()

    def fetch(self, db: Any, unit_ids: List[str]) -> List[List[float]]:
        from vector_store import vectors

        refs = []
        for uid in unit_ids:
            row = db.execute("SELECT data FROM retrieval_units WHERE id=?", (uid,)).fetchone()
            if not row:
                raise ValueError("Indexed unit removed during discovery")
            refs.append(json.loads(row["data"])["vector_id"])

        v = vectors(self.store, representation_key=self.policy["policy_key"], dimension=self.policy["dimensions"])
        found = v.fetch(refs)
        return [found[r] for r in refs]

    def search(self, source: Dict[str, Any], check: Any, top_k: int = 5) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        from profiling import terms
        from vector_store import vectors
        import numpy as np

        aid = source["asset_id"]
        neighbors = {}
        comparisons = 0
        v = vectors(self.store, representation_key=self.policy["policy_key"], dimension=self.policy["dimensions"])

        with self.store.db() as db:
            anchors = self.profile_units(db, aid)
            query_vectors = self.fetch(db, [r["id"] for r in anchors])
            generations = [
                r[0]
                for r in db.execute(
                    "SELECT generation FROM retrieval_generations WHERE policy_key=?",
                    (self.policy["policy_key"],),
                ).fetchall()
            ]
            # Preload text retrieval_units to eliminate N+1 queries in the inner loop
            txt_units = {}
            for r in db.execute("SELECT id, asset_id, data FROM retrieval_units WHERE kind='txt'"):
                txt_units[r["id"]] = (r["asset_id"], json.loads(r["data"]))

            for anchor, query_vector in zip(anchors, query_vectors):
                check()
                query = json.loads(anchor["data"])
                words = list(dict.fromkeys(terms(query["text"])))[:12]
                lexical = []
                if words:
                    match = " OR ".join('"' + w.replace('"', '""') + '"' for w in words)
                    lexical = [
                        r["unit_id"]
                        for r in db.execute(
                            "SELECT unit_id FROM retrieval_fts WHERE retrieval_fts MATCH ? ORDER BY rank LIMIT 32",
                            (match,),
                        )
                    ]
                hits = {r["unit_id"]: r["vector"] for r in v.search(query_vector, generations)}
                missing = [uid for uid in lexical if uid not in hits]
                hits.update(zip(missing, self.fetch(db, missing)))
                for uid, vector in hits.items():
                    check()
                    unit_info = txt_units.get(uid)
                    if not unit_info:
                        r = db.execute("SELECT asset_id, data FROM retrieval_units WHERE id=?", (uid,)).fetchone()
                        if not r:
                            continue
                        unit_info = (r["asset_id"], json.loads(r["data"]))
                        txt_units[uid] = unit_info
                    text_aid, unit = unit_info

                    similarity = float(np.dot(np.asarray(query_vector, dtype="float32"), np.asarray(vector, dtype="float32")))
                    comparisons += 1
                    islex = uid in lexical
                    # High-recall filtering:
                    # - Semantic-only hits require solid similarity (>= 0.55)
                    # - Lexical hits require a gentle positive similarity floor (>= 0.10) to reject orthogonal/negative noise
                    if not islex and similarity < 0.55:
                        continue
                    if islex and similarity < 0.10:
                        continue
                    score = max(0, similarity) * 0.7 + (0.3 / (1 + lexical.index(uid) / 10) if islex else 0)
                    candidate = {
                        "table": aid,
                        "text": text_aid,
                        "score": round(score, 6),
                        "semantic_similarity": round(similarity, 6),
                        "shared_terms": sorted(set(words) & set(terms(unit["text"])))[:6],
                        "channels": ["semantic"] + (["lexical"] if islex else []),
                        "status": "unverified candidate",
                        "evidence": {
                            "row_index": query.get("record_index"),
                            "start": unit.get("start"),
                            "end": unit.get("end"),
                            "preview": unit["text"][:180],
                        },
                    }
                    old = neighbors.get(text_aid)
                    if not old or candidate["score"] > old["score"]:
                        neighbors[text_aid] = candidate
        return (
            sorted(neighbors.values(), key=lambda c: (-c["score"], c["text"]))[:top_k],
            {"scored_passages": comparisons, "expanded_queries": 0, "anchors": len(anchors)},
        )
