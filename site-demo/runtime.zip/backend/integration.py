import collections, json, threading, io, csv, copy, hashlib, time
import discovery, settings
from schema_policy import effective_schema

VERSION = "semantic-joins-v5.1"


def validate_schema(value):
    import re
    if not isinstance(value, dict) or not ({'mode', 'labels', 'definitions'}.issubset(set(value)) and set(value).issubset({'mode', 'labels', 'definitions', 'prompt_id', 'context_config', 'preset'})):
        raise ValueError('A schema requires mode, labels and definitions')
    if value['mode'] not in ('strict', 'hybrid', 'open'):
        raise ValueError('Unknown schema mode')
    labels, definitions = value['labels'], value['definitions']
    if not isinstance(labels, list) or len(labels) > 100 or any(
        not isinstance(label, str) or not re.fullmatch(r'[A-Z0-9_]{2,64}', label) for label in labels
    ):
        raise ValueError('Use at most 100 canonical predicate labels')
    if not isinstance(definitions, dict) or len(definitions) > 100 or any(
        not isinstance(label, str) or not re.fullmatch(r'[A-Z0-9_]{2,64}', label)
        or not isinstance(text, str) or len(text) > 1200 for label, text in definitions.items()
    ):
        raise ValueError('Invalid predicate definitions')
    res = {
        'mode': value['mode'],
        'labels': list(dict.fromkeys(labels + ['NEGATIVE', 'UNRESOLVED'])),
        'definitions': dict(definitions),
    }
    if 'prompt_id' in value:
        res['prompt_id'] = value['prompt_id']
    if 'context_config' in value:
        res['context_config'] = value['context_config']
    if 'preset' in value:
        res['preset'] = value['preset']
    return effective_schema(res)


def schema_settings(store, value=None):
    if value is not None:
        value = validate_schema(value)
    with store.lock, store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS integration_schema(id INTEGER PRIMARY KEY,data TEXT)')
        if value is not None:
            db.execute('INSERT OR REPLACE INTO integration_schema VALUES(1,?)', (json.dumps(value),))
            if hasattr(store, 'root') and (store.root / 'lake_config.json').is_file():
                try:
                    import lake_config
                    cfg = lake_config.read_lake_config(store)
                    cfg['schema_config'] = dict(value)
                    if 'prompt_id' in value:
                        cfg['prompt_id'] = value['prompt_id']
                    path = lake_config.lake_config_path(store)
                    temp_path = store.root / "lake_config.json.tmp"
                    temp_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
                    temp_path.replace(path)
                except Exception:
                    pass
        row = db.execute('SELECT data FROM integration_schema WHERE id=1').fetchone()
    if row:
        res = json.loads(row['data'])
        if 'prompt_id' not in res and hasattr(store, 'root') and (store.root / 'lake_config.json').is_file():
            try:
                import lake_config
                cfg = lake_config.read_lake_config(store)
                if 'prompt_id' in cfg:
                    res['prompt_id'] = cfg['prompt_id']
            except Exception:
                pass
        return effective_schema(res)
    if hasattr(store, 'root') and (store.root / 'lake_config.json').is_file():
        try:
            import lake_config
            cfg = lake_config.read_lake_config(store)
            res = dict(cfg.get('schema_config', {}))
            if 'prompt_id' in cfg:
                res['prompt_id'] = cfg['prompt_id']
            return effective_schema(res)
        except Exception:
            pass
    import lake_config
    return lake_config.default_lake_config()["schema_config"]


def resumable_checkpoint(store, revision):
    from evidence_storage import decode
    with store.db() as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='semantic_checkpoint'").fetchone():
            return None
        checkpoint = db.execute("SELECT * FROM semantic_checkpoint WHERE id=1 AND state='active'").fetchone()
    if not checkpoint or checkpoint['revision'] != revision:
        return None
    saved = decode(checkpoint['data'])
    saved_schema = saved.get('schema_config')
    # Older checkpoints are resumable only when their policy matches the default
    # schema. Never guess the schema of an older custom-schema checkpoint.
    if checkpoint['policy'] != semantic.policy_key(settings.read(store)['llm'], saved_schema):
        return None
    return {**{k: checkpoint[k] for k in ('budget', 'total', 'completed')},
            'fingerprint': checkpoint['fingerprint'], 'schema_config': saved_schema,
            'mode': saved.get('mode', 'new'), 'base_run_id': saved.get('base_run_id'),
            'base_revision': saved.get('base_revision')}


def content_revision(plan):
    return hashlib.sha256(json.dumps(plan, sort_keys=True).encode()).hexdigest()


def apply_curation(decisions, operations):
    """Replay user naming decisions without changing the model's stored output."""
    result = copy.deepcopy(decisions)
    for operation in operations:
        sources, target = set(operation['sources']), operation['target']
        for decision in result:
            for path in decision.get('path_decisions', []):
                if path.get('relationship') in sources:
                    path['relationship'] = target
            for field in ('relations', 'pathways', 'supported_pathways'):
                if field in decision:
                    decision[field] = list(dict.fromkeys(target if label in sources else label
                                                        for label in decision[field]))
    return result


def relationship_definition(schema, sources, target, explicit=None, require_review=False):
    if explicit: return explicit
    definitions = (schema or {}).get('definitions', {})
    values = list(dict.fromkeys(definitions[s].strip() for s in list(sources) + [target]
                                if isinstance(definitions.get(s), str) and definitions[s].strip()))
    if require_review and len(values) > 1:
        raise ValueError('These relationships have different definitions. Choose or write the merged definition before accepting.')
    # Legacy operations without a recorded definition retain their old fallback.
    return definitions.get(target) or (values[0] if values else None)


def curated_schema(schema, operations):
    if not isinstance(schema, dict):
        return schema
    result = copy.deepcopy(schema)
    for edit in operations:
        definition = relationship_definition(result, edit['sources'], edit['target'], edit.get('definition'))
        result['labels'] = list(dict.fromkeys(edit['target'] if label in edit['sources'] else label
                                             for label in result['labels']))
        if edit['target'] not in result['labels']:
            result['labels'].append(edit['target'])
        for source in edit['sources']:
            if source != edit['target']:
                result['definitions'].pop(source, None)
        if definition:
            result['definitions'][edit['target']] = definition
    return result


def setup(store):
    with store.db() as db:
        db.execute(
            "CREATE TABLE IF NOT EXISTS integration_rows(plan_id TEXT,idx INTEGER,data TEXT,PRIMARY KEY(plan_id,idx))"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS integration_job(id INTEGER PRIMARY KEY,data TEXT)"
        )
        db.execute(
            "CREATE TABLE IF NOT EXISTS integration_plans(id TEXT PRIMARY KEY,revision TEXT,sources TEXT,data TEXT,materialized INTEGER DEFAULT 0,created REAL)"
        )


def pin_saved(db):
    db.execute('CREATE TABLE IF NOT EXISTS integration_evidence(id TEXT PRIMARY KEY,data BLOB)')
    db.execute('CREATE TABLE IF NOT EXISTS integration_evidence_refs(plan_id TEXT,link_id TEXT,PRIMARY KEY(plan_id,link_id))')
    if not db.execute("SELECT 1 FROM sqlite_master WHERE name='integration_plans'").fetchone():return
    import re
    def ids(value):
        if isinstance(value,dict):
            for item in value.values():yield from ids(item)
        elif isinstance(value,list):
            for item in value:yield from ids(item)
        elif isinstance(value,str) and re.fullmatch('[a-f0-9]{64}',value):yield value
    for row in db.execute('SELECT id,data FROM integration_plans').fetchall():
        for lid in set(ids(json.loads(row['data']))):
            link=db.execute('SELECT data FROM discovery_links WHERE id=?',(lid,)).fetchone()
            if link:db.execute('INSERT OR IGNORE INTO integration_evidence VALUES(?,?)',(lid,link['data']))
            if db.execute('SELECT 1 FROM integration_evidence WHERE id=?',(lid,)).fetchone():
                db.execute('INSERT OR IGNORE INTO integration_evidence_refs VALUES(?,?)',(row['id'],lid))


def snapshot(store):
    state = discovery.status(store)
    if state["status"] != "ready":
        raise ValueError("Run current LOKI discovery before integration")
    return state["revision"]


def remove_sources(db, ids):
    for table in ("semantic_labels", "semantic_rank_cache", "semantic_checkpoint"):
        if db.execute("SELECT 1 FROM sqlite_master WHERE name=?", (table,)).fetchone():
            db.execute("DELETE FROM " + table)
    if not db.execute(
        "SELECT 1 FROM sqlite_master WHERE name='integration_plans'"
    ).fetchone():
        return
    for row in db.execute("SELECT id,sources FROM integration_plans").fetchall():
        if set(ids) & set(json.loads(row["sources"])):
            db.execute("DELETE FROM integration_rows WHERE plan_id=?", (row["id"],))
            db.execute("DELETE FROM integration_plans WHERE id=?", (row["id"],))

    import knowledge
    knowledge.prune_removed_runs(db)
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='relationship_suggestions'").fetchone():
        db.execute('DELETE FROM relationship_suggestions WHERE plan_id NOT IN (SELECT id FROM integration_plans)')
    if db.execute("SELECT 1 FROM sqlite_master WHERE name='integration_evidence_refs'").fetchone():
        db.execute('DELETE FROM integration_evidence_refs WHERE plan_id NOT IN (SELECT id FROM integration_plans)')
        db.execute('DELETE FROM integration_evidence WHERE id NOT IN (SELECT link_id FROM integration_evidence_refs)')


def status(store):
    with store.lock:
        return _status(store)


def rename_run(store, pid, data):
    title = data.get('title')
    if not isinstance(title, str) or not title.strip() or len(title) > 120:
        raise ValueError('Run name must contain 1–120 characters')
    with store.lock:
        with store.db() as db:
            row = db.execute('SELECT data FROM integration_plans WHERE id=?', (pid,)).fetchone()
            if not row:
                raise KeyError('Integration run not found')
            plan = json.loads(row['data'])
            plan['title'] = title.strip()
            db.execute('UPDATE integration_plans SET data=? WHERE id=?', (json.dumps(plan), pid))
    return {'id': pid, 'title': title.strip()}


def remove_run(store, pid):
    with store.lock:
        if getattr(store, 'integration_active', False):
            raise ValueError('Wait for integration to finish before removing a run')
        with store.db() as db:
            if not db.execute('SELECT 1 FROM integration_plans WHERE id=?', (pid,)).fetchone():
                raise KeyError('Integration run not found')
            db.execute('DELETE FROM integration_rows WHERE plan_id=?', (pid,))
            db.execute('DELETE FROM integration_plans WHERE id=?', (pid,))
            if db.execute("SELECT 1 FROM sqlite_master WHERE name='integration_materialization_receipts'").fetchone():
                db.execute('DELETE FROM integration_materialization_receipts WHERE run=?', (pid,))
            import knowledge
            knowledge.prune_removed_runs(db)
            if db.execute("SELECT 1 FROM sqlite_master WHERE name='relationship_suggestions'").fetchone():
                db.execute('DELETE FROM relationship_suggestions WHERE plan_id=?', (pid,))
            if db.execute("SELECT 1 FROM sqlite_master WHERE name='integration_evidence_refs'").fetchone():
                db.execute('DELETE FROM integration_evidence_refs WHERE plan_id=?', (pid,))
                db.execute('DELETE FROM integration_evidence WHERE id NOT IN (SELECT link_id FROM integration_evidence_refs)')
            row = db.execute('SELECT data FROM integration_job WHERE id=1').fetchone()
            if row and json.loads(row['data']).get('plan_id') == pid:
                db.execute('DELETE FROM integration_job WHERE id=1')
    return {'removed': pid}


def relationship_merge_scope(plan, sources, target=None):
    """Whole-run merges require one identifiable, disjoint source-table pair.

    Include an existing target: renaming into it also merges its occurrences.
    A rename to an unused name does not combine relationship types.
    """
    selected = set(sources)
    values = plan.get('output') if 'output' in plan else rows(plan)
    existing = {r['relation'] for r in values}
    existing.update(label for d in plan.get('decisions', []) for label in d.get('relations', []))
    existing.update(p.get('relationship') for d in plan.get('decisions', []) for p in d.get('path_decisions', []))
    if target in existing: selected.add(target)
    if len(selected) < 2: return {'reason': None, 'tables': []}
    cases = {c['candidate']: c for c in plan.get('cases', [])}
    pairs, found, names = set(), set(), {}
    for value in values:
        if value['relation'] not in selected: continue
        case = cases.get(value['candidate'])
        if not case or not case.get('left', {}).get('source') or not case.get('right', {}).get('source'):
            return {'reason': 'Cannot merge: source-table identity is unavailable for these relationships.', 'tables': []}
        a, b = case['left']['source'], case['right']['source']
        if a == b: return {'reason': 'Cannot merge: relationships must connect two distinct source tables.', 'tables': []}
        pairs.add(tuple(sorted((a, b)))); found.add(value['relation'])
        names.update({a: case['left'].get('name', a), b: case['right'].get('name', b)})
    if selected - found:
        return {'reason': 'Cannot merge: every relationship needs output rows with identifiable source tables.', 'tables': []}
    if len(pairs) != 1:
        return {'reason': 'Cannot merge: selected relationships (including an existing target) span different source-table pairs. Keep them separate or edit a table-pair scope in the Knowledge Graph.', 'tables': []}
    pair = next(iter(pairs))
    return {'reason': None, 'tables': [{'id': source, 'name': names[source]} for source in pair]}


def remap_relationships(store, pid, data):
    import re
    if not isinstance(data, dict):
        raise ValueError('Invalid request data')
    sources = data.get('sources')
    target = data.get('target')
    definition = data.get('definition')
    add_to_schema = data.get('add_to_schema', False)
    if type(add_to_schema) is not bool:
        raise ValueError('add_to_schema must be a boolean')

    if not isinstance(sources, list) or not sources:
        raise ValueError('sources must be a non-empty list of relationship names')
    if any(not isinstance(s, str) for s in sources):
        raise ValueError('Relationship names must be strings')
    sources = [s.strip() for s in sources]
    if any(not s for s in sources):
        raise ValueError('Relationship names in sources cannot be empty')

    if not isinstance(target, str) or not target.strip():
        raise ValueError('Target relationship name is required')
    target = target.strip()
    if not re.fullmatch(r'[A-Z0-9_]{2,64}', target):
        raise ValueError(f"Invalid target relationship name '{target}'. Must be 2–64 uppercase letters, numbers, or underscores.")
    if target in ('NEGATIVE', 'UNRESOLVED'):
        raise ValueError(f"'{target}' is a reserved label and cannot be used as a target relationship.")
    if any(s in ('NEGATIVE', 'UNRESOLVED') for s in sources):
        raise ValueError('Reserved labels cannot be remapped')
    if len(sources) == 1 and sources[0] == target and not definition and not add_to_schema:
        raise ValueError('Target relationship name must be different from source relationship')
    if definition is not None:
        if not isinstance(definition, str) or len(definition) > 1200:
            raise ValueError('Predicate definition must be a string up to 1200 characters')
        definition = definition.strip()

    setup(store)
    with store.lock:
        with store.db() as db:
            row = db.execute('SELECT data, materialized FROM integration_plans WHERE id=?', (pid,)).fetchone()
            if not row:
                raise KeyError('Integration run not found')
            plan = json.loads(row['data'])
            if data.get('expected_revision') and data['expected_revision'] != content_revision(plan):
                raise ValueError('Integration run changed; reload its suggestions before accepting a merge')
            materialized = bool(row['materialized'])

            # Verify that at least one of the source relationships exists in the plan
            plan_rels = {r['relation'] for r in rows(plan)} | {r for d in plan.get('decisions', []) for r in d.get('relations', [])}
            plan_rels |= {pd.get('relationship') for d in plan.get('decisions', []) for pd in d.get('path_decisions', []) if pd.get('relationship')}
            source_set = set(sources)
            if source_set - plan_rels:
                raise ValueError('Unknown relationships in this run: ' + ', '.join(sorted(source_set - plan_rels)))

            scope = relationship_merge_scope({**plan, 'output': rows(plan)}, sources, target)
            if scope['reason']: raise ValueError(scope['reason'])
            definition = relationship_definition(plan.get('schema_config'), sources, target, definition, require_review=True)

            # Old runs may already have been curated before audit records existed.
            # Preserve what we have, without claiming to recover lost model output.
            if 'model_decisions' not in plan:
                plan['model_decisions'] = copy.deepcopy(plan.get('decisions', []))
                plan['inference_schema_config'] = copy.deepcopy(plan.get('schema_config'))
                plan['provenance_status'] = 'legacy_baseline_original_labels_unverified'
            plan.setdefault('curation', []).append({'sources': sorted(source_set), 'target': target,
                                                   'definition': definition, 'created': time.time()})

            # Validate schema changes before writing; save everything in this transaction.
            if add_to_schema:
                db.execute('CREATE TABLE IF NOT EXISTS integration_schema(id INTEGER PRIMARY KEY,data TEXT)')
                schema_row = db.execute('SELECT data FROM integration_schema WHERE id=1').fetchone()
                import lake_config
                cur_schema = json.loads(schema_row['data']) if schema_row else copy.deepcopy(plan.get('schema_config')) or lake_config.default_lake_config()['schema_config']
                cur_schema['labels'] = list(dict.fromkeys(cur_schema['labels'] + [target]))
                if definition:
                    cur_schema['definitions'][target] = definition
                cur_schema = validate_schema(cur_schema)

            # Scoped KG edits preserve raw decisions. Replay whole-run renames over
            # their emitted rows too, without invalidating immutable row selectors.
            if plan.get('relationship_row_edits'):
                edits=plan['relationship_row_edits']
                for emitted in rows(plan):
                    if emitted['relation'] in source_set:
                        for key in emitted['origin_row_keys']:edits[key]=target
            # Update raw decisions only for plans without scoped row curation.
            for d in ([] if plan.get('relationship_row_edits') else plan.get('decisions', [])):
                # 1. Update path_decisions
                for pd in d.get('path_decisions', []):
                    if pd.get('relationship') in source_set:
                        pd['relationship'] = target

                # 2. Update relations
                if 'relations' in d:
                    new_rels = []
                    for r in d['relations']:
                        nr = target if r in source_set else r
                        if nr not in new_rels:
                            new_rels.append(nr)
                    d['relations'] = new_rels

                # 3. Update pathways
                if 'pathways' in d:
                    new_pw = []
                    for p in d['pathways']:
                        np = target if p in source_set else p
                        if np not in new_pw:
                            new_pw.append(np)
                    d['pathways'] = new_pw

                # 4. Update supported_pathways
                if 'supported_pathways' in d:
                    new_sp = []
                    for sp in d['supported_pathways']:
                        nsp = target if sp in source_set else sp
                        if nsp not in new_sp:
                            new_sp.append(nsp)
                    d['supported_pathways'] = new_sp

            # Update schema_config in plan
            plan['schema_config'] = curated_schema(plan.get('schema_config'), [plan['curation'][-1]])

            # Recompute rows
            updated_rows = rows(plan)

            # If materialized, rewrite integration_rows
            if materialized:
                db.execute('DELETE FROM integration_rows WHERE plan_id=?', (pid,))
                if db.execute("SELECT 1 FROM sqlite_master WHERE name='integration_materialization_receipts'").fetchone():
                    db.execute('DELETE FROM integration_materialization_receipts WHERE run=?', (pid,))
                db.executemany('INSERT INTO integration_rows VALUES(?,?,?)',
                               [(pid, i, json.dumps(r)) for i, r in enumerate(updated_rows)])

            # Update integration_plans table
            db.execute('UPDATE integration_plans SET data=? WHERE id=?', (json.dumps(plan), pid))
            if add_to_schema:
                db.execute('INSERT OR REPLACE INTO integration_schema VALUES(1,?)', (json.dumps(cur_schema),))

    return get(store, pid)


def _status(store):
    setup(store)
    with store.db() as db:
        job = db.execute("SELECT data FROM integration_job WHERE id=1").fetchone()
        plans = db.execute(
            "SELECT id,revision,data,materialized,created FROM integration_plans ORDER BY created DESC LIMIT 30"
        ).fetchall()
    job = json.loads(job["data"]) if job else None
    if (
        job
        and job["status"] in ("queued", "running", "cancelling")
        and not getattr(store, "integration_active", False)
    ):
        job.update(status="interrupted", phase="API restarted; start a new proposal")
        with store.db() as db:
            db.execute(
                "UPDATE integration_job SET data=? WHERE id=1", (json.dumps(job),)
            )
    try:
        revision = snapshot(store)
    except ValueError:
        revision = None
    items = []
    for row in plans:
        p = json.loads(row["data"])
        items.append(
            {
                "id": row["id"],
                "title": p["title"],
                "description": p["description"],
                "counts": p["counts"],
                "materialized": bool(row["materialized"]),
                "stale": row["revision"] != revision or p.get("version") != VERSION,
                "created": row["created"],
                "model": p["model"],
            }
        )
    resume=resumable_checkpoint(store, revision)
    return {"job": job, "plans": items, "discovery_ready": revision is not None,"discovery_revision":revision,"resume":resume}


def get(store, pid):
    setup(store)
    with store.lock:
        with store.db() as db:
            row = db.execute(
                "SELECT * FROM integration_plans WHERE id=?", (pid,)
            ).fetchone()
        if not row:
            raise KeyError("Integration plan not found")
        # Append keeps original source bytes; prior runs remain readable snapshots.
        try: historical=snapshot(store)!=row['revision']
        except ValueError: historical=True
        plan = {**json.loads(row["data"]), "materialized": bool(row["materialized"])}
        if plan.get("version") != VERSION:
            raise ValueError(
                "This legacy concept-match proposal has been retired; run semantic integration again"
            )
        with store.db() as db:
            stored = [
                json.loads(r["data"])
                for r in db.execute(
                    "SELECT data FROM integration_rows WHERE plan_id=? ORDER BY idx",
                    (pid,),
                )
            ]
        return {**plan, 'content_revision': content_revision(json.loads(row['data'])),
                "historical":historical, "output": stored if plan["materialized"] else rows(plan)}


from integration_diff import compare_outputs


def diff(store, pid, previous_id=None):
    setup(store)
    with store.lock:
        current_plan = get(store, pid)
        with store.db() as db:
            cur_row = db.execute("SELECT created FROM integration_plans WHERE id=?", (pid,)).fetchone()
            if not cur_row:
                raise KeyError("Integration plan not found")
            cur_created = cur_row["created"]
            
            if previous_id:
                prev_row = db.execute("SELECT id FROM integration_plans WHERE id=?", (previous_id,)).fetchone()
                if not prev_row:
                    raise KeyError("Previous integration plan not found")
                target_prev_id = prev_row["id"]
            elif current_plan.get('parent_run_id'):
                prev_row = db.execute('SELECT id FROM integration_plans WHERE id=?',
                                      (current_plan['parent_run_id'],)).fetchone()
                target_prev_id = prev_row['id'] if prev_row else None
            else:
                prev_row = db.execute(
                    "SELECT id FROM integration_plans WHERE created < ? ORDER BY created DESC LIMIT 1",
                    (cur_created,)
                ).fetchone()
                target_prev_id = prev_row["id"] if prev_row else None

        curr_output = current_plan.get("output", [])

        if not target_prev_id:
            current_rows = [
                {**r, "diff_status": "added", "diff_notes": "Initial run establishment"}
                for r in curr_output
            ]
            return {
                "has_previous": False,
                "current": {
                    "id": current_plan["id"],
                    "title": current_plan["title"],
                    "created": cur_created,
                    "model": current_plan.get("model", ""),
                },
                "previous": None,
                "counts": {
                    "added": len(current_rows),
                    "changed": 0,
                    "withdrawn": 0,
                    "unchanged": 0,
                    "not_reviewed": 0,
                    "total_current": len(current_rows),
                    "total_previous": 0,
                },
                "rows": current_rows,
            }

        prev_plan = get(store, target_prev_id)
        with store.db() as db:
            prev_created = db.execute("SELECT created FROM integration_plans WHERE id=?", (target_prev_id,)).fetchone()["created"]

        prev_output = prev_plan.get("output", [])

        diff_rows, counts = compare_outputs(current_plan, prev_plan)
        return {
            'has_previous': True,
            'current': {'id': current_plan['id'], 'title': current_plan['title'], 'created': cur_created, 'model': current_plan.get('model', '')},
            'previous': {'id': prev_plan['id'], 'title': prev_plan['title'], 'created': prev_created, 'model': prev_plan.get('model', '')},
            'counts': {**counts, 'total_current': len(curr_output), 'total_previous': len(prev_output)},
            'rows': diff_rows,
        }


def materialize(store, pid, policy='matched-only', scope_id=None, augmentation_run_id=None):
    with store.lock:
        plan = get(store, pid)
        if not plan['counts']['include']:
            raise ValueError('No source-grounded included rows to materialize')
        if policy and policy != 'matched-only':
            import outer_join
            view = outer_join.materialize_outer_view(
                store, pid, policy=policy, scope_id=scope_id, augmentation_run_id=augmentation_run_id
            )
            rows_to_store = view['rows']
        else:
            rows_to_store = rows(plan)
        with store.db() as db:
            db.execute('DELETE FROM integration_rows WHERE plan_id=?', (pid,))
            db.executemany('INSERT INTO integration_rows VALUES(?,?,?)',
                           [(pid, i, json.dumps(row)) for i, row in enumerate(rows_to_store)])
            db.execute('UPDATE integration_plans SET materialized=1 WHERE id=?', (pid,))
            from augmentation_journey import record_materialization
            record_materialization(db, pid, policy, augmentation_run_id if policy != 'matched-only' else None, plan['content_revision'], rows_to_store)
        return {
            'id': pid,
            'rows': rows_to_store,
            'policy': policy,
            'grain': plan.get('grain', 'one_row_per_source_pair_document_relationship')
        }


def export_csv(store, pid, relation=None, policy='matched-only', scope_id=None, augmentation_run_id=None):
    plan = get(store, pid)
    if not plan['materialized']:
        raise ValueError('Materialize this plan before exporting')
    if policy and policy != 'matched-only':
        import outer_join
        return outer_join.export_outer_csv(
            store,
            pid,
            policy=policy,
            scope_id=scope_id,
            relation=relation,
            augmentation_run_id=augmentation_run_id,
        )
    if relation is not None and relation not in {r['relation'] for r in plan['output']}:
        raise ValueError('Unknown relationship table')
    data = []
    for original in plan['output']:
        if relation is not None and original['relation'] != relation:
            continue
        row = dict(original)
        for side, clinical_label, neutral_label in (('left', 'Diagnosis', 'Record_A'), ('right', 'Medication', 'Record_B')):
            for i, (column, value) in enumerate(zip(row[side + '_columns'], row[side + '_cells'])):
                row[f'{clinical_label}[{i+1}].{column}'] = value
                row[f'{neutral_label}[{i+1}].{column}'] = value
        data.append(row)
    out = io.StringIO(newline='')
    writer = csv.writer(out)
    fields = list(dict.fromkeys(k for row in data for k in row))
    writer.writerow(fields)
    for row in data:
        values = []
        for k in fields:
            v = json.dumps(row.get(k, ''), ensure_ascii=False) if isinstance(row.get(k), (list, dict)) else str(row.get(k, ''))
            values.append("'" + v if v.lstrip().startswith(('=', '+', '-', '@')) else v)
        writer.writerow(values)
    return out.getvalue().encode('utf-8-sig')


def start(store, data):
    data = dict(data)
    mode = data.get('mode', 'new')
    if mode not in ('new', 'extend', 'rebuild'):
        raise ValueError('Choose new, extend or rebuild integration')
    if data.get('schema_config') is None: data['schema_config'] = schema_settings(store)
    if not isinstance(data['schema_config'], dict): raise ValueError('Invalid schema configuration')
    if 'schema_config' in data and isinstance(data['schema_config'], dict):
        if hasattr(store, 'root') and (store.root / 'lake_config.json').is_file():
            try:
                import lake_config
                lake_cfg = lake_config.read_lake_config(store)
                lake_pid = lake_cfg.get('prompt_id')
                if 'prompt_id' not in data['schema_config'] and lake_pid:
                    data['schema_config']['prompt_id'] = lake_pid
                if 'context_config' not in data['schema_config'] and 'context_config' in lake_cfg:
                    data['schema_config']['context_config'] = lake_cfg['context_config']
            except Exception:
                pass
        data['schema_config'] = validate_schema(data['schema_config'])
    limit = data.get('limit', 12)
    timeout = data.get('timeout', settings.read(store)['llm']['timeout_seconds'])
    if type(limit) != int or not 1 <= limit <= 5000:
        raise ValueError('Review between 1 and 5000 row-pair candidates')
    if type(timeout) != int or timeout < 0:
        raise ValueError('Generation timeout must be nonnegative seconds; 0 means no timeout')
    setup(store)
    with store.lock:
        if any(getattr(store, k, False) for k in ('profile_active', 'discovery_active', 'integration_active', 'restarting')):
            raise ValueError('Wait for the active job before integration')
        revision = snapshot(store)
        if data.get('resume'):
            checkpoint = resumable_checkpoint(store, revision)
            if data.get('new_batch') or not checkpoint or checkpoint['fingerprint'] != data['resume']:
                raise ValueError('The original batch is no longer resumable. Refresh and start a new batch.')
            limit = checkpoint['budget']
            data['schema_config'] = checkpoint['schema_config']
            mode = checkpoint['mode']
            data.update({k: checkpoint[k] for k in ('base_run_id', 'base_revision')})
        if mode in ('extend', 'rebuild'):
            if not data.get('base_run_id') or not data.get('base_revision'):
                raise ValueError('Select a base run and its current revision')
            base = get(store, data['base_run_id'])
            if base['content_revision'] != data['base_revision']:
                raise ValueError('The selected run changed. Refresh before continuing.')
            if mode == 'extend':
                data['schema_config'] = base.get('inference_schema_config', base.get('schema_config'))
        config = settings.read(store)['llm']
        if config['provider'] == 'disabled' or not config['model']:
            raise ValueError('Configure an LLM provider and model in Settings')
        store.integration_active = True
        store.integration_cancel = threading.Event()
        job = {'operation': data.get('operation', 'integration'), 'status': 'queued',
               'phase': 'Preparing grounded candidates', 'completed': 0, 'total': limit}
        with store.db() as db:
            db.execute('INSERT OR REPLACE INTO integration_job VALUES(1,?)', (json.dumps(job),))

    def update(**kw):
        with store.lock:
            job.update(kw)
            with store.db() as db:
                db.execute('UPDATE integration_job SET data=? WHERE id=1', (json.dumps(job),))

    def check():
        if store.integration_cancel.is_set():
            raise InterruptedError('Integration cancelled')

    def work():
        try:
            update(status='running')
            if data.get('operation') == 'relationship_probe':
                import relationship_probe
                result = relationship_probe.probe_dataset(store, limit, timeout, check=check, progress=update)
                with store.lock:
                    check()
                    if snapshot(store) != revision:
                        raise ValueError('Discovery changed during probing; rerun the probe')
                    update(status='failed' if result['status'] == 'failed' else 'complete',
                           phase='All probe requests failed validation or execution' if result['status'] == 'failed' else 'Relationship sample reviewed',
                           result=result)
                return
            options = {'check': check, 'progress': update}
            if mode != 'new' or data.get('mode'):
                options.update(mode=mode, base_run_id=data.get('base_run_id'), base_revision=data.get('base_revision'))
            if data.get('new_batch') is True: options['new_batch'] = True
            if 'schema_config' in data: options['schema_config'] = data['schema_config']
            if data.get('resume'): options['resume_key'] = data['resume']
            plan = run(store, limit, timeout, **options)
            batch = plan.get('batch', {})
            label = {'new': 'New run', 'extend': 'Extension', 'rebuild': 'Rebuilt run'}[mode]
            details = f" · {batch.get('retained', 0)} retained · {batch['run_total']} total candidates" if 'run_total' in batch else ''
            update(status='complete', phase=label + ' ready for review' + details, plan_id=plan['id'])
        except InterruptedError:
            update(status='cancelled', phase='Cancelled; no proposal published')
        except Exception as e:
            update(status='failed', phase=str(e))
        finally:
            if config.get('provider') == 'huggingface' and config.get('auto_unload'):
                try:
                    import hf_model_manager
                    hf_model_manager.unload_model()
                except Exception:
                    pass
            with store.lock:
                store.integration_active = False

    store.integration_future = store.pool.submit(work)
    return status(store)


def cancel(store):
    with store.lock:
        if getattr(store, 'integration_active', False):
            store.integration_cancel.set()
            future = getattr(store, 'integration_future', None)
            queued = bool(future and future.cancel())
            if queued:
                store.integration_active = False
            with store.db() as db:
                row = db.execute('SELECT data FROM integration_job WHERE id=1').fetchone()
                job = json.loads(row['data'])
                job.update(status='cancelled' if queued else 'cancelling',
                           phase='Cancelled' if queued else 'Waiting for in-flight LLM request; its response will be discarded')
                db.execute('UPDATE integration_job SET data=? WHERE id=1', (json.dumps(job),))
    return status(store)


import semantic
from semantic import run, rows

