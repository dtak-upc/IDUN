"""Open extraction never inherits domain relationship vocabularies."""
import copy
RESERVED = ['NEGATIVE', 'UNRESOLVED']
DEFINITIONS = {
    'NEGATIVE': 'The evidence explicitly rejects or indicates no relationship between the records.',
    'UNRESOLVED': 'Insufficient evidence to determine a relationship between the records.',
}

def effective_schema(schema, prompt_id=None):
    result = copy.deepcopy(schema)
    if prompt_id is not None: result['prompt_id'] = prompt_id
    if result.get('mode') == 'open':
        result['labels'] = list(RESERVED)
        result['definitions'] = dict(DEFINITIONS)
    return result
