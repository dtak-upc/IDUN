import copy
import csv
import hashlib
import io
import json
import re
import time
import uuid
from collections import Counter

import inference
import lake_config
import typed_extraction


def policy(store):
    path = store.root / 'lake_config.json'
    config = json.loads(path.read_text(encoding='utf-8')) if path.exists() else lake_config.default_lake_config()
    return config.get('projection_policy', lake_config.DEFAULT_PROJECTION_POLICY)


def column_kind(values, name):
    if inference.suggest_technical_identifiers([name]):
        return 'identifier'
    if not values:
        return 'no_seeds'
    if values['numeric_or_date'] == values['observed']:
        return 'typed'
    if values['numeric_or_date']:
        return 'mixed'
    return 'qualitative'


def new_table(aid, name, version, columns):
    return {'id': aid, 'name': name, 'version': version, 'rows': 0, 'rows_with_gaps': 0,
            'malformed_rows': 0, 'columns': [{'index': i, 'name': name, 'missing': 0,
                'observed': 0, 'numeric_or_date': 0} for i, name in columns]}


def add_row(table, cells, null_tokens, projected=False):
    gaps = 0
    table['rows'] += 1
    for col in table['columns']:
        value = cells[col['index']]
        # Integration cells are already projected. Reinterpreting literal NULL/NA here
        # would turn escaped source literals back into missing values.
        missing = value is None or (value == '' if projected else inference.resolve_cell_value(value, null_tokens)[1])
        if missing:
            col['missing'] += 1
            gaps += 1
        else:
            col['observed'] += 1
            text = str(value).strip()
            if re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?', text) or re.fullmatch(r'\d{4}-\d{2}-\d{2}(?:[T ].*)?', text):
                col['numeric_or_date'] += 1
    table['rows_with_gaps'] += bool(gaps)


def finish(tables, scope, revision, **extra):
    columns = []
    for table in tables:
        for col in table['columns']:
            counts = Counter({k: col[k] for k in ('observed', 'numeric_or_date')}) if col['observed'] else Counter()
            col['kind'] = column_kind(counts, col['name'])
            columns.append(col)
    return {'scope': scope, 'revision': revision, 'tables': tables,
            'counts': {'tables': len(tables), 'rows': sum(t['rows'] for t in tables),
                'rows_with_gaps': sum(t['rows_with_gaps'] for t in tables),
                'missing_cells': sum(c['missing'] for c in columns),
                'observed_cells': sum(c['observed'] for c in columns),
                'qualitative_gap_cells': sum(c['missing'] for c in columns if c['kind'] == 'qualitative'),
                'seedless_gap_cells': sum(c['missing'] for c in columns if c['kind'] == 'no_seeds'),
                'malformed_rows': sum(t['malformed_rows'] for t in tables)}, **extra}


def runs(store):
    with store.db() as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='integration_plans'").fetchone():
            return {'runs': []}
        result = []
        for row in db.execute('SELECT id,data,created FROM integration_plans ORDER BY created DESC'):
            p = json.loads(row['data'])
            result.append({'id': row['id'], 'title': p.get('title', row['id']), 'model': p.get('model', ''), 'created': row['created']})
        return {'runs': result}


def assess(store, scope='source', run_id=''):
    if scope not in ('source', 'integration'):
        raise ValueError('Choose source or integration scope')
    projection = policy(store)
    excluded = projection.get('exclude_identifiers', [])
    null_tokens = projection.get('null_tokens', inference.DEFAULT_NULL_TOKENS)
    if scope == 'integration':
        if not run_id:
            raise ValueError('Select an integration run')
        import integration
        with store.db() as db:
            if not db.execute("SELECT 1 FROM sqlite_master WHERE name='integration_plans'").fetchone():
                raise KeyError('Integration run not found')
            stored = db.execute('SELECT data,materialized FROM integration_plans WHERE id=?', (run_id,)).fetchone()
            if not stored:
                raise KeyError('Integration run not found')
            asset_names = dict(db.execute('SELECT id,name FROM assets').fetchall())
            plan = json.loads(stored['data'])
            if plan.get('version') != integration.VERSION:
                raise ValueError('Legacy run cannot be assessed; select a current run')
            plan['content_revision'] = integration.content_revision(plan)
            plan['output'] = ([json.loads(r['data']) for r in db.execute('SELECT data FROM integration_rows WHERE plan_id=? ORDER BY idx', (run_id,))]
                              if stored['materialized'] else integration.rows(plan))
        tables, seen = {}, {}
        cases = {c['candidate']: c for c in plan.get('cases', [])}
        for output in plan.get('output', []):
            for side in ('left', 'right'):
                rid = output.get(side + '_record')
                cols, cells = output.get(side + '_columns'), output.get(side + '_cells')
                if not rid or cols is None or cells is None or len(cols) != len(cells):
                    raise ValueError('Run lacks complete source-cell provenance; cannot assess safely')
                if rid in seen:
                    if seen[rid] != (cols, cells):
                        raise ValueError('Run contains inconsistent copies of a source row')
                    continue
                seen[rid] = (cols, cells)
                aid, version, _ = rid.rsplit(':', 2)
                included = inference.table_columns(cols, excluded)
                key = (aid, version)
                if key not in tables:
                    name = cases.get(output.get('candidate'), {}).get(side, {}).get('name') or asset_names.get(aid, 'Unavailable source table')
                    tables[key] = new_table(aid, name, version, [(i, cols[i]) for i in included])
                if [(c['index'], c['name']) for c in tables[key]['columns']] != [(i, cols[i]) for i in included]:
                    raise ValueError('Inconsistent source schema within this run')
                add_row(tables[key], cells, null_tokens, projected=True)
        return finish(list(tables.values()), scope, plan.get('content_revision', ''), run_id=run_id,
            title=plan.get('title', run_id),
            output_rows=len(plan.get('output', [])), documents=None)
    tables, versions, documents, skipped = [], [], 0, []
    with store.db() as db:
        db.execute('BEGIN')
        jobs = db.execute("SELECT j.asset_id,j.version,a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.status='ready' ORDER BY a.name,a.id").fetchall()
        for job in jobs:
            versions.append([job['asset_id'], job['version']])
            if not job['name'].lower().endswith('.csv'):
                documents += 1
                continue
            header = db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1', (job['asset_id'], job['version'])).fetchone()
            try:
                cols = json.loads(header['data']) if header else []
                included = inference.table_columns(cols, excluded)
            except ValueError as e:
                skipped.append({'id': job['asset_id'], 'name': job['name'], 'reason': str(e)})
                continue
            table = new_table(job['asset_id'], job['name'], job['version'], [(i, cols[i]) for i in included])
            for row in db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx>1 ORDER BY idx', (job['asset_id'], job['version'])):
                cells = json.loads(row['data'])
                if not isinstance(cells, list) or len(cells) != len(cols):
                    table['malformed_rows'] += 1
                    continue
                add_row(table, cells, null_tokens)
            tables.append(table)
    revision = hashlib.sha256(json.dumps([versions, projection], sort_keys=True).encode()).hexdigest()
    return finish(tables, scope, revision, documents=documents, skipped_sources=skipped)


def setup(store):
    with store.db() as db:
        db.execute('''
            CREATE TABLE IF NOT EXISTS augmentation_runs(
                id TEXT PRIMARY KEY,
                lake_id TEXT,
                scope TEXT,
                source_revision TEXT,
                base_run_id TEXT,
                base_revision TEXT,
                config TEXT,
                status TEXT,
                counts TEXT,
                feedback_passes INTEGER DEFAULT 0,
                created REAL,
                updated REAL
            )
        ''')
        cols = [r['name'] for r in db.execute("PRAGMA table_info(augmentation_runs)").fetchall()]
        if 'feedback_passes' not in cols:
            db.execute("ALTER TABLE augmentation_runs ADD COLUMN feedback_passes INTEGER DEFAULT 0")
        db.execute('''
            CREATE TABLE IF NOT EXISTS augmentation_proposals(
                id TEXT PRIMARY KEY,
                run_id TEXT,
                target_id TEXT,
                data TEXT,
                decision TEXT
            )
        ''')
        db.execute('CREATE INDEX IF NOT EXISTS idx_aug_proposals_run ON augmentation_proposals(run_id)')
        db.execute('''
            CREATE TABLE IF NOT EXISTS augmentation_views(
                id TEXT PRIMARY KEY,
                run_id TEXT,
                data TEXT,
                created REAL
            )
        ''')


def recalculate_counts(db, run_id, store=None):
    rows = db.execute('SELECT data, decision FROM augmentation_proposals WHERE run_id=?', (run_id,)).fetchall()
    proposals = [json.loads(r['data']) for r in rows]
    targets = {p['target_id'] for p in proposals}
    saved = db.execute('SELECT counts,config FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
    counts = {**json.loads(saved['counts']),
        'llm_calls': json.loads(db.execute('SELECT counts FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()['counts']).get('llm_calls', 0),
        'targets': len(targets),
        'proposals': len([p for p in proposals if p['decision'] != 'unresolved']),
        'attributed': len([p for p in proposals if p.get('attribution', {}).get('status') == 'attributed']),
        'accepted': len([p for p in proposals if p['decision'] == 'accepted']),
        'rejected': len([p for p in proposals if p['decision'] == 'rejected']),
        'conflicting': len([p for p in proposals if p['decision'] == 'conflicting']),
        'unresolved': len([p for p in proposals if p['decision'] == 'unresolved'])
    }
    if store:
        counts['telemetry'] = typed_extraction.calculate_telemetry(store, run_id)
    db.execute('UPDATE augmentation_runs SET counts=?, updated=? WHERE id=?', (json.dumps(counts), time.time(), run_id))
    config = json.loads(saved['config'])
    if config.get('review', {}).get('status') == 'finalized':
        config['review']['status'] = 'changed'
        db.execute('UPDATE augmentation_runs SET config=? WHERE id=?', (json.dumps(config), run_id))
    return counts


def compile_targets(store, run_id, expand_retrieval=False, selection=None):
    import integration
    with store.db() as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='integration_plans'").fetchone():
            raise KeyError('Integration run not found')
        stored = db.execute('SELECT data,materialized FROM integration_plans WHERE id=?', (run_id,)).fetchone()
        if not stored:
            raise KeyError('Integration run not found')
        asset_names = dict(db.execute('SELECT id,name FROM assets').fetchall())
        plan = json.loads(stored['data'])
        if plan.get('version') != integration.VERSION:
            raise ValueError('Legacy run cannot be assessed; select a current run')
        rows = ([json.loads(r['data']) for r in db.execute('SELECT data FROM integration_rows WHERE plan_id=? ORDER BY idx', (run_id,))]
                if stored['materialized'] else integration.rows(plan))
    projection = policy(store)
    excluded = projection.get('exclude_identifiers', [])
    null_tokens = projection.get('null_tokens', inference.DEFAULT_NULL_TOKENS)

    targets = {}
    for out_idx, output in enumerate(rows):
        for side in ('left', 'right'):
            rid = output.get(f'{side}_record')
            cols = output.get(f'{side}_columns')
            cells = output.get(f'{side}_cells')
            if not rid or cols is None or cells is None or len(cols) != len(cells):
                continue
            parts = rid.rsplit(':', 2)
            aid = parts[0] if len(parts) >= 1 else rid
            version = parts[1] if len(parts) >= 2 else ''
            rec_idx = parts[2] if len(parts) >= 3 else '0'

            if selection and aid != selection['table_id']: continue
            included = inference.table_columns(cols, excluded)
            for c_idx in included:
                if selection and c_idx not in selection['columns']: continue
                val = cells[c_idx]
                is_missing = val is None or val == ''
                if is_missing:
                    col_name = cols[c_idx]
                    target_id = hashlib.sha256(f"{rid}:{c_idx}".encode()).hexdigest()
                    if target_id not in targets:
                        if selection and (len(targets) >= selection['target_limit'] or int(rec_idx) <= 1+selection['row_offset']): continue
                        targets[target_id] = {
                            'id': target_id,
                            'record_id': rid,
                            'asset_id': aid,
                            'version': version,
                            'record_index': rec_idx,
                            'column_index': c_idx,
                            'column_name': col_name,
                            'table_name': asset_names.get(aid, 'Unavailable source table'),
                            'row_context': {cols[i]: cells[i] for i in included if cells[i] not in (None, '')},
                            'expected_type': (selection or {}).get('types', {}).get(str(c_idx), 'string'),
                            'original_value': val,
                            'null_reason': 'empty_cell',
                            'output_references': [],
                            'evidence_contexts': []
                        }
                    targets[target_id]['output_references'].append({
                        'output_idx': out_idx,
                        'side': side,
                        'candidate': output.get('candidate'),
                        'relation': output.get('relation'),
                        'other_record': output.get(f"{'right' if side=='left' else 'left'}_record")
                    })
                    doc_id = output.get('text_source')
                    ev_list = output.get('evidence', [])
                    if ev_list:
                        for p in ev_list:
                            txt = p.get('context_text') or p.get('text') or output.get('evidence_quote', '')
                            start = p.get('context_start', p.get('start', 0))
                            end = p.get('context_end', p.get('end', len(txt)))
                            if selection and len(targets[target_id]['evidence_contexts']) >= selection['contexts_limit']: continue
                            if txt and not any((e.get('document'), e.get('start'), e.get('end'), e.get('text')) == (doc_id, start, end, txt) for e in targets[target_id]['evidence_contexts']):
                                targets[target_id]['evidence_contexts'].append({
                                    'document': doc_id,
                                    'document_name': output.get('text_source_name', doc_id),
                                    'document_version': p.get('text_version'),
                                    'origin_link_ids': [p.get('left'), p.get('right')],
                                    'start': start,
                                    'end': end,
                                    'text': txt,
                                    'evidence_id': p.get('evidence_id', p.get('evidence', ''))
                                })
                    elif output.get('evidence_quote'):
                        txt = output['evidence_quote']
                        if not any(e.get('text') == txt for e in targets[target_id]['evidence_contexts']):
                            targets[target_id]['evidence_contexts'].append({
                                'document': doc_id,
                                'document_name': output.get('text_source_name', doc_id),
                                'start': 0,
                                'end': len(txt),
                                'text': txt,
                                'evidence_id': 'quote'
                            })

    if expand_retrieval:
        with store.db() as db:
            for target in targets.values():
                if not target['evidence_contexts']:
                    has_links = db.execute("SELECT 1 FROM sqlite_master WHERE name='discovery_links'").fetchone()
                    if has_links:
                        links = db.execute("SELECT text_id, data FROM discovery_links WHERE table_id=? LIMIT 5", (target['asset_id'],)).fetchall()
                        for link in links:
                            doc_id = link['text_id']
                            doc_row = db.execute("SELECT data FROM records WHERE asset_id=? AND idx=1", (doc_id,)).fetchone() if db.execute("SELECT 1 FROM sqlite_master WHERE name='records'").fetchone() else None
                            if doc_row:
                                try:
                                    txt_content = json.loads(doc_row['data'])
                                    if isinstance(txt_content, str) and txt_content.strip():
                                        target['evidence_contexts'].append({
                                            'document': doc_id,
                                            'document_name': doc_id,
                                            'start': 0,
                                            'end': len(txt_content),
                                            'text': txt_content[:1500],
                                            'evidence_id': f"expanded_{doc_id}"
                                        })
                                except Exception:
                                    pass

    if selection:
        for target in targets.values():
            target['evidence_contexts'] = target['evidence_contexts'][:selection['contexts_limit']]
    return list(targets.values())


def decode_discovery_data(data):
    if not data:
        return {}
    try:
        import evidence_storage
        return evidence_storage.decode(data)
    except Exception:
        try:
            return json.loads(data)
        except Exception:
            return {}


def compile_source_targets(store, expand_retrieval=False, table_id=None):
    setup(store)
    projection = policy(store)
    excluded = projection.get('exclude_identifiers', [])
    null_tokens = projection.get('null_tokens', inference.DEFAULT_NULL_TOKENS)

    targets = {}
    with store.db() as db:
        has_discovery_links = bool(db.execute("SELECT 1 FROM sqlite_master WHERE name='discovery_links'").fetchone())
        has_fts = bool(db.execute("SELECT 1 FROM sqlite_master WHERE name='retrieval_fts'").fetchone())
        
        jobs = db.execute("SELECT j.asset_id, j.version, a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.status='ready' AND lower(a.name) LIKE '%.csv' ORDER BY a.name, a.id").fetchall()
        txt_jobs = db.execute("SELECT j.asset_id, j.version, a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.status='ready' AND lower(a.name) LIKE '%.txt' ORDER BY a.name, a.id").fetchall()

        for job in jobs:
            aid = job['asset_id']
            version = job['version']
            if table_id and aid != table_id:
                continue
            first = db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1', (aid, version)).fetchone()
            if not first:
                continue
            cols = json.loads(first['data'])
            included = inference.table_columns(cols, excluded)

            # Pre-cache discovery links for this table if available (single-row atomic links)
            table_links_by_record = {}
            if has_discovery_links:
                d_rows = db.execute('SELECT data FROM discovery_links WHERE table_id=?', (aid,)).fetchall()
                for dr in d_rows:
                    link = decode_discovery_data(dr['data'])
                    rid = link.get('record_id')
                    if rid:
                        table_links_by_record.setdefault(rid, []).append(link)

            rows_cursor = db.execute('SELECT idx, data FROM records WHERE asset_id=? AND version=? AND idx>1 ORDER BY idx', (aid, version)).fetchall()
            for row in rows_cursor:
                cells = json.loads(row['data'])
                rec_idx = row['idx']
                rid = f"{aid}:{version}:{rec_idx}"

                # Extract qualitative terms from this row for on-demand text matching
                row_terms = []
                for c_idx in included:
                    val = cells[c_idx]
                    if val and not inference.resolve_cell_value(val, null_tokens)[1]:
                        s_val = str(val).strip()
                        for word in re.findall(r'[A-Za-z0-9_]{2,}', s_val):
                            if word.lower() not in {'null', 'none', 'the', 'and', 'for', 'with', 'from', 'this', 'that'}:
                                row_terms.append(word)

                for c_idx in included:
                    val = cells[c_idx]
                    is_missing = val is None or val == '' or inference.resolve_cell_value(val, null_tokens)[1]
                    if is_missing:
                        col_name = cols[c_idx]
                        target_id = hashlib.sha256(f"{rid}:{c_idx}".encode()).hexdigest()
                        if target_id not in targets:
                            targets[target_id] = {
                                'id': target_id,
                                'record_id': rid,
                                'asset_id': aid,
                                'version': version,
                                'record_index': rec_idx,
                                'column_index': c_idx,
                                'column_name': col_name,
                                'original_value': val,
                                'null_reason': 'empty_cell',
                                'row_cells': cells,
                                'output_references': [],
                                'evidence_contexts': []
                            }

                        ev_contexts = targets[target_id]['evidence_contexts']
                        # 1. From discovery_links (atomic links, no two-row bridge required)
                        if rid in table_links_by_record:
                            for lk in table_links_by_record[rid]:
                                doc_id = lk.get('text', '')
                                txt = lk.get('text_preview', '')
                                start = lk.get('start', 0)
                                end = lk.get('end', len(txt))
                                if txt and not any((e['document'], e['start'], e['end']) == (doc_id, start, end) for e in ev_contexts):
                                    ev_contexts.append({
                                        'document': doc_id,
                                        'document_name': lk.get('text_name', doc_id),
                                        'start': start,
                                        'end': end,
                                        'text': txt,
                                        'evidence_id': lk.get('id', f"link_{doc_id}")
                                    })

                        # 2. On-demand retrieval with bounded work budget (limit 5 contexts)
                        BUDGET = 5
                        if ((not ev_contexts) or expand_retrieval):
                            # FTS5 search
                            if has_fts and row_terms:
                                for term in row_terms[:3]:
                                    if len(ev_contexts) >= BUDGET:
                                        break
                                    try:
                                        fts_rows = db.execute("SELECT unit_id, asset_id, content FROM retrieval_fts WHERE content MATCH ? LIMIT ?", (term, BUDGET - len(ev_contexts))).fetchall()
                                        for f_row in fts_rows:
                                            u_content = f_row['content']
                                            doc_id = f_row['asset_id']
                                            if u_content and not any(e['text'] == u_content for e in ev_contexts):
                                                ev_contexts.append({
                                                    'document': doc_id,
                                                    'document_name': doc_id,
                                                    'start': 0,
                                                    'end': len(u_content),
                                                    'text': u_content,
                                                    'evidence_id': f"fts_{f_row['unit_id']}"
                                                })
                                    except Exception:
                                        pass

                            # Direct text records search fallback
                            if len(ev_contexts) < BUDGET and txt_jobs:
                                for tj in txt_jobs:
                                    if len(ev_contexts) >= BUDGET:
                                        break
                                    t_aid = tj['asset_id']
                                    t_records = db.execute("SELECT idx, start, end, data FROM records WHERE asset_id=? AND version=? LIMIT 10", (t_aid, tj['version'])).fetchall()
                                    for tr in t_records:
                                        if len(ev_contexts) >= BUDGET:
                                            break
                                        try:
                                            t_content = json.loads(tr['data'])
                                            if isinstance(t_content, str):
                                                lower_c = t_content.lower()
                                                if (not row_terms) or any(term.lower() in lower_c for term in row_terms):
                                                    if not any((e['document'], e['text']) == (t_aid, t_content) for e in ev_contexts):
                                                        ev_contexts.append({
                                                            'document': t_aid,
                                                            'document_name': tj['name'],
                                                            'start': tr['start'] or 0,
                                                            'end': tr['end'] or len(t_content),
                                                            'text': t_content[:1500],
                                                            'evidence_id': f"txt_{t_aid}_{tr['idx']}"
                                                        })
                                        except Exception:
                                            pass

    return list(targets.values())


def extract_proposals_for_target(target, concept, engine, extractor, aug_id, now, prompt_snapshot=None, store=None):
    """Extracts candidate proposals for a single target cell according to engine mode."""

    if engine == 'hybrid':
        # THOR supplies observed seeds; the LLM verifies the target-specific value.
        eff_engine = 'typed_llm'
    elif engine == 'typed_llm':
        eff_engine = 'typed_llm'
    else:
        eff_engine = engine

    target_info = {
        'asset_id': target['asset_id'],
        'version': target['version'],
        'record_id': target['record_id'],
        'record_index': target['record_index'],
        'column_index': target['column_index'],
        'column_name': target['column_name'],
        'table_name': target.get('table_name', '')
    }
    output_refs = target.get('output_references', [])

    if eff_engine == 'thor':
        # Check if concept has seeds directly or candidate equivalent
        seeds = concept.get('seeds') if concept else []
        if not seeds and concept and isinstance(concept.get('cold_start'), dict) and concept['cold_start'].get('candidates'):
            # Candidate equivalent columns available
            seeds = concept['cold_start']['candidates'][0].get('seeds', [])

        if not concept or not seeds:
            kind = concept.get('kind', 'unknown') if concept else 'unknown'
            rationale = (
                f"THOR is designed for qualitative phrase matching against observed text seeds. Field '{target['column_name']}' is {kind} without text seeds. Use Hybrid or Typed engine for numeric/date extraction."
                if kind in ('typed', 'mixed', 'numeric')
                else f"Cold-start: Column '{target['column_name']}' has no observed seeds in this table. Use Hybrid engine for rule-based or LLM extraction."
            )
            return [{
                'id': f"prop_{uuid.uuid4().hex[:12]}",
                'run_id': aug_id,
                'engine': 'thor',
                'target_id': target['id'],
                'target': target_info,
                'output_references': output_refs,
                'original_value': target['original_value'],
                'null_reason': 'empty_cell',
                'proposed_value': None,
                'concept': {'id': concept['id'] if concept else '', 'name': target['column_name']},
                'seed': None,
                'evidence': None,
                'scores': {'semantic': 0.0, 'word_overlap': 0.0, 'character': 0.0, 'combined': 0.0},
                'attribution': {'status': 'unresolved', 'rationale': rationale},
                'conflict_group': None,
                'decision': 'unresolved',
                'decision_history': [{'decision': 'unresolved', 'timestamp': now, 'reason': rationale}],
                'typed_data': None
            }]

        if not target.get('evidence_contexts'):
            return [{
                'id': f"prop_{uuid.uuid4().hex[:12]}",
                'run_id': aug_id,
                'engine': 'thor',
                'target_id': target['id'],
                'target': target_info,
                'output_references': output_refs,
                'original_value': target['original_value'],
                'null_reason': 'empty_cell',
                'proposed_value': None,
                'concept': {'id': concept['id'], 'name': concept['name']},
                'seed': None,
                'evidence': None,
                'scores': {'semantic': 0.0, 'word_overlap': 0.0, 'character': 0.0, 'combined': 0.0},
                'attribution': {'status': 'unresolved', 'rationale': 'No evidence text passages associated with target record'},
                'conflict_group': None,
                'decision': 'unresolved',
                'decision_history': [{'decision': 'unresolved', 'timestamp': now, 'reason': 'No evidence passages'}],
                'typed_data': None
            }]

        extractions_for_target = []
        for ctx in target['evidence_contexts']:
            extracted = extractor.extract(
                ctx['text'],
                [concept],
                check_attribution=True
            )
            for cand in extracted:
                cand['evidence_context'] = ctx
                extractions_for_target.append(cand)

        if not extractions_for_target:
            return [{
                'id': f"prop_{uuid.uuid4().hex[:12]}",
                'run_id': aug_id,
                'engine': 'thor',
                'target_id': target['id'],
                'target': target_info,
                'output_references': output_refs,
                'original_value': target['original_value'],
                'null_reason': 'empty_cell',
                'proposed_value': None,
                'concept': {'id': concept['id'], 'name': concept['name']},
                'seed': None,
                'evidence': target['evidence_contexts'][0] if target['evidence_contexts'] else None,
                'scores': {'semantic': 0.0, 'word_overlap': 0.0, 'character': 0.0, 'combined': 0.0},
                'attribution': {'status': 'unresolved', 'rationale': 'No matching phrase met similarity threshold in evidence passages'},
                'conflict_group': None,
                'decision': 'unresolved',
                'decision_history': [{'decision': 'unresolved', 'timestamp': now, 'reason': 'No candidate met threshold'}],
                'typed_data': None
            }]

        distinct_values = {c['value'].strip().lower(): c['value'].strip() for c in extractions_for_target if c['attribution'] == 'attributed'}
        is_conflicting = len(distinct_values) > 1
        conflict_gid = f"conflict_{target['id']}" if is_conflicting else None

        proposals = []
        for cand in extractions_for_target:
            ctx = cand['evidence_context']
            attribution_status = 'conflict' if is_conflicting and cand['attribution'] == 'attributed' else cand['attribution']
            attribution_rationale = (
                f"Conflicting candidates extracted for this cell: {list(distinct_values.values())}"
                if is_conflicting and cand['attribution'] == 'attributed'
                else cand['attribution_rationale']
            )
            decision = (
                'conflicting' if is_conflicting and cand['attribution'] == 'attributed'
                else 'rejected' if cand['attribution'] in ('negated', 'hypothetical', 'wrong_subject')
                else 'proposed'
            )
            prop = {
                'id': f"prop_{uuid.uuid4().hex[:12]}",
                'run_id': aug_id,
                'engine': 'thor',
                'target_id': target['id'],
                'target': target_info,
                'output_references': output_refs,
                'original_value': target['original_value'],
                'null_reason': 'empty_cell',
                'proposed_value': cand['value'],
                'concept': {'id': concept['id'], 'name': concept['name']},
                'seed': cand['seed'],
                'evidence': {
                    'document': ctx['document'],
                    'document_name': ctx.get('document_name', ctx['document']),
                    'start': ctx.get('start', 0) + cand['start'],
                    'end': ctx.get('start', 0) + cand['end'],
                    'text': ctx['text'],
                    'quote': cand['value'],
                    'sentence_start': cand['sentence_start'],
                    'sentence_end': cand['sentence_end'],
                    'document_version': ctx.get('document_version'),
                    'retrieval': ctx.get('retrieval'),
                    'evidence_id': ctx.get('evidence_id', '')
                },
                'scores': cand['scores'],
                'attribution': {'status': attribution_status, 'rationale': attribution_rationale},
                'conflict_group': conflict_gid,
                'decision': decision,
                'decision_history': [{'decision': decision, 'timestamp': now, 'reason': 'Initial THOR extraction'}],
                'typed_data': None
            }
            proposals.append(prop)
        return proposals

    else:
        # eff_engine in ('typed_llm', 'heuristic')
        if not target.get('evidence_contexts'):
            return [{
                'id': f"prop_{uuid.uuid4().hex[:12]}",
                'run_id': aug_id,
                'engine': eff_engine,
                'target_id': target['id'],
                'target': target_info,
                'output_references': output_refs,
                'original_value': target['original_value'],
                'null_reason': 'empty_cell',
                'proposed_value': None,
                'concept': {'id': concept['id'] if concept else '', 'name': target['column_name']},
                'seed': None,
                'evidence': None,
                'scores': {'semantic': 0.0, 'word_overlap': 0.0, 'character': 0.0, 'combined': 0.0},
                'attribution': {'status': 'unresolved', 'rationale': 'No evidence text passages associated with target record'},
                'conflict_group': None,
                'decision': 'unresolved',
                'decision_history': [{'decision': 'unresolved', 'timestamp': now, 'reason': 'No evidence passages'}],
                'typed_data': None
            }]

        concept_dict = dict(concept or {'id': target['column_name'], 'name': target['column_name'], 'kind': 'no_seeds'})
        concept_dict['expected_type'] = target.get('expected_type') or ('numeric' if concept_dict.get('kind') == 'typed' else 'string')
        cands = []
        for ctx in target['evidence_contexts']:
            extracted = typed_extraction.extract_typed_attribute(
                concept_dict, target, ctx, engine_label=eff_engine, store=store, prompt_snapshot=prompt_snapshot
            )
            if extracted and extracted.get('found'):
                cands.append(extracted)

        if not cands:
            engine_title = 'LLM' if eff_engine == 'typed_llm' else 'Rule-based extractor'
            return [{
                'id': f"prop_{uuid.uuid4().hex[:12]}",
                'run_id': aug_id,
                'engine': eff_engine,
                'target_id': target['id'],
                'target': target_info,
                'output_references': output_refs,
                'original_value': target['original_value'],
                'null_reason': 'empty_cell',
                'proposed_value': None,
                'concept': {'id': concept_dict.get('id', ''), 'name': target['column_name']},
                'seed': None,
                'evidence': target['evidence_contexts'][0] if target['evidence_contexts'] else None,
                'scores': {'semantic': 0.0, 'word_overlap': 0.0, 'character': 0.0, 'combined': 0.0},
                'attribution': {'status': 'unresolved', 'rationale': f'{engine_title} found no grounded value in evidence passages'},
                'conflict_group': None,
                'decision': 'unresolved',
                'decision_history': [{'decision': 'unresolved', 'timestamp': now, 'reason': f'No grounded value found via {engine_title}'}],
                'typed_data': None
            }]

        distinct_values = {
            str(c['normalized_value']).strip().lower(): str(c['normalized_value']).strip()
            for c in cands
            if c.get('attribution_status') == 'attributed' and c.get('validation') == 'valid'
        }
        is_conflicting = len(distinct_values) > 1
        conflict_gid = f"conflict_{target['id']}" if is_conflicting else None

        proposals = []
        for c in cands:
            ctx = c['evidence_context']
            cand_eng = c.get('engine', eff_engine)
            attr_status = (
                'conflict' if is_conflicting and c.get('attribution_status') == 'attributed' and c.get('validation') == 'valid'
                else c.get('attribution_status', 'unresolved')
            )
            attr_rationale = (
                f"Conflicting candidates extracted for this cell: {list(distinct_values.values())}"
                if is_conflicting and c.get('attribution_status') == 'attributed' and c.get('validation') == 'valid'
                else c.get('attribution_rationale', '')
            )
            decision = (
                'unresolved' if c.get('validation') != 'valid' or attr_status == 'unresolved'
                else 'conflicting' if is_conflicting and attr_status == 'conflict'
                else 'rejected' if attr_status in ('negated', 'hypothetical', 'wrong_subject')
                else 'proposed'
            )
            typed_info = {
                'type': c.get('value_type', 'numeric'),
                'raw_quoted': c.get('raw_quoted', ''),
                'normalized_value': c.get('normalized_value'),
                'unit': c.get('unit'),
                'temporal_scope': c.get('temporal_scope'),
                'precision': c.get('precision', 'unknown'),
                'validation': c.get('validation', 'valid')
            }
            proposed_val = str(c['normalized_value']) if c.get('validation') == 'valid' else None
            prop = {
                'id': f"prop_{uuid.uuid4().hex[:12]}",
                'run_id': aug_id,
                'engine': cand_eng,
                'target_id': target['id'],
                'target': target_info,
                'output_references': output_refs,
                'original_value': target['original_value'],
                'null_reason': 'empty_cell',
                'proposed_value': proposed_val,
                'concept': {'id': concept_dict.get('id', ''), 'name': target['column_name']},
                'seed': None,
                'evidence': {
                    'document': ctx['document'],
                    'document_name': ctx.get('document_name', ctx['document']),
                    'start': ctx.get('start', 0) + c.get('start', 0),
                    'end': ctx.get('start', 0) + c.get('end', 0),
                    'text': ctx['text'],
                    'quote': c.get('raw_quoted', ''),
                    'sentence_start': c.get('sentence_start', 0),
                    'sentence_end': c.get('sentence_end', len(ctx['text'])),
                    'document_version': ctx.get('document_version'),
                    'retrieval': ctx.get('retrieval'),
                    'evidence_id': ctx.get('evidence_id', '')
                },
                'scores': {'semantic': 1.0, 'word_overlap': 1.0, 'character': 1.0, 'combined': 1.0},
                'attribution': {'status': attr_status, 'rationale': attr_rationale},
                'conflict_group': conflict_gid,
                'decision': decision,
                'decision_history': [{'decision': decision, 'timestamp': now, 'reason': f'Initial extraction via {cand_eng}'}],
                'typed_data': typed_info
            }
            proposals.append(prop)
        return proposals


def extract_with_document_pass(target, concept, engine, extractor, aug_id, now, prompt_snapshot, store, selection, nearby_extractor):
    original = extract_proposals_for_target(target, concept, engine, extractor, aug_id, now, prompt_snapshot=prompt_snapshot, store=store)
    for p in original:
        if p['decision'] == 'unresolved' and p.get('proposed_value') is None:
            p['retry_target'] = target
    if not (selection or {}).get('nearby_second_pass') or any(p['decision'] != 'unresolved' for p in original):
        return original
    if not target.get('evidence_contexts'):
        for p in original: p['second_pass'] = {'status':'unavailable','passages':0,'skipped':['No linked evidence document']}
        return original
    from augmentation_document_pass import expand
    contexts, report = expand(store,target,concept,nearby_extractor(),selection)
    if not contexts:
        for p in original: p['second_pass'] = report
        return original
    expanded = {**target,'evidence_contexts':contexts}
    reviewed = extract_proposals_for_target(expanded,concept,engine,extractor,aug_id,now,prompt_snapshot=prompt_snapshot,store=store)
    for p in reviewed:
        p['second_pass'] = {**report,'first_pass': [{'decision':o['decision'],'proposed_value':o.get('proposed_value'),'evidence_id':(o.get('evidence') or {}).get('evidence_id')} for o in original]}
    return reviewed


def execute_pre_integration(store, expand_retrieval=False, engine='thor', prompt_config=None, selection=None):
    setup(store)
    import thor
    import thor_adapter
    prep = thor.prepare(store, scope='source', table_id=(selection or {}).get('table_id')) if engine != 'typed_llm' or (selection or {}).get('nearby_second_pass') else {'concepts': [], 'base_revision': assess(store)['revision']}
    concepts_by_col = {(c['source'], c['version'], c['column']): c for c in prep['concepts']}

    raw_cfg = thor.config(store)['config']
    extractor = thor_adapter.Extractor(raw_cfg) if engine == 'thor' else None
    nearby_runtime = [extractor]
    def nearby_extractor():
        if nearby_runtime[0] is None: nearby_runtime[0] = thor_adapter.Extractor(raw_cfg)
        return nearby_runtime[0]

    prompt_snapshot = typed_extraction.snapshot_typed_prompt(store, prompt_config)
    cfg = dict(raw_cfg)
    cfg['engine'] = engine
    cfg['typed_extraction'] = dict(prompt_snapshot)
    cfg['selection'] = selection
    if engine != 'thor':
        active, llm_cfg = typed_extraction.is_llm_active(store)
        if not active: raise ValueError('Configure an LLM provider and model in Settings')
        prompt_snapshot['_llm_config'] = llm_cfg
        cfg['llm'] = {key: llm_cfg.get(key) for key in ('provider', 'model', 'base_url', 'timeout_seconds', 'max_output_tokens')}

    from augmentation_selection import source_targets
    targets = source_targets(store, selection) if selection else compile_source_targets(store, expand_retrieval=expand_retrieval)
    aug_id = f"aug_{uuid.uuid4().hex[:12]}"
    now = time.time()
    proposals = []
    calls = [0]
    prompt_snapshot['_on_llm_call'] = lambda: calls.__setitem__(0, calls[0]+1)

    failure = None
    processed = 0
    for target in targets:
        concept = concepts_by_col.get((target['asset_id'], target['version'], target['column_index']))
        try:
            target_props = extract_with_document_pass(
                target, concept, engine, extractor, aug_id, now, prompt_snapshot, store, selection, nearby_extractor
            )
        except Exception as error:
            failure = str(error)
            break
        proposals.extend(target_props)
        processed += 1
    if failure:
        cfg['error'] = failure

    with store.db() as db:
        db.executemany(
            'INSERT INTO augmentation_proposals VALUES(?,?,?,?,?)',
            [(p['id'], aug_id, p['target_id'], json.dumps(p), p['decision']) for p in proposals]
        )

    telemetry = typed_extraction.calculate_telemetry(store, aug_id)
    counts = {
        'second_pass_targets': len({p['target_id'] for p in proposals if p.get('second_pass', {}).get('status') == 'expanded'}),
        'second_pass_unavailable': len({p['target_id'] for p in proposals if p.get('second_pass', {}).get('status') == 'unavailable'}),
        'processed_targets': processed,
        'llm_calls': calls[0],
        'targets': len(targets),
        'proposals': len([p for p in proposals if p['decision'] != 'unresolved']),
        'attributed': len([p for p in proposals if p['attribution']['status'] == 'attributed']),
        'accepted': 0,
        'rejected': len([p for p in proposals if p['decision'] == 'rejected']),
        'conflicting': len([p for p in proposals if p['decision'] == 'conflicting']),
        'unresolved': len([p for p in proposals if p['decision'] == 'unresolved']),
        'telemetry': telemetry
    }
    run_record = {
        'id': aug_id,
        'lake_id': getattr(store, 'lake_id', store.root.name),
        'scope': 'source',
        'source_revision': prep.get('base_revision', ''),
        'base_run_id': None,
        'base_revision': prep.get('base_revision', ''),
        'config': cfg,
        'status': 'failed' if failure else 'completed',
        'counts': counts,
        'feedback_passes': 0,
        'created': now,
        'updated': now
    }
    with store.db() as db:
        from augmentation_journey import capture_assessment
        captured = capture_assessment(db, run_record['scope'], run_record['base_run_id'], run_record['source_revision'])
        if captured: cfg['journey_assessment'] = captured
        cfg['journey_null_tokens'] = policy(store).get('null_tokens', inference.DEFAULT_NULL_TOKENS)
        if run_record['base_run_id']:
            parent = db.execute('SELECT data FROM integration_plans WHERE id=?', (run_record['base_run_id'],)).fetchone()
            if parent:
                import integration
                cfg['journey_input_revision'] = integration.content_revision(json.loads(parent['data']))
        db.execute(
            '''INSERT INTO augmentation_runs
               (id, lake_id, scope, source_revision, base_run_id, base_revision, config, status, counts, feedback_passes, created, updated)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
            (
                aug_id, run_record['lake_id'], run_record['scope'],
                run_record['source_revision'], run_record['base_run_id'],
                run_record['base_revision'], json.dumps(cfg),
                run_record['status'], json.dumps(counts),
                0, now, now
            )
        )
    return get_augmentation_run(store, aug_id)


def execute_post_integration(store, run_id, expand_retrieval=False, engine='thor', prompt_config=None, selection=None):
    setup(store)
    import thor
    import thor_adapter
    prep = thor.prepare(store, scope='integration', run_id=run_id, table_id=(selection or {}).get('table_id')) if engine != 'typed_llm' or (selection or {}).get('nearby_second_pass') else {'concepts': [], 'base_revision': assess(store, 'integration', run_id)['revision']}
    concepts_by_col = {(c['source'], c['version'], c['column']): c for c in prep['concepts']}

    raw_cfg = thor.config(store)['config']
    extractor = thor_adapter.Extractor(raw_cfg) if engine == 'thor' else None
    nearby_runtime = [extractor]
    def nearby_extractor():
        if nearby_runtime[0] is None: nearby_runtime[0] = thor_adapter.Extractor(raw_cfg)
        return nearby_runtime[0]

    prompt_snapshot = typed_extraction.snapshot_typed_prompt(store, prompt_config)
    cfg = dict(raw_cfg)
    cfg['engine'] = engine
    cfg['typed_extraction'] = dict(prompt_snapshot)
    cfg['selection'] = selection
    if engine != 'thor':
        active, llm_cfg = typed_extraction.is_llm_active(store)
        if not active: raise ValueError('Configure an LLM provider and model in Settings')
        prompt_snapshot['_llm_config'] = llm_cfg
        cfg['llm'] = {key: llm_cfg.get(key) for key in ('provider', 'model', 'base_url', 'timeout_seconds', 'max_output_tokens')}

    targets = compile_targets(store, run_id, expand_retrieval=expand_retrieval, selection=selection)
    # Output column indices are projected; match concepts by name, not raw index.
    concepts_by_col = {(t['asset_id'], t['version'], t['column_index']): next((c for c in prep['concepts'] if c['source']==t['asset_id'] and c['version']==t['version'] and c['name']==t['column_name']), None) for t in targets}
    aug_id = f"aug_{uuid.uuid4().hex[:12]}"
    now = time.time()
    proposals = []
    calls = [0]
    prompt_snapshot['_on_llm_call'] = lambda: calls.__setitem__(0, calls[0]+1)

    failure = None
    processed = 0
    for target in targets:
        concept = concepts_by_col.get((target['asset_id'], target['version'], target['column_index']))
        try:
            target_props = extract_with_document_pass(
                target, concept, engine, extractor, aug_id, now, prompt_snapshot, store, selection, nearby_extractor
            )
        except Exception as error:
            failure = str(error)
            break
        proposals.extend(target_props)
        processed += 1
    if failure:
        cfg['error'] = failure

    with store.db() as db:
        db.executemany(
            'INSERT INTO augmentation_proposals VALUES(?,?,?,?,?)',
            [(p['id'], aug_id, p['target_id'], json.dumps(p), p['decision']) for p in proposals]
        )

    telemetry = typed_extraction.calculate_telemetry(store, aug_id)
    counts = {
        'second_pass_targets': len({p['target_id'] for p in proposals if p.get('second_pass', {}).get('status') == 'expanded'}),
        'second_pass_unavailable': len({p['target_id'] for p in proposals if p.get('second_pass', {}).get('status') == 'unavailable'}),
        'processed_targets': processed,
        'llm_calls': calls[0],
        'targets': len(targets),
        'proposals': len([p for p in proposals if p['decision'] != 'unresolved']),
        'attributed': len([p for p in proposals if p['attribution']['status'] == 'attributed']),
        'accepted': 0,
        'rejected': len([p for p in proposals if p['decision'] == 'rejected']),
        'conflicting': len([p for p in proposals if p['decision'] == 'conflicting']),
        'unresolved': len([p for p in proposals if p['decision'] == 'unresolved']),
        'telemetry': telemetry
    }
    run_record = {
        'id': aug_id,
        'lake_id': getattr(store, 'lake_id', store.root.name),
        'scope': 'integration',
        'source_revision': prep.get('base_revision', ''),
        'base_run_id': run_id,
        'base_revision': prep.get('base_revision', ''),
        'config': cfg,
        'status': 'failed' if failure else 'completed',
        'counts': counts,
        'feedback_passes': 0,
        'created': now,
        'updated': now
    }
    with store.db() as db:
        from augmentation_journey import capture_assessment
        captured = capture_assessment(db, run_record['scope'], run_record['base_run_id'], run_record['source_revision'])
        if captured: cfg['journey_assessment'] = captured
        cfg['journey_null_tokens'] = policy(store).get('null_tokens', inference.DEFAULT_NULL_TOKENS)
        if run_record['base_run_id']:
            parent = db.execute('SELECT data FROM integration_plans WHERE id=?', (run_record['base_run_id'],)).fetchone()
            if parent:
                import integration
                cfg['journey_input_revision'] = integration.content_revision(json.loads(parent['data']))
        db.execute(
            '''INSERT INTO augmentation_runs
               (id, lake_id, scope, source_revision, base_run_id, base_revision, config, status, counts, feedback_passes, created, updated)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
            (
                aug_id, run_record['lake_id'], run_record['scope'],
                run_record['source_revision'], run_record['base_run_id'],
                run_record['base_revision'], json.dumps(cfg),
                run_record['status'], json.dumps(counts),
                0, now, now
            )
        )
    return get_augmentation_run(store, aug_id)


def list_augmentation_runs(store, base_run_id=None):
    setup(store)
    with store.db() as db:
        query = 'SELECT * FROM augmentation_runs'
        args = ()
        if base_run_id:
            query += ' WHERE base_run_id=?'
            args = (base_run_id,)
        query += ' ORDER BY created DESC'
        rows = db.execute(query, args).fetchall()
        result = []
        for r in rows:
            result.append({
                'id': r['id'],
                'lake_id': r['lake_id'],
                'scope': r['scope'],
                'source_revision': r['source_revision'],
                'base_run_id': r['base_run_id'],
                'base_revision': r['base_revision'],
                'config': json.loads(r['config']),
                'status': r['status'],
                'counts': json.loads(r['counts']),
                'feedback_passes': r['feedback_passes'] if 'feedback_passes' in r.keys() else 0,
                'created': r['created'],
                'updated': r['updated']
            })
        return {'runs': result}


def get_augmentation_run(store, run_id):
    setup(store)
    with store.db() as db:
        r = db.execute('SELECT * FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
        if not r:
            raise KeyError('Augmentation run not found')
        from augmentation_retry import eligible
        counts = json.loads(r['counts'])
        counts['retryable_targets'] = len(eligible(db, run_id))
        return {
            'id': r['id'],
            'lake_id': r['lake_id'],
            'scope': r['scope'],
            'source_revision': r['source_revision'],
            'base_run_id': r['base_run_id'],
            'base_revision': r['base_revision'],
            'config': json.loads(r['config']),
            'status': r['status'],
            'counts': counts,
            'feedback_passes': r['feedback_passes'] if 'feedback_passes' in r.keys() else 0,
            'created': r['created'],
            'updated': r['updated']
        }


def get_proposals(store, run_id, status=None, decision=None, table_id=None, limit=None, offset=0, include_records=False):
    setup(store)
    with store.db() as db:
        where, args = ['run_id=?'], [run_id]
        for path, value in [('target.asset_id', table_id), ('decision', decision), ('attribution.status', status)]:
            if value:
                where.append(f"json_extract(data, '$.{path}')=?")
                args.append(value)
        clause = ' AND '.join(where)
        total = db.execute('SELECT count(*) FROM augmentation_proposals WHERE '+clause, args).fetchone()[0]
        query = 'SELECT data FROM augmentation_proposals WHERE '+clause+' ORDER BY rowid'
        if limit is not None:
            query += ' LIMIT ? OFFSET ?'
            args += [max(1, min(100, int(limit))), max(0, int(offset))]
        rows = db.execute(query, args).fetchall()
        asset_names = dict(db.execute('SELECT id, name FROM assets').fetchall())
    res = []
    for r in rows:
        p = json.loads(r['data'])
        aid = p.get('target', {}).get('asset_id')
        if aid and aid in asset_names:
            p['target']['table_name'] = asset_names[aid]
        res.append(p)
    if include_records:
        # UI-only inspection of the exact source version; never model input.
        with store.db() as db:
            cache = {}
            run_row = db.execute('SELECT scope,base_run_id FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
            snapshots = {}
            if run_row and run_row['scope'] == 'integration':
                parent = db.execute('SELECT data,materialized FROM integration_plans WHERE id=?', (run_row['base_run_id'],)).fetchone()
                if parent:
                    import integration
                    output = (json.loads(r['data']) for r in db.execute('SELECT data FROM integration_rows WHERE plan_id=?', (run_row['base_run_id'],))) if parent['materialized'] else integration.rows(json.loads(parent['data']))
                    wanted = {p.get('target', {}).get('record_id') for p in res}
                    for item in output:
                        for side in ('left', 'right'):
                            rid = item.get(side+'_record')
                            if rid in wanted and isinstance(item.get(side+'_columns'), list) and isinstance(item.get(side+'_cells'), list):
                                snapshots[rid] = {'columns': item[side+'_columns'], 'cells': item[side+'_cells'], 'origin': 'integration_snapshot'}
            for p in res:
                target = p.get('target', {})
                key = (target.get('asset_id'), target.get('version'), target.get('record_index'))
                if key not in cache:
                    header = db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1', key[:2]).fetchone()
                    record = db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=?', key).fetchone()
                    cache[key] = {'columns': json.loads(header['data']), 'cells': json.loads(record['data'])} if header and record else None
                target['source_record'] = cache[key] or snapshots.get(target.get('record_id'))
    if table_id:
        res = [p for p in res if p.get('target', {}).get('asset_id') == table_id]
    if decision:
        res = [p for p in res if p['decision'] == decision]
    if status:
        res = [p for p in res if p['attribution']['status'] == status]
    return {'run_id': run_id, 'total': total, 'proposals': res}


def journey(store, run_id, decision=None, offset=0):
    """Read one consistent, bounded review receipt without deriving a lake view."""
    setup(store)
    with store.lock, store.db() as db:
        row = db.execute('SELECT * FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
        if not row:
            raise KeyError('Augmentation run not found')
        states = dict(db.execute('SELECT decision,count(*) FROM augmentation_proposals WHERE run_id=? GROUP BY decision', (run_id,)).fetchall())
        targets = db.execute('SELECT count(DISTINCT target_id) FROM augmentation_proposals WHERE run_id=?', (run_id,)).fetchone()[0]
        accepted_targets = db.execute("SELECT count(DISTINCT target_id) FROM augmentation_proposals WHERE run_id=? AND decision='accepted'", (run_id,)).fetchone()[0]
        config = json.loads(row['config'])
        selection = config.get('selection') or {}
        table_id = selection.get('table_id')
        table = db.execute('SELECT name FROM assets WHERE id=?', (table_id,)).fetchone() if table_id else None
        page = get_proposals(store, run_id, decision=decision, limit=12, offset=offset)
        from augmentation_journey import capture_assessment, consumers
        assessment = config.get('journey_assessment')
        if not assessment or assessment.get('revision') != row['source_revision']:
            assessment = capture_assessment(db, row['scope'], row['base_run_id'], row['source_revision'])
            if assessment:
                import augmentation_workspace
                assessment = augmentation_workspace.read(store, row['scope'], row['base_run_id'], include_manifest=False)['assessment']
        return {'run_id': run_id, 'scope': row['scope'], 'status': row['status'],
                'source_revision': row['source_revision'], 'base_run_id': row['base_run_id'],
                'base_revision': row['base_revision'], 'updated': row['updated'],
                'selection': selection, 'table_name': table['name'] if table else None,
                'review': config.get('review') or {}, 'engine': config.get('engine'),
                'states': states, 'targets': targets, 'accepted_targets': accepted_targets,
                'proposal_records': sum(states.values()), 'page': page, 'assessment':assessment,
                'assessment_status': 'available' if assessment else 'historical_unavailable',
                'consumers': consumers(db, row, accepted_targets)}


def delete_run(store, run_id):
    setup(store)
    with store.lock, store.db() as db:
        row = db.execute('SELECT status FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
        if not row:
            raise KeyError('Augmentation run not found')
        if row['status'] in ('queued', 'running'):
            raise ValueError('Wait for the augmentation run to finish before removing it')
        db.execute('DELETE FROM augmentation_views WHERE run_id=?', (run_id,))
        db.execute('DELETE FROM augmentation_proposals WHERE run_id=?', (run_id,))
        db.execute('DELETE FROM augmentation_runs WHERE id=?', (run_id,))
    return {'deleted': run_id}


def override_proposal(store, proposal_id, value, accept=False):
    if not isinstance(value, str) or not value.strip() or len(value) > 10000:
        raise ValueError('Enter a non-empty value of at most 10,000 characters')
    if not isinstance(accept, bool):
        raise ValueError('accept must be a boolean')
    setup(store)
    with store.lock, store.db() as db:
        row = db.execute('SELECT run_id,target_id,data FROM augmentation_proposals WHERE id=?', (proposal_id,)).fetchone()
        if not row:
            raise KeyError('Proposal not found')
        prop = json.loads(row['data'])
        prop.setdefault('original_model_proposal', {k: copy.deepcopy(prop.get(k)) for k in
            ('proposed_value', 'engine', 'typed_data', 'attribution', 'evidence', 'scores', 'decision')})
        now = time.time()
        prop.setdefault('manual_edits', []).append({'previous_value': prop.get('proposed_value'),
            'value': value.strip(), 'timestamp': now})
        prop.update(proposed_value=value.strip(), engine='manual', typed_data=None,
            attribution={'status': 'manual', 'rationale': 'Entered by the user; model grounding is not asserted'},
            scores={'semantic': 0, 'word_overlap': 0, 'character': 0, 'combined': 0},
            decision='accepted' if accept else 'proposed')
        prop.setdefault('decision_history', []).append({'decision': prop['decision'], 'timestamp': now,
            'reason': 'Manual value override' + (' and acceptance' if accept else '; awaiting acceptance')})
        db.execute('UPDATE augmentation_proposals SET data=?,decision=? WHERE id=?', (json.dumps(prop),prop['decision'],proposal_id))
        if accept:
            supersede_accepted_target(db, row['run_id'], row['target_id'], proposal_id, now)
        recalculate_counts(db, row['run_id'])
    return prop


def supersede_accepted_target(db, run_id, target_id, proposal_id, now):
    for row in db.execute("SELECT id,data FROM augmentation_proposals WHERE run_id=? AND target_id=? AND id!=? AND decision='accepted'", (run_id,target_id,proposal_id)).fetchall():
        other = json.loads(row['data'])
        other['decision'] = 'rejected'
        other.setdefault('decision_history', []).append({'decision':'rejected','timestamp':now,
            'reason':f'Superseded by accepted proposal {proposal_id}'})
        db.execute("UPDATE augmentation_proposals SET data=?,decision='rejected' WHERE id=?", (json.dumps(other),row['id']))


def update_proposal_decision(store, proposal_id, decision, reason=None):
    if decision not in ('accepted', 'rejected', 'proposed', 'conflicting', 'unresolved'):
        raise ValueError(f"Invalid decision '{decision}'")
    setup(store)
    with store.lock, store.db() as db:
        row = db.execute('SELECT run_id, target_id, data FROM augmentation_proposals WHERE id=?', (proposal_id,)).fetchone()
        if not row:
            raise KeyError('Proposal not found')
        run_id = row['run_id']
        prop = json.loads(row['data'])
        if decision == 'accepted' and (prop.get('proposed_value') is None or (prop.get('typed_data') or {}).get('validation', 'valid') != 'valid'):
            raise ValueError('This proposal has no validated value to accept')
        prop['decision'] = decision
        prop.setdefault('decision_history', []).append({
            'decision': decision,
            'timestamp': time.time(),
            'reason': reason or f"User set decision to {decision}"
        })
        db.execute('UPDATE augmentation_proposals SET data=?, decision=? WHERE id=?', (json.dumps(prop), decision, proposal_id))

        if decision == 'accepted':
            supersede_accepted_target(db, run_id, row['target_id'], proposal_id, time.time())

        if decision == 'accepted' and prop.get('conflict_group'):
            other_rows = db.execute('SELECT id, data FROM augmentation_proposals WHERE run_id=? AND id!=?', (run_id, proposal_id)).fetchall()
            for other in other_rows:
                o_prop = json.loads(other['data'])
                if o_prop.get('conflict_group') == prop['conflict_group'] and o_prop['decision'] != 'accepted':
                    o_prop['decision'] = 'rejected'
                    o_prop.setdefault('decision_history', []).append({
                        'decision': 'rejected',
                        'timestamp': time.time(),
                        'reason': f"Superseded by accepted proposal {proposal_id}"
                    })
                    db.execute('UPDATE augmentation_proposals SET data=?, decision=? WHERE id=?', (json.dumps(o_prop), 'rejected', other['id']))

        recalculate_counts(db, run_id)
    return prop


def finalize_review(store, run_id):
    """Record completion of review without accepting or rejecting any proposal."""
    setup(store)
    with store.lock, store.db() as db:
        row = db.execute('SELECT status,config FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
        if not row:
            raise KeyError('Augmentation run not found')
        if row['status'] in ('queued', 'running'):
            raise ValueError('Wait for extraction to finish before finalizing review')
        counts = recalculate_counts(db, run_id)
        accepted = [r['id'] for r in db.execute("SELECT id FROM augmentation_proposals WHERE run_id=? AND decision='accepted' ORDER BY id", (run_id,))]
        total = db.execute('SELECT count(*) FROM augmentation_proposals WHERE run_id=?', (run_id,)).fetchone()[0]
        config = json.loads(row['config'])
        config['review'] = {'status': 'finalized', 'finalized_at': time.time(),
            'accepted_proposal_ids': accepted, 'accepted': len(accepted), 'rejected': counts['rejected'],
            'not_included': total-len(accepted)}
        db.execute('UPDATE augmentation_runs SET config=?,updated=? WHERE id=?', (json.dumps(config),time.time(),run_id))
    return get_augmentation_run(store, run_id)


def bulk_proposal_decision(store, run_id, action, proposal_ids=None, table_id=None, column_name=None):
    if action.endswith('_selected') and not proposal_ids:
        raise ValueError('Select at least one proposal')
    setup(store)
    with store.lock, store.db() as db:
        rows = db.execute('SELECT id, data FROM augmentation_proposals WHERE run_id=?', (run_id,)).fetchall()
        if not rows:
            raise KeyError('Augmentation run not found or has no proposals')
        now = time.time()
        updated = 0
        p_ids_set = set(proposal_ids) if proposal_ids else None
        accepted_targets = {json.loads(r['data']).get('target_id') for r in rows if json.loads(r['data']).get('decision') == 'accepted'}

        for r in rows:
            prop = json.loads(r['data'])
            old_dec = prop['decision']
            t = prop.get('target', {})
            aid = t.get('asset_id')
            cname = t.get('column_name')

            # Filter by table_id if specified
            if table_id and aid != table_id:
                continue

            # Filter by column_name if specified
            if column_name and cname != column_name:
                continue

            # Filter by proposal_ids if specified
            if p_ids_set and r['id'] not in p_ids_set:
                continue

            if action in ('accept_attributed', 'accept_all', 'accept_table', 'accept_column', 'accept_selected'):
                # Aggregate acceptance fills undecided slots; it never reverses rejection.
                if old_dec != 'proposed': continue
                if prop.get('target_id') in accepted_targets: continue
                if prop.get('conflict_group'): continue
                if prop.get('proposed_value') is None or (prop.get('typed_data') or {}).get('validation', 'valid') != 'valid': continue
                if prop['attribution']['status'] == 'attributed' or (prop.get('engine') == 'manual' and action != 'accept_attributed'):
                    prop['decision'] = 'accepted'
                    accepted_targets.add(prop.get('target_id'))
                    prop.setdefault('decision_history', []).append({'decision': 'accepted', 'timestamp': now, 'reason': f"Bulk {action}"})
            elif action in ('reject_flagged', 'reject_all', 'reject_table', 'reject_column', 'reject_selected'):
                if action != 'reject_selected' and old_dec in ('accepted', 'rejected'): continue
                if action == 'reject_flagged' and prop.get('attribution', {}).get('status') not in ('negated', 'hypothetical', 'wrong_subject', 'unresolved', 'conflict') and old_dec not in ('unresolved', 'conflicting'): continue
                prop['decision'] = 'rejected'
                prop.setdefault('decision_history', []).append({'decision': 'rejected', 'timestamp': now, 'reason': f"Bulk {action}"})
            elif action in ('reset', 'reset_table', 'reset_column', 'reset_selected'):
                init_dec = 'rejected' if prop['attribution']['status'] in ('negated', 'hypothetical', 'wrong_subject') else 'conflicting' if prop['attribution']['status'] == 'conflict' else 'unresolved' if prop['attribution']['status'] == 'unresolved' else 'proposed'
                prop['decision'] = init_dec
                prop.setdefault('decision_history', []).append({'decision': init_dec, 'timestamp': now, 'reason': f"Reset ({action})"})
            else:
                raise ValueError(f"Unknown bulk action '{action}'")

            if prop['decision'] != old_dec:
                db.execute('UPDATE augmentation_proposals SET data=?, decision=? WHERE id=?', (json.dumps(prop), prop['decision'], r['id']))
                updated += 1
        if updated:
            recalculate_counts(db, run_id)
    return {'run_id': run_id, 'updated': updated, 'action': action}


def derived_integration_view(store, run_id):
    with store.db() as db:
        run_row = db.execute('SELECT * FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
        if not run_row:
            raise KeyError('Augmentation run not found')
        base_run_id = run_row['base_run_id']
        counts = json.loads(run_row['counts'])
        accepted_rows = db.execute("SELECT data FROM augmentation_proposals WHERE run_id=? AND decision='accepted'", (run_id,)).fetchall()
        accepted = [json.loads(r['data']) for r in accepted_rows]

    accepted_map = {}
    for p in accepted:
        t = p['target']
        accepted_map[(t['asset_id'], t['record_id'], t['column_index'])] = p

    import integration
    with store.db() as db:
        stored = db.execute('SELECT data,materialized FROM integration_plans WHERE id=?', (base_run_id,)).fetchone()
        if not stored:
            raise KeyError('Base integration run not found')
        plan = json.loads(stored['data'])
        base_rows = ([json.loads(r['data']) for r in db.execute('SELECT data FROM integration_rows WHERE plan_id=? ORDER BY idx', (base_run_id,))]
                     if stored['materialized'] else integration.rows(plan))

    enriched_rows = []
    enriched_cell_count = 0
    for row in base_rows:
        row_copy = copy.deepcopy(row)
        for side in ('left', 'right'):
            rid = row_copy.get(f'{side}_record')
            parts = rid.rsplit(':', 2) if rid else []
            aid = parts[0] if parts else ''
            cells = list(row_copy.get(f'{side}_cells', []))
            cols = row_copy.get(f'{side}_columns', [])
            augs = []
            for c_idx in range(len(cells)):
                key = (aid, rid, c_idx)
                if key in accepted_map:
                    prop = accepted_map[key]
                    orig = cells[c_idx]
                    cells[c_idx] = prop['proposed_value']
                    augs.append({
                        'column_index': c_idx,
                        'column_name': cols[c_idx] if c_idx < len(cols) else '',
                        'original': orig,
                        'value': prop['proposed_value'],
                        'proposal_id': prop['id'],
                        'evidence_quote': (prop.get('evidence') or {}).get('quote', ''),
                        'engine': prop.get('engine', 'thor'),
                        'typed_data': prop.get('typed_data')
                    })
                    enriched_cell_count += 1
            row_copy[f'{side}_cells'] = cells
            row_copy[f'{side}_augmentations'] = augs
        enriched_rows.append(row_copy)

    return {
        'augmentation_run_id': run_id,
        'scope': 'integration',
        'base_run_id': base_run_id,
        'counts': {
            'base_rows': len(base_rows),
            'enriched_rows': len(enriched_rows),
            'enriched_cells': enriched_cell_count,
            'accepted_proposals': len(accepted),
            'unresolved_cells': counts.get('unresolved', 0),
            'conflicting_cells': counts.get('conflicting', 0)
        },
        'output': enriched_rows
    }


def derived_source_view(store, run_id, table_id=None):
    with store.db() as db:
        run_row = db.execute('SELECT * FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
        if not run_row:
            raise KeyError('Augmentation run not found')
        counts = json.loads(run_row['counts'])
        accepted_rows = db.execute("SELECT data FROM augmentation_proposals WHERE run_id=? AND decision='accepted'", (run_id,)).fetchall()
        accepted = [json.loads(r['data']) for r in accepted_rows]

    accepted_map = {}
    for p in accepted:
        t = p['target']
        accepted_map[(t['asset_id'], t['record_id'], t['column_index'])] = p

    tables = []
    total_enriched_cells = 0
    total_enriched_rows = 0

    with store.db() as db:
        jobs = db.execute("SELECT j.asset_id, j.version, a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.status='ready' AND lower(a.name) LIKE '%.csv' ORDER BY a.name, a.id").fetchall()
        for j in jobs:
            if table_id and j['asset_id'] != table_id:
                continue
            first = db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1', (j['asset_id'], j['version'])).fetchone()
            if not first:
                continue
            cols = json.loads(first['data'])
            rows_data = db.execute('SELECT idx, data FROM records WHERE asset_id=? AND version=? AND idx>1 ORDER BY idx', (j['asset_id'], j['version'])).fetchall()

            table_rows = []
            table_enriched_cells = 0
            for r in rows_data:
                cells = json.loads(r['data'])
                rid = f"{j['asset_id']}:{j['version']}:{r['idx']}"
                row_augs = []
                enriched_cells = list(cells)
                for c_idx in range(len(cells)):
                    key = (j['asset_id'], rid, c_idx)
                    if key in accepted_map:
                        prop = accepted_map[key]
                        orig = cells[c_idx]
                        enriched_cells[c_idx] = prop['proposed_value']
                        row_augs.append({
                            'column_index': c_idx,
                            'column_name': cols[c_idx] if c_idx < len(cols) else f"col_{c_idx}",
                            'original': orig,
                            'value': prop['proposed_value'],
                            'proposal_id': prop['id'],
                            'evidence_quote': (prop.get('evidence') or {}).get('quote', ''),
                            'engine': prop.get('engine', 'thor'),
                            'typed_data': prop.get('typed_data')
                        })
                        table_enriched_cells += 1
                        total_enriched_cells += 1
                if row_augs:
                    total_enriched_rows += 1
                table_rows.append({
                    'record_id': rid,
                    'record_index': r['idx'],
                    'original_cells': cells,
                    'cells': enriched_cells,
                    'augmentations': row_augs
                })
            tables.append({
                'id': j['asset_id'],
                'name': j['name'],
                'version': j['version'],
                'columns': cols,
                'rows': table_rows,
                'enriched_cells': table_enriched_cells,
                'enriched_rows': len([r for r in table_rows if r['augmentations']])
            })

    return {
        'augmentation_run_id': run_id,
        'scope': 'source',
        'counts': {
            'tables': len(tables),
            'rows': sum(len(t['rows']) for t in tables),
            'enriched_rows': total_enriched_rows,
            'enriched_cells': total_enriched_cells,
            'accepted_proposals': len(accepted),
            'unresolved_cells': counts.get('unresolved', 0),
            'conflicting_cells': counts.get('conflicting', 0)
        },
        'tables': tables
    }


def derived_view(store, run_id, table_id=None):
    setup(store)
    with store.db() as db:
        run_row = db.execute('SELECT scope FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
        if not run_row:
            raise KeyError('Augmentation run not found')
        scope = run_row['scope']
    if scope == 'source':
        return derived_source_view(store, run_id, table_id=table_id)
    return derived_integration_view(store, run_id)


def export_derived_source_view(store, run_id, table_id=None, format='csv'):
    view = derived_source_view(store, run_id, table_id=table_id)
    if format == 'json':
        return json.dumps(view, indent=2).encode('utf-8')
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['# IDUN Pre-Integration Derived View'])
    writer.writerow([f'# Augmentation Run: {run_id}'])
    writer.writerow([f'# Scope: source'])
    writer.writerow([f'# Enriched Cells: {view["counts"]["enriched_cells"]}'])
    writer.writerow([f'# Accepted Proposals: {view["counts"]["accepted_proposals"]}'])
    writer.writerow([f'# Unresolved Cells: {view["counts"]["unresolved_cells"]}'])
    writer.writerow([])

    for tbl in view['tables']:
        writer.writerow([f'# Table: {tbl["name"]} ({tbl["id"]})'])
        header = list(tbl['columns']) + ['_augmented']
        writer.writerow(header)
        for r in tbl['rows']:
            augs_str = '; '.join(f"{a['column_name']}={a['value']}" for a in r['augmentations'])
            writer.writerow(list(r['cells']) + [augs_str])
        writer.writerow([])
    return output.getvalue().encode('utf-8')


def export_derived_integration_view(store, run_id, format='csv', relation=None):
    view = derived_integration_view(store, run_id)
    rows = view.get('output', [])
    if relation:
        rows = [r for r in rows if r.get('relation') == relation]
    if format == 'json':
        export_view = dict(view)
        export_view['output'] = rows
        return json.dumps(export_view, indent=2).encode('utf-8')
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['# IDUN Post-Integration Derived View'])
    writer.writerow([f'# Augmentation Run: {run_id}'])
    writer.writerow([f'# Base Integration Run: {view["base_run_id"]}'])
    if relation:
        writer.writerow([f'# Relationship: {relation}'])
    writer.writerow([f'# Enriched Cells: {view["counts"]["enriched_cells"]}'])
    writer.writerow([f'# Accepted Proposals: {view["counts"]["accepted_proposals"]}'])
    writer.writerow([f'# Unresolved Cells: {view["counts"]["unresolved_cells"]}'])
    writer.writerow([])

    if rows:
        first = rows[0]
        left_cols = [f"left_{c}" for c in first.get('left_columns', [])]
        right_cols = [f"right_{c}" for c in first.get('right_columns', [])]
        header = left_cols + ['relation', 'direction'] + right_cols + ['evidence_quote', 'left_augmented', 'right_augmented']
        writer.writerow(header)
        for row in rows:
            left_c = row.get('left_cells', [])
            right_c = row.get('right_cells', [])
            rel = row.get('relation', '')
            direct = row.get('direction', '')
            quote = row.get('evidence_quote', '')
            left_aug = '; '.join(f"{a['column_name']}={a['value']}" for a in row.get('left_augmentations', []))
            right_aug = '; '.join(f"{a['column_name']}={a['value']}" for a in row.get('right_augmentations', []))
            writer.writerow(list(left_c) + [rel, direct] + list(right_c) + [quote, left_aug, right_aug])
    return output.getvalue().encode('utf-8')


def export_derived_view(store, run_id, format='csv', table_id=None, relation=None):
    setup(store)
    with store.db() as db:
        run_row = db.execute('SELECT scope FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
        if not run_row:
            raise KeyError('Augmentation run not found')
        scope = run_row['scope']
    if scope == 'source':
        return export_derived_source_view(store, run_id, table_id=table_id, format=format)
    return export_derived_integration_view(store, run_id, format=format, relation=relation)


def evaluate_candidate_neighborhoods(store, run_id):
    setup(store)
    with store.db() as db:
        run_row = db.execute('SELECT * FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
        if not run_row:
            raise KeyError('Augmentation run not found')
        accepted_rows = db.execute("SELECT data FROM augmentation_proposals WHERE run_id=? AND decision='accepted'", (run_id,)).fetchall()
        accepted = [json.loads(r['data']) for r in accepted_rows]

    affected_by_record = {}
    for p in accepted:
        rid = p['target']['record_id']
        affected_by_record.setdefault(rid, []).append(p)

    affected_row_ids = sorted(affected_by_record.keys())
    revision_parts = [run_id, sorted([p['id'] for p in accepted]), affected_row_ids]
    proj_revision = hashlib.sha256(json.dumps(revision_parts, sort_keys=True).encode()).hexdigest()

    if not affected_row_ids:
        return {
            'run_id': run_id,
            'projection_revision': proj_revision,
            'affected_rows_count': 0,
            'enriched_cells_count': 0,
            'baseline': {'candidate_budget': 5, 'connections_count': 0, 'connections': []},
            'enriched': {'candidate_budget': 5, 'connections_count': 0, 'connections': []},
            'comparison': {
                'added_connections_count': 0,
                'old_to_new_count': 0,
                'new_to_old_count': 0,
                'added_connections': [],
                'old_to_new_connections': [],
                'new_to_old_connections': [],
                'notice': 'No accepted additions in this run yet. Accept proposals to generate candidate neighborhoods with equal candidate budgets.'
            }
        }

    BUDGET_PER_ROW = 5
    baseline_connections = []
    enriched_connections = []
    added_connections = []
    old_to_new = []
    new_to_old = []

    with store.db() as db:
        all_csv_jobs = db.execute("SELECT j.asset_id, j.version, a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.status='ready' AND lower(a.name) LIKE '%.csv'").fetchall()

        for rid, props in affected_by_record.items():
            parts = rid.rsplit(':', 2)
            aid = parts[0]
            ver = parts[1]
            idx = int(parts[2])

            row_rec = db.execute("SELECT data FROM records WHERE asset_id=? AND version=? AND idx=?", (aid, ver, idx)).fetchone()
            if not row_rec:
                continue
            orig_cells = json.loads(row_rec['data'])
            aug_cells = list(orig_cells)
            new_values_map = {}
            for p in props:
                c_idx = p['target']['column_index']
                val = p['proposed_value']
                aug_cells[c_idx] = val
                new_values_map[c_idx] = val

            base_tokens = set()
            for c in orig_cells:
                if c:
                    base_tokens.update(re.findall(r'[A-Za-z0-9_]{3,}', str(c).lower()))

            enriched_tokens = set(base_tokens)
            added_tokens = set()
            for nv in new_values_map.values():
                if nv:
                    toks = set(re.findall(r'[A-Za-z0-9_]{3,}', str(nv).lower()))
                    added_tokens.update(toks)
                    enriched_tokens.update(toks)

            row_base_conns = []
            row_enrich_conns = []
            for other_job in all_csv_jobs:
                if other_job['asset_id'] == aid:
                    continue
                o_aid = other_job['asset_id']
                o_ver = other_job['version']
                o_rows = db.execute("SELECT idx, data FROM records WHERE asset_id=? AND version=? AND idx>1 LIMIT 50", (o_aid, o_ver)).fetchall()
                for o_r in o_rows:
                    o_cells = json.loads(o_r['data'])
                    o_rid = f"{o_aid}:{o_ver}:{o_r['idx']}"
                    o_tokens = set()
                    for cell in o_cells:
                        if cell:
                            o_tokens.update(re.findall(r'[A-Za-z0-9_]{3,}', str(cell).lower()))

                    base_overlap = base_tokens & o_tokens
                    if base_overlap and len(row_base_conns) < BUDGET_PER_ROW:
                        row_base_conns.append({
                            'source_record': rid,
                            'target_type': 'table_record',
                            'target_id': o_rid,
                            'matched_tokens': list(base_overlap)
                        })

                    enrich_overlap = enriched_tokens & o_tokens
                    if enrich_overlap and len(row_enrich_conns) < BUDGET_PER_ROW:
                        row_enrich_conns.append({
                            'source_record': rid,
                            'target_type': 'table_record',
                            'target_id': o_rid,
                            'matched_tokens': list(enrich_overlap)
                        })

                        if (added_tokens & o_tokens) and not base_overlap:
                            added_item = {
                                'source_record': rid,
                                'target_type': 'table_record',
                                'target_id': o_rid,
                                'matched_tokens': list(added_tokens & o_tokens),
                                'direction': 'old_to_new'
                            }
                            added_connections.append(added_item)
                            old_to_new.append(added_item)

            baseline_connections.extend(row_base_conns)
            enriched_connections.extend(row_enrich_conns)

    return {
        'run_id': run_id,
        'projection_revision': proj_revision,
        'affected_rows_count': len(affected_by_record),
        'enriched_cells_count': len(accepted),
        'baseline': {
            'candidate_budget': BUDGET_PER_ROW,
            'connections_count': len(baseline_connections),
            'connections': baseline_connections
        },
        'enriched': {
            'candidate_budget': BUDGET_PER_ROW,
            'connections_count': len(enriched_connections),
            'connections': enriched_connections
        },
        'comparison': {
            'added_connections_count': len(added_connections),
            'old_to_new_count': len(old_to_new),
            'new_to_old_count': len(new_to_old),
            'added_connections': added_connections,
            'old_to_new_connections': old_to_new,
            'new_to_old_connections': new_to_old,
            'notice': 'Candidate budgets were held strictly equal between baseline and enriched queries. More filled cells alone is not proof of better joins; candidate connections reflect newly matching semantic and lexical overlap.'
        }
    }


def execute_feedback_pass(store, run_id):
    setup(store)
    with store.lock, store.db() as db:
        run_row = db.execute('SELECT * FROM augmentation_runs WHERE id=?', (run_id,)).fetchone()
        if not run_row:
            raise KeyError('Augmentation run not found')
        feedback_passes = run_row['feedback_passes'] if 'feedback_passes' in run_row.keys() else 0
        if feedback_passes >= 1:
            raise ValueError('At most one user-triggered feedback pass is permitted to prevent uncontrolled feedback loops')

        # Strictly enforce: proposals must NEVER become seeds or evidence.
        # Seeds are derived strictly from original source records via thor.prepare
        import thor
        import thor_adapter
        cfg = json.loads(run_row['config'])
        selection = cfg.get('selection') or {}
        projection = policy(store)
        mask = inference.identifier_mask(db, projection.get('exclude_identifiers', []))
        prep = thor.prepare(store, scope=run_row['scope'], run_id=run_row['base_run_id'] or '', table_id=selection.get('table_id')) if cfg.get('engine') != 'typed_llm' else {'concepts': []}
        concepts_by_col = {(c['source'], c['version'], c['column']): c for c in prep['concepts']}
        cfg = json.loads(run_row['config'])
        extractor = thor_adapter.Extractor(cfg) if cfg.get('engine', 'thor') == 'thor' else None
        prompt_snapshot = dict(cfg.get('typed_extraction') or {})

        unresolved_rows = db.execute("SELECT id, data FROM augmentation_proposals WHERE run_id=? AND decision IN ('unresolved', 'conflicting') ORDER BY rowid LIMIT ?", (run_id, int(selection.get('target_limit', 10)))).fetchall()
        now = time.time()
        updated_count = 0

        for ur in unresolved_rows:
            prop = json.loads(ur['data'])
            t = prop['target']
            concept = next((c for c in prep['concepts'] if c['source']==t['asset_id'] and c['version']==t['version'] and c['name']==t['column_name']), None)
            p_engine = prop.get('engine', 'thor')
            if p_engine == 'thor' and (not concept or not concept.get('seeds')):
                continue

            expanded_contexts = []
            has_fts = bool(db.execute("SELECT 1 FROM sqlite_master WHERE name='retrieval_fts'").fetchone())
            txt_jobs = db.execute("SELECT j.asset_id, j.version, a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.status='ready' AND lower(a.name) LIKE '%.txt'").fetchall()

            row_rec = db.execute("SELECT data FROM records WHERE asset_id=? AND version=? AND idx=?", (t['asset_id'], t['version'], t['record_index'])).fetchone()
            if row_rec:
                cells = json.loads(row_rec['data'])
                header_row = db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1', (t['asset_id'], t['version'])).fetchone()
                header = json.loads(header_row['data']) if header_row else []
                included = inference.table_columns(header, projection.get('exclude_identifiers', []))
                t['row_context'] = {mask(header[i]): mask(str(cells[i])) for i in included if i<len(cells) and not inference.resolve_cell_value(cells[i], projection.get('null_tokens'))[1]}
                terms = [v for v in t['row_context'].values() if re.search('[A-Za-z]{2}', v) and '█' not in v]
                if len(expanded_contexts) < 10 and txt_jobs:
                    for tj in txt_jobs:
                        if len(expanded_contexts) >= int(selection.get('contexts_limit', 3)): break
                        t_records = db.execute("SELECT idx, start, end, data FROM records WHERE asset_id=? AND version=? LIMIT 20", (tj['asset_id'], tj['version'])).fetchall()
                        for tr in t_records:
                            if len(expanded_contexts) >= int(selection.get('contexts_limit', 3)): break
                            try:
                                t_c = json.loads(tr['data'])
                                if isinstance(t_c, str) and terms and any(term.lower() in t_c[:1500].lower() for term in terms):
                                    if not any(e['text'] == t_c for e in expanded_contexts):
                                        expanded_contexts.append({
                                            'document': tj['asset_id'],
                                            'document_name': tj['name'],
                                            'start': tr['start'] or 0,
                                            'end': (tr['start'] or 0) + len(t_c[:1500]),
                                            'text': mask(t_c[:1500]),
                                            'evidence_id': f"expanded_feedback_{tj['asset_id']}_{tr['idx']}"
                                        })
                            except Exception:
                                pass

            if p_engine in ('typed_llm', 'heuristic'):
                concept_dict = dict(concept or {'id': t['column_name'], 'name': t['column_name'], 'kind': 'no_seeds'})
                concept_dict['expected_type'] = selection.get('types', {}).get(str(t['column_index']), 'string')
                typed_cands = []
                for ctx in expanded_contexts:
                    tc = typed_extraction.extract_typed_attribute(
                        concept_dict, t, ctx, engine_label=p_engine, store=store, prompt_snapshot=prompt_snapshot
                    )
                    if tc and tc.get('found') and tc.get('valid') and tc.get('attribution_status') == 'attributed':
                        typed_cands.append(tc)
                distinct_values = {str(c['normalized_value']).strip().lower(): str(c['normalized_value']).strip() for c in typed_cands}
                if len(distinct_values) == 1:
                    cand = typed_cands[0]
                    ctx = cand['evidence_context']
                    prop['proposed_value'] = str(cand['normalized_value'])
                    prop['attribution'] = {'status': 'attributed', 'rationale': cand['attribution_rationale']}
                    prop['typed_data'] = {
                        'type': cand.get('value_type', 'numeric'),
                        'raw_quoted': cand.get('raw_quoted', ''),
                        'normalized_value': cand.get('normalized_value'),
                        'unit': cand.get('unit'),
                        'temporal_scope': cand.get('temporal_scope'),
                        'precision': cand.get('precision', 'unknown'),
                        'validation': cand.get('validation', 'valid')
                    }
                    prop['evidence'] = {
                        'document': ctx['document'],
                        'document_name': ctx.get('document_name', ctx['document']),
                        'start': ctx.get('start', 0) + cand.get('start', 0),
                        'end': ctx.get('start', 0) + cand.get('end', 0),
                        'text': ctx['text'],
                        'quote': cand.get('raw_quoted', ''),
                        'sentence_start': cand.get('sentence_start', 0),
                        'sentence_end': cand.get('sentence_end', len(ctx['text'])),
                        'document_version': ctx.get('document_version'),
                    'retrieval': ctx.get('retrieval'),
                    'evidence_id': ctx.get('evidence_id', '')
                    }
                    prop['decision'] = 'proposed'
                    prop.setdefault('decision_history', []).append({
                        'decision': 'proposed',
                        'timestamp': now,
                        'reason': 'Bounded feedback pass re-evaluation (typed extraction)'
                    })
                    db.execute("UPDATE augmentation_proposals SET data=?, decision='proposed' WHERE id=?", (json.dumps(prop), prop['id']))
                    updated_count += 1
            else:
                extractions = []
                for ctx in expanded_contexts:
                    cands = extractor.extract(ctx['text'], [concept], check_attribution=True)
                    for c in cands:
                        c['evidence_context'] = ctx
                        extractions.append(c)

                attributed = [c for c in extractions if c['attribution'] == 'attributed']
                distinct_values = {c['value'].strip().lower(): c['value'].strip() for c in attributed}

                if len(distinct_values) == 1:
                    cand = attributed[0]
                    ctx = cand['evidence_context']
                    prop['proposed_value'] = cand['value']
                    prop['seed'] = cand['seed']
                    prop['scores'] = cand['scores']
                    prop['attribution'] = {'status': 'attributed', 'rationale': cand['attribution_rationale']}
                    prop['evidence'] = {
                        'document': ctx['document'],
                        'document_name': ctx.get('document_name', ctx['document']),
                        'start': ctx.get('start', 0) + cand['start'],
                        'end': ctx.get('start', 0) + cand['end'],
                        'text': ctx['text'],
                        'quote': cand['value'],
                        'sentence_start': cand['sentence_start'],
                        'sentence_end': cand['sentence_end'],
                        'document_version': ctx.get('document_version'),
                    'retrieval': ctx.get('retrieval'),
                    'evidence_id': ctx.get('evidence_id', '')
                    }
                    prop['decision'] = 'proposed'
                    prop.setdefault('decision_history', []).append({
                        'decision': 'proposed',
                        'timestamp': now,
                        'reason': 'Bounded feedback pass re-evaluation (seeds kept strictly original)'
                    })
                    db.execute("UPDATE augmentation_proposals SET data=?, decision='proposed' WHERE id=?", (json.dumps(prop), prop['id']))
                    updated_count += 1

        db.execute("UPDATE augmentation_runs SET feedback_passes=1, updated=? WHERE id=?", (now, run_id))
        recalculate_counts(db, run_id)

    return {
        'run_id': run_id,
        'feedback_passes': 1,
        'updated_proposals': updated_count,
        'notice': 'Bounded feedback pass completed. Seeds were derived strictly from original source tables without self-reinforcing loops.'
    }

