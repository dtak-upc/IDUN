from evidence_storage import decode as unpack
"""LOKI-style semantic materialization without admission keys or annotation access.
Reference: research/LOKI/LOKI/materialize_joins.py, Stage 5/6 functions.
"""

import collections, json, math, time, uuid, subprocess, os, hashlib, re, copy
from pathlib import Path
import discovery, inference, settings, llm

VERSION = "semantic-joins-v5.1"
LABEL_POLICY = "clinical-single-anchors-quote-alias-v2"
POSITIVE = set(llm.LABELS) - {"NEGATIVE", "UNRESOLVED"}


def policy_key(config, schema_config=None):
    system_prompt = llm.build_system_prompt(schema_config)
    return hashlib.sha256(json.dumps([LABEL_POLICY,system_prompt,config['provider'],config['base_url'],config['model'],config.get('temperature'),config.get('top_p'),config.get('max_output_tokens')],sort_keys=True).encode()).hexdigest()


def role(columns):
    names = [c.strip().lower() for c in columns]
    for name in ("diagnosis", "condition"):
        if name in names:
            return "diagnosis", names.index(name)
    for name in ("drug", "medication"):
        if name in names:
            return "medication", names.index(name)
    return None, None


def passage_context(store, link, mask, other=None):
    """Bounded source context covering both anchors, with projected exact offsets."""
    lo = max(0, min(link["start"], (other or link)["start"]) - 1200)
    hi = max(link["end"], (other or link)["end"]) + 1200
    with store.db() as db:
        chunks = db.execute(
            "SELECT start,end,data FROM records WHERE asset_id=? AND version=? AND end>? AND start<? ORDER BY idx",
            (link["text"], link["text_version"], lo, hi),
        ).fetchall()
    if not chunks:
        raise ValueError("Source passage is unavailable")
    base = chunks[0]["start"]
    text = mask("".join(unpack(r["data"]) for r in chunks))
    begin = link["start"] - base
    end = link["end"] - base
    if text[begin:end] != link["text_preview"]:
        raise ValueError("Source passage changed")
    if other is not None:
        other_begin, other_end = other["start"] - base, other["end"] - base
        if text[other_begin:other_end] != other["text_preview"]:
            raise ValueError("Source passage changed")
        begin, end = min(begin, other_begin), max(end, other_end)
    before = list(re.finditer(r"(?:\r?\n)[ \t]*(?:\r?\n)", text[:begin]))
    after = re.search(r"(?:\r?\n)[ \t]*(?:\r?\n)", text[end:])
    left = max(lo - base, before[-1].end() if before else 0)
    right = min(hi - base, end + after.start() if after else len(text))
    return {
        "context_text": text[left:right],
        "context_start": base + left,
        "context_end": base + right,
    }


def collect(store, pool_limit=256, candidate_policy=None, legacy=False, schema_config=None, same_span_only=False):
    with store.db() as db:
        links = [
            unpack(r["data"])
            for r in db.execute(
                "SELECT data FROM discovery_links ORDER BY score DESC,id"
            )
        ]
        mask = inference.identifier_mask(db)

    if not links:
        return [], {
            "available_pairs": 0,
            "pool_pairs": 0,
            "pool_omitted": 0,
            "candidate_paths": 0,
            "sentence_gate_omitted": 0,
            "untyped_sources": 0,
        }

    pages = {}
    records = {}
    roles = {}
    for link in links:
        aid = link["table"]
        idx = link["row_index"]
        offset = ((idx - 2) // 20) * 20
        key = (aid, offset)
        if key not in pages:
            pages[key] = inference.prepare(store, aid, offset, _mask=mask)
        page = pages[key]
        roles[aid] = role(page["payload"]["columns"])
        if page["provenance"]["version"] != link["row_version"]:
            raise ValueError("Source version changed")
        if (aid, idx) not in records:
            r, cells = next(
                (r, c)
                for r, c in zip(page["provenance"]["records"], page["payload"]["rows"])
                if r["index"] == idx
            )
            anchor_col = roles[aid][1]
            if anchor_col is None:
                # Find first non-empty text cell, or default to 0
                anchor_col = 0
                for col_i, c_val in enumerate(cells):
                    if str(c_val).strip():
                        anchor_col = col_i
                        break
            summary = cells[anchor_col] if 0 <= anchor_col < len(cells) else (cells[0] if cells else "")
            records[(aid, idx)] = {
                "source": aid,
                "name": link["table_name"],
                "columns": page["payload"]["columns"],
                "record": {"index": idx, "record_id": r["record_id"], "cells": cells},
                "anchor_column": anchor_col,
                "summary": summary,
            }

    if candidate_policy is None:
        if (store.root / "lake_config.json").is_file():
            try:
                import lake_config
                cfg = lake_config.read_lake_config(store)
                candidate_policy = cfg.get("candidate_policy", {})
            except Exception:
                candidate_policy = {}
        else:
            candidate_policy = {}

    allow_same_table = candidate_policy.get("allow_same_table", False)
    tokens_limit = candidate_policy.get("context_window_tokens")
    if tokens_limit is not None:
        context_window_chars = int(tokens_limit * 4)
    else:
        context_window_chars = candidate_policy.get("context_window_chars", 1200)

    # The caller owns the ranking budget; lake settings still control windows.

    pairs = {}
    paragraphs = {}
    raw_paths = 0
    omitted_paths = 0

    if legacy:
        # Legacy clinical collection
        groups = collections.defaultdict(list)
        for link in links:
            groups[(link["context"], link["text"], link["start"], link["end"])].append(link)

        for (context, doc, start, end), group in groups.items():
            a = sorted(
                (l for l in group if roles[l["table"]][0] == "diagnosis"),
                key=lambda l: (-l["score"], l["id"]),
            )[:3]
            b = sorted(
                (l for l in group if roles[l["table"]][0] == "medication"),
                key=lambda l: (-l["score"], l["id"]),
            )[:4]
            candidates = sorted(
                ((l, r) for l in a for r in b if l["table"] != r["table"]),
                key=lambda pair: -(pair[0]["score"] + pair[1]["score"]),
            )
            raw_paths += len(candidates)
            omitted_paths += max(0, len(candidates) - 8)
            for left, right in candidates[:8]:
                key = (doc, left["record_id"], right["record_id"])
                score = (left["score"] + right["score"]) / 2
                case = pairs.setdefault(
                    key,
                    {
                        "left": records[(left["table"], left["row_index"])],
                        "right": records[(right["table"], right["row_index"])],
                        "document": doc,
                        "document_name": left["text_name"],
                        "paths": {},
                    },
                )
                span_key = (doc, start, end)
                if span_key not in paragraphs:
                    paragraphs[span_key] = passage_context(store, left, mask)
                p = {
                    **paragraphs[span_key],
                    "text_version": left["text_version"],
                    "left": left["id"],
                    "right": right["id"],
                    "start": start,
                    "end": end,
                    "text": left["text_preview"],
                    "score": score,
                    "vector_context": context,
                }
                old = case["paths"].get((start, end))
                if old is None or score > old["score"]:
                    case["paths"][(start, end)] = p
    else:
        # Schema constraints follow the chosen prompt, never the dataset name.
        if schema_config is None and (store.root / "lake_config.json").is_file():
            import lake_config
            cfg = lake_config.read_lake_config(store)
            schema_config = {**cfg.get("schema_config", {}), "prompt_id": cfg.get("prompt_id")}
        from candidate_paths import neighborhoods
        for doc, raw_candidates, raw_count in neighborhoods(
                links, roles, context_window_chars, allow_same_table,
                required_roles=('diagnosis','medication') if is_clinical_context(schema_config) else None):
            raw_paths += raw_count
            omitted_paths += max(0, raw_count - len(raw_candidates))
            for left, right, _ in raw_candidates[:16]:
                if same_span_only and (left['start'], left['end']) != (right['start'], right['end']):
                    continue
                rec_left = records[(left["table"], left["row_index"])]
                rec_right = records[(right["table"], right["row_index"])]

                role_l = roles.get(left["table"], (None, None))[0]
                role_r = roles.get(right["table"], (None, None))[0]
                if role_l == "diagnosis" and role_r == "medication":
                    c_left, c_right = left, right
                    rec_a, rec_b = rec_left, rec_right
                elif role_l == "medication" and role_r == "diagnosis":
                    c_left, c_right = right, left
                    rec_a, rec_b = rec_right, rec_left
                else:
                    key_l = (rec_left["source"], rec_left["record"]["record_id"])
                    key_r = (rec_right["source"], rec_right["record"]["record_id"])
                    if key_l <= key_r:
                        c_left, c_right = left, right
                        rec_a, rec_b = rec_left, rec_right
                    else:
                        c_left, c_right = right, left
                        rec_a, rec_b = rec_right, rec_left

                key = (doc, rec_a["record"]["record_id"], rec_b["record"]["record_id"])
                score = (c_left["score"] + c_right["score"]) / 2
                case = pairs.setdefault(
                    key,
                    {
                        "left": rec_a,
                        "right": rec_b,
                        "document": doc,
                        "document_name": c_left["text_name"],
                        "paths": {},
                    },
                )
                span_key = (doc, min(c_left["start"], c_right["start"]), max(c_left["end"], c_right["end"]))
                if span_key not in paragraphs:
                    paragraphs[span_key] = passage_context(store, c_left, mask, c_right)
                p = {
                    **paragraphs[span_key],
                    "text_version": c_left["text_version"],
                    "left": c_left["id"],
                    "right": c_right["id"],
                    "start": c_left["start"],
                    "end": c_left["end"],
                    "text": c_left["text_preview"],
                    "score": score,
                    "vector_context": c_left["context"],
                    "same_span": (c_left['start'], c_left['end']) == (c_right['start'], c_right['end']),
                    "anchors": [
                        {"side": "left", "start": c_left["start"], "end": c_left["end"], "preview": c_left["text_preview"]},
                        {"side": "right", "start": c_right["start"], "end": c_right["end"], "preview": c_right["text_preview"]},
                    ],
                }
                path_key = (c_left["start"], c_left["end"], c_right["start"], c_right["end"])
                old = case["paths"].get(path_key)
                if old is None or score > old["score"]:
                    case["paths"][path_key] = p

    cases = list(pairs.values())
    for c in cases:
        c["paths"] = sorted(
            c["paths"].values(), key=lambda p: (not p.get('same_span', legacy), -p["score"], p["start"])
        )[:12]
        c["score"] = max(p["score"] for p in c["paths"])
    # Round-robin documents prevents repeated rows in one document exhausting the budget.
    queues = collections.defaultdict(list)
    for c in sorted(cases, key=lambda c: -c["score"]):
        queues[c["document"]].append(c)
    ordered = []
    while any(queues.values()):
        for doc in sorted(
            queues, key=lambda d: -queues[d][0]["score"] if queues[d] else 1
        ):
            if queues[doc]:
                ordered.append(queues[doc].pop(0))
    selected = ordered[:pool_limit] if pool_limit else ordered
    needed = collections.defaultdict(list)
    for case in selected:
        for path in case['paths']:
            needed[path.pop('vector_context')].append(path)
    # Decode vectors according to store's active model bundle dimension
    from retrieval import get_encoder_policy
    has_lake_config = getattr(store, "root", None) and (Path(store.root) / "lake_config.json").is_file()
    if not has_lake_config:
        policy = get_encoder_policy(store, bundle_id="legacy-loki-clinical")
    else:
        policy = get_encoder_policy(store)
    expected_dim = policy.get("dimensions", 1024)
    with store.db() as db:
        for context, paths in needed.items():
            row = db.execute('SELECT data FROM discovery_cache WHERE key=?',(context,)).fetchone()
            vectors = unpack(row['data']).get('sentence_vectors',{}) if row else {}
            for path in paths:
                vector = vectors.get(str(path['start']))
                if vector is None:
                    raise ValueError('LOKI refined sentence vectors are missing. Run discovery again with the updated adapter.')
                if len(vector) != expected_dim or not all(math.isfinite(v) for v in vector):
                    raise ValueError(f'Invalid contextual sentence vector (expected {expected_dim}, got {len(vector)})')
                path['vector'] = vector
    return selected, {
        "available_pairs": len(cases),
        "pool_pairs": len(selected),
        "pool_omitted": len(cases) - len(selected),
        "candidate_paths": raw_paths,
        "sentence_gate_omitted": omitted_paths,
        "untyped_sources": sum(v[0] is None for v in roles.values()),
        "construction_policy": "legacy-span-v1" if legacy else "span-preserving-neighborhood-v2",
        "endpoint_contract": "diagnosis-medication" if legacy or is_clinical_context(schema_config) else "generic-cross-table",
    }


def anonymous(case):
    left_rec = case["left"]["record"]
    right_rec = case["right"]["record"]
    left_cells = left_rec["cells"]
    right_cells = right_rec["cells"]

    left_anchor = case["left"].get("summary")
    if not left_anchor:
        anc_col = case["left"].get("anchor_column")
        if anc_col is not None and 0 <= anc_col < len(left_cells):
            left_anchor = left_cells[anc_col]
        else:
            left_anchor = next((c for c in left_cells if str(c).strip()), (left_cells[0] if left_cells else ""))

    right_anchor = case["right"].get("summary")
    if not right_anchor:
        anc_col = case["right"].get("anchor_column")
        if anc_col is not None and 0 <= anc_col < len(right_cells):
            right_anchor = right_cells[anc_col]
        else:
            right_anchor = next((c for c in right_cells if str(c).strip()), (right_cells[0] if right_cells else ""))

    left_dict = dict(zip(case["left"]["columns"], left_cells))
    right_dict = dict(zip(case["right"]["columns"], right_cells))

    return {
        "record_a_summary": left_anchor,
        "record_b_summary": right_anchor,
        "record_a": left_dict,
        "record_b": right_dict,
        "record_a_name": case["left"].get("name", "Record A"),
        "record_b_name": case["right"].get("name", "Record B"),
        "query_text": (f"Diagnosis: {left_anchor} | Medication: {right_anchor}"
                       if role(case['left']['columns'])[0] == 'diagnosis' and role(case['right']['columns'])[0] == 'medication'
                       else f"{case['left']['columns'][case['left']['anchor_column']]}: {left_anchor} | {case['right']['columns'][case['right']['anchor_column']]}: {right_anchor}"),
        "diagnosis_anchor": left_anchor,
        "medication_anchor": right_anchor,
        "diagnosis": left_dict,
        "medication": right_dict,
        "paths": [
            {
                "text": p.get("context_text", p["text"]),
                "score": p["score"],
                "vector": p["vector"],
            }
            for p in case["paths"]
        ],
    }


def resolve_reranker(store):
    root = Path(__file__).resolve().parents[1]
    config_path = store.root / 'lake_config.json'
    if config_path.is_file():
        cfg = json.loads(config_path.read_text(encoding='utf-8'))
        if cfg.get('reranker_id'):
            from reranker_config import resolve
            return resolve(cfg['reranker_id'])
        configured = {**cfg.get('schema_config', {}), 'prompt_id': cfg.get('prompt_id')}
        if cfg.get('bundle_id') != 'legacy-loki-clinical' and not is_clinical_context(configured):
            bge = root / 'models/step2_discovery/bge-reranker-base'
            if (bge / 'model.safetensors').is_file():
                return str(bge), 'BAAI/bge-reranker-base'
    for gte_dir in [
        root / ".idun/models/gte-reranker",
        root / "models/step2_discovery/gte-reranker",
        root / "models/step2_discovery/gte-reranker-modernbert-base",
    ]:
        if (gte_dir / "model.safetensors").is_file() or (gte_dir / "pytorch_model.bin").is_file():
            return str(gte_dir), "Alibaba-NLP/gte-reranker-modernbert-base"
    raise ValueError('The restored Integration policy requires the local GTE reranker. Install gte-reranker-modernbert-base in Settings; no silent model substitution is performed.')


def ranking_payload(cases):
    """Share repeated evidence vectors across candidates in worker/cache inputs."""
    import array
    vectors, indices, by_object = [], {}, {}
    items = []
    for case in cases:
        item = anonymous(case)
        for path in item['paths']:
            vector = path.pop('vector')
            key = by_object.get(id(vector))
            if key is None:
                key = hashlib.sha256(array.array('f', vector).tobytes()).hexdigest()
                by_object[id(vector)] = key
            if key not in indices:
                indices[key] = len(vectors)
                vectors.append(vector)
            path['vector_index'] = indices[key]
        items.append(item)
    return {'cases': items, 'vectors': vectors}


def worker(store, cases, check):
    root = Path(__file__).resolve().parents[1]
    token = uuid.uuid4().hex
    request = store.root / "pending" / (token + ".semantic.json")
    response = request.with_suffix(".result")
    log = request.with_suffix(".log")
    progress_file = Path(str(response) + ".progress")
    process = None
    last = -1
    reranker_path, reranker_name = resolve_reranker(store)
    try:
        request.write_text(
            json.dumps({
                **ranking_payload(cases),
                "reranker_path": reranker_path,
                "reranker_name": reranker_name,
                "score_cache": str(store.root / 'reranker-scores.sqlite3'),
            }),
            encoding="utf-8",
        )
        with log.open("w", encoding="utf-8") as out:
            process = subprocess.Popen(
                [
                    settings.runtime(store)["python"],
                    str(root / "scripts/materialize-loki.py"),
                    str(request),
                    str(response),
                ],
                stdout=out,
                stderr=out,
                env=settings.worker_env(store),
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            deadline = time.monotonic() + 600
            while process.poll() is None:
                check()
                if progress_file.exists():
                    try:
                        raw = progress_file.read_text(encoding="utf-8")
                        detail = json.loads(raw)
                        if not isinstance(detail, dict):
                            detail = {'phase': 'Cross-encoder evidence scoring', 'completed': int(detail), 'total': sum(len(c['paths']) for c in cases)}
                        n = (detail['phase'], detail['completed'], detail['total'])
                    except (ValueError, OSError):
                        n = last
                    callback = getattr(store, "semantic_worker_progress", None)
                    if n != last:
                        if callback:
                            callback(**detail)
                        last = n
                        deadline = time.monotonic() + 600
                if time.monotonic() > deadline:
                    raise ValueError("Semantic worker made no progress for ten minutes")
                time.sleep(0.1)
        if process.returncode:
            err_msg = ""
            if log.exists():
                try:
                    raw_log = log.read_text(encoding="utf-8").strip()
                    lines = [l.strip() for l in raw_log.splitlines() if l.strip()]
                    if lines:
                        err_msg = lines[-1]
                except Exception:
                    pass
            raise ValueError(
                f"Semantic worker failed: {err_msg or 'Verify the selected Python runtime, sentence-transformers, and reranker model artifacts.'}"
            )
        result = json.loads(response.read_text(encoding="utf-8"))
        if len(result["items"]) != len(cases):
            raise ValueError("Incomplete semantic worker response")
        for c, item in zip(cases, result["items"]):
            scores = item["ce_scores"]
            if (
                len(scores) != len(c["paths"])
                or not all(
                    type(v) in (int, float) and math.isfinite(v) and 0 <= v <= 1
                    for v in scores
                )
                or type(item["cluster"]) != int
            ):
                raise ValueError("Invalid semantic worker output")
        return result
    finally:
        if process and process.poll() is None:
            process.kill()
            process.wait()
        for p in (request, response, log, progress_file):
            p.unlink(missing_ok=True)


def model_input(case, schema_config=None):
    def fields(side):
        return [
            {"column": name, "value": value}
            for name, value in zip(case[side]["columns"], case[side]["record"]["cells"])
        ]

    payload = {
        "record_a": fields("left"),
        "record_b": fields("right"),
        "diagnosis": fields("left"),
        "medication": fields("right"),
        "evidence": [
            {"evidence": p["evidence"], "text": p.get("context_text", p["text"])}
            for p in case["paths"]
        ],
    }
    # Preserve the working clinical request without duplicate aliases. An explicit
    # generic preset takes precedence over clinical-looking source columns.
    if is_clinical_context(schema_config, case):
        payload.pop('record_a')
        payload.pop('record_b')
    return payload

def is_clinical_context(schema_config=None, case=None):
    if schema_config and isinstance(schema_config, dict):
        preset = schema_config.get("preset") or schema_config.get("prompt_id")
        if preset == "clinical-preset-v1":
            return True
        if preset in ("generic-evidence-v1", "open-discovery-v1"):
            return False
        labels = schema_config.get("labels")
        if labels:
            clinical_specific = {"TREATS", "ADVERSE_EFFECT", "DISCONTINUED", "CONTRAINDICATED", "INDICATED"}
            if any(l in clinical_specific for l in labels):
                return True
            return False
    if case and isinstance(case, dict):
        left_cols = case.get("left", {}).get("columns", [])
        right_cols = case.get("right", {}).get("columns", [])
        clinical_names = {"diagnosis", "medication", "drug", "condition"}
        if any(c.lower() in clinical_names for c in left_cols + right_cols):
            return True
    return False


def validate(output, case, schema_config=None):
    if (
        not isinstance(output, dict)
        or set(output) != {"decisions"}
        or not isinstance(output["decisions"], list)
    ):
        raise ValueError("Invalid semantic label response")
    known = {p["evidence"] for p in case["paths"]}
    seen = {}
    decisions = [dict(d) if isinstance(d, dict) else d for d in output["decisions"]]
    if not 1 <= len(decisions) <= len(known) * 24:
        raise ValueError("Invalid number of path labels")
    active_labels = llm.resolve_labels(schema_config)
    mode = schema_config.get("mode", "strict") if isinstance(schema_config, dict) else "strict"
    required_keys = {"evidence", "relationship", "basis", "reason"}
    valid_keys = set(llm.DECISION["properties"])
    clinical = is_clinical_context(schema_config, case)
    for d in decisions:
        if not isinstance(d, dict):
            raise ValueError("Invalid path label shape")
        # Normalize direction and quote aliases between neutral and clinical
        d.setdefault("direction", "undirected")
        if d.get("record_a_quote") and not d.get("diagnosis_quote"):
            d["diagnosis_quote"] = d["record_a_quote"]
        if d.get("record_b_quote") and not d.get("medication_quote"):
            d["medication_quote"] = d["record_b_quote"]
        if d.get("diagnosis_quote") and not d.get("record_a_quote"):
            d["record_a_quote"] = d["diagnosis_quote"]
        if d.get("medication_quote") and not d.get("record_b_quote"):
            d["record_b_quote"] = d["medication_quote"]

        if not required_keys.issubset(set(d)) or not set(d).issubset(valid_keys):
            raise ValueError("Invalid path label shape")
        if (
            not all(
                isinstance(d[k], str) for k in ("evidence", "relationship", "basis")
            )
            or d["evidence"] not in known
            or d["basis"]
            not in ("text_supported", "inference", "clinical_inference", "insufficient")
        ):
            raise ValueError("Unknown evidence or relationship")
        rel = d["relationship"].strip().upper()
        if mode == "strict":
            if rel not in active_labels:
                raise ValueError(f"Unknown relationship: {d['relationship']}")
        else:
            if not (rel in active_labels or re.fullmatch(r"[A-Z0-9_]{2,64}", rel)):
                raise ValueError(f"Invalid emergent relationship name: {d['relationship']}")
        d["relationship"] = rel
        if (
            not isinstance(d["reason"], str)
            or not d["reason"].strip()
            or len(d["reason"]) > 1200
        ):
            raise ValueError("A bounded relation explanation is required")
        passage = next(
            p.get("context_text", p["text"])
            for p in case["paths"]
            if p["evidence"] == d["evidence"]
        )
        for quote_key in ("diagnosis_quote", "medication_quote", "record_a_quote", "record_b_quote"):
            if quote_key in d:
                if not isinstance(d[quote_key], str) or len(d[quote_key]) > 1000:
                    raise ValueError("Invalid grounding quote")
                quote = d[quote_key]
                if quote.strip() and quote not in passage:
                    match = re.search(
                        r"\s+".join(re.escape(part) for part in quote.split()), passage
                    )
                    if match:
                        d[quote_key] = match.group()
        is_positive = d["relationship"] not in ("NEGATIVE", "UNRESOLVED")
        quote_a = d.get("record_a_quote", d.get("diagnosis_quote", ""))
        quote_b = d.get("record_b_quote", d.get("medication_quote", ""))
        if (
            is_positive
            and d["basis"] == "text_supported"
            and (not quote_a.strip() or quote_a not in passage or not quote_b.strip() or quote_b not in passage)
        ):
            d.update(
                basis="insufficient",
                reason=d["reason"]
                + (" [Withheld: both clinical anchors must be grounded in this passage.]" if clinical else " [Withheld: both anchors must be grounded in this passage.]"),
            )

        # Ambiguous co-reference checks
        pronouns = {'it', 'its', 'they', 'them', 'their', 'theirs', 'he', 'him', 'his', 'she', 'her', 'hers', 'this', 'that', 'these', 'those'}
        if is_positive and d["basis"] == "text_supported":
            if quote_a.strip().lower() in pronouns or quote_b.strip().lower() in pronouns:
                d.update(
                    basis="insufficient",
                    reason=d["reason"]
                    + " [Withheld: ambiguous co-reference pronoun without named entity grounding.]",
                )

        # Polarity contradiction check (positive label with explicit negative explanation)
        if is_positive and d["basis"] == "text_supported":
            if re.search(r'\b(?:no\s+longer|not\s+(?:supported|associated|related|employed|found|indicated|present|connected)|no\s+(?:evidence|relationship|relation|association|connection)|unsupported|contradicts?|denies?|never)\b', d["reason"], re.I):
                d.update(
                    basis="insufficient",
                    reason=d["reason"]
                    + " [Withheld: polarity contradiction between positive label and negative explanation.]",
                )

        # Modality check (speculative modality does not support factual relationship)
        if is_positive and d["basis"] == "text_supported":
            if re.search(r'\b(?:purely\s+speculative|unclear\s+whether|hypothetical|unknown\s+if|uncertain\s+whether|no\s+direct\s+evidence|speculates?)\b', d["reason"], re.I):
                d.update(
                    basis="insufficient",
                    reason=d["reason"]
                    + " [Withheld: speculative modality does not support factual relationship.]",
                )

        # Clinical dosage/regimen check exclusively when clinical
        if clinical:
            regimen = bool(
                re.search(
                    r"\bsig\s*:|\b(?:mg|mcg|tablet|capsule)\b.*\b(?:PO|IV|Q24H|daily|BID|TID)\b",
                    passage,
                    re.I,
                )
            )
            action = bool(
                re.search(
                    r"\b(?:started|stopped|held|discontinued|recommended|caused|worsened|developed|because|following|secondary to|due to|for (?!\d|one\b|two\b|three\b|four\b|five\b|six\b|seven\b))",
                    passage,
                    re.I,
                )
            )
            if (
                is_positive
                and d["basis"] == "text_supported"
                and regimen
                and not action
            ):
                d.update(
                    basis="clinical_inference",
                    reason=d["reason"]
                    + " [Withheld: this passage is a medication regimen without a clinical relationship statement.]",
                )
        key = (d["evidence"], d["relationship"])
        if key in seen:
            previous=seen[key]
            if previous['basis']!=d['basis']:
                previous['basis']='insufficient'
                previous['reason']='[Withheld: repeated labels disagree about evidence support.] '+previous['reason']
            elif d['reason'] not in previous['reason']:
                previous['reason'] += ' ' + d['reason']
            previous['reason']=previous['reason'][:1200]
        else:
            seen[key]=d
    decisions=list(seen.values())
    if len(decisions)>len(known)*max(len(active_labels), 10):raise ValueError('Too many distinct relationship labels')
    if {d["evidence"] for d in decisions} != known:
        raise ValueError("Every evidence path needs a decision")
    positives = sorted(
        {
            d["relationship"]
            for d in decisions
            if d["relationship"] not in ("NEGATIVE", "UNRESOLVED") and d["basis"] == "text_supported"
        }
    )
    negative = any(
        d["relationship"] == "NEGATIVE" and d["basis"] == "text_supported"
        for d in decisions
    )
    status = (
        "conflict"
        if positives and negative
        else ("include" if positives else "abstain")
    )
    return {
        "candidate": case["candidate"],
        "status": status,
        "relations": positives,
        "reason": " ".join(dict.fromkeys(d["reason"] for d in decisions)),
        "validation": "Exact source references preserved. Semantic typing is model-proposed; no patient/admission identity is inferred.",
        "path_decisions": decisions,
    }




def corrected_label(case, schema_config, request, check, retrying, cached=None):
    """Initial response plus at most two model corrections, validated independently."""
    correction = None
    for attempt in range(3):
        check()
        output = None
        try:
            output = cached if attempt == 0 and cached is not None else request(correction)
        except llm.InvalidCompletion as error:
            failure, output = error, error.response
        else:
            check()
            try:
                validated = validate(output, case, schema_config=schema_config)
            except ValueError as error:
                failure = error
            else:
                return {'decisions': validated['path_decisions']}, attempt
        check()
        if attempt == 2:
            raise ValueError(f'LLM response invalid after 2 correction retries: {failure}. Completed passages are preserved; resume the run to retry this candidate.') from failure
        correction = {'response': output, 'error': str(failure)}
        retrying(attempt + 1, str(failure))


def run(
    store,
    limit,
    timeout,
    check=lambda: None,
    progress=lambda **kw: None,
    generate=llm.generate,
    execute=worker,
    new_batch=False,
    schema_config=None,
    resume_key=None,
    mode='new',
    base_run_id=None,
    base_revision=None,
):
    import integration

    if schema_config is not None and isinstance(schema_config, dict) and hasattr(store, "root") and (store.root / "lake_config.json").is_file():
        try:
            import lake_config
            lake_cfg = lake_config.read_lake_config(store)
            if "prompt_id" not in schema_config and "prompt_id" in lake_cfg:
                schema_config["prompt_id"] = lake_cfg["prompt_id"]
            if "context_config" not in schema_config and "context_config" in lake_cfg:
                schema_config["context_config"] = lake_cfg["context_config"]
        except Exception:
            pass

    integration.setup(store)
    before = integration.snapshot(store)
    config = settings.llm_validate(settings.read(store)["llm"])
    if mode not in ('new', 'extend', 'rebuild'):
        raise ValueError('Unknown integration mode')
    base = None
    if mode != 'new':
        base = integration.get(store, base_run_id)
        if not base_revision or base['content_revision'] != base_revision:
            raise ValueError('The selected base run changed. Refresh before continuing.')
        if mode == 'extend':
            original_schema = base.get('inference_schema_config', base.get('schema_config'))
            base_config = {'provider': base['provider'], 'base_url': base['endpoint'],
                           'model': base['model'], **base.get('generation', {})}
            if policy_key(base_config, original_schema) != policy_key(config, schema_config):
                raise ValueError('Model or inference settings changed. Rebuild instead of extending this run.')
    is_clinical = is_clinical_context(schema_config)
    if not is_clinical and hasattr(store, "root") and (store.root / "lake_config.json").is_file():
        try:
            import lake_config
            cfg = lake_config.read_lake_config(store)
            if cfg.get("prompt_id") == "clinical-preset-v1":
                is_clinical = True
        except Exception:
            pass
    check()
    progress(phase="Extracting complementary row-pair paths", completed=0, total=limit)
    # September 19 contract: one document-balanced pool, capped before reranking.
    cases, coverage = collect(store, 256, legacy=is_clinical, same_span_only=is_clinical,
                              schema_config=schema_config)
    coverage.update(ranking_pool_policy='september19-span-256-v1' if is_clinical else 'generic-neighborhood-256-v1')
    if not cases:
        raise ValueError(
            "No diagnosis–medication shared-text paths. Inspect discovery coverage and projected column roles."
            if is_clinical
            else "No row–text evidence paths found. Inspect discovery coverage and projected columns."
        )
    progress(phase="Cross-encoder ranking and contextual HDBSCAN", total=len(cases))
    reranker_path, reranker_name = resolve_reranker(store)
    from reranker_config import fingerprint
    rank_key = hashlib.sha256(
        json.dumps(
            [
                VERSION,
                "projection-pca-3d-v1",
                "september19-span-256-v1",
                ranking_payload(cases),
                fingerprint(reranker_path, reranker_name),
                len(cases),
            ]
        ).encode()
    ).hexdigest()
    with store.db() as db:
        db.execute(
            "CREATE TABLE IF NOT EXISTS semantic_rank_cache(key TEXT PRIMARY KEY,data TEXT)"
        )
        cached_rank = db.execute(
            "SELECT data FROM semantic_rank_cache WHERE key=?", (rank_key,)
        ).fetchone()
    if cached_rank:
        result = json.loads(cached_rank["data"])
        result.update(seconds=0, reused=True)
    else:
        store.semantic_worker_progress = progress
        try:
            result = execute(store, cases, check)
        finally:
            store.semantic_worker_progress = None
        check()
        with store.lock:
            check()
            if integration.snapshot(store) != before:
                raise ValueError("Discovery changed during semantic ranking")
            with store.db() as db:
                db.execute(
                    "INSERT OR REPLACE INTO semantic_rank_cache VALUES(?,?)",
                    (rank_key, json.dumps(result)),
                )
    check()
    for c, item in zip(cases, result["items"]):
        c["cluster"] = item["cluster"]
        c["noise"] = item["noise"]
        c["point"] = item.get("point", [0, 0])
        for p, score in zip(c["paths"], item["ce_scores"]):
            p["ce_score"] = score
            p.pop("vector", None)
        c["paths"].sort(key=lambda p: (-p["ce_score"], -p["score"], p["start"]))
        c["ce_score"] = max(p["ce_score"] for p in c["paths"])
        # Choose distinct contextual passages AFTER reranking, not three raw-score sentences.
        c["ranked_paths"] = len(c["paths"])
        distinct = {}
        for p in c["paths"]:
            key = (p.get("context_start", p["start"]), p.get("context_end", p["end"]))
            anchor = {
                k: p[k] for k in ("left", "right", "start", "end", "score", "ce_score")
            }
            if key not in distinct:
                distinct[key] = {**p, "anchors": [anchor]}
            else:
                distinct[key]["anchors"].append(anchor)
        c["paths"] = list(distinct.values())[:3]
    # Original combined CE filter: remove a pair only when weak in BOTH score distributions.
    scores = sorted(c["score"] for c in cases)
    ces = sorted(c["ce_score"] for c in cases)

    def quartile(values):
        at = (len(values) - 1) * 0.25
        lo = int(at)
        hi = min(lo + 1, len(values) - 1)
        return values[lo] + (values[hi] - values[lo]) * (at - lo)

    loki_cutoff, ce_cutoff = quartile(scores), quartile(ces)
    kept = [
        c for c in cases if not (c["score"] < loki_cutoff and c["ce_score"] < ce_cutoff)
    ]
    coverage["ce_filtered"] = len(cases) - len(kept)
    system_prompt = llm.build_system_prompt(schema_config)
    def label_key(payload):
        return hashlib.sha256(json.dumps([VERSION,LABEL_POLICY,system_prompt,config['provider'],config['base_url'],config['model'],config.get('temperature'),config.get('top_p'),config.get('max_output_tokens'),payload],sort_keys=True).encode()).hexdigest()
    decisions=[];began=time.perf_counter();cached_calls=0;issued_calls=0
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS semantic_labels(key TEXT PRIMARY KEY,data TEXT)')
    def identity(case):
        return (case['left']['record']['record_id'], case['right']['record']['record_id'], case['document'])
    def inputs(case):
        return sorted(label_key(model_input({**case, 'paths': [{**p, 'evidence': 'E1'}]}, schema_config)) for p in case['paths'])
    ranked = sorted(kept, key=lambda c: (-c['ce_score'], -c['score'], identity(c)))
    retained = []
    old_cases = {identity(c): c for c in base['cases']} if base and mode == 'extend' else {}
    eligible = [c for c in ranked if identity(c) not in old_cases or base.get('inference_policy') != LABEL_POLICY or inputs(c) != inputs(old_cases[identity(c)])]
    selected = eligible[:limit]
    if old_cases:
        replacing = {identity(c) for c in selected}
        retained = [c for key, c in old_cases.items() if key not in replacing]
    coverage.update(retained_pairs=len(retained), updated_pairs=len(selected), pending_pairs=max(0, len(eligible)-limit))
    from evidence_storage import encode as pack
    batch_key=hashlib.sha256(json.dumps([rank_key,LABEL_POLICY,system_prompt,config['provider'],config['base_url'],config['model'],config.get('temperature'),config.get('top_p'),config.get('max_output_tokens'),limit],sort_keys=True).encode()).hexdigest()
    if mode != 'new':
        batch_key = hashlib.sha256(json.dumps([batch_key, mode, base_run_id, base_revision]).encode()).hexdigest()
    with store.lock,store.db() as db:
        check()
        if integration.snapshot(store)!=before:raise ValueError('Discovery changed before integration batch selection')
        db.execute('CREATE TABLE IF NOT EXISTS semantic_checkpoint(id INTEGER PRIMARY KEY,fingerprint TEXT,data BLOB,completed INTEGER,state TEXT,total INTEGER,budget INTEGER,revision TEXT,policy TEXT)')
        checkpoint=db.execute('SELECT * FROM semantic_checkpoint WHERE id=1').fetchone()
        if resume_key and (new_batch or resume_key != batch_key or not checkpoint
                           or checkpoint['state'] != 'active' or checkpoint['fingerprint'] != resume_key):
            raise ValueError('The original batch changed while queued. Refresh before starting a new batch.')
        if resume_key and not new_batch and checkpoint and checkpoint['state']=='active' and checkpoint['fingerprint']==batch_key:
            saved=unpack(checkpoint['data']);selected=saved['selected'];coverage=saved['coverage']
            label_namespace = saved.get('label_namespace')
            resumed=True
        else:
            if checkpoint:
                previous_namespace = unpack(checkpoint['data']).get('label_namespace')
                if previous_namespace:
                    db.execute('DELETE FROM semantic_labels WHERE key LIKE ?', ('batch:' + previous_namespace + ':%',))
            label_namespace = uuid.uuid4().hex if mode != 'extend' else None
            db.execute("INSERT OR REPLACE INTO semantic_checkpoint VALUES(1,?,?,0,'active',?,?,?,?)",(batch_key,pack({'selected':selected,'coverage':coverage,'schema_config':schema_config,
                'mode':mode,'base_run_id':base_run_id,'base_revision':base_revision,'label_namespace':label_namespace}),len(selected),limit,before,policy_key(config, schema_config)))
            resumed=False
    progress(phase='Resuming original integration batch' if resumed else 'Integration batch fixed',total=len(selected),completed=0)
    for i, c in enumerate(selected):
        check()
        c["candidate"] = f"P{i+1}"
        for j, p in enumerate(c["paths"]):
            p["evidence"] = f"E{j+1}"
        progress(
            phase="Typing diagnosis–medication evidence" if is_clinical else "Typing evidence-grounded relationships",
            completed=i,
            total=len(selected),
        )
        combined = {"decisions": []}
        for path_index, path in enumerate(c["paths"]):
            check()
            original_evidence=path["evidence"]
            single = {**c, "paths": [{**path,"evidence":"E1"}]}
            payload = model_input(single, schema_config)
            progress(
                phase=f"Typing pair {i+1}/{len(selected)}, passage {path_index+1}/{len(c['paths'])}",
                completed=i,
                total=len(selected),
            )
            key = label_key(payload)
            scoped_key = 'batch:' + label_namespace + ':' + key if label_namespace else key
            with store.db() as db:
                old = db.execute(
                    "SELECT data FROM semantic_labels WHERE key=?", (scoped_key,)
                ).fetchone() if resumed or mode == 'extend' else None
            def request(correction):
                nonlocal issued_calls
                issued_calls += 1
                if generate is llm.generate:
                    if config.get('provider') == 'huggingface':
                        return llm.generate(config, payload, timeout, schema_config=schema_config, check=check, correction=correction)
                    return llm.generate_cancellable(config, payload, timeout, check, schema_config=schema_config, correction=correction)
                import inspect
                parameters = inspect.signature(generate).parameters
                accepts_kwargs = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in parameters.values())
                options = {k: v for k, v in {'schema_config': schema_config, 'correction': correction, 'check': check}.items() if accepts_kwargs or k in parameters}
                return generate(config, payload, timeout, **options)
            def retrying(attempt, error):
                progress(phase=f'Correcting pair {i+1}/{len(selected)}, passage {path_index+1}/{len(c["paths"])} · retry {attempt}/2 · {error}', completed=i, total=len(selected))
            output, corrections = corrected_label(single, schema_config, request, check, retrying, cached=json.loads(old['data']) if old else None)
            combined["decisions"].extend({**d,"evidence":original_evidence} for d in output["decisions"])
            with store.lock:
                check()
                if integration.snapshot(store) != before:
                    raise ValueError("Discovery changed; semantic proposal discarded")
                if old and not corrections:
                    cached_calls += 1
                else:
                    with store.db() as db:
                        db.execute(
                            "INSERT OR REPLACE INTO semantic_labels VALUES(?,?)",
                            (key, json.dumps(output)),
                        )
                        if scoped_key != key:
                            db.execute('INSERT OR REPLACE INTO semantic_labels VALUES(?,?)', (scoped_key, json.dumps(output)))
        decisions.append(validate(combined, c, schema_config=schema_config))
        with store.db() as db:db.execute('UPDATE semantic_checkpoint SET completed=? WHERE id=1 AND fingerprint=?',(i+1,batch_key))
        progress(completed=i + 1)
    batch_total = len(selected)
    llm_calls = issued_calls
    retained_candidates = {}
    if retained:
        old_decisions = {d['candidate']: d for d in base.get('model_decisions', base['decisions'])}
        for case in retained:
            case = copy.deepcopy(case)
            decision = copy.deepcopy(old_decisions[case['candidate']])
            previous_candidate = case['candidate']
            case['candidate'] = decision['candidate'] = f'P{len(selected)+1}'
            retained_candidates[previous_candidate] = case['candidate']
            selected.append(case)
            decisions.append(decision)
    model_decisions = copy.deepcopy(decisions)
    curation = copy.deepcopy(base.get('curation', [])) if base else []
    decisions = integration.apply_curation(model_decisions, curation)
    # Unchanged retained pairs preserve their already reviewed decisions.
    if retained_candidates:
        reviewed = {retained_candidates[d['candidate']]: dict(copy.deepcopy(d), candidate=retained_candidates[d['candidate']])
                    for d in base['decisions'] if d['candidate'] in retained_candidates}
        decisions = [reviewed.get(d['candidate'], d) for d in decisions]
    coverage.update(
        reviewed=len(selected),
        omitted=max(0, len(cases) - len(selected)),
        available_bridges=coverage["available_pairs"],
    )
    plan = {
        "id": uuid.uuid4().hex,
        "version": VERSION,
        "title": "Diagnosis–medication integration" if is_clinical else "Evidence-grounded integration",
        "description": "Clinical relationships inferred from LOKI row-pair paths and mediating narrative evidence." if is_clinical else "Relationships inferred from row-pair paths and mediating narrative evidence.",
        "operation": "semantic_join",
        "grain": "one_row_per_source_pair_document_relationship",
        "schema_config": integration.curated_schema(schema_config, curation),
        "inference_schema_config": copy.deepcopy(schema_config),
        "inference_policy": LABEL_POLICY,
        "model_decisions": model_decisions,
        "provenance_status": base.get('provenance_status', 'legacy_baseline_original_labels_unverified') if base and mode == 'extend' else 'model_original',
        "curation": curation,
        "parent_run_id": base_run_id,
        "cases": selected,
        "decisions": decisions,
        "counts": {
            key: sum(d["status"] == key for d in decisions)
            for key in ("include", "abstain", "conflict")
        },
        "coverage": coverage,
        "provider": config["provider"],
        "endpoint": config["base_url"],
        "model": config["model"],
        "generation": {
            "temperature": config.get("temperature"),
            "top_p": config.get("top_p"),
            "max_output_tokens": config.get("max_output_tokens"),
            "timeout_seconds": timeout,
        },
        "seconds": time.perf_counter() - began + result["seconds"],
        "scope": "Projected diagnosis and medication rows joined through source narrative. Distinct source rows and mediator documents stay distinct; this is not a patient/admission identity join." if is_clinical else "Projected entity rows joined through source narrative. Distinct source rows and mediator documents stay distinct.",
        "pipeline": {k: v for k, v in result.items() if k != "items"},
        "cached_calls": cached_calls,
        "llm_calls": llm_calls,
        "batch": {"resumed":resumed,"budget":limit,"total":batch_total,"mode":mode,
                  "retained":len(retained),"run_total":len(selected)},
        "policy": "Narrative-supported clinical relationships; co-occurrence-only treatment hypotheses are withheld." if is_clinical else "Narrative-supported relationships; ungrounded co-occurrence hypotheses are withheld.",
    }
    if retained_candidates and base.get('relationship_row_edits'):
        plan['relationship_row_edits'] = inherit_relationship_edits(base, plan, retained_candidates)
        plan['relationship_edit_audit'] = copy.deepcopy(base.get('relationship_edit_audit', []))
    sources = sorted(
        {c[k]["source"] for c in selected for k in ("left", "right")}
        | {c["document"] for c in selected}
    )
    with store.lock:
        check()
        if integration.snapshot(store) != before:
            raise ValueError("Discovery changed; proposal was not published")
        if base and integration.get(store, base_run_id)['content_revision'] != base_revision:
            raise ValueError('The base run changed during inference; proposal was not published. Refresh and retry.')
        with store.db() as db:
            from integration_journey import capture_input
            plan['journey_input'] = capture_input(db, before)
            db.execute(
                "INSERT INTO integration_plans VALUES(?,?,?,?,0,?)",
                (
                    plan["id"],
                    before,
                    json.dumps(sources),
                    json.dumps(plan),
                    time.time(),
                ),
            )
            db.execute("UPDATE semantic_checkpoint SET state='complete' WHERE id=1 AND fingerprint=?",(batch_key,))
            if label_namespace:
                db.execute('DELETE FROM semantic_labels WHERE key LIKE ?', ('batch:' + label_namespace + ':%',))
    return plan


def inherit_relationship_edits(base, plan, candidates):
    """Carry only reviews of unchanged retained pairs, despite candidate renumbering."""
    old = copy.deepcopy(base);old.pop('relationship_row_edits', None)
    current = copy.deepcopy(plan);current.pop('relationship_row_edits', None)
    available = {relationship_row_key(row) for row in rows(current)}
    inherited = {}
    for row in rows(old):
        key = relationship_row_key(row)
        if key not in base.get('relationship_row_edits', {}) or row['candidate'] not in candidates:
            continue
        row['candidate'] = candidates[row['candidate']]
        new_key = relationship_row_key(row)
        if new_key in available:
            inherited[new_key] = base['relationship_row_edits'][key]
    return inherited


def relationship_row_key(row):
    return hashlib.sha256(json.dumps([row['candidate'],row['left_record'],row['right_record'],row['relation'],row['direction'],row['text_source']],sort_keys=True).encode()).hexdigest()


def curated_rows(plan,values):
    edits=plan.get('relationship_row_edits',{})
    grouped={}
    for source in values:
        row=dict(source);key=relationship_row_key(row)
        row['origin_row_keys']=[key];row['original_relation']=row['relation'];row['original_relations']=[row['relation']]
        if key in edits:
            target=edits[key]
            if target is None:continue
            row.update(relation=target,refined_cluster=f"{row['cluster']}:{target}",status='Manually curated relationship; original model output preserved')
        group=(row['candidate'],row['left_record'],row['right_record'],row['relation'],row['direction'],row['text_source'])
        if group not in grouped:grouped[group]=row;continue
        saved=grouped[group]
        saved['origin_row_keys']+=row['origin_row_keys']
        saved['original_relations']=sorted(set(saved['original_relations']+row['original_relations']))
        seen={json.dumps(e,sort_keys=True) for e in saved['evidence']}
        saved['evidence']=saved['evidence']+[e for e in row['evidence'] if json.dumps(e,sort_keys=True) not in seen]
        saved['evidence_count']=len(saved['evidence'])
        saved['path_count']=sum(len(e.get('anchors',[e])) for e in saved['evidence'])
    return list(grouped.values())


def rows(plan):
    cases = {c["candidate"]: c for c in plan["cases"]}
    out = []
    for d in plan["decisions"]:
        if d["status"] != "include":
            continue
        c = cases[d["candidate"]]
        
        # Group supported path decisions by (relation, direction)
        # This guarantees distinct directed relations are materialized by (source-row A/B, mediator doc, predicate, direction)
        supported_by_rel_dir = collections.defaultdict(list)
        for v in d.get("path_decisions", []):
            if v.get("basis") == "text_supported" and v.get("relationship") not in ("NEGATIVE", "UNRESOLVED"):
                rel = v["relationship"]
                direction = v.get("direction", "undirected")
                supported_by_rel_dir[(rel, direction)].append(v)

        for (relation, direction), v_list in supported_by_rel_dir.items():
            supported_evidence = {v["evidence"] for v in v_list}
            paths = [p for p in c["paths"] if p["evidence"] in supported_evidence]
            if not paths:
                continue
            p = paths[0]
            primary_dec = v_list[0]
            quote_a = primary_dec.get("record_a_quote", primary_dec.get("diagnosis_quote", ""))
            quote_b = primary_dec.get("record_b_quote", primary_dec.get("medication_quote", ""))
            left_val = c["left"]["record"]["cells"][c["left"]["anchor_column"]]
            right_val = c["right"]["record"]["cells"][c["right"]["anchor_column"]]
            out.append(
                {
                    "candidate": d["candidate"],
                    "left_value": left_val,
                    "right_value": right_val,
                    "record_a_value": left_val,
                    "record_b_value": right_val,
                    "relation": relation,
                    "direction": direction,
                    "cluster": c["cluster"],
                    "refined_cluster": f"{c['cluster']}:{relation}",
                    "evidence_quote": p.get("context_text", p["text"]),
                    "record_a_quote": quote_a,
                    "record_b_quote": quote_b,
                    "diagnosis_quote": quote_a,
                    "medication_quote": quote_b,
                    "evidence_count": len(paths),
                    "path_count": sum(len(p.get("anchors", [p])) for p in paths),
                    "evidence": [
                        {k: v for k, v in p.items() if k != "vector"} for p in paths
                    ],
                    "left_record": c["left"]["record"]["record_id"],
                    "right_record": c["right"]["record"]["record_id"],
                    "record_a_record": c["left"]["record"]["record_id"],
                    "record_b_record": c["right"]["record"]["record_id"],
                    "text_source": c["document"],
                    "left_cells": c["left"]["record"]["cells"],
                    "right_cells": c["right"]["record"]["cells"],
                    "record_a_cells": c["left"]["record"]["cells"],
                    "record_b_cells": c["right"]["record"]["cells"],
                    "left_columns": c["left"]["columns"],
                    "right_columns": c["right"]["columns"],
                    "record_a_columns": c["left"]["columns"],
                    "record_b_columns": c["right"]["columns"],
                    "left_link": p["left"],
                    "right_link": p["right"],
                    "status": "Model-proposed relation; inspect evidence",
                }
            )
    return curated_rows(plan,out)

