"""Reviewed concept axioms, separate from Integration assertions and entity identity."""
import json
import knowledge as kg
import knowledge_mapping_history as history


def setup(store):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_concept_axioms(id TEXT PRIMARY KEY,data TEXT)')


def read(store):
    setup(store)
    with store.db() as db:
        return [json.loads(r['data']) for r in db.execute('SELECT data FROM kg_concept_axioms ORDER BY id')]


def validate(axioms):
    # Equivalence contracts classes only for cycle checking, never stored instances.
    parent={}
    def root(x):
        parent.setdefault(x,x)
        if parent[x]!=x: parent[x]=root(parent[x])
        return parent[x]
    for a in axioms:
        if a['kind']=='equivalent':parent[root(a['source'])]=root(a['target'])
    edges={}
    for a in axioms:
        if a['kind']=='subclass':
            s,t=root(a['source']),root(a['target'])
            if s==t:raise ValueError('A subclass cannot also be equivalent to its parent')
            edges.setdefault(s,set()).add(t)
    active=set();done=set()
    def visit(n):
        if n in active:raise ValueError('This mapping creates a subclass cycle')
        if n in done:return
        active.add(n)
        for t in edges.get(n,()):visit(t)
        active.remove(n);done.add(n)
    for n in edges:visit(n)


def route(store,action,body):
    import knowledge_auto as auto
    with store.lock:
        graph=auto.view(store,auto.selected(body))
        if body.get('revision')!=graph['revision']:raise ValueError('Graph changed; refresh and preview again')
        if kg._jobs.get(str(store.root),{}).get("status")=="running":raise ValueError("Wait for the current graph task before editing mappings")
        saved=read(store)
        if action=='undo-alignment':
            item=next((a for a in graph['alignments'] if a['id']==body.get('id')),None)
            if not item:raise ValueError('Select an alignment in the visible schema')
            # Retain the decision for audit; undo does not erase its definition.
            item=dict(item,status='undone')
            with store.db() as db:
                history.record(db,'concept',item,graph,auto.selected(body))
                db.execute('UPDATE kg_concept_axioms SET data=? WHERE id=?',(json.dumps(item),item['id']))
            return auto.view(store,auto.selected(body))
        kind=body.get('kind');source=body.get('source');target=body.get('target')
        concepts={c['id']:c for c in graph['concepts']}
        if kind not in ('equivalent','subclass') or source not in concepts or target not in concepts or source==target:
            raise ValueError('Choose two different visible concepts and a mapping type')
        if kind=='equivalent':source,target=sorted([source,target])
        item={'id':'axiom_'+kg.digest([kind,source,target]),'kind':kind,'source':source,'target':target,'status':'accepted'}
        current=[a for a in saved if a['status']=='accepted']
        if any(a['id']==item['id'] for a in current):raise ValueError('This mapping is already accepted')
        validate([*current,item])
        affected=[e for e in graph['relationships'] if source in (e['source'],e['target']) or target in (e['source'],e['target'])]
        conflicts=[a['name'] for a in concepts[source]['attributes'] for b in concepts[target]['attributes'] if a['name'].casefold()==b['name'].casefold() and a['datatype']!=b['datatype']]
        preview={'mapping':item,'relationships':len(affected),'attribute_conflicts':sorted(set(conflicts)),
                 'token':kg.digest([graph['revision'],saved,item])}
        if action=='preview-alignment':
            from knowledge_mapping_examples import examples
            preview['examples']=examples(store,graph,auto.selected(body),'concept',item)
            return preview
        if action!='apply-alignment' or body.get('token')!=preview['token']:raise ValueError('Preview changed; review again')
        with store.db() as db:
            history.record(db,'concept',item,graph,auto.selected(body))
            db.execute('INSERT OR REPLACE INTO kg_concept_axioms VALUES(?,?)',(item['id'],json.dumps(item)))
        return auto.view(store,auto.selected(body))
