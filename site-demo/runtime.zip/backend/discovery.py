from evidence_storage import encode as pack, decode as unpack, retain, source_roles, POLICY, policy_for
"""Live LOKI discovery orchestration; identity and evidence stay outside the worker."""
import itertools,collections,hashlib,json,math,os,subprocess,threading,time,uuid
from pathlib import Path
import profiling
from retrieval import ENCODER_KEY
VERSION='loki-discovery-v1.6-september19-contexts'
MODEL_KEY='00a94bcd04421e50bd1c370d1bc96fb233127c558fc118a401668863caffd0fb'
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()

def configuration_key(store):
 import lake_config
 from retrieval import get_encoder_policy
 cfg=lake_config.read_lake_config(store)
 return digest([cfg.get('bundle_id'),cfg.get('bundle_version'),cfg.get('model_version'),
                cfg.get('candidate_policy'),cfg.get('projection_policy'),get_encoder_policy(store)['policy_key']])
def setup(store):
 with store.db() as db:db.executescript('''
 CREATE TABLE IF NOT EXISTS discovery_job(id INTEGER PRIMARY KEY,data TEXT);
 CREATE TABLE IF NOT EXISTS discovery_cache(key TEXT PRIMARY KEY,sources TEXT,data TEXT);
 CREATE TABLE IF NOT EXISTS discovery_report(id INTEGER PRIMARY KEY,signature TEXT,revision TEXT,data TEXT);
 CREATE TABLE IF NOT EXISTS discovery_links(id TEXT PRIMARY KEY,table_id TEXT,text_id TEXT,score REAL,data TEXT);
 CREATE INDEX IF NOT EXISTS idx_discovery_links_text_score ON discovery_links(text_id, score DESC);
 CREATE INDEX IF NOT EXISTS idx_discovery_links_score ON discovery_links(score DESC, id);
 CREATE TABLE IF NOT EXISTS discovery_bridges(id TEXT PRIMARY KEY,score REAL,data TEXT);
 ''')
def remove_sources(db,ids):
 if not db.execute("SELECT 1 FROM sqlite_master WHERE name='discovery_cache'").fetchone():return
 for row in db.execute('SELECT key,sources FROM discovery_cache').fetchall():
  if set(json.loads(row['sources']))&set(ids):db.execute('DELETE FROM discovery_cache WHERE key=?',(row['key'],))
 for table in ('discovery_report','discovery_links','discovery_bridges'):db.execute('DELETE FROM '+table)
 if db.execute("SELECT 1 FROM sqlite_master WHERE name='discovery_score_blocks'").fetchone():db.execute('DELETE FROM discovery_score_blocks')
def current_signature(store,scope_id=None):
 if scope_id is not None:
  import discovery_scope
  try:discovery_scope.read(store,scope_id)
  except ValueError:return None
  base=current_signature(store)
  return digest([base,scope_id]) if base else None
 # Reuse across identical profile reruns, but invalidate changed candidate contexts.
 with store.lock:
  p=profiling.status(store)
  if p['status']!='ready':return None
  with store.db() as db:r=db.execute('SELECT signature FROM lake_profile WHERE id=1').fetchone()
  stamp=(r['signature'],p.get('revision'),configuration_key(store))
  cached=getattr(store,'discovery_input_signature',None)
  if cached and cached[0]==stamp:return cached[1]
  profile=profiling.read(store)
  if profile['status']!='ready':return None
  candidates=[(c['table'],c['text'],c['score']) for c in profile['candidates']]
  key=digest([VERSION,MODEL_KEY,ENCODER_KEY,r['signature'],candidates,stamp[2]])
  store.discovery_input_signature=(stamp,key)
  return key
def status(store):
 with store.lock:return _status(store)

def _status(store):
 setup(store)
 with store.db() as db:
  r=db.execute('SELECT signature,revision,data FROM discovery_report WHERE id=1').fetchone()
  j=db.execute('SELECT data FROM discovery_job WHERE id=1').fetchone()
 job=json.loads(j['data']) if j else None
 if job and job['status'] in ('queued','running','cancelling') and not getattr(store,'discovery_active',False):
  job.update(status='interrupted',phase='Service restarted; run again to reuse completed contexts')
  with store.db() as db:db.execute('UPDATE discovery_job SET data=? WHERE id=1',(json.dumps(job),))
 result={'status':'empty','job':job}
 if r:
  result={'status':'stale','job':job} if r['signature']!=current_signature(store,(unpack(r['data']).get('scope') or {}).get('id')) else {'status':'ready','revision':r['revision'],'job':job,**unpack(r['data'])}
 return result

def worker(store,contexts,threshold,check,progress,session=None):
 root=Path(__file__).resolve().parents[1]
 from settings import runtime,worker_env
 import lake_config
 cfg=lake_config.read_lake_config(store)
 bundle_id=cfg.get('bundle_id','generic-adapter-v1')
 version=cfg.get('bundle_version') or cfg.get('model_version')
 python=runtime(store)['python'];token=uuid.uuid4().hex
 request=store.root/'pending'/(token+'.loki.json');response=store.root/'pending'/(token+'.loki.result');log=store.root/'pending'/(token+'.loki.log');progress_file=Path(str(response)+'.progress');process=None;last=-1
 try:
  # No source IDs, names, folders, row text or annotations are sent to the model worker.
  with store.db() as db:
   def vectors(items):
    from retrieval import Index
    return Index(store).fetch(db,[item['unit_id'] for item in items])
   payload={'full_scores':bool(contexts and contexts[0].get('full_scores')),'threshold':threshold,'bundle_id':bundle_id,'version':version,'contexts':[{'rows':vectors(c['rows']),'text':vectors(c['units'])} for c in contexts]}
  payload['generic_encoder']=cfg.get('generic_encoder')
  payload['generic_dimensions']=cfg.get('generic_dimensions')
  request.write_text(json.dumps(payload),encoding='utf-8')
  with log.open('w',encoding='utf-8') as out:
   process=session.dispatch(request,response) if session else subprocess.Popen([python,str(root/'scripts/discover-loki.py'),str(request),str(response)],stdout=out,stderr=out,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0,env=worker_env(store))
   deadline=time.monotonic()+600
   while process.poll() is None and not (session and response.exists()):
    check()
    if progress_file.exists():
     try:n=int(progress_file.read_text(encoding='utf-8'))
     except (ValueError,OSError):n=last
     if n!=last:progress(n);last=n
    if time.monotonic()>deadline:raise ValueError('LOKI worker exceeded the ten-minute batch budget')
    time.sleep(.1)
  if process.poll() not in (None,0):
   err_msg=""
   if log.exists():
    try:
     raw_log=(session.log if session else log).read_text(encoding='utf-8').strip()
     lines=[l.strip() for l in raw_log.splitlines() if l.strip()]
     if lines:err_msg=lines[-1]
    except Exception:pass
   raise ValueError(f"LOKI worker failed: {err_msg or 'Verify the pinned Step 07 model artifacts and runtime.'}")
  result=json.loads(response.read_text(encoding='utf-8'))
  if not result.get('strict_load') or len(result['contexts'])!=len(contexts):raise ValueError('Incomplete or unverified LOKI response')
  return result
 finally:
  if not session and process and process.poll() is None:process.kill();process.wait()
  for p in (request,response,log,progress_file,Path(str(response)+".tmp")):p.unlink(missing_ok=True)

class WorkerSession:
 """Own one model process for a single Discovery job; batches remain unchanged."""
 def __init__(self,store):
  self.store=store;self.process=None;self.output=None
  self.log=store.root/'pending'/(uuid.uuid4().hex+'.loki.session.log')
 def dispatch(self,request,response):
  from settings import runtime,worker_env
  if self.process is None:
   self.output=self.log.open('w',encoding='utf-8')
   self.process=subprocess.Popen([runtime(self.store)['python'],str(Path(__file__).resolve().parents[1]/'scripts/discover-loki.py'),'--session'],stdin=subprocess.PIPE,stdout=self.output,stderr=self.output,text=True,encoding='utf-8',creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0,env=worker_env(self.store))
  if self.process.poll() is not None:raise ValueError('LOKI session stopped unexpectedly')
  self.process.stdin.write(json.dumps({'request':str(request),'response':str(response)})+'\n');self.process.stdin.flush()
  return self.process
 def execute(self,store,contexts,threshold,check,progress):
  return worker(store,contexts,threshold,check,progress,session=self)
 def close(self):
  if self.process:
   if self.process.stdin:self.process.stdin.close()
   if self.process.poll() is None:
    try:self.process.wait(timeout=5)
    except subprocess.TimeoutExpired:self.process.kill();self.process.wait()
  if self.output:self.output.close()
  self.log.unlink(missing_ok=True)

def indexed_metadata(row):
 data=json.loads(row['data']);data.pop('vector',None);data.pop('codes',None);data['unit_id']=row['id'];return data

def get_source_rows(store, aid, mask, max_rows=None, excluded_identifiers=None, null_tokens=None):
    from inference import table_columns, resolve_cell_value
    with store.db() as db:
        job = db.execute("SELECT j.version, a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.asset_id=? AND j.status='ready'", (aid,)).fetchone()
        if not job:
            return []
        first = db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1', (aid, job['version'])).fetchone()
        if not first:
            return []
        header = json.loads(first['data'])
        try:
            included = table_columns(header, excluded_identifiers=excluded_identifiers)
        except Exception:
            included = list(range(len(header)))
        limit_clause = f"LIMIT {int(max_rows)}" if max_rows else ""
        record_rows = db.execute(
            f"SELECT idx, data FROM records WHERE asset_id=? AND version=? AND idx > 1 ORDER BY idx {limit_clause}",
            (aid, job['version'])
        ).fetchall()

    rows = []
    for r in record_rows:
        val = json.loads(r['data'])
        if len(val) != len(header):
            continue
        cells = []
        for i in included:
            resolved, is_null = resolve_cell_value(val[i], null_tokens)
            cells.append("" if is_null else mask(resolved))
        text = '; '.join(cells)[:1500]
        rows.append({
            'record_index': r['idx'],
            'record_id': f"{aid}:{job['version']}:{r['idx']}",
            'asset_id': aid,
            'name': job['name'],
            'version': job['version'],
            'text': text,
            'character_clipped': len('; '.join(cells)) > 1500,
        })
    return rows

def ensure_candidate_table_vectors(store, aid, rows, policy, check=lambda: None, progress=None):
    from vector_store import vectors
    from retrieval import encode as encode_texts

    with store.db() as db:
        existing = {}
        for r in db.execute("SELECT id, data FROM retrieval_units WHERE asset_id=? AND kind='csv'", (aid,)).fetchall():
            try:
                data = json.loads(r['data'])
                if 'record_index' in data and data.get('policy_key')==policy['policy_key']:
                    existing[data['record_index']] = (r['id'], data.get('vector_id'))
            except Exception:
                pass

    v_store = vectors(store, representation_key=policy['policy_key'], dimension=policy['dimensions'])
    refs=list({ref for _,ref in existing.values() if ref})
    present=set()
    from vector_store import quoted
    for offset in range(0,len(refs),256):
        batch=refs[offset:offset+256]
        present.update(item['id'] for item in v_store.table.search().where("id IN ("+','.join(map(quoted,batch))+")").limit(len(batch)).to_list())
    existing={idx:value for idx,value in existing.items() if value[1] in present}

    for r in rows:
        if r['record_index'] in existing:
            r['unit_id'] = existing[r['record_index']][0]
            r['vector_id'] = existing[r['record_index']][1]

    missing = [r for r in rows if 'unit_id' not in r]
    if not missing:
        return

    v_store = vectors(store, representation_key=policy['policy_key'], dimension=policy['dimensions'])

    for chunk_start in range(0, len(missing), 2048):
        check()
        chunk = missing[chunk_start:chunk_start + 2048]
        texts = [r['text'] for r in chunk]
        if progress:
            progress(phase=f"Embedding discovery rows ({chunk_start + len(chunk)}/{len(missing)})")
        encoded = encode_texts(store, texts, check, policy=policy)
        staged_units = []
        for r_item, enc_item in zip(chunk, encoded['items']):
            staged_units.append({
                'vector': enc_item['vector'],
                'text': r_item['text'],
                'record_index': r_item['record_index'],
                'character_clipped': r_item.get('character_clipped', False),
            })
        generation = v_store.stage(aid, 'csv', staged_units)
        with store.db() as db:
            for i, (r_item, unit) in enumerate(zip(chunk, staged_units)):
                uid = f"{aid}:disc_{generation}_{i}"
                metadata = {
                    'text': r_item['text'],
                    'record_index': r_item['record_index'],
                    'character_clipped': r_item.get('character_clipped', False),
                    'vector_id': f"{generation}:{i}",
                    'policy_key': policy['policy_key'],
                }
                db.execute(
                    "INSERT OR REPLACE INTO retrieval_units VALUES(?,?,?,?)",
                    (uid, aid, 'csv', json.dumps(metadata))
                )
                r_item['unit_id'] = uid
                r_item['vector_id'] = f"{generation}:{i}"

def contexts_for(store, profile, threshold, check=lambda: None, progress=None, scope_id=None):
    import discovery_scope
    profile=discovery_scope.restrict(store,profile,scope_id)
    import lake_config
    import inference
    from retrieval import get_encoder_policy

    cfg = lake_config.read_lake_config(store)
    cand_policy = cfg.get("candidate_policy", {})
    discovery_row_limit = cand_policy.get("discovery_row_limit")
    proj_policy = cfg.get("projection_policy", {})
    excluded_ids = proj_policy.get("exclude_identifiers")
    null_tokens = proj_policy.get("null_tokens")
    policy = get_encoder_policy(store)
    config_key = configuration_key(store)

    sources = {s['asset_id']: s for s in profile['sources']}
    bydoc = collections.defaultdict(list)
    for c in profile['candidates']:
        bydoc[c['text']].append(c)

    with store.db() as db:
        mask = inference.identifier_mask(db, excluded_identifiers=excluded_ids)

    candidate_tables = {c['table'] for c in profile['candidates']}
    candidate_table_rows = {}
    for aid in candidate_tables:
        check()
        all_rows = get_source_rows(store, aid, mask, max_rows=discovery_row_limit,
                                   excluded_identifiers=excluded_ids, null_tokens=null_tokens)
        if all_rows:
            ensure_candidate_table_vectors(store, aid, all_rows, policy, check=check, progress=progress)
            candidate_table_rows[aid] = all_rows
        else:
            with store.db() as db:
                table_rows = [indexed_metadata(r) for r in db.execute("SELECT id,data FROM retrieval_units WHERE asset_id=? AND kind='csv'", (aid,))]
                table_rows.sort(key=lambda r: r['record_index'])
                candidate_table_rows[aid] = [{**r, 'asset_id': aid, 'name': sources[aid]['name'], 'version': sources[aid]['version']} for r in table_rows]

    contexts = []
    with store.db() as db:
        for doc, candidates in sorted(bydoc.items()):
            all_units = [indexed_metadata(r) for r in db.execute("SELECT id,data FROM retrieval_units WHERE asset_id=? AND kind='txt'", (doc,))]
            all_units.sort(key=lambda u: u['start'])
            if not all_units:
                continue
            windows = [all_units[i:i+128] for i in range(0, len(all_units), 112) if i == 0 or i + 16 < len(all_units)]
            seen_table_names = set()
            deduped_candidates = []
            for c in sorted(candidates, key=lambda c: (-c['score'], c['table'])):
                tname = c['table']  # Source identity, never a filename-based association.
                if tname in seen_table_names:
                    continue
                seen_table_names.add(tname)
                deduped_candidates.append(c)
            ordered = deduped_candidates
            from context_pages import table_blocks, page_schedule
            for raw_block in table_blocks(ordered):
                block = sorted(raw_block, key=lambda item: item['table'])
                members = [doc]
                keys = []
                pages = []
                row_limit = max(32, 256 // len(block))
                for c in block:
                    aid = c['table']
                    members.append(aid)
                    table_rows = candidate_table_rows.get(aid, [])
                    pages.append([table_rows[i:i+row_limit] for i in range(0, len(table_rows), row_limit)] or [[]])
                for aid in members:
                    key = db.execute('SELECT cache_key FROM profile_cache WHERE asset_id=?', (aid,)).fetchone()
                    if not key:
                        raise ValueError('Profile cache missing; refresh lake indexing')
                    keys.append((aid, sources[aid].get('inference_key', key['cache_key'])))
                max_pages = max((len(p) for p in pages), default=0)
                for indices in page_schedule([len(p) for p in pages]):
                    rows = [r for p, index in zip(pages, indices) for r in p[index]]
                    if not rows:
                        continue
                    for units in windows:
                        key = digest([VERSION, config_key, threshold, scope_id, keys, [(r['asset_id'], r['record_index']) for r in rows], [(u['start'], u['end']) for u in units]])
                        contexts.append({
                            'key': key,
                            'members': members,
                            'text_id': doc,
                            'text_version': sources[doc]['version'],
                            'text_name': sources[doc]['name'],
                            'rows': rows,
                            'units': units,
                            'split_document_context': len(ordered) > 8 or len(windows) > 1 or max_pages > 1,
                            'row_combinations_omitted': max(0, math.prod(len(p) for p in pages) - 64),
                        })
    return contexts, sources

def materialize(context,result,threshold):
 if result['rows']!=len(context['rows']) or result['units']!=len(context['units']) or not math.isfinite(result['global_score']):raise ValueError('LOKI context dimensions differ from source mapping')
 links=[];seen=set();perrow=collections.Counter()
 for item in result['links']:
  r=item['row'];u=item['unit'];score=item['score']
  if type(r)!=int or type(u)!=int or not 0<=r<len(context['rows']) or not 0<=u<len(context['units']) or not math.isfinite(score) or not threshold<=score<=1.01:raise ValueError('Invalid LOKI atomic link')
  if (r,u) in seen:raise ValueError('Duplicate LOKI link')
  seen.add((r,u));perrow[r]+=1
  if perrow[r]>32:raise ValueError('LOKI row link budget exceeded')
  row=context['rows'][r];unit=context['units'][u]
  rid=f"{row['asset_id']}:{row['version']}:{row['record_index']}"
  link={'id':digest([context['key'],rid,unit['start'],unit['end']]),'context':context['key'],'table':row['asset_id'],'table_name':row.get('name',row['asset_id']),'text_name':context.get('text_name',context['text_id']),'text':context['text_id'],'row_version':row['version'],'text_version':context['text_version'],'record_id':rid,'row_index':row['record_index'],'start':unit['start'],'end':unit['end'],'score':score,'row_preview':row['text'],'text_preview':unit['text'],'character_clipped':row.get('character_clipped',False),'status':'LOKI-proposed link'}
  links.append(link)
 return {'key':context['key'],'members':context['members'],'text':context['text_id'],'rows':len(context['rows']),'units':len(context['units']),'global_score':result['global_score'],'eligible_links':result['eligible_links'],'links':links,'split_document_context':context['split_document_context'],'sentence_vectors':{str(context['units'][int(u)]['start']):v for u,v in result.get('sentence_vectors',{}).items()}}

def bridges_for(links, cap=2000):
 if type(cap)!=int or cap<0:raise ValueError('Join-path cap must be a nonnegative integer (0 = all)')
 groups=collections.defaultdict(list)
 for link in links:groups[(link['text'],link['start'],link['end'])].append(link)
 bridges=[];linked=set();truncated=0
 seen_pairs=set()
 for group in groups.values():
  table_ids={l['table'] for l in group}
  for l in group:l['one_sided']=len(table_ids)==1
  ranked=sorted(group,key=lambda l:(-l['score'],l['id']));truncated+=max(0,len(ranked)-12);ranked=ranked[:12]
  for i,left in enumerate(ranked):
   for right in ranked[i+1:]:
    if left['table']==right['table']:continue
    if left.get('record_id')==right.get('record_id'):continue
    pair_key=(min(left['record_id'],right['record_id']),max(left['record_id'],right['record_id']),left['text'],left['start'],left['end'])
    if pair_key in seen_pairs:continue
    seen_pairs.add(pair_key)
    bridges.append({'id':digest(sorted([left['id'],right['id']])),'left':left['id'],'right':right['id'],'text':left['text'],'start':left['start'],'end':left['end'],'score':min(left['score'],right['score']),'status':'Join-path candidate'})
 bridges.sort(key=lambda b:(-b['score'],b['id']));dropped=max(0,len(bridges)-cap) if cap else 0
 if cap:bridges=bridges[:cap]
 for b in bridges:linked.update([b['left'],b['right']])
 for link in links:link['bridge_retained']=link['id'] in linked
 return bridges,{'bridge_group_links_omitted':truncated,'bridges_omitted':dropped,'bridge_cap':cap}

def run(store,threshold=.15,execute=worker,check=lambda:None,progress=lambda **kw:None,scope_id=None):
 setup(store);check();before=current_signature(store,scope_id)
 if before is None:raise ValueError('Profile the saved lake before running LOKI discovery')
 profile=profiling.read(store);contexts,sources=contexts_for(store,profile,threshold,check=check,progress=progress,scope_id=scope_id)
 old=status(store)
 if old['status']=='ready' and (old.get('scope') or {}).get('id')==scope_id and old['threshold']==threshold and old.get('retention_policy')==policy_for(store):
  old.pop('job',None);old.pop('status',None);revision=old.pop('revision',None);old['work']={**old['work'],'reused_contexts':len(contexts),'scored_contexts':0}
  with store.db() as db:db.execute('UPDATE discovery_report SET revision=?,data=? WHERE id=1',(revision,json.dumps(old)))
  progress(completed=len(contexts),total=len(contexts),phase='Reused unchanged LOKI evidence');return status(store)
 cached=[];missing=[];started=time.perf_counter();peak=0;device=None
 with store.db() as db:
  for context in contexts:
   r=db.execute('SELECT data FROM discovery_cache WHERE key=?',(context['key'],)).fetchone()
   if r:cached.append(retain(unpack(r['data']),source_roles(profile),policy=policy_for(store)))
   else:missing.append(context)
 results=list(cached)
 for offset in range(0,len(missing),8):
  check();batch=missing[offset:offset+8];progress(phase='LOKI contextual scoring',completed=offset+len(cached),total=len(contexts))
  output=execute(store,batch,threshold,check,lambda n:progress(completed=len(cached)+offset+n))
  built=[retain(materialize(c,r,threshold),source_roles(profile),policy=policy_for(store)) for c,r in zip(batch,output['contexts'])]
  if len(built)!=len(batch):raise ValueError('Missing LOKI contexts')
  peak=max(peak,output.get('peak_reserved_gib') or 0);device=output.get('device',device)
  with store.lock:
   check()
   if current_signature(store,scope_id)!=before:raise ValueError('Lake changed during discovery; refresh the index and rerun')
   with store.db() as db:
    for result in built:db.execute('INSERT OR REPLACE INTO discovery_cache VALUES(?,?,?)',(result['key'],json.dumps(result['members']),pack(result)))
  results.extend(built)
 links=[link for result in results for link in result['links']];bridges,bounds=bridges_for(links)
 bounds.update(evaluated_text_units=len({(c['text_id'],u['start'],u['end']) for c in contexts for u in c['units']}),
               discovery_row_limit=__import__('lake_config').read_lake_config(store).get('candidate_policy',{}).get('discovery_row_limit'))
 report={'scope':__import__('discovery_scope').read(store,scope_id) if scope_id else None,'retention_policy':policy_for(store),'version':VERSION,'threshold':threshold,'checkpoint':MODEL_KEY,'sources':[{'id':aid,'name':s['name']} for aid,s in sources.items()],
 'storage':{'policy':policy_for(store),'scored_links':sum(r.get('retention',{}).get('scored_links',len(r['links'])) for r in results),'retained_links':len(links)},
 'summary':{'contexts':len(results),'links':len(links),'bridges':len(bridges),'one_sided':sum(l['one_sided'] for l in links),'rows_without_links':sum(r['rows']-len({l['record_id'] for l in r['links']}) for r in results),'evaluated_table_rows':len({(r['asset_id'],r['record_index']) for c in contexts for r in c['rows']})},
 'coverage':{'sampled_sources':sum(s['coverage']['sampled'] for s in sources.values()),'context_row_limit':256,'context_text_limit':128,'max_row_combinations_omitted':max((c.get('row_combinations_omitted',0) for c in contexts),default=0),'split_contexts':sum(c['split_document_context'] for c in contexts),'eligible_links':sum(r['eligible_links'] for r in results),'evaluated_table_rows':len({(r['asset_id'],r['record_index']) for c in contexts for r in c['rows']}),**bounds},
 'work':{'reused_contexts':len(cached),'scored_contexts':len(missing),'device':device,'peak_reserved_gib':peak,'seconds':time.perf_counter()-started},
 'notice':'Scored all indexed units within shortlisted source contexts, subject to an explicit row cap if configured. Source shortlisting, bounded link retention and score thresholds still limit join recall. Scores are not probabilities.'}
 with store.lock:
  check()
  if current_signature(store,scope_id)!=before:raise ValueError('Lake changed during discovery; results were not published')
  with store.db() as db:
   from integration import pin_saved
   pin_saved(db)
   db.execute('DELETE FROM discovery_links');db.execute('DELETE FROM discovery_bridges')
   db.executemany('INSERT INTO discovery_links VALUES(?,?,?,?,?)',[(l['id'],l['table'],l['text'],l['score'],pack(l)) for l in links])
   db.executemany('INSERT INTO discovery_bridges VALUES(?,?,?)',[(b['id'],b['score'],json.dumps(b)) for b in bridges])
   db.execute('INSERT OR REPLACE INTO discovery_report VALUES(1,?,?,?)',(before,uuid.uuid4().hex,json.dumps(report)))
   if db.execute("SELECT 1 FROM sqlite_master WHERE name='discovery_score_blocks'").fetchone():db.execute('DELETE FROM discovery_score_blocks')
   # Retain only contexts used by this published revision. Saved runs use pinned evidence.
   db.execute('CREATE TEMP TABLE current_context_keys(key TEXT PRIMARY KEY)')
   db.executemany('INSERT OR IGNORE INTO current_context_keys VALUES(?)',[(r['key'],) for r in results])
   db.execute('DELETE FROM discovery_cache WHERE key NOT IN (SELECT key FROM current_context_keys)')
  from storage_compaction import reclaim_after_publication
  reclaim_after_publication(store)
 progress(completed=len(contexts),total=len(contexts),phase='LOKI evidence ready');return status(store)

def listing(store,kind,offset=0,source=''):
 with store.lock:return _listing(store,kind,offset,source)

def _listing(store,kind,offset,source):
 state=status(store)
 if state['status']!='ready':raise ValueError('Discovery results are unavailable or stale')
 table='discovery_links' if kind=='links' else 'discovery_bridges';where=' WHERE table_id=? OR text_id=?' if source and kind=='links' else '';args=(source,source) if where else ()
 with store.db() as db:
  count=db.execute('SELECT count(*) FROM '+table+where,args).fetchone()[0]
  rows=db.execute('SELECT data FROM '+table+where+' ORDER BY score DESC,id LIMIT 20 OFFSET ?',args+(offset,)).fetchall()
 return {'revision':state['revision'],'total':count,'offset':offset,'items':[unpack(r['data']) for r in rows]}
def link(store,lid):
 setup(store)
 with store.db() as db:
  r=db.execute('SELECT data FROM discovery_links WHERE id=?',(lid,)).fetchone()
  if not r and db.execute("SELECT 1 FROM sqlite_master WHERE name='integration_evidence'").fetchone():
   r=db.execute('SELECT data FROM integration_evidence WHERE id=?',(lid,)).fetchone()
 if not r:raise KeyError('Link not found')
 return unpack(r['data'])

def start(store,data):
 threshold=data.get('threshold',.15)
 scope_id=data.get('scope_id')
 if data.get('operation')=='filter':
  import discovery_scores
  source=discovery_scores.current(store,data.get('generation'));discovery_scores.filters(data)
  scope_id=(source.get('scope') or {}).get('id')
 if type(threshold) not in (float,int) or not math.isfinite(threshold) or not -1<=threshold<=1:raise ValueError('Score threshold must be between -1 and 1')
 setup(store)
 with store.lock:
  if getattr(store,'integration_active',False):raise ValueError('Wait for integration to finish or cancel it first')
  if getattr(store,'profile_active',False):raise ValueError('Wait for indexing to finish before running LOKI')
  if getattr(store,'discovery_active',False):return status(store)
  if scope_id is not None:__import__('discovery_scope').read(store,scope_id)
  if current_signature(store,scope_id) is None:raise ValueError('Profile the saved lake before running LOKI')
  store.discovery_active=True;store.discovery_cancel=threading.Event();state={'status':'queued','phase':'Preparing LOKI contexts','scope_id':scope_id,'completed':0,'total':0}
  with store.db() as db:db.execute('INSERT OR REPLACE INTO discovery_job VALUES(1,?)',(json.dumps(state),))
 def update(**kw):
  with store.lock:
   state.update(kw)
   with store.db() as db:db.execute('UPDATE discovery_job SET data=? WHERE id=1',(json.dumps(state),))
 def check():
  if store.discovery_cancel.is_set():raise profiling.ProfileCancelled()
 def work():
  try:
   update(status='running')
   if data.get('operation')=='filter':
    import discovery_scores
    discovery_scores.apply(store,data,check=check,progress=update)
   elif 'threshold' not in data:
    import discovery_scores
    discovery_scores.compute(store,scope_id,execute=worker,check=check,progress=update)
   else:run(store,threshold,execute=worker,check=check,progress=update,scope_id=scope_id)
   update(status='complete')
  except profiling.ProfileCancelled:update(status='cancelled',phase='Cancelled; completed context caches retained')
  except Exception as e:update(status='failed',phase=str(e))
  finally:
   with store.lock:store.discovery_active=False
 store.discovery_future=store.pool.submit(work);return status(store)
def cancel(store):
 with store.lock:
  if getattr(store,'discovery_active',False):
   store.discovery_cancel.set();future=getattr(store,'discovery_future',None);cancelled=bool(future and future.cancel())
   if cancelled:store.discovery_active=False
   with store.db() as db:
    r=db.execute('SELECT data FROM discovery_job WHERE id=1').fetchone();state=unpack(r['data']);state.update(status='cancelled' if cancelled else 'cancelling',phase='Cancelling LOKI discovery');db.execute('UPDATE discovery_job SET data=? WHERE id=1',(json.dumps(state),))
 return status(store)


def landscape(store):
 """Bounded overview of all retained evidence, not the first list page."""
 with store.lock:
  state=status(store)
  if state['status']!='ready':raise ValueError('Discovery results are unavailable or stale')
  names={s['id']:s['name'] for s in state['sources']}
  with store.db() as db:
   totals=db.execute('SELECT count(DISTINCT text_id) FROM discovery_links').fetchone()[0]
   docs=db.execute('SELECT text_id,count(*) AS links,count(DISTINCT table_id) AS tables,max(score) AS score FROM discovery_links GROUP BY text_id ORDER BY tables DESC,score DESC,text_id LIMIT 12').fetchall()
   neighborhoods=[]
   for doc in docs:
    tables=db.execute('SELECT table_id,count(*) AS links,max(score) AS score FROM discovery_links WHERE text_id=? GROUP BY table_id ORDER BY score DESC,table_id LIMIT 6',(doc['text_id'],)).fetchall()
    members=[]
    for table in tables:
     best=db.execute('SELECT data FROM discovery_links WHERE text_id=? AND table_id=? ORDER BY score DESC,id LIMIT 1',(doc['text_id'],table['table_id'])).fetchone()
     members.append({'id':table['table_id'],'name':names.get(table['table_id'],table['table_id']),'links':table['links'],'evidence':unpack(best['data'])})
    neighborhoods.append({'id':doc['text_id'],'name':names.get(doc['text_id'],doc['text_id']),'links':doc['links'],'tables':doc['tables'],'members':members})
   supported={r[0] for r in db.execute('SELECT table_id FROM discovery_links UNION SELECT text_id FROM discovery_links')}
  return {'revision':state['revision'],'total':totals,'neighborhoods':neighborhoods,'unlinked':[s for s in state['sources'] if s['id'] not in supported]}


def workbench(store,source,k=5):
 """Rank opposite-modality sources by their strongest retained LOKI link."""
 if not 1<=k<=20:raise ValueError('Top K must be between 1 and 20')
 with store.lock:
  state=status(store)
  if state['status']!='ready':raise ValueError('Discovery results are unavailable or stale')
  names={s['id']:s['name'] for s in state['sources']}
  if source not in names:raise KeyError('Source is not in the discovery snapshot')
  csv=names[source].lower().endswith('.csv')
  own,other=('table_id','text_id') if csv else ('text_id','table_id')
  with store.db() as db:
   total=db.execute(f'SELECT count(DISTINCT {other}) FROM discovery_links WHERE {own}=?',(source,)).fetchone()[0]
   rows=db.execute(f'SELECT {other} AS id,count(*) AS links,max(score) AS score FROM discovery_links WHERE {own}=? GROUP BY {other} ORDER BY score DESC,{other} LIMIT ?',(source,k)).fetchall()
  return {'revision':state['revision'],'source':source,'kind':'csv' if csv else 'txt','total':total,'k':k,'candidates':[dict(r)|{'name':names[r['id']]} for r in rows]}

def workbench_links(store,source,candidate,offset=0):
 with store.lock:
  state=status(store)
  if state['status']!='ready':raise ValueError('Discovery results are unavailable or stale')
  with store.db() as db:
   where=' WHERE (table_id=? AND text_id=?) OR (table_id=? AND text_id=?)'
   args=(source,candidate,candidate,source)
   total=db.execute('SELECT count(*) FROM discovery_links'+where,args).fetchone()[0]
   rows=db.execute('SELECT data FROM discovery_links'+where+' ORDER BY score DESC,id LIMIT 20 OFFSET ?',args+(offset,)).fetchall()
  return {'revision':state['revision'],'total':total,'offset':offset,'items':[unpack(r['data']) for r in rows]}

def evidence_context(store,lid,companion=None):
 from inference import prepare,identifier_mask
 with store.lock:
  first=link(store,lid);links=[first]
  if companion:
   second=link(store,companion)
   if any(first[k]!=second[k] for k in ('text','text_version')) or first['table']==second['table']:raise ValueError('Links do not form a cross-table path in the same document version')
   links.append(second)
  with store.db() as db:mask=identifier_mask(db)
  tables=[]
  for item in links:
   page=prepare(store,item['table'],max(0,item['row_index']-6),_mask=mask)
   if page['provenance']['version']!=item['row_version']:raise ValueError('Evidence source version changed')
   tables.append({'id':item['table'],'name':item['table_name'],'columns':page['payload']['columns'],'rows':[{'index':r['index'],'record_id':r['record_id'],'cells':cells} for r,cells in zip(page['provenance']['records'][:11],page['payload']['rows'][:11])],'selected':item['row_index'],'total':page['total'],'excluded_columns':page['excluded_columns']})
  lo=max(0,min(item['start'] for item in links)-1200);hi=max(item['end'] for item in links)+1200
  with store.db() as db:
   chunks=db.execute('SELECT start,end,data FROM records WHERE asset_id=? AND version=? AND end>? AND start<? ORDER BY idx',(first['text'],first['text_version'],lo,hi)).fetchall()
  if not chunks:raise ValueError('Evidence text is no longer available')
  base=chunks[0]['start'];text=mask(''.join(unpack(r['data']) for r in chunks));end=min(hi,chunks[-1]['end'])
  text=text[lo-base:end-base]
  for item in links:
   if text[item['start']-lo:item['end']-lo]!=item['text_preview']:raise ValueError('Stored evidence no longer matches its source span')
  highlights=[{'start':item['start'],'end':item['end'],'link_id':item['id']} for item in links]
  return {'revision':status(store).get('revision','historical'),'links':links,'tables':tables,'document':{'id':first['text'],'name':first['text_name'],'text':text,'start':lo,'end':end,'highlight_start':first['start'],'highlight_end':first['end'],'highlights':highlights,'version':first['text_version']}}
