"""Lake-wide T-Box and reviewed A-Box references, separate from source snapshots."""
import json
import time
import knowledge as kg
import knowledge_schema as proposals


def setup(store):
    kg.setup(store)
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_ontology(id INTEGER PRIMARY KEY,data TEXT NOT NULL)')
        db.execute('CREATE TABLE IF NOT EXISTS kg_contributions(run TEXT PRIMARY KEY,snapshot TEXT NOT NULL,data TEXT NOT NULL)')
        db.execute('CREATE TABLE IF NOT EXISTS kg_reviews(snapshot TEXT,assertion TEXT,data TEXT NOT NULL,PRIMARY KEY(snapshot,assertion))')


def state(db):
    row = db.execute('SELECT data FROM kg_ontology WHERE id=1').fetchone()
    return json.loads(row['data']) if row else {'concepts': [], 'relationships': [], 'generation': 0}


def check(current, body):
    if body.get('revision') != kg.digest(current):
        raise ValueError('Knowledge workspace changed. Refresh before saving.')


def write(db, current):
    current['generation'] += 1
    db.execute('INSERT OR REPLACE INTO kg_ontology VALUES(1,?)', (json.dumps(current),))


def prune(db):
    if not db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_contributions'").fetchone():
        return
    db.execute('DELETE FROM kg_contributions WHERE snapshot NOT IN (SELECT id FROM kg_snapshots)')
    db.execute('DELETE FROM kg_reviews WHERE snapshot NOT IN (SELECT id FROM kg_snapshots)')


def overview(store):
    setup(store)
    with store.db() as db:
        current = state(db)
        layers = [dict(r) for r in db.execute('SELECT run,snapshot,data FROM kg_contributions')]
    for layer in layers:
        layer['mappings'] = json.loads(layer.pop('data'))
    return {**current, 'revision': kg.digest(current), 'layers': layers}


def map_sources(store, body):
    """Explicit submission authorizes same-name class reuse, never entity merging."""
    setup(store)
    sid = body.get('snapshot')
    with store.lock, kg._guard:
        meta, groups = proposals.inputs(store, sid)
        mappings = proposals.validate(body.get('mappings'), groups, merge=True)
        with store.db() as db:
            current = state(db)
            check(current, body)
            concepts = {c['id']: c for c in current['concepts']}
            for m in mappings:
                cid = 'type_' + kg.digest([store.lake_id, m['concept'].casefold()])
                concept = concepts.setdefault(cid, {'id': cid, 'label': m['concept'], 'attributes': []})
                attributes = {a['name'].casefold(): a for a in concept['attributes']}
                for a in m['attributes']:
                    if not a['included']: continue
                    key = a['name'].casefold()
                    if key in attributes and attributes[key]['datatype'] != a['datatype']:
                        raise ValueError('Conflicting shared attribute type: ' + a['name'])
                    attributes[key] = {'name': a['name'], 'datatype': a['datatype']}
                concept['attributes'] = list(attributes.values())
                m['concept_id'] = cid
            old = db.execute('SELECT snapshot,data FROM kg_contributions WHERE run=?', (meta['run_id'],)).fetchone()
            # Changing a mapping invalidates approvals for this contribution only.
            if old and (old['snapshot'] != sid or json.loads(old['data']) != mappings):
                db.execute('DELETE FROM kg_reviews WHERE snapshot=?', (sid,))
            current['concepts'] = list(concepts.values())
            db.execute('INSERT OR REPLACE INTO kg_contributions VALUES(?,?,?)', (meta['run_id'], sid, json.dumps(mappings)))
            db.execute('CREATE TABLE IF NOT EXISTS kg_schema_drafts(snapshot TEXT PRIMARY KEY,data TEXT)')
            db.execute('INSERT OR REPLACE INTO kg_schema_drafts VALUES(?,?)',
                       (sid, json.dumps({'mappings': mappings, 'origin': 'Reviewed global schema mapping'})))
            write(db, current)
    return overview(store)


def assertions(store, query):
    setup(store)
    status = query.get('status', ['pending'])[0]
    if status not in ('pending', 'accepted', 'rejected'): raise ValueError('Invalid review status')
    offset = max(0, int(query.get('offset', ['0'])[0]))
    concept = query.get('concept', [''])[0]
    relation = query.get('relationship', [''])[0]
    run = query.get('run', [''])[0]
    # SQL pagination avoids loading the lake's assertions into the browser or Python.
    where = "COALESCE(json_extract(r.data,'$.status'),'pending')=?"
    args = [status]
    if run:
        where += ' AND c.run=?'; args.append(run)
    if concept:
        where += " AND EXISTS (SELECT 1 FROM json_each(c.data) m WHERE json_extract(m.value,'$.concept_id')=? AND json_extract(m.value,'$.source_class') IN (json_extract(a.data,'$.subject.class_id'),json_extract(a.data,'$.object.class_id')))"
        args.append(concept)
    if relation:
        where += " AND json_extract(r.data,'$.relationship')=?"; args.append(relation)
    joins = ' FROM kg_contributions c JOIN kg_snapshots s ON s.id=c.snapshot JOIN integration_plans p ON p.id=c.run JOIN kg_assertions a ON a.snapshot=c.snapshot LEFT JOIN kg_reviews r ON r.snapshot=a.snapshot AND r.assertion=a.id WHERE ' + where
    with store.db() as db:
        total = db.execute('SELECT count(*)' + joins, args).fetchone()[0]
        rows = db.execute('SELECT a.data,c.snapshot,c.run,c.data mappings,r.data review,s.data meta,p.data plan' + joins + ' ORDER BY c.run,a.id LIMIT 25 OFFSET ?', (*args, offset)).fetchall()
        assets = {r['id'] for r in db.execute('SELECT id FROM assets')}
    items = []
    from knowledge_review import endpoint_checks
    for row in rows:
        a = json.loads(row['data']); meta = json.loads(row['meta'])
        if a['document_id'] not in assets or any(c['asset'] not in assets for c in meta.get('source_classes',meta['classes'])):
            raise ValueError('Source data was removed; refresh the graph contribution')
        plan = json.loads(row['plan'])
        if kg.digest(plan) == meta['revision']: endpoint_checks(plan, [a])
        lookup = {m['source_class']: m for m in json.loads(row['mappings'])}
        for side in ('subject', 'object'):
            record = a[side]; m = lookup[record['class_id']]
            record['concept_id'] = m['concept_id']; record['concept'] = m['concept']
            col = m['label_column']
            record['label'] = str(record['cells'][col]) if col < len(record['cells']) else record['label']
        a.update(snapshot=row['snapshot'], run_id=row['run'], run_title=meta['title'], decision=json.loads(row['review']) if row['review'] else {'status': 'pending'})
        items.append(a)
    return {'items': items, 'total': total, 'offset': offset, 'limit': 25}


def decide(store, body):
    setup(store)
    sid, aid = body.get('snapshot'), body.get('assertion')
    status = body.get('status')
    if status not in ('accepted', 'rejected', 'pending'): raise ValueError('Invalid decision')
    note = body.get('note', '')
    if not isinstance(note, str) or len(note) > 4000: raise ValueError('Invalid review explanation')
    with store.lock, kg._guard:
        # Read pinned provenance with the same availability rules as the source explorer.
        meta = kg.read(store, sid)['snapshot']
        with store.db() as db:
            current = state(db); check(current, body)
            layer = db.execute('SELECT data FROM kg_contributions WHERE snapshot=?', (sid,)).fetchone()
            row = db.execute('SELECT data FROM kg_assertions WHERE snapshot=? AND id=?', (sid, aid)).fetchone()
            if not layer or not row: raise ValueError('Assertion is not in an active contribution')
            a = json.loads(row['data'])
            if not db.execute('SELECT 1 FROM assets WHERE id=?', (a['document_id'],)).fetchone(): raise ValueError('Evidence source was removed')
            mappings = {m['source_class']: m for m in json.loads(layer['data'])}
            source = mappings[a['subject']['class_id']]['concept_id']
            target = mappings[a['object']['class_id']]['concept_id']
            decision = {'status': status, 'note': note.strip(), 'recorded_at': time.time()}
            if status == 'accepted':
                from knowledge_review import endpoint_checks
                plan, _ = kg.load_plan(store, meta['run_id'])
                if kg.digest(plan) != meta['revision']:
                    raise ValueError('Source run changed. Prepare and review its current contribution before accepting assertions.')
                endpoint_checks(plan, [a])
                caution = source == target or a['direction'] != 'directed' or any(x['status']=='needs_review' for x in a.get('endpoint_checks', []))
                if caution and not note.strip(): raise ValueError('Explain your endpoint/direction review before accepting this assertion')
                if not a['evidence']: raise ValueError('Cannot accept an assertion without evidence')
                if a['direction'] != 'directed': source, target = sorted((source, target))
                rid = 'predicate_' + kg.digest([a['relation'], source, target, a['direction']])
                if not any(r['id'] == rid for r in current['relationships']):
                    current['relationships'].append({'id': rid, 'label': a['relation'], 'source': source, 'target': target, 'direction': a['direction']})
                decision['relationship'] = rid
            db.execute('INSERT OR REPLACE INTO kg_reviews VALUES(?,?,?)', (sid, aid, json.dumps(decision)))
            write(db, current)
    return overview(store)


def remove_contribution(store, body):
    setup(store)
    with store.lock, kg._guard, store.db() as db:
        current = state(db); check(current, body)
        layer = db.execute('SELECT snapshot FROM kg_contributions WHERE run=?', (body.get('run'),)).fetchone()
        if not layer: raise KeyError('Contribution not found')
        db.execute('DELETE FROM kg_reviews WHERE snapshot=?', (layer['snapshot'],))
        db.execute('DELETE FROM kg_contributions WHERE run=?', (body['run'],))
        write(db, current)
    return overview(store)


def route(store, method, path, body, query):
    if method == 'GET' and not path: return overview(store)
    if method == 'GET' and path == ['assertions']: return assertions(store, query)
    if method == 'POST' and path == ['map']: return map_sources(store, body())
    if method == 'POST' and path == ['review']: return decide(store, body())
    if method == 'POST' and path == ['remove']: return remove_contribution(store, body())
    raise KeyError('Knowledge workspace operation not found')
