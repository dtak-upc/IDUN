"""Compare immutable integration outputs at source-pair/document/relation grain."""
import json


def identity(row):
    values = tuple(row.get(k) for k in ('left_record', 'right_record', 'text_source'))
    return values if all(isinstance(v, str) and v for v in values) else None


def relation_key(row):
    id_tuple = identity(row)
    if not id_tuple:
        return None
    return (id_tuple, row.get('relation'), row.get('direction', 'undirected'))


def evidence_signature(row):
    def canonical(value):
        return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
    # Scores, clusters, candidate aliases and link hashes can change when a
    # discovery context is rebuilt without changing the underlying evidence.
    passages = []
    for passage in row.get('evidence', []):
        content = {k: passage[k] for k in ('start', 'end', 'text', 'context_start', 'context_end', 'context_text', 'text_version') if k in passage}
        content['anchors'] = sorted({canonical({k: a[k] for k in ('start', 'end') if k in a}) for a in passage.get('anchors', [])})
        passages.append(canonical(content))
    return canonical({
        'passages': sorted(set(passages)),
        'fallback_quote': row.get('evidence_quote') if not passages else None,
        'evidence_count': row.get('evidence_count'),
        'path_count': row.get('path_count'),
        'direction': row.get('direction', 'undirected'),
        'records': {k: row.get(k) for k in ('left_columns', 'right_columns', 'left_cells', 'right_cells')},
    })


def compare_outputs(current, previous):
    current_rows, old_rows = current.get('output', []), previous.get('output', [])
    old_by_dir = {relation_key(r): r for r in old_rows if relation_key(r)}
    new_by_dir = {relation_key(r): r for r in current_rows if relation_key(r)}
    old_by_rel = {(identity(r), r['relation']): r for r in old_rows if identity(r)}
    new_by_rel = {(identity(r), r['relation']): r for r in current_rows if identity(r)}

    reviewed = {identity(r) for r in current_rows if identity(r)}
    decided = {d.get('candidate') for d in current.get('decisions', []) if d.get('status') in ('include', 'abstain', 'conflict')}
    for case in current.get('cases', []):
        if case.get('candidate') in decided:
            key = identity({'left_record': case.get('left', {}).get('record', {}).get('record_id'),
                            'right_record': case.get('right', {}).get('record', {}).get('record_id'),
                            'text_source': case.get('document')})
            if key:
                reviewed.add(key)
    schema = current.get('schema_config') or {}
    from llm import DEFAULT_LABELS
    labels = set(schema.get('labels') or DEFAULT_LABELS)
    counts = dict.fromkeys(('added', 'changed', 'withdrawn', 'unchanged', 'not_reviewed'), 0)
    result = []
    def add(row, status, note, origin):
        counts[status] += 1
        result.append({**row, 'diff_status': status, 'diff_notes': note,
                       'diff_origin': origin, 'diff_key': f'{origin}:{len(result)}'})
    for row in current_rows:
        r_key = relation_key(row)
        prior = old_by_dir.get(r_key) if r_key else None
        if prior is not None:
            if evidence_signature(row) != evidence_signature(prior):
                add(row, 'changed', 'Source values or supporting passages/offsets changed.', 'current')
            else:
                add(row, 'unchanged', 'Same source pair, document, relationship, direction and evidence.', 'current')
        elif identity(row) and (identity(row), row['relation']) in old_by_rel:
            rel_prior = old_by_rel[(identity(row), row['relation'])]
            add(row, 'changed', f"Relationship direction changed from {rel_prior.get('direction', 'undirected')} to {row.get('direction', 'undirected')}.", 'current')
        else:
            add(row, 'added', 'Present in this run; no matching source-pair/document/relation in the previous run.', 'current')

    for row in old_rows:
        r_key = relation_key(row)
        if r_key and r_key in new_by_dir:
            continue
        key = identity(row)
        if key and (key, row['relation']) in new_by_rel:
            continue
        if key is None:
            add(row, 'not_reviewed', 'Historical source/document identity is incomplete; withdrawal cannot be established.', 'previous')
        elif schema.get('mode', 'strict') == 'strict' and labels and row['relation'] not in labels:
            add(row, 'not_reviewed', 'This relationship is outside the current strict schema.', 'previous')
        elif key not in reviewed:
            add(row, 'not_reviewed', 'This source pair and document were not reviewed in this run; they may be outside its candidate pool or budget.', 'previous')
        else:
            add(row, 'withdrawn', 'Reviewed in this run, but this relationship was not retained as supported.', 'previous')
    return result, counts
