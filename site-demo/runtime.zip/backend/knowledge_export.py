"""Dependency-free RDF export: Turtle full-IRI triples and expanded JSON-LD.

Unknown direction is not symmetry: undirected facts are association nodes with
unordered endpoints, never fabricated directed predicate triples.
"""
import json
import knowledge as kg
import knowledge_auto as auto

RDF='http://www.w3.org/1999/02/22-rdf-syntax-ns#'
RDFS='http://www.w3.org/2000/01/rdf-schema#'
OWL='http://www.w3.org/2002/07/owl#'
XSD='http://www.w3.org/2001/XMLSchema#'
PROV='http://www.w3.org/ns/prov#'
VOCAB='urn:idun:vocab:'


def serialize(triples,fmt):
    triples=sorted(set(triples))
    if fmt=='ttl':
        # Full IRIs and escaped string literals are valid Turtle, with no prefix ambiguity.
        def quoted(value):
            escapes={'"':'\\"','\\':'\\\\','\n':'\\n','\r':'\\r','\t':'\\t'}
            return '"'+''.join(escapes.get(c,'\\u%04X'%ord(c) if ord(c)<32 else c) for c in value)+'"'
        return '\n'.join('<'+s+'> <'+p+'> '+(quoted(o) if literal else '<'+o+'>')+' .' for s,p,o,literal in triples)+'\n'
    nodes={}
    for s,p,o,literal in triples:
        node=nodes.setdefault(s,{'@id':s})
        if p==RDF+'type' and not literal:node.setdefault('@type',[]).append(o)
        else:node.setdefault(p,[]).append({'@value':o} if literal else {'@id':o})
    return json.dumps(list(nodes.values()),ensure_ascii=False,indent=2)


def export(store,body):
    fmt=body.get('format');box=body.get('box')
    if fmt not in ('ttl','jsonld') or box not in ('tbox','abox'):raise ValueError('Choose T-Box or A-Box and Turtle or JSON-LD')
    runs=auto.selected(body)
    with store.lock:
        graph=auto.view(store,runs)
        base='urn:idun:lake:'+kg.digest(store.lake_id)+':'
        def uri(kind,key):return base+kind+':'+str(key)
        def attribute(c,name):return uri('attribute',kg.digest([c,name]))
        triples=[]
        def add(s,p,o,literal=False):triples.append((s,p,str(o),literal))
        if box=='tbox':
            for c in graph['concepts']:
                cid=uri('concept',c['id']);add(cid,RDF+'type',OWL+'Class');add(cid,RDFS+'label',c['label'],True)
                if c.get('definition'):add(cid,RDFS+'comment',c['definition'],True)
                for a in c['attributes']:
                    aid=attribute(c['id'],a['name']);add(aid,RDF+'type',OWL+'DatatypeProperty')
                    add(aid,RDFS+'label',a['name'],True);add(aid,RDFS+'domain',cid)
                    # Raw CSV values are exported as strings; do not invent datatypes.
                    add(aid,RDFS+'range',XSD+'string')
            for mapping in graph.get('attribute_alignments',[]):
                if not mapping['stale']:
                    a,b=mapping['attributes']
                    add(attribute(a['concept'],a['name']),OWL+'equivalentProperty',attribute(b['concept'],b['name']))
            for a in graph.get('property_alignments',[]):
                if not a['stale']:add(uri('relationship',a['source']),OWL+('inverseOf' if a['kind']=='inverse' else 'equivalentProperty'),uri('relationship',a['target']))
            for a in graph.get('alignments',[]):
                add(uri('concept',a['source']),OWL+'equivalentClass' if a['kind']=='equivalent' else RDFS+'subClassOf',uri('concept',a['target']))
            for e in graph['relationships']:
                eid=uri('relationship',e['id']);add(eid,RDF+'type',OWL+'ObjectProperty');add(eid,RDFS+'label',e['label'],True)
                add(eid,VOCAB+'direction',e['direction'],True)
                if e['direction']=='directed':
                    add(eid,RDFS+'domain',uri('concept',e['source']));add(eid,RDFS+'range',uri('concept',e['target']))
                else:
                    for c in (e['source'],e['target']):add(eid,VOCAB+'endpointConcept',uri('concept',c))
                    if e['direction']=='bidirectional':add(eid,RDF+'type',OWL+'SymmetricProperty')
        else:
            edges={e['id']:e for e in graph['relationships']}
            for layer in graph['layers']:
                run=uri('run',kg.digest(layer['run']));add(run,RDF+'type',PROV+'Entity');add(run,RDFS+'label',layer['title'],True)
            if runs:
                with store.db() as db:
                    for a in auto.grouped_instances(db,runs):
                        e=edges[a['edge']]
                        if a['subject']['concept_id']!=e['source']:a['subject'],a['object']=a['object'],a['subject']
                        sid=uri('assertion',a['id'])
                        add(sid,RDF+'type',VOCAB+'Assertion');add(sid,VOCAB+'relationship',uri('relationship',e['id']))
                        add(sid,VOCAB+'direction',e['direction'],True)
                        for contribution in a['contributions']:
                            run_uri=uri('run',kg.digest(contribution['run_id']))
                            add(sid,PROV+'wasDerivedFrom',run_uri)
                            cid=uri('contribution',kg.digest([a['id'],contribution['run_id']]))
                            add(cid,RDF+'type',VOCAB+'Contribution');add(cid,VOCAB+'assertion',sid);add(cid,PROV+'wasDerivedFrom',run_uri)
                            for passage in contribution['evidence']:add(cid,VOCAB+'evidenceMetadata',json.dumps(passage,ensure_ascii=False),True)
                        doc=uri('document',kg.digest([a['document_id'],a['document_versions']]))
                        add(sid,PROV+'wasDerivedFrom',doc);add(doc,RDFS+'label',a['document'],True)
                        records=[]
                        for r in (a['subject'],a['object']):
                            rid=uri('record',r['id']);records.append(rid)
                            add(rid,RDF+'type',uri('concept',r['concept_id']));add(rid,RDFS+'label',r['label'],True)
                            add(rid,VOCAB+'sourceTable',r['source'],True);add(rid,VOCAB+'sourceRecord',r['reference'],True)
                            for name,value in zip(r['columns'],r['cells']):
                                if value is not None:add(rid,attribute(r['concept_id'],name),str(value),True)
                        if e['direction']=='unspecified':
                            for rid in records:add(sid,VOCAB+'endpoint',rid)
                        else:
                            add(sid,RDF+'subject',records[0]);add(sid,RDF+'predicate',uri('relationship',e['id']));add(sid,RDF+'object',records[1])
                            add(records[0],uri('relationship',e['id']),records[1])
                            if e['direction']=='bidirectional':add(records[1],uri('relationship',e['id']),records[0])
                        for evidence in a['evidence']:
                            add(sid,VOCAB+'evidence',evidence.get('context_text') or evidence.get('text',''),True)
                            add(sid,VOCAB+'evidenceMetadata',json.dumps(evidence,ensure_ascii=False),True)
        return {'filename':'idun-'+box+'.'+fmt,'media_type':'text/turtle' if fmt=='ttl' else 'application/ld+json',
                'content':serialize(triples,fmt),'triple_count':len(set(triples))}
