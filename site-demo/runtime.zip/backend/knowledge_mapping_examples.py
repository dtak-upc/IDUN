"""Bounded, run-balanced examples from pinned KG projections; no new inference."""
import json


def examples(store,graph,runs,family,item):
    if not runs:return []
    import knowledge_auto as auto
    names={c['id']:c['label'] for c in graph['concepts']}
    edge_lookup={e['id']:e for e in graph['relationships']}
    selectors=item['attributes'] if family=='attribute' else [item['source'],item['target']]
    result=[]
    with store.db() as db:
        for selector in selectors:
            attribute=selector['name'] if family=='attribute' else None
            key=selector['concept'] if family=='attribute' else selector
            where='run IN ('+','.join('?' for _ in runs)+')';args=list(runs)
            if family=='property':
                where+=' AND edge=?';args.append(key)
                title=edge_lookup[key]['label']
            else:
                where+=" AND (json_extract(data,'$.subject.concept_id')=? OR json_extract(data,'$.object.concept_id')=?)";args.extend([key,key])
                title=names[key]+(' · '+attribute if attribute else '')
            total=db.execute('SELECT count(DISTINCT id) FROM kg_auto_instances WHERE '+where,args).fetchone()[0]
            counts={r['run']:r['n'] for r in db.execute('SELECT run,count(DISTINCT id) n FROM kg_auto_instances WHERE '+where+' GROUP BY run',args)}
            # Rank within each run before limiting so a large first run cannot monopolize examples.
            candidates=db.execute('SELECT id FROM (SELECT id,run,row_number() OVER(PARTITION BY run ORDER BY id) rn FROM kg_auto_instances WHERE '+where+') ORDER BY rn,run LIMIT 6',args).fetchall()
            ids=list(dict.fromkeys(r['id'] for r in candidates))
            samples=[]
            for assertion in auto.grouped_instances(db,runs,ids):
                records=[]
                for side in ('subject','object'):
                    r=assertion[side]
                    if family!='property' and r['concept_id']!=key:continue
                    fields=list(zip(r['columns'],r['cells']))
                    if attribute is not None:fields=[(n,v) for n,v in fields if n==attribute]
                    records.append({'label':str(r['label'])[:160],'concept':names[r['concept_id']],
                                    'source':r['source'],'row':r.get('row'),
                                    'fields':[{'name':n,'value':None if v is None else str(v)[:240]} for n,v in fields[:8]],
                                    'more_fields':max(0,len(fields)-8)})
                samples.append({'id':assertion['id'],'records':records,
                                'runs':[c['run_title'] for c in assertion['contributions']],
                                'evidence':[str(p.get('context_text') or p.get('text',''))[:400] for p in assertion['evidence'][:2]]})
            result.append({'label':title,'total':total,'runs':[{'title':l['title'],'count':counts.get(l['run'],0)} for l in graph['layers']],
                           'samples':samples,'limit':6})
    return result
