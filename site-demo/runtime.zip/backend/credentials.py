"""Resolve one named credential at request time; never enumerate or log secrets."""
import os
import re


def windows_value(name):
    if os.name != 'nt':
        return None
    import winreg
    for hive, path in ((winreg.HKEY_CURRENT_USER, r'Environment'),
                       (winreg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Control\Session Manager\Environment')):
        try:
            with winreg.OpenKey(hive, path) as key:
                value, kind = winreg.QueryValueEx(key, name)
                if kind in (winreg.REG_SZ, winreg.REG_EXPAND_SZ):
                    return value
        except FileNotFoundError:
            continue
    return None


def resolve(name):
    if not name:
        return ''
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,127}', name):
        raise ValueError('Invalid credential environment variable name')
    # User/machine values reflect rotation without inheriting Node's old snapshot.
    # An explicitly empty stored value disables stale process-level credentials.
    value = windows_value(name)
    if value is None:
        value = os.environ.get(name, '')
    if not isinstance(value, str) or len(value) > 8192 or any(ord(c) < 32 for c in value):
        raise ValueError('Invalid credential environment value')
    return value
