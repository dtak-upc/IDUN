"""Append-only mapping decisions committed with each mapping edit."""
import json
import time

TABLES={'concept':'kg_concept_axioms','property':'kg_property_axioms','attribute':'kg_attribute_axioms'}

def setup(db):
    db.execute('CREATE TABLE IF NOT EXISTS kg_mapping_events(sequence INTEGER PRIMARY KEY AUTOINCREMENT, recorded REAL NOT NULL, family TEXT NOT NULL, mapping_id TEXT NOT NULL, action TEXT NOT NULL, data TEXT NOT NULL)')
    db.execute('CREATE INDEX IF NOT EXISTS kg_mapping_events_mapping ON kg_mapping_events(family,mapping_id)')
    for family,table in TABLES.items():
        if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():continue
        for row in db.execute(f'SELECT id,data FROM {table} WHERE NOT EXISTS (SELECT 1 FROM kg_mapping_events WHERE family=? AND mapping_id={table}.id)',(family,)).fetchall():
            item=json.loads(row['data'])
            db.execute('INSERT INTO kg_mapping_events(recorded,family,mapping_id,action,data) VALUES(?,?,?,?,?)',
                       (time.time(),family,row['id'],'baseline',json.dumps({'before':None,'after':item,'runs':[],'revision':None,'label':'Imported existing mapping; original decision time unavailable'})))

def revision(store):
    with store.db() as db:
        setup(db)
        return db.execute('SELECT coalesce(max(sequence),0) FROM kg_mapping_events').fetchone()[0]

def label(family,item,graph):
    concepts={c['id']:c['label'] for c in graph['concepts']}
    if family=='attribute':
        return ' ≡ '.join(concepts.get(a['concept'],a['concept'])+' · '+a['name'] for a in item['attributes'])
    names=concepts
    if family=='property':
        names={e['id']:e['label']+' · '+concepts.get(e['source'],e['source'])+' → '+concepts.get(e['target'],e['target']) for e in graph['relationships']}
    operation={'subclass':' subclass of ','equivalent':' equivalent to ','inverse':' inverse of '}[item['kind']]
    return names.get(item['source'],item['source'])+operation+names.get(item['target'],item['target'])

def record(db,family,item,graph,runs):
    setup(db)
    row=db.execute(f'SELECT data FROM {TABLES[family]} WHERE id=?',(item['id'],)).fetchone()
    data={'before':json.loads(row['data']) if row else None,'after':item,'runs':runs,'revision':graph['revision'],'label':label(family,item,graph)}
    db.execute('INSERT INTO kg_mapping_events(recorded,family,mapping_id,action,data) VALUES(?,?,?,?,?)',
               (time.time(),family,item['id'],'accept' if item['status']=='accepted' else 'undo',json.dumps(data)))

def history(store,body):
    offset=body.get('offset',0)
    if type(offset) is not int or offset<0:raise ValueError('History offset must be a nonnegative integer')
    with store.lock,store.db() as db:
        setup(db)
        total=db.execute('SELECT count(*) FROM kg_mapping_events').fetchone()[0]
        rows=db.execute('SELECT * FROM kg_mapping_events ORDER BY sequence DESC LIMIT 25 OFFSET ?',(offset,)).fetchall()
        return {'total':total,'offset':offset,'limit':25,'items':[dict(sequence=r['sequence'],recorded=r['recorded'],family=r['family'],action=r['action'],**json.loads(r['data'])) for r in rows]}
