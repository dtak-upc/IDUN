"""Bounded, explicitly selected augmentation work; raw paths never guide retrieval."""
import hashlib
import json
import re

import inference


def validate(selection):
    if not isinstance(selection, dict) or not selection.get('table_id') or not selection.get('columns'):
        raise ValueError('Select a source table and at least one field before extraction')
    result = dict(selection)
    result['columns'] = [int(i) for i in result['columns']]
    for key, default, low, high in [('target_limit', 10, 1, 100), ('contexts_limit', 3, 1, 10), ('row_offset', 0, 0, 100000000), ('nearby_radius', 1500, 200, 5000), ('nearby_limit', 2, 1, 5)]:
        result[key] = int(result.get(key, default))
        if not low <= result[key] <= high:
            raise ValueError(f'{key} must be between {low} and {high}')
    if type(result.get('nearby_second_pass', False)) is not bool: raise ValueError('Second pass must be enabled or disabled')
    for value in result.get('types', {}).values():
        if value not in ('string', 'numeric', 'date', 'unit_quantity'):
            raise ValueError('Unsupported field type')
    return result


def source_targets(store, selection):
    import augmentation
    s = validate(selection)
    projection = augmentation.policy(store)
    nulls = projection.get('null_tokens', inference.DEFAULT_NULL_TOKENS)
    targets = []
    with store.db() as db:
        mask = inference.identifier_mask(db, projection.get('exclude_identifiers', []))
        job = db.execute("SELECT j.asset_id,j.version,a.name FROM jobs j JOIN assets a ON a.id=j.asset_id WHERE j.asset_id=? AND j.status='ready' AND lower(a.name) LIKE '%.csv'", (s['table_id'],)).fetchone()
        if not job:
            raise ValueError('Selected table is not ready')
        aid, version = job['asset_id'], job['version']
        header = json.loads(db.execute('SELECT data FROM records WHERE asset_id=? AND version=? AND idx=1', (aid, version)).fetchone()['data'])
        included = inference.table_columns(header, projection.get('exclude_identifiers', []))
        if not set(s['columns']).issubset(included):
            raise ValueError('Selected fields include hidden or unavailable columns')
        for row in db.execute('SELECT idx,data FROM records WHERE asset_id=? AND version=? AND idx>? ORDER BY idx', (aid, version, 1+s['row_offset'])):
            cells = json.loads(row['data'])
            if len(cells) != len(header):
                continue
            projected = {i: inference.resolve_cell_value(cells[i], nulls) for i in included}
            context = {mask(header[i]): mask(str(value)) for i, (value, missing) in projected.items() if not missing and value is not None}
            for index in s['columns']:
                if not projected[index][1] and cells[index] not in (None, ''):
                    continue
                rid = f"{aid}:{version}:{row['idx']}"
                targets.append(dict(id=hashlib.sha256(f'{rid}:{index}'.encode()).hexdigest(),
                    record_id=rid, asset_id=aid, version=version, record_index=row['idx'],
                    table_name=job['name'], column_index=index, column_name=mask(header[index]),
                    expected_type=s.get('types', {}).get(str(index), 'string'), original_value=cells[index],
                    null_reason='empty_cell', row_context=context, output_references=[], evidence_contexts=[]))
                if len(targets) >= s['target_limit']:
                    break
            if len(targets) >= s['target_limit']:
                break
        by_record = {}
        for target in targets:
            by_record.setdefault(target['record_id'], []).append(target)
        has_links = db.execute("SELECT 1 FROM sqlite_master WHERE name='discovery_links'").fetchone()
        if has_links:
            # Streaming keeps memory bounded even for existing large discovery inventories.
            for row in db.execute('SELECT data FROM discovery_links WHERE table_id=? ORDER BY score DESC', (aid,)):
                link = augmentation.decode_discovery_data(row['data'])
                rid = link.get('record_id') or f"{aid}:{link.get('row_version', '')}:{link.get('row_index', '')}"
                if rid not in by_record:
                    continue
                text = link.get('text_preview', '')
                start = link.get('start')
                if not text or start is None:
                    continue
                for target in by_record[rid]:
                    ev = target['evidence_contexts']
                    if len(ev) >= s['contexts_limit']:
                        continue
                    doc = link.get('text') or link.get('text_id')
                    if not any(e['document'] == doc and e['start'] == start for e in ev):
                        ev.append(dict(document=doc, document_name=link.get('text_name', doc),
                            start=start, end=start+len(text), text=mask(text), document_version=link.get('text_version'), evidence_id=link.get('id', '')))
        # Retrieval fallback uses known descriptive values, never IDs, paths, or empty queries.
        pending = [t for t in targets if not t['evidence_contexts']]
        if pending:
            docs = db.execute("SELECT r.asset_id,r.version,r.idx,r.start,r.data,a.name FROM records r JOIN jobs j ON j.asset_id=r.asset_id AND j.version=r.version JOIN assets a ON a.id=r.asset_id WHERE j.status='ready' AND lower(a.name) LIKE '%.txt' ORDER BY a.id,r.idx")
            terms = {t['id']: [v for v in t['row_context'].values() if re.search(r'[A-Za-z]{2}', v) and '█' not in v] for t in pending}
            for record in docs:
                text = json.loads(record['data'])
                if not isinstance(text, str):
                    continue
                for target in pending:
                    ev = target['evidence_contexts']
                    if len(ev) >= s['contexts_limit']:
                        continue
                    matches = [m.start() for value in terms[target['id']] for m in re.finditer(r'(?<!\w)'+re.escape(value)+r'(?!\w)', text, re.I)]
                    if not matches:
                        continue
                    begin = max(0, min(matches)-400)
                    snippet = text[begin:begin+1500]
                    start = (record['start'] or 0)+begin
                    ev.append(dict(document=record['asset_id'], document_name=record['name'], start=start,
                        end=start+len(snippet), text=mask(snippet), document_version=record['version'], evidence_id=f"txt_{record['asset_id']}_{record['idx']}"))
                if all(len(t['evidence_contexts']) >= s['contexts_limit'] or not terms[t['id']] for t in pending):
                    break
    return targets
