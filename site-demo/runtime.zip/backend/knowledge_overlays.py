"""Pinned finalized augmentation claims; never overwrites KG source cells."""
import json
import time
import knowledge as kg


def setup(db):
    db.execute('CREATE TABLE IF NOT EXISTS kg_augmentation_layers(id TEXT PRIMARY KEY,data TEXT NOT NULL)')
    db.execute('CREATE TABLE IF NOT EXISTS kg_augmentation_claims(layer TEXT,id TEXT,data TEXT NOT NULL,PRIMARY KEY(layer,id))')
    db.execute("CREATE INDEX IF NOT EXISTS kg_augmentation_claim_record ON kg_augmentation_claims(layer,json_extract(data,'$.record'))")
    db.execute('CREATE TABLE IF NOT EXISTS kg_augmentation_events(sequence INTEGER PRIMARY KEY AUTOINCREMENT,recorded REAL,data TEXT NOT NULL)')


def source(db,run):
    if not db.execute("SELECT 1 FROM sqlite_master WHERE name='augmentation_runs'").fetchone():return None,[]
    row=db.execute('SELECT * FROM augmentation_runs WHERE id=?',(run,)).fetchone()
    if not row:return None,[]
    meta=dict(row);meta['config']=json.loads(meta['config'])
    proposals=[json.loads(r['data']) for r in db.execute("SELECT data FROM augmentation_proposals WHERE run_id=? AND decision='accepted' ORDER BY id",(run,))]
    return meta,proposals


def finalized(meta):
    return bool(meta and meta['status'] not in ('queued','running') and meta['config'].get('review',{}).get('status')=='finalized')


def fingerprint(meta,proposals):return kg.digest([meta,proposals]) if meta else None


def read(store):
    with store.db() as db:
        setup(db)
        return [json.loads(r['data']) for r in db.execute('SELECT data FROM kg_augmentation_layers ORDER BY id')]


def catalog(store,graph,runs):
    layers=read(store);versions={l['run']:l['revision'] for l in graph['layers']};scope=sorted(runs)
    with store.db() as db:
        available=[]
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='augmentation_runs'").fetchone():
            for row in db.execute('SELECT id FROM augmentation_runs ORDER BY created DESC'):
                meta,proposals=source(db,row['id']);review=meta['config'].get('review',{})
                available.append({'id':meta['id'],'title':meta['config'].get('title') or 'Augmentation · '+time.strftime('%Y-%m-%d %H:%M',time.localtime(meta['created'])),
                    'scope':meta['scope'],'accepted':len(proposals),'review':review.get('status','not finalized'),'eligible':finalized(meta),'base_run':meta['base_run_id']})
        visible=[]
        for layer in layers:
            if layer['runs']!=scope:continue
            meta,proposals=source(db,layer['augmentation'])
            visible.append(dict(layer,update_available=fingerprint(meta,proposals)!=layer['source_revision'],source_available=bool(meta),graph_stale=layer['projections']!=versions))
    return {'revision':kg.digest(layers),'sources':available,'layers':visible}


def prepare(store,graph,runs,run):
    with store.db() as db:
        meta,proposals=source(db,run)
        if not runs:raise ValueError('Select KG Integration runs first')
        if meta and (meta['lake_id']!=store.lake_id or meta['scope'] not in ('source','integration')):raise ValueError('Invalid augmentation scope')
        if not finalized(meta):raise ValueError('Finalize augmentation review before attaching a layer')
        if meta['scope']=='integration' and meta['base_run_id'] not in runs:raise ValueError('Select the augmentation base Integration run in the KG scope')
        scope=','.join('?' for _ in runs);claims=[];skipped=0
        included=set(meta['config']['review'].get('accepted_proposal_ids',[]))
        for proposal in proposals:
            typed=proposal.get('typed_data') or {};target=proposal.get('target',{});ref=target.get('record_id','')
            parts=ref.rsplit(':',2)
            if (proposal.get('decision')!='accepted' or proposal.get('id') not in included or proposal.get('proposed_value') is None
                    or isinstance(proposal.get('proposed_value'),str) and not proposal['proposed_value'].strip() or typed.get('validation','valid')!='valid' or typed.get('valid',True) is False or len(parts)!=3 or not parts[2].isdigit()
                    or parts[0]!=target.get('asset_id') or parts[1]!=target.get('version')):
                skipped+=1;continue
            rid='r_'+kg.digest([store.lake_id,parts[0],parts[1],int(parts[2])])
            bindings=[];originals=[]
            for side in ('subject','object'):
                sql=f"SELECT run,json_extract(data,'$.{side}') record FROM kg_auto_instances WHERE run IN ({scope}) AND json_extract(data,'$.{side}.id')=?"
                for row in db.execute(sql,[*runs,rid]):
                    if meta['scope']=='integration' and row['run']!=meta['base_run_id']:continue
                    record=json.loads(row['record']);column=target.get('column_name')
                    if record['reference']!=ref or record['columns'].count(column)!=1:continue
                    index=record['columns'].index(column)
                    if index>=len(record['cells']):continue
                    binding={'run':row['run'],'record':rid,'concept':record['concept_id']}
                    if binding not in bindings:bindings.append(binding)
                    original=record['cells'][index]
                    if not any(type(v) is type(original) and v==original for v in originals):originals.append(original)
            if not bindings:skipped+=1;continue
            manual=proposal.get('engine')=='manual' or (proposal.get('attribution') or {}).get('status')=='manual'
            value=proposal['proposed_value'];conflict=any(v is not None and v!='' and (type(v) is not type(value) or v!=value) for v in originals)
            claims.append({'id':proposal['id'],'proposal':proposal['id'],'augmentation':run,'record':rid,'column':target['column_name'],
                'value':value,'normalized_value':typed.get('normalized_value'),'original_at_review':proposal.get('original_value'),'original_values':originals,'conflict':conflict,'fills_gap':any(v is None or v=='' for v in originals),
                'datatype':typed.get('value_type','string'),'unit':typed.get('unit'),'temporal_scope':typed.get('temporal_scope'),'origin':'manual' if manual else 'accepted_extraction',
                'engine':proposal.get('engine'),'grounding':'manual' if manual else (proposal.get('attribution') or {}).get('status','unspecified'),
                'evidence':None if manual else proposal.get('evidence'),'bindings':sorted(bindings,key=lambda b:(b['run'],b['concept'])),
                'source':target.get('table_name',''),
                'row':int(parts[2]),'target_version':parts[1]})
        # Source names come from the pinned KG record, not opaque target hashes.
        for claim in claims:
            for side in ('subject','object'):
                row=db.execute(f"SELECT json_extract(data,'$.{side}.source') FROM kg_auto_instances WHERE run IN ({scope}) AND json_extract(data,'$.{side}.id')=? LIMIT 1",[*runs,claim['record']]).fetchone()
                if row:claim['source']=row[0];break
        layer={'id':'overlay_'+kg.digest([run,sorted(runs)]),'augmentation':run,'title':meta['config'].get('title') or 'Augmentation · '+time.strftime('%Y-%m-%d %H:%M',time.localtime(meta['created'])),
            'runs':sorted(runs),'projections':{l['run']:l['revision'] for l in graph['layers']},'source_revision':fingerprint(meta,proposals),
            'enabled':True,'count':len(claims),'skipped':skipped,'manual':sum(c['origin']=='manual' for c in claims),'conflicts':sum(c['conflict'] for c in claims),
            'fills_gap':sum(c['fills_gap'] for c in claims),'finalized_at':meta['config']['review'].get('finalized_at')}
    return layer,claims


def annotate(store,graph,runs,items,interrupted=None):
    """Expose claims alongside cells, without changing filters or source values."""
    versions={l['run']:l['revision'] for l in graph['layers']}
    with store.db() as db:
        if interrupted:db.set_progress_handler(interrupted,1000)
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_augmentation_layers'").fetchone():return
        layers=[json.loads(r['data']) for r in db.execute('SELECT data FROM kg_augmentation_layers')]
        layers=[l for l in layers if l['enabled'] and l['runs']==sorted(runs) and l['projections']==versions]
        if not layers or not items:return
        ids=list({a[side]['id'] for a in items for side in ('subject','object')});by_record={}
        for layer in layers:
            sql="SELECT data FROM kg_augmentation_claims WHERE layer=? AND json_extract(data,'$.record') IN ("+','.join('?' for _ in ids)+') ORDER BY id'
            for row in db.execute(sql,[layer['id'],*ids]):
                claim=json.loads(row['data']);claim.update(layer=layer['id'],layer_title=layer['title'])
                by_record.setdefault(claim['record'],[]).append(claim)
    for assertion in items:
        contributing={c['run_id'] for c in assertion.get('contributions',[])}
        for side in ('subject','object'):
            record=assertion[side]
            matches=[c for c in by_record.get(record['id'],[]) if any(b['run'] in contributing and b['concept']==record['concept_id'] for b in c['bindings'])]
            if matches:record['augmentation_claims']=matches


def route(store,action,body):
    import knowledge_auto as auto
    runs=auto.selected(body)
    with store.lock:
        graph=auto.view(store,runs)
        if action=='augmentation-layers':return catalog(store,graph,runs)
        saved=read(store)
        if action=='augmentation-claims':
            layer=next((l for l in saved if l['id']==body.get('id') and l['runs']==sorted(runs)),None)
            if not layer:raise ValueError('Choose a layer in this scope')
            start=body.get('offset',0)
            if type(start) is not int or start<0:raise ValueError('Invalid claim page')
            with store.db() as db:items=[json.loads(r['data']) for r in db.execute('SELECT data FROM kg_augmentation_claims WHERE layer=? ORDER BY id LIMIT 20 OFFSET ?',(layer['id'],start))]
            return {'items':items,'total':layer['count'],'offset':start,'limit':20}
        if graph['revision']!=body.get('revision'):raise ValueError('Graph changed; reload augmentation layers')
        if kg._jobs.get(str(store.root),{}).get('status')=='running':raise ValueError('Wait for the current graph task')
        if action in ('toggle-augmentation-layer','remove-augmentation-layer'):
            layer=next((l for l in saved if l['id']==body.get('id') and l['runs']==sorted(runs)),None)
            if not layer or body.get('layer_revision')!=kg.digest(saved):raise ValueError('Layer selection changed; reload')
            if action=='toggle-augmentation-layer':
                if type(body.get('enabled')) is not bool:raise ValueError('Choose an enabled state')
                result=dict(layer,enabled=body['enabled'])
            else:result=None
            claims=None
        else:
            if any(l['update_available'] for l in graph['layers']):raise ValueError('Review pending graph updates before attaching claims')
            result,claims=prepare(store,graph,runs,body.get('augmentation'))
            token=kg.digest([graph['revision'],saved,result,claims])
            if action=='preview-augmentation-layer':return {'layer':result,'items':claims[:5],'token':token}
            if action!='apply-augmentation-layer' or body.get('token')!=token:raise ValueError('Augmentation preview changed; preview again')
            if not claims:raise ValueError('No accepted claims match the selected KG records')
            layer=next((l for l in saved if l['id']==result['id']),None)
        with store.db() as db:
            id=result['id'] if result else layer['id']
            if result:
                db.execute('INSERT OR REPLACE INTO kg_augmentation_layers VALUES(?,?)',(id,json.dumps(result)))
            else:db.execute('DELETE FROM kg_augmentation_layers WHERE id=?',(id,))
            if claims is not None or result is None:
                db.execute('DELETE FROM kg_augmentation_claims WHERE layer=?',(id,))
                if claims:db.executemany('INSERT INTO kg_augmentation_claims VALUES(?,?,?)',[(id,c['id'],json.dumps(c)) for c in claims])
            db.execute('INSERT INTO kg_augmentation_events(recorded,data) VALUES(?,?)',(time.time(),json.dumps({'before':layer,'after':result,'revision':graph['revision']})))
        return catalog(store,graph,runs)
