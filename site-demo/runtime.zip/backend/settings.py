import credentials
"""Local backend settings. Credentials are referenced by environment variable, never returned."""
import json,os,re,sys,subprocess,math,urllib.request,urllib.error,ipaddress,logging
from pathlib import Path
from urllib.parse import urlsplit

# Suppress external torchao ABI compatibility warnings across backend workers
logging.getLogger("torchao").setLevel(logging.ERROR)
os.environ.setdefault("TORCHAO_SKIP_LOADING_SO_FILES", "1")

ROOT=Path(__file__).resolve().parents[1]
DEFAULT_VENV=ROOT/'.venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
DEFAULT_MODEL=DEFAULT_VENV if DEFAULT_VENV.exists() else (ROOT/'.idun/model-runtime'/('Scripts/python.exe' if os.name=='nt' else 'bin/python'))


def defaults():
 return {'api_python':'','model_python':'','device':'auto','vram_gib':6,'llm':{'provider':'disabled','base_url':'http://127.0.0.1:11434','model':'','key_env':'','timeout_seconds':15,'max_output_tokens':8192,'temperature':None,'top_p':None,'auto_unload':True}}

def read(store):
 path=getattr(store,'settings_root',store.root)/'settings.json'
 value=json.loads(path.read_text(encoding='utf-8')) if path.exists() else defaults()
 value['llm']={**defaults()['llm'],**value['llm']}
 return value

def runtime(store):
 settings=read(store)
 model_py=settings['model_python']
 if model_py and not Path(model_py).is_file():
  model_py=''
 default_py=str(DEFAULT_VENV if DEFAULT_VENV.exists() else DEFAULT_MODEL)
 return {'python':os.environ.get('IDUN_MODEL_PYTHON') or model_py or default_py,'device':settings['device'],'vram_gib':settings['vram_gib']}

def worker_env(store):
 settings=runtime(store)
 return {**os.environ,'IDUN_DEVICE':settings['device']}

def python_path(value):
 if not isinstance(value,str) or len(value)>2048:raise ValueError('Invalid Python executable path')
 if not value:return value
 path=Path(value)
 if not path.is_absolute() or not path.is_file() or not re.fullmatch(r'python(?:\d+(?:\.\d+)*)?(?:\.exe)?',path.name,re.I):raise ValueError('Choose an existing Python executable using its full path')
 return str(path.absolute())

def llm_validate(value):
 if not isinstance(value,dict):raise ValueError('Invalid LLM settings')
 value={'max_output_tokens':8192,'temperature':None,'top_p':None,'auto_unload':True,**value}
 fields={'provider','base_url','model','key_env','timeout_seconds','max_output_tokens','temperature','top_p','auto_unload'}
 if set(value)!=fields:raise ValueError('Unexpected LLM settings fields')
 if not isinstance(value.get('auto_unload'),bool):raise ValueError('auto_unload must be a boolean')
 if value['provider'] not in ('disabled','ollama','openai-compatible','lm-studio','unsloth','huggingface'):raise ValueError('Unsupported LLM provider')
 if value['provider']=='huggingface':
  if not isinstance(value.get('model',''),str) or len(value.get('model',''))>2048 or not value.get('model','').strip():raise ValueError('Invalid Hugging Face model repository ID')
  base=''
 else:
  for key in ('base_url','model','key_env'):
   if not isinstance(value[key],str) or len(value[key])>2048 or any(ord(c)<32 for c in value[key]):raise ValueError('Invalid LLM setting')
  url=urlsplit(value['base_url'])
  if url.scheme not in ('http','https') or not url.hostname or url.username or url.password or url.query or url.fragment:raise ValueError('Use a base URL without credentials, query or fragment')
  try:url.port
  except ValueError:raise ValueError('Invalid LLM server port')
  local=url.hostname in ('localhost','127.0.0.1','::1')
  try:
   address=ipaddress.ip_address(url.hostname)
   local=local or address.is_loopback or any(address in ipaddress.ip_network(network) for network in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16','fc00::/7'))
  except ValueError:pass
  if url.scheme=='http' and not local:raise ValueError('Public LLM endpoints require HTTPS; HTTP is supported on loopback and private LAN IPs')
  base=value['base_url'].rstrip('/')
  if value['provider'] in ('openai-compatible','lm-studio','unsloth') and not url.path.strip('/'):base+='/v1'
 if value['key_env'] and not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,127}',value['key_env']):raise ValueError('Enter an environment variable name, not an API key')
 if type(value['timeout_seconds'])!=int or value['timeout_seconds']<0:raise ValueError('Timeout must be a nonnegative number of seconds; 0 means no timeout')
 if type(value['max_output_tokens'])!=int or not 256<=value['max_output_tokens']<=65536:raise ValueError('Output token allowance must be 256–65536')
 for name,low,high in (('temperature',0,2),('top_p',0.001,1)):
  v=value[name]
  if v is not None and (type(v) not in (int,float) or not math.isfinite(v) or not low<=v<=high):raise ValueError('Invalid sampling setting: '+name)
 return dict(value,base_url=base)

def save(store,data):
 with store.lock:
  if getattr(store,'registry',None) and store.registry.busy():raise ValueError('Finish or cancel active lake jobs before changing settings')
  if getattr(store,'restarting',False):raise ValueError('API restart is in progress')
  if getattr(store,'profile_active',False) or getattr(store,'discovery_active',False) or getattr(store,'integration_active',False):raise ValueError('Wait for indexing/discovery to finish before changing settings')
  if not isinstance(data,dict) or set(data)!=set(defaults()):raise ValueError('Unexpected settings fields')
  if data['device'] not in ('auto','cuda','cpu'):raise ValueError('Device must be auto, cuda or cpu')
  if type(data['vram_gib']) not in (int,float) or not math.isfinite(data['vram_gib']) or data['vram_gib']<=0:raise ValueError('VRAM reference must be a positive finite number')
  value={**data,'api_python':python_path(data['api_python']),'model_python':python_path(data['model_python']),'llm':llm_validate(data['llm'])}
  temporary=getattr(store,'settings_root',store.root)/'settings.json.tmp'
  temporary.write_text(json.dumps(value,indent=2),encoding='utf-8');temporary.replace(getattr(store,'settings_root',store.root)/'settings.json')
 return public(store)

def environments(store):
 default_model_path=str(DEFAULT_VENV if DEFAULT_VENV.exists() else DEFAULT_MODEL)
 paths=[sys.executable,default_model_path,str(DEFAULT_VENV),os.environ.get('IDUN_MODEL_PYTHON',''),read(store)['model_python'],read(store)['api_python']]
 for folder in (ROOT/'.venv',ROOT/'venv'):
  paths.append(str(folder/('Scripts/python.exe' if os.name=='nt' else 'bin/python')))
 conda=Path.home()/'.conda/environments.txt'
 if conda.exists():
  paths.extend(str(Path(p)/('python.exe' if os.name=='nt' else 'bin/python')) for p in conda.read_text(encoding='utf-8').splitlines()[:100] if p.strip())
 found={}
 for p in paths:
  if p and Path(p).is_file():
   resolved=str(Path(p).absolute());found[os.path.normcase(resolved)]={'path':resolved,'name':Path(p).parent.parent.name if Path(p).parent.name in ('Scripts','bin') else Path(p).parent.name}
 return list(found.values())

def public(store):
 settings=read(store)
 last=None
 with store.db() as db:
  if db.execute("SELECT 1 FROM sqlite_master WHERE name='discovery_report'").fetchone():
   row=db.execute('SELECT data FROM discovery_report WHERE id=1').fetchone()
   if row:last=json.loads(row['data']).get('work')
 api_saved=settings['api_python']
 if api_saved and not Path(api_saved).is_file():
  api_saved=''
 default_api=str(DEFAULT_VENV) if DEFAULT_VENV.exists() else sys.executable
 effective_api=os.environ.get('IDUN_PYTHON') or api_saved or os.environ.get('IDUN_DEFAULT_API_PYTHON') or default_api
 return {'restart_available':os.environ.get('IDUN_MANAGED_API')=='1','process_id':os.getpid(),'restart_error':os.environ.get('IDUN_RESTART_ERROR',''),'settings':settings,'active_api_python':sys.executable,'next_api_python':effective_api,'api_restart_required':os.path.normcase(effective_api)!=os.path.normcase(sys.executable),'runtime':runtime(store),'environments':environments(store),'overrides':{'api':bool(os.environ.get('IDUN_PYTHON')),'model':bool(os.environ.get('IDUN_MODEL_PYTHON'))},'key_available':bool(settings['llm']['key_env'] and credentials.resolve(settings['llm']['key_env'])),'last_discovery':last,'storage':str(store.root)}

def probe(data):
 py = data.get('python') or data.get('model_python') or ''
 if not py:
  default_py = str(DEFAULT_VENV if DEFAULT_VENV.exists() else DEFAULT_MODEL)
  py = os.environ.get('IDUN_MODEL_PYTHON') or default_py
 path = python_path(py)
 if not path:raise ValueError('Select a Python environment to test')
 try:
  result = subprocess.run([path,'-I',str(ROOT/'scripts/probe-runtime.py')],capture_output=True,text=True,encoding='utf-8',timeout=45,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
 except (OSError,subprocess.TimeoutExpired):raise ValueError('Python environment did not respond within 45 seconds')
 if result.returncode:raise ValueError('Runtime probe failed. Check that the Python environment starts correctly.')
 try:return json.loads(result.stdout)
 except (ValueError,TypeError):raise ValueError('Python returned an invalid runtime probe')

class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None

def test_llm(data):
 settings=llm_validate(data)
 if settings['provider']=='disabled':raise ValueError('Select an LLM provider first')
 key=credentials.resolve(settings['key_env'])
 if settings['provider']=='huggingface':
  import hf_model_manager
  repo_id=settings['model'].strip()
  if not repo_id:raise ValueError('Enter or select a Hugging Face model repository ID')
  cached_map=hf_model_manager.get_cached_models_map()
  is_downloaded=repo_id in cached_map
  models=[m['repo_id'] for m in hf_model_manager.list_models()]
  notice=f'Model {repo_id} is downloaded and ready for in-process inference ({cached_map[repo_id]["size_str"]}).' if is_downloaded else f'Model {repo_id} is not yet downloaded. Click Download to cache weights locally.'
  return {'status':'connected' if is_downloaded else 'pending_download','models':models,'selected_model_available':is_downloaded,'notice':notice}
 if settings['key_env'] and not key:raise ValueError('API key environment variable is not available to this backend. Set it in Windows user environment variables; it is read again on each request.')
 headers={'Accept':'application/json'}
 if key and (len(key)>8192 or any(ord(c)<32 for c in key)):raise ValueError('API key environment variable contains an invalid value')
 if key:headers['Authorization']='Bearer '+key
 suffix='/api/tags' if settings['provider']=='ollama' else '/models'
 request=urllib.request.Request(settings['base_url']+suffix,headers=headers)
 try:
  with urllib.request.build_opener(NoRedirect).open(request,timeout=settings['timeout_seconds'] or None) as response:
   payload=response.read(1024*1024+1)
   if len(payload)>1024*1024:raise ValueError('Model listing exceeds 1 MiB')
   data=json.loads(payload)
 except urllib.error.HTTPError as e:raise ValueError(f'LLM server returned HTTP {e.code}. Check endpoint and authentication.')
 except (urllib.error.URLError,TimeoutError,OSError):raise ValueError('Cannot reach the LLM endpoint. Check the URL and whether the server is running.')
 except (ValueError,UnicodeError):raise ValueError('LLM server did not return a supported model listing')
 field,name=('models','name') if settings['provider']=='ollama' else ('data','id')
 if not isinstance(data,dict) or not isinstance(data.get(field),list):raise ValueError('LLM server did not return a supported model listing')
 models=[m[name] for m in data[field] if isinstance(m,dict) and isinstance(m.get(name),str)][:200]
 return {'status':'connected','models':models,'selected_model_available':settings['model'] in models,'notice':'Model listing only; no lake data or inference prompt sent.'}

def request_restart(server):
 store=server.store
 with store.lock:
  manager=sys.modules.get('hf_model_manager')
  if manager and manager.download_active():raise ValueError('Finish or cancel the model download before restarting')
  if getattr(server,'lakes',None) and server.lakes.busy():raise ValueError('Finish or cancel jobs in all lakes before restarting')
  if os.environ.get('IDUN_MANAGED_API')!='1':raise ValueError('Restart requires the combined npm start launcher. Start it once to enable in-app restarts.')
  if getattr(store,'restarting',False):raise ValueError('API restart is already in progress')
  if getattr(store,'profile_active',False) or getattr(store,'discovery_active',False) or getattr(store,'integration_active',False):raise ValueError('Finish or cancel indexing/discovery before restarting')
  with store.db() as db:
   if db.execute("SELECT 1 FROM jobs WHERE status NOT IN ('ready','failed','cancelled','interrupted') LIMIT 1").fetchone():raise ValueError('Finish or cancel file ingestion before restarting')
  target=python_path(public(store)['next_api_python'])
  command="import sys; assert sys.version_info >= (3,11); sys.path.insert(0,sys.argv[1]); import server"
  try:
   result=subprocess.run([target,'-I','-c',command,str(ROOT/'backend')],capture_output=True,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
  except (OSError,subprocess.TimeoutExpired):raise ValueError('Selected API Python cannot start. The current API is still running.')
  if result.returncode:raise ValueError('Selected API Python needs Python 3.11+ and working backend dependencies. The current API is still running.')
  store.restarting=True;server.restart_requested=True
  return {'status':'restarting','process_id':os.getpid(),'python':target}

def request_shutdown(server, force=False):
 store=server.store
 with store.lock:
  if getattr(store,'shutting_down',False):return {'status':'shutting_down','process_id':os.getpid()}
  if not force:
   manager=sys.modules.get('hf_model_manager')
   if manager and manager.download_active():raise ValueError('Finish or cancel the model download before shutting down')
   if getattr(server,'lakes',None) and server.lakes.busy():raise ValueError('Finish or cancel jobs in all lakes before shutting down')
   if getattr(store,'profile_active',False) or getattr(store,'discovery_active',False) or getattr(store,'integration_active',False):raise ValueError('Finish or cancel indexing/discovery before shutting down')
   with store.db() as db:
    if db.execute("SELECT 1 FROM jobs WHERE status NOT IN ('ready','failed','cancelled','interrupted') LIMIT 1").fetchone():raise ValueError('Finish or cancel file ingestion before shutting down')
  else:
   manager=sys.modules.get('hf_model_manager')
   if manager:manager.stop_download()
   if getattr(store,'profile_active',False):store.profile_cancel.set()
   if getattr(store,'discovery_active',False):store.discovery_cancel.set()
   if getattr(store,'integration_active',False):store.integration_cancel.set()
  store.shutting_down=True;server.shutdown_requested=True
  if 'hf_model_manager' in sys.modules:
   try:
    sys.modules['hf_model_manager'].unload_model()
   except Exception:pass
  return {'status':'shutting_down','process_id':os.getpid()}
