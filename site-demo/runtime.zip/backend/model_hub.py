"""Unified Global Model Hub for IDUN.

Organizes all models into a single global directory (ROOT / 'models') structured by steps:
- step1_profiling: Dense passage and table row embedding models for profiling & vector retrieval.
- step2_discovery: Cross-encoder rerankers for candidate pair discovery.
- step3_cross_attention: Cross-attention adapters and checkpoints (LOKI, generic).
- step4_llm: Generative LLMs for evidence synthesis and relationship extraction.
"""

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import hashlib
import json
import os
import shutil
import sys
import threading
import time
import urllib.request
from encoder_defaults import MODEL, REVISION, default_directory

ROOT = Path(__file__).resolve().parents[1]
MODELS_ROOT = Path(os.environ.get("IDUN_MODELS_DIR", ROOT / "models"))

STEP_DIRS = {
    "step1_profiling": MODELS_ROOT / "step1_profiling",
    "step2_discovery": MODELS_ROOT / "step2_discovery",
    "step3_cross_attention": MODELS_ROOT / "step3_cross_attention",
    "step4_llm": MODELS_ROOT / "step4_llm",
}

# Ensure step directories exist
for d in STEP_DIRS.values():
    d.mkdir(parents=True, exist_ok=True)


# =====================================================================
# Model Catalog Definitions
# =====================================================================

CATALOG: Dict[str, Dict[str, Any]] = {
    "step1_profiling": {
        "title": "Step 1: Dataset Profiling & Passage Embeddings",
        "description": "Dense embedding models for indexing CSV tables and text passages into vector storage.",
        "default_model": "embeddinggemma-2",
        "models": {
            "embeddinggemma-2": {
                "id": "embeddinggemma-2", "name": "EmbeddingGemma-2 (Text only · Default generic encoder)",
                "repo_id": MODEL, "revision": REVISION, "dimensions": 768,
                "token_limit": 262144,
                "recommended": True, "description": "Text-only encoder with a symmetric sentence similarity prompt. Prepare in Settings to install its isolated runtime.",
                "estimated_size_mb": 1420, "files": [],
            },
            "all-minilm": {
                "id": "all-minilm",
                "name": "all-MiniLM-L6-v2 (Lightweight alternative)",
                "repo_id": "sentence-transformers/all-MiniLM-L6-v2",
                "dimensions": 384,
                "token_limit": 512,
                "recommended": False,
                "description": "Fast 384d embedding model with minimal VRAM/CPU footprint. Ideal for domain-agnostic tabular data.",
                "dir_name": "all-minilm",
                "estimated_size_mb": 90,
                "files": [
                    {"rel": "model.safetensors", "url": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/model.safetensors"},
                    {"rel": "config.json", "url": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/config.json"},
                    {"rel": "config_sentence_transformers.json", "url": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/config_sentence_transformers.json"},
                    {"rel": "modules.json", "url": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/modules.json"},
                    {"rel": "sentence_bert_config.json", "url": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/sentence_bert_config.json"},
                    {"rel": "special_tokens_map.json", "url": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/special_tokens_map.json"},
                    {"rel": "tokenizer.json", "url": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/tokenizer.json"},
                    {"rel": "tokenizer_config.json", "url": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/tokenizer_config.json"},
                    {"rel": "vocab.txt", "url": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/vocab.txt"},
                    {"rel": "1_Pooling/config.json", "url": "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/1_Pooling/config.json"},
                ],
            },
            "medembed": {
                "id": "medembed",
                "name": "MedEmbed-large-v0.1 (Clinical / LOKI)",
                "repo_id": "abhinand/MedEmbed-large-v0.1",
                "dimensions": 1024,
                "token_limit": 512,
                "recommended": False,
                "description": "High-accuracy biomedical and clinical passage embedding model (1024d) for MIMIC and EHR datasets.",
                "dir_name": "medembed",
                "estimated_size_mb": 670,
                "files": [
                    {"rel": "model.safetensors", "url": "https://huggingface.co/abhinand/MedEmbed-large-v0.1/resolve/963121bfb9c625475f65b08fb54990ce9c4e7a1a/model.safetensors"},
                    {"rel": "config.json", "url": "https://huggingface.co/abhinand/MedEmbed-large-v0.1/resolve/963121bfb9c625475f65b08fb54990ce9c4e7a1a/config.json"},
                    {"rel": "config_sentence_transformers.json", "url": "https://huggingface.co/abhinand/MedEmbed-large-v0.1/resolve/963121bfb9c625475f65b08fb54990ce9c4e7a1a/config_sentence_transformers.json"},
                    {"rel": "modules.json", "url": "https://huggingface.co/abhinand/MedEmbed-large-v0.1/resolve/963121bfb9c625475f65b08fb54990ce9c4e7a1a/modules.json"},
                    {"rel": "sentence_bert_config.json", "url": "https://huggingface.co/abhinand/MedEmbed-large-v0.1/resolve/963121bfb9c625475f65b08fb54990ce9c4e7a1a/sentence_bert_config.json"},
                    {"rel": "special_tokens_map.json", "url": "https://huggingface.co/abhinand/MedEmbed-large-v0.1/resolve/963121bfb9c625475f65b08fb54990ce9c4e7a1a/special_tokens_map.json"},
                    {"rel": "tokenizer.json", "url": "https://huggingface.co/abhinand/MedEmbed-large-v0.1/resolve/963121bfb9c625475f65b08fb54990ce9c4e7a1a/tokenizer.json"},
                    {"rel": "tokenizer_config.json", "url": "https://huggingface.co/abhinand/MedEmbed-large-v0.1/resolve/963121bfb9c625475f65b08fb54990ce9c4e7a1a/tokenizer_config.json"},
                    {"rel": "vocab.txt", "url": "https://huggingface.co/abhinand/MedEmbed-large-v0.1/resolve/963121bfb9c625475f65b08fb54990ce9c4e7a1a/vocab.txt"},
                    {"rel": "1_Pooling/config.json", "url": "https://huggingface.co/abhinand/MedEmbed-large-v0.1/resolve/963121bfb9c625475f65b08fb54990ce9c4e7a1a/1_Pooling/config.json"},
                ],
            },
            "bge-small": {
                "id": "bge-small",
                "name": "bge-small-en-v1.5 (High-Accuracy 384d)",
                "repo_id": "BAAI/bge-small-en-v1.5",
                "dimensions": 384,
                "token_limit": 512,
                "recommended": False,
                "description": "High-accuracy English retrieval embedding model by BAAI with 384 dimensions.",
                "dir_name": "bge-small",
                "estimated_size_mb": 130,
                "files": [
                    {"rel": "model.safetensors", "url": "https://huggingface.co/BAAI/bge-small-en-v1.5/resolve/main/model.safetensors"},
                    {"rel": "config.json", "url": "https://huggingface.co/BAAI/bge-small-en-v1.5/resolve/main/config.json"},
                    {"rel": "config_sentence_transformers.json", "url": "https://huggingface.co/BAAI/bge-small-en-v1.5/resolve/main/config_sentence_transformers.json"},
                    {"rel": "modules.json", "url": "https://huggingface.co/BAAI/bge-small-en-v1.5/resolve/main/modules.json"},
                    {"rel": "special_tokens_map.json", "url": "https://huggingface.co/BAAI/bge-small-en-v1.5/resolve/main/special_tokens_map.json"},
                    {"rel": "tokenizer.json", "url": "https://huggingface.co/BAAI/bge-small-en-v1.5/resolve/main/tokenizer.json"},
                    {"rel": "tokenizer_config.json", "url": "https://huggingface.co/BAAI/bge-small-en-v1.5/resolve/main/tokenizer_config.json"},
                    {"rel": "vocab.txt", "url": "https://huggingface.co/BAAI/bge-small-en-v1.5/resolve/main/vocab.txt"},
                    {"rel": "1_Pooling/config.json", "url": "https://huggingface.co/BAAI/bge-small-en-v1.5/resolve/main/1_Pooling/config.json"},
                ],
            },
        },
    },
    "step2_discovery": {
        "title": "Step 2: Candidate Discovery & Rerankers",
        "description": "Cross-encoder neural rerankers for scoring candidate table-to-text pairs.",
        "default_model": "heuristic",
        "models": {
            "heuristic": {
                "id": "heuristic",
                "name": "Heuristic Lexical + Cosine (Built-in)",
                "recommended": True,
                "description": "High-speed BM25 FTS5 + cosine similarity ranking. No additional neural reranker weights required.",
                "dir_name": "heuristic",
                "estimated_size_mb": 0,
                "builtin": True,
                "files": [],
            },
            "bge-reranker-base": {
                "id": "bge-reranker-base",
                "name": "BAAI/bge-reranker-base (Neural Cross-Encoder)",
                "repo_id": "BAAI/bge-reranker-base",
                "recommended": False,
                "description": "Cross-encoder scoring for table-text relevance ranking.",
                "dir_name": "bge-reranker-base",
                "estimated_size_mb": 1100,
                "files": [
                    {"rel": "model.safetensors", "url": "https://huggingface.co/BAAI/bge-reranker-base/resolve/main/model.safetensors"},
                    {"rel": "config.json", "url": "https://huggingface.co/BAAI/bge-reranker-base/resolve/main/config.json"},
                    {"rel": "special_tokens_map.json", "url": "https://huggingface.co/BAAI/bge-reranker-base/resolve/main/special_tokens_map.json"},
                    {"rel": "tokenizer.json", "url": "https://huggingface.co/BAAI/bge-reranker-base/resolve/main/tokenizer.json"},
                    {"rel": "tokenizer_config.json", "url": "https://huggingface.co/BAAI/bge-reranker-base/resolve/main/tokenizer_config.json"},
                ],
            },
            "gte-reranker-modernbert-base": {
                "id": "gte-reranker-modernbert-base",
                "name": "Alibaba-NLP/gte-reranker-modernbert-base",
                "repo_id": "Alibaba-NLP/gte-reranker-modernbert-base",
                "recommended": False,
                "description": "ModernBERT-based neural cross-encoder for table-text relevance reranking.",
                "dir_name": "gte-reranker",
                "estimated_size_mb": 596,
                "files": [
                    {"rel": "model.safetensors", "url": "https://huggingface.co/Alibaba-NLP/gte-reranker-modernbert-base/resolve/main/model.safetensors"},
                    {"rel": "config.json", "url": "https://huggingface.co/Alibaba-NLP/gte-reranker-modernbert-base/resolve/main/config.json"},
                    {"rel": "special_tokens_map.json", "url": "https://huggingface.co/Alibaba-NLP/gte-reranker-modernbert-base/resolve/main/special_tokens_map.json"},
                    {"rel": "tokenizer.json", "url": "https://huggingface.co/Alibaba-NLP/gte-reranker-modernbert-base/resolve/main/tokenizer.json"},
                    {"rel": "tokenizer_config.json", "url": "https://huggingface.co/Alibaba-NLP/gte-reranker-modernbert-base/resolve/main/tokenizer_config.json"},
                ],
            },
        },
    },
    "step3_cross_attention": {
        "title": "Step 3: Relationship Scoring & Cross-Attention Adapters",
        "description": "Strict tensor contract cross-attention models matching table records to text passages.",
        "default_model": "generic-adapter-v1",
        "models": {
            "generic-adapter-v1": {
                "id": "generic-adapter-v1",
                "name": "Generic SentenceTransformer Adapter (v1 · Text only)",
                "adapter_id": "generic-cross-encoder",
                "dimensions": 768,
                "recommended": True,
                "description": "Normalized cosine scoring with EmbeddingGemma-2 text-only embeddings by default; no trained cross-attention checkpoint.",
                "dir_name": "generic_adapter",
                "encoder_ref": MODEL,
                "versions": [
                    {"id": "v1", "name": "v1 (EmbeddingGemma-2 · 768d)", "default": True},
                ],
            },
            "legacy-loki-clinical": {
                "id": "legacy-loki-clinical",
                "name": "LOKI Clinical Cross-Attention Checkpoint",
                "adapter_id": "legacy-loki",
                "dimensions": 1024,
                "recommended": False,
                "description": "Legacy clinical model trained on MIMIC discharge summaries. Operates with MedEmbed.",
                "dir_name": "loki",
                "encoder_ref": "step1_profiling/medembed",
                "versions": [
                    {"id": "best_model_epoch_13", "name": "Best Model (Epoch 13 · Recommended)", "default": True},
                    {"id": "best_model_epoch_10", "name": "Checkpoint (Epoch 10)", "default": False},
                    {"id": "best_model_epoch_5", "name": "Checkpoint (Epoch 5)", "default": False},
                ],
            },
        },
    },
    "step4_llm": {
        "title": "Step 4: Generative LLMs for Evidence Synthesis",
        "description": "Local Hugging Face models for schema-guided extraction and relationship explanation.",
        "default_model": "Qwen/Qwen2.5-3B-Instruct",
        "models": {
            "Qwen/Qwen2.5-3B-Instruct": {
                "id": "Qwen/Qwen2.5-3B-Instruct",
                "name": "Qwen 2.5 (3B Instruct)",
                "params": "3.09B",
                "vram_estimate": "3.5 GB",
                "recommended": True,
                "description": "State-of-the-art small model with outstanding structured JSON adherence and clinical reasoning.",
            },
            "Qwen/Qwen2.5-1.5B-Instruct": {
                "id": "Qwen/Qwen2.5-1.5B-Instruct",
                "name": "Qwen 2.5 (1.5B Instruct)",
                "params": "1.54B",
                "vram_estimate": "2.0 GB",
                "recommended": False,
                "description": "Ultra-lightweight and fast inference. Minimal VRAM footprint.",
            },
            "microsoft/Phi-3.5-mini-instruct": {
                "id": "microsoft/Phi-3.5-mini-instruct",
                "name": "Phi 3.5 Mini (3.8B Instruct)",
                "params": "3.82B",
                "vram_estimate": "4.5 GB",
                "recommended": True,
                "description": "Microsoft high-capability reasoning model with exceptional instruction adherence.",
            },
            "meta-llama/Llama-3.2-3B-Instruct": {
                "id": "meta-llama/Llama-3.2-3B-Instruct",
                "name": "Llama 3.2 (3B Instruct)",
                "params": "3.21B",
                "vram_estimate": "4.0 GB",
                "recommended": False,
                "description": "Meta 3B edge model. Requires Hugging Face license and HF_TOKEN.",
            },
        },
    },
}


# =====================================================================
# State & Download Tracking
# =====================================================================

_HUB_LOCK = threading.Lock()
_HUB_CANCEL_EVENT = threading.Event()
_HUB_DOWNLOAD_STATE: Dict[str, Any] = {
    "status": "idle",  # "idle" | "downloading" | "completed" | "error"
    "step": "",
    "model_id": "",
    "version": "",
    "message": "",
    "percent": 0,
    "downloaded_mb": 0,
    "total_mb": 0,
    "error": "",
    "started_at": 0,
}


def _get_dir_size(p: Path) -> Tuple[int, str]:
    if not p.exists():
        return 0, ""
    if p.is_file():
        total = p.stat().st_size
    else:
        total = sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
    if total >= 1024**3:
        return total, f"{total / 1024**3:.2f} GB"
    elif total >= 1024**2:
        return total, f"{total / 1024**2:.1f} MB"
    elif total >= 1024:
        return total, f"{total / 1024:.0f} KB"
    return total, f"{total} B" if total > 0 else ""


def _download_file_chunked(url: str, dest: Path, cancel_event: threading.Event, on_bytes=None) -> str:
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    hasher = hashlib.sha256()
    req = urllib.request.Request(url, headers={"User-Agent": "IDUN-ModelHub/1.0"})
    with urllib.request.urlopen(req, timeout=180) as source, part.open("wb") as out:
        while True:
            if cancel_event.is_set():
                out.close()
                if part.exists():
                    part.unlink()
                raise InterruptedError("Download cancelled by user")
            chunk = source.read(1024 * 1024)
            if not chunk:
                break
            out.write(chunk)
            hasher.update(chunk)
            if on_bytes:
                on_bytes(len(chunk))
    part.replace(dest)
    return hasher.hexdigest()


# =====================================================================
# Status & Query APIs
# =====================================================================

def get_step_model_dir(step: str, model_id: str, version: Optional[str] = None) -> Path:
    """Returns directory path for a model within a step."""
    if (step == 'step1_profiling' and model_id == 'embeddinggemma-2') or (step == 'step3_cross_attention' and model_id == 'generic-adapter-v1'):
        return default_directory()
    step_dir = STEP_DIRS.get(step, MODELS_ROOT / step)
    step_catalog = CATALOG.get(step, {}).get("models", {})
    m_info = step_catalog.get(model_id, {})
    dir_name = m_info.get("dir_name", model_id.split("/")[-1])
    target = step_dir / dir_name
    if version and step == "step3_cross_attention":
        target = target / version
    return target


def check_model_downloaded(step: str, model_id: str, version: Optional[str] = None) -> Tuple[bool, int, str, List[str]]:
    """Checks whether all required files for a model are present on disk."""
    if step == "step2_discovery" and model_id == "heuristic":
        return True, 0, "Built-in", []
    
    target_dir = get_step_model_dir(step, model_id, version)
    if not target_dir.exists():
        return False, 0, "", ["Directory missing"]

    step_catalog = CATALOG.get(step, {}).get("models", {})
    m_info = step_catalog.get(model_id, {})

    missing = []
    if model_id in ('embeddinggemma-2', 'generic-adapter-v1'):
        if not (target_dir / 'idun-encoder.json').exists():
            missing.append('Validated text-only encoder receipt missing')
        size_bytes, size_str = _get_dir_size(target_dir)
        return not missing, size_bytes, size_str, missing
    if step == "step1_profiling":
        # Check required SentenceTransformer files
        for req_f in ("model.safetensors", "config.json", "tokenizer.json"):
            if not (target_dir / req_f).exists():
                missing.append(req_f)
    elif step == "step2_discovery":
        for req_f in ("model.safetensors", "config.json"):
            if not (target_dir / req_f).exists():
                missing.append(req_f)
    elif step == "step3_cross_attention":
        if model_id == "generic-adapter-v1":
            # Generic adapter can have verified weights or synthetic fixture
            model_pt = target_dir / "model.pt"
            args_json = target_dir / "args.json"
            if not model_pt.exists() or not args_json.exists():
                missing.append("model.pt")
        elif model_id == "legacy-loki-clinical":
            model_pt = target_dir / "model.pt"
            args_json = target_dir / "args.json"
            if not model_pt.exists():
                missing.append("model.pt")
            if not args_json.exists():
                missing.append("args.json")

    size_bytes, size_str = _get_dir_size(target_dir)
    is_ready = len(missing) == 0 and size_bytes > 0
    return is_ready, size_bytes, size_str, missing


def get_models_hub_status(store=None) -> Dict[str, Any]:
    """Returns complete state of the 4 steps in the Model Hub."""
    result = {}

    # Active lake config resolution
    active_bundle_id = "generic-adapter-v1"
    active_reranker_id = None
    active_encoder = MODEL
    if store is not None:
        try:
            import lake_config
            cfg = lake_config.read_lake_config(store)
            active_bundle_id = cfg.get("bundle_id", "generic-adapter-v1")
            active_reranker_id = cfg.get('reranker_id')
            import model_registry
            active_encoder = model_registry.configured_bundle(cfg)['retrieval_encoder']
        except Exception:
            pass

    for step_key, step_data in CATALOG.items():
        models_out = []
        for m_id, m_spec in step_data["models"].items():
            if step_key == "step3_cross_attention":
                versions_out = []
                for v in m_spec.get("versions", []):
                    ready, sz, sz_str, missing = check_model_downloaded(step_key, m_id, v["id"])
                    versions_out.append({
                        **v,
                        "ready": ready,
                        "size_bytes": sz,
                        "size_str": sz_str,
                        "missing_files": missing,
                    })
                overall_ready = any(v["ready"] for v in versions_out)
                models_out.append({
                    **m_spec,
                    "versions": versions_out,
                    "ready": overall_ready,
                    "is_active": m_id == active_bundle_id,
                })
            elif step_key == "step4_llm":
                # Connect with hf_model_manager
                try:
                    import hf_model_manager
                    cached_map = hf_model_manager.get_cached_models_map()
                    cached = cached_map.get(m_id)
                    loaded_info = hf_model_manager.get_loaded_model()
                    models_out.append({
                        **m_spec,
                        "ready": cached is not None,
                        "size_str": cached["size_str"] if cached else "",
                        "size_bytes": cached["size_on_disk"] if cached else 0,
                        "loaded": bool(loaded_info["loaded"] and loaded_info["repo_id"] == m_id),
                    })
                except Exception:
                    models_out.append({**m_spec, "ready": False, "size_str": "", "size_bytes": 0, "loaded": False})
            else:
                ready, sz, sz_str, missing = check_model_downloaded(step_key, m_id)
                models_out.append({
                    **m_spec,
                    "ready": ready,
                    "size_bytes": sz,
                    "size_str": sz_str,
                    "missing_files": missing,
                    "is_active": m_id == active_reranker_id if step_key == 'step2_discovery' else m_spec.get("repo_id") == active_encoder,
                })

        result[step_key] = {
            "title": step_data["title"],
            "description": step_data["description"],
            "default_model": step_data.get("default_model", ""),
            "models": models_out,
        }

    return {
        "hub_root": str(MODELS_ROOT),
        "steps": result,
        "download_status": get_hub_download_status(),
    }


def get_hub_download_status() -> Dict[str, Any]:
    with _HUB_LOCK:
        return dict(_HUB_DOWNLOAD_STATE)


# =====================================================================
# Download Engine
# =====================================================================

def start_hub_download(step: str, model_id: str, version: Optional[str] = None, store=None) -> Dict[str, Any]:
    """Starts background download of a model within a step."""
    if step not in CATALOG:
        raise ValueError(f"Unknown step: {step}")
    step_models = CATALOG[step]["models"]
    if model_id not in step_models:
        raise ValueError(f"Unknown model {model_id} for {step}")

    m_info = step_models[model_id]
    if m_info.get("builtin"):
        return {"status": "completed", "message": f"{m_info['name']} is built-in and requires no download."}

    target_dir = get_step_model_dir(step, model_id, version)
    target_dir.mkdir(parents=True, exist_ok=True)

    with _HUB_LOCK:
        if _HUB_DOWNLOAD_STATE["status"] == "downloading":
            if _HUB_DOWNLOAD_STATE["model_id"] == model_id and _HUB_DOWNLOAD_STATE["version"] == (version or ""):
                return {"status": "downloading", "model_id": model_id, "already_running": True}
            raise ValueError(f"Another download ({_HUB_DOWNLOAD_STATE['model_id']}) is currently active")

        _HUB_CANCEL_EVENT.clear()
        total_mb = m_info.get("estimated_size_mb", 500)
        _HUB_DOWNLOAD_STATE.update({
            "status": "downloading",
            "step": step,
            "model_id": model_id,
            "version": version or "",
            "message": f"Starting download for {m_info['name']}…",
            "percent": 5,
            "downloaded_mb": 0,
            "total_mb": total_mb,
            "error": "",
            "started_at": int(time.time()),
        })

    def _worker():
        try:
            total_bytes = 0

            def _on_chunk(n):
                nonlocal total_bytes
                total_bytes += n
                mb = total_bytes // (1024 * 1024)
                with _HUB_LOCK:
                    _HUB_DOWNLOAD_STATE["downloaded_mb"] = mb
                    target = _HUB_DOWNLOAD_STATE["total_mb"] or 500
                    _HUB_DOWNLOAD_STATE["percent"] = min(98, max(5, int((mb / target) * 92) + 5))
                    _HUB_DOWNLOAD_STATE["message"] = f"Downloading files ({mb} MB downloaded)…"

            if model_id in ('embeddinggemma-2', 'generic-adapter-v1'):
                if store is None:
                    raise ValueError('Prepare the encoder from Settings in a selected lake.')
                from custom_encoder import prepare
                prepare(store, {'model': MODEL, 'revision': REVISION})
            elif step == "step1_profiling" or step == "step2_discovery":
                files = m_info.get("files", [])
                for idx, fspec in enumerate(files):
                    rel = fspec["rel"]
                    url = fspec["url"]
                    dest = target_dir / rel
                    with _HUB_LOCK:
                        _HUB_DOWNLOAD_STATE["message"] = f"Downloading ({idx + 1}/{len(files)}): {rel}…"
                    _download_file_chunked(url, dest, _HUB_CANCEL_EVENT, _on_chunk)

            elif step == "step3_cross_attention":
                if model_id == "legacy-loki-clinical":
                    v = version or "best_model_epoch_13"
                    rev = "2e2fc2f5b8f5bb5c87da69cf2c15a5d1af04c13f"
                    base = f"https://huggingface.co/shaoncsecu/LOKI/resolve/{rev}/Exp-1/Input_Models/LOKI/"
                    ckpt_rel = f"abhinand/MedEmbed-large-v0.1/{v}/model.pt"

                    with _HUB_LOCK:
                        _HUB_DOWNLOAD_STATE["message"] = "Downloading model args configuration…"
                    args_sha = _download_file_chunked(base + "args.json", target_dir / "args.json", _HUB_CANCEL_EVENT, _on_chunk)

                    with _HUB_LOCK:
                        _HUB_DOWNLOAD_STATE["message"] = f"Downloading {v} weights (1.34 GB)…"
                    model_sha = _download_file_chunked(base + ckpt_rel, target_dir / "model.pt", _HUB_CANCEL_EVENT, _on_chunk)

                    manifest = {
                        "repository": "shaoncsecu/LOKI",
                        "revision": rev,
                        "checkpoint": v,
                        "sha256": model_sha,
                        "args_sha256": args_sha,
                    }
                    (target_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

            with _HUB_LOCK:
                _HUB_DOWNLOAD_STATE.update({
                    "status": "completed",
                    "percent": 100,
                    "message": f"Successfully downloaded and verified {m_info['name']}.",
                    "error": "",
                })
        except InterruptedError:
            with _HUB_LOCK:
                _HUB_DOWNLOAD_STATE.update({
                    "status": "idle",
                    "percent": 0,
                    "message": "Download was cancelled.",
                    "error": "",
                })
        except Exception as e:
            with _HUB_LOCK:
                _HUB_DOWNLOAD_STATE.update({
                    "status": "error",
                    "percent": 0,
                    "message": f"Download failed: {e}",
                    "error": str(e),
                })

    thread = threading.Thread(target=_worker, daemon=True)
    thread.start()
    return {"status": "downloading", "step": step, "model_id": model_id, "version": version or ""}


def cancel_hub_download() -> Dict[str, Any]:
    with _HUB_LOCK:
        if _HUB_DOWNLOAD_STATE["status"] == "downloading":
            _HUB_CANCEL_EVENT.set()
            _HUB_DOWNLOAD_STATE["message"] = "Cancelling download…"
            return {"cancelled": True}
        return {"cancelled": False}


def delete_hub_model(step: str, model_id: str, version: Optional[str] = None) -> Dict[str, Any]:
    """Safely removes a model or version from disk to free storage."""
    target_dir = get_step_model_dir(step, model_id, version)
    if not target_dir.exists():
        return {"status": "not_found", "message": "Model files not found on disk."}

    shutil.rmtree(target_dir, ignore_errors=True)
    return {"status": "deleted", "message": f"Deleted {model_id} from {step}."}
