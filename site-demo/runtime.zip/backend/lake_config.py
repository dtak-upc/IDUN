"""Lake-scoped execution configuration and immutable job snapshots (Stage 10.DA-02).

Manages reusable model and prompt catalogs, lake-scoped selections/overrides,
optimistic concurrency, impact previews, and immutable execution snapshots for queued jobs.
"""
from schema_policy import effective_schema
import copy
import hashlib
import json
import time
import uuid
from encoder_defaults import MODEL as DEFAULT_ENCODER
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple

CONFIG_VERSION = "lake-config-v1"

# =====================================================================
# Catalogs
# =====================================================================

DEFAULT_BUNDLES = {
    "legacy-loki-clinical": {
        "bundle_id": "legacy-loki-clinical",
        "name": "LOKI Clinical Cross-Attention Checkpoint (Experiment-2)",
        "adapter_id": "legacy-loki",
        "retrieval_encoder": "abhinand/MedEmbed-large-v0.1",
        "scoring_model": "shaoncsecu/LOKI/best_model_epoch_13",
        "reranker": "Alibaba-NLP/gte-reranker-modernbert-base",
        "dimensions": 1024,
        "is_default": False,
    },
    "generic-adapter-v1": {
        "bundle_id": "generic-adapter-v1",
        "name": "Generic Domain-Agnostic Adapter",
        "description": "Domain-neutral pipeline adapter compatible with arbitrary table/document structures.",
        "adapter_id": "generic-v1",
        "retrieval_encoder": DEFAULT_ENCODER,
        "scoring_model": "normalized-cosine",
        "reranker": "Alibaba-NLP/gte-reranker-modernbert-base",
        "dimensions": 768,
        "is_default": True,
    },
}

DEFAULT_PROMPTS = {
    "generic-evidence-v1": {
        "prompt_id": "generic-evidence-v1",
        "name": "Generic Evidence Grounding",
        "description": "Domain-neutral relationship extraction from projected records and narrative evidence.",
        "mode": "open",
        "labels": ["NEGATIVE", "UNRESOLVED"],
        "definitions": {
            "NEGATIVE": "The evidence explicitly rejects or indicates no relationship between the records.",
            "UNRESOLVED": "Insufficient evidence to determine a relationship between the records.",
        },
        "is_default": True,
    },
    "clinical-preset-v1": {
        "prompt_id": "clinical-preset-v1",
        "name": "Clinical Diagnosis–Medication Preset",
        "description": "Preserves original clinical definitions and specific medical relationship types.",
        "mode": "strict",
        "labels": ["TREATS", "ADVERSE_EFFECT", "DISCONTINUED", "CONTRAINDICATED", "NEGATIVE", "UNRESOLVED"],
        "definitions": {
            "TREATS": "Medication used, prescribed, started or continued to treat/manage this diagnosis.",
            "ADVERSE_EFFECT": "Medication caused, worsened or is suspected to cause this diagnosis/symptom.",
            "DISCONTINUED": "Medication stopped, held, avoided or switched away from.",
            "CONTRAINDICATED": "Medication unsafe/inappropriate because of this diagnosis/context.",
            "NEGATIVE": "Evidence indicates the medication is for a different condition or rejects this relationship.",
            "UNRESOLVED": "Insufficient evidence to decide.",
        },
        "is_default": False,
    },
    "open-discovery-v1": {
        "prompt_id": "open-discovery-v1",
        "name": "Open-Ended Relationship Discovery",
        "description": "Free-form relationship extraction where the model derives canonical UPPER_SNAKE_CASE relationship labels.",
        "mode": "open",
        "labels": ["NEGATIVE", "UNRESOLVED"],
        "definitions": {
            "NEGATIVE": "The evidence explicitly rejects or indicates unrelated entities.",
            "UNRESOLVED": "Insufficient evidence to determine a relationship.",
        },
        "is_default": False,
    },
}

DEFAULT_CANDIDATE_POLICY = {
    "policy_id": "candidate-default-v1",
    "max_candidates": 100,
    "allow_same_table": False,
    "context_window_tokens": 300,
    "context_window_chars": 1200,
    "profiling_top_k": 0,
    "discovery_row_limit": None,
}

DEFAULT_PROJECTION_POLICY = {
    "policy_id": "projection-default-v1",
    "exclude_identifiers": ["subject_id", "hadm_id"],
    "null_tokens": ["__DOC2DB_NULL__", "NULL", "null", ""],
    "mask_identifier_values": True,
}

DEFAULT_CONTEXT_CONFIG = {
    "mode": "none",  # "none" | "sampled_context" | "user_examples"
    "sampled_context": None,
    "examples": [],
}


def catalogs() -> Dict[str, Any]:
    """Returns installation-wide reusable catalogs."""
    return {
        "bundles": list(DEFAULT_BUNDLES.values()),
        "prompts": list(DEFAULT_PROMPTS.values()),
        "default_bundle_id": "generic-adapter-v1",
        "default_prompt_id": "generic-evidence-v1",
        "candidate_policy": dict(DEFAULT_CANDIDATE_POLICY),
        "projection_policy": dict(DEFAULT_PROJECTION_POLICY),
        "context_config": copy.deepcopy(DEFAULT_CONTEXT_CONFIG),
    }


# =====================================================================
# Lake Configuration Reading and Writing
# =====================================================================

def default_lake_config() -> Dict[str, Any]:
    """Returns default configuration for a new lake."""
    return {
        "version": CONFIG_VERSION,
        "revision": uuid.uuid4().hex,
        "updated": time.time(),
        "bundle_id": "generic-adapter-v1",
        "bundle_version": None,
        "prompt_id": "generic-evidence-v1",
        "schema_config": {
            "prompt_id": "generic-evidence-v1",
            "mode": DEFAULT_PROMPTS["generic-evidence-v1"]["mode"],
            "labels": list(DEFAULT_PROMPTS["generic-evidence-v1"]["labels"]),
            "definitions": dict(DEFAULT_PROMPTS["generic-evidence-v1"]["definitions"]),
        },
        "candidate_policy": dict(DEFAULT_CANDIDATE_POLICY),
        "projection_policy": dict(DEFAULT_PROJECTION_POLICY),
        "context_config": copy.deepcopy(DEFAULT_CONTEXT_CONFIG),
        "llm_overrides": {},
    }


def lake_config_path(store: Any) -> Path:
    """Returns path to the lake's configuration file."""
    return store.root / "lake_config.json"


def read_lake_config(store: Any) -> Dict[str, Any]:
    """Reads lake-scoped configuration, initializing with safe generic defaults if not present."""
    path = lake_config_path(store)
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("version") == CONFIG_VERSION:
                data.setdefault("context_config", copy.deepcopy(DEFAULT_CONTEXT_CONFIG))
                if isinstance(data.get("schema_config"), dict):
                    data["schema_config"] = effective_schema(data["schema_config"], data.get("prompt_id"))
                return data
        except Exception:
            pass
    # Cold-start or legacy lake: initialize default config and persist it
    cfg = default_lake_config()
    try:
        temp_path = store.root / "lake_config.json.tmp"
        temp_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        temp_path.replace(path)
    except Exception:
        pass
    return cfg


def save_lake_config(
    store: Any,
    data: Dict[str, Any],
    expected_revision: Optional[str] = None
) -> Dict[str, Any]:
    """Atomically validates and saves lake-scoped configuration.

    Enforces optimistic concurrency checking against `expected_revision`.
    Rejects changes if active jobs are running on this lake.
    """
    with store.lock:
        if any(getattr(store, k, False) for k in ("profile_active", "discovery_active", "integration_active", "storage_active")):
            raise ValueError("Cannot modify lake configuration while jobs are active on this lake")

        current = read_lake_config(store)
        if expected_revision is not None and current.get("revision") != expected_revision:
            raise ValueError("Lake configuration changed concurrently. Refresh and review changes before saving.")

        # Validate bundle_id
        bundle_id = data.get("bundle_id", current["bundle_id"])
        if bundle_id not in DEFAULT_BUNDLES:
            raise ValueError(f"Unknown model bundle: {bundle_id}")

        # Validate prompt_id
        prompt_id = data.get("prompt_id", current["prompt_id"])
        if prompt_id not in DEFAULT_PROMPTS:
            raise ValueError(f"Unknown prompt template: {prompt_id}")

        # Validate schema_config if provided
        schema_config = data.get("schema_config", current.get("schema_config"))
        if "prompt_id" in data and prompt_id != current["prompt_id"] and "schema_config" not in data:
            preset = DEFAULT_PROMPTS[prompt_id]
            schema_config = {"prompt_id": prompt_id, "mode": preset["mode"], "labels": list(preset["labels"]), "definitions": dict(preset["definitions"])}
        if schema_config:
            if not isinstance(schema_config, dict) or "mode" not in schema_config or "labels" not in schema_config:
                raise ValueError("Invalid schema_config shape")
            if schema_config["mode"] not in ("strict", "hybrid", "open"):
                raise ValueError("Schema mode must be strict, hybrid, or open")
            labels = list(dict.fromkeys(schema_config.get("labels", []) + ["NEGATIVE", "UNRESOLVED"]))
            schema_config = {
                "prompt_id": prompt_id,
                "mode": schema_config["mode"],
                "labels": labels,
                "definitions": dict(schema_config.get("definitions", {})),
            }

        if schema_config: schema_config = effective_schema(schema_config, prompt_id)

        candidate_policy = {**current["candidate_policy"], **data.get("candidate_policy", {})}
        if "context_window_tokens" in candidate_policy:
            try:
                val = int(candidate_policy["context_window_tokens"])
                if val < 20 or val > 4096:
                    raise ValueError("context_window_tokens must be between 20 and 4096")
                candidate_policy["context_window_tokens"] = val
                candidate_policy["context_window_chars"] = val * 4
            except (TypeError, ValueError):
                raise ValueError("context_window_tokens must be an integer between 20 and 4096")
        elif "context_window_chars" in candidate_policy:
            try:
                chars = int(candidate_policy["context_window_chars"])
                candidate_policy["context_window_tokens"] = max(1, chars // 4)
            except (TypeError, ValueError):
                candidate_policy["context_window_tokens"] = 300
        else:
            candidate_policy["context_window_tokens"] = 300
            candidate_policy["context_window_chars"] = 1200

        if "profiling_top_k" in candidate_policy:
            try:
                val = int(candidate_policy["profiling_top_k"])
                if val < 0 or val > 50:
                    raise ValueError("profiling_top_k must be between 0 (auto) and 50")
                candidate_policy["profiling_top_k"] = val
            except (TypeError, ValueError):
                raise ValueError("profiling_top_k must be an integer between 0 and 50")
        else:
            candidate_policy["profiling_top_k"] = 0

        if "max_candidates" in candidate_policy:
            try:
                mc = int(candidate_policy["max_candidates"])
                if mc < 5 or mc > 5000:
                    raise ValueError("max_candidates must be between 5 and 5000")
                candidate_policy["max_candidates"] = mc
            except (TypeError, ValueError):
                raise ValueError("max_candidates must be an integer between 5 and 5000")
        else:
            candidate_policy["max_candidates"] = 100

        if "discovery_row_limit" in candidate_policy and candidate_policy["discovery_row_limit"] is not None:
            try:
                drl = int(candidate_policy["discovery_row_limit"])
                if drl < 10 or drl > 1000000:
                    raise ValueError("discovery_row_limit must be between 10 and 1000000 (or null)")
                candidate_policy["discovery_row_limit"] = drl
            except (TypeError, ValueError):
                raise ValueError("discovery_row_limit must be an integer between 10 and 1000000 (or null)")
        elif "discovery_row_limit" not in candidate_policy:
            candidate_policy["discovery_row_limit"] = None

        projection_policy = {**current["projection_policy"], **data.get("projection_policy", {})}
        llm_overrides = {**current.get("llm_overrides", {}), **data.get("llm_overrides", {})}

        # Validate context_config if provided
        context_config = copy.deepcopy(current.get("context_config", DEFAULT_CONTEXT_CONFIG))
        if "context_config" in data and isinstance(data["context_config"], dict):
            new_ctx = data["context_config"]
            mode = new_ctx.get("mode", context_config.get("mode", "none"))
            if mode not in ("none", "sampled_context", "user_examples"):
                raise ValueError("Context mode must be none, sampled_context, or user_examples")
            context_config["mode"] = mode
            if "sampled_context" in new_ctx:
                context_config["sampled_context"] = new_ctx["sampled_context"]
            if "examples" in new_ctx and isinstance(new_ctx["examples"], list):
                from context_service import validate_example
                validated_examples = []
                for ex in new_ctx["examples"]:
                    val_ex = validate_example(ex, store=store, projection_policy=projection_policy)
                    validated_examples.append(val_ex)
                context_config["examples"] = validated_examples

        bundle_version = data.get("bundle_version", current.get("bundle_version"))
        from custom_encoder import validate
        generic_encoder = validate(data.get('generic_encoder', current.get('generic_encoder')))
        generic_dimensions = data.get('generic_dimensions', current.get('generic_dimensions'))
        from model_registry import configured_bundle
        configured_bundle({'bundle_id': bundle_id, 'generic_encoder': generic_encoder, 'generic_dimensions': generic_dimensions})
        from reranker_config import validate as validate_reranker
        reranker_id = validate_reranker(data.get('reranker_id', current.get('reranker_id')))

        new_config = {
            "version": CONFIG_VERSION,
            "revision": uuid.uuid4().hex,
            "updated": time.time(),
            "bundle_id": bundle_id,
            "bundle_version": bundle_version,
            "generic_encoder": generic_encoder,
            "generic_dimensions": generic_dimensions,
            "reranker_id": reranker_id,
            "prompt_id": prompt_id,
            "schema_config": schema_config,
            "candidate_policy": candidate_policy,
            "projection_policy": projection_policy,
            "context_config": context_config,
            "llm_overrides": llm_overrides,
        }

        # Configuration changes invalidate active results, never delete saved runs.
        preview = config_impact_preview(store, data)
        invalidated = preview.get("invalidated_stages", [])
        if data.get("reset") or invalidated:
            with store.db() as db:
                tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if (data.get('reset') or 'indexing' in invalidated) and 'lake_profile' in tables:
                    db.execute("UPDATE lake_profile SET signature='configuration-changed'")
                if (data.get('reset') or 'indexing' in invalidated or 'discovery' in invalidated) and 'discovery_report' in tables:
                    db.execute("UPDATE discovery_report SET signature='configuration-changed'")
                if 'semantic_checkpoint' in tables:
                    db.execute("UPDATE semantic_checkpoint SET state='invalidated'")
            if hasattr(store, 'discovery_input_signature'):
                del store.discovery_input_signature

        temp_path = store.root / "lake_config.json.tmp"
        temp_path.write_text(json.dumps(new_config, indent=2), encoding="utf-8")
        temp_path.replace(lake_config_path(store))

        try:
            with store.db() as db:
                db.execute('CREATE TABLE IF NOT EXISTS integration_schema(id INTEGER PRIMARY KEY,data TEXT)')
                db.execute('INSERT OR REPLACE INTO integration_schema VALUES(1,?)', (json.dumps(schema_config),))
        except Exception:
            pass

        return new_config


# =====================================================================
# Impact Preview
# =====================================================================

def config_impact_preview(store: Any, proposed_data: Dict[str, Any]) -> Dict[str, Any]:
    """Evaluates what lake data, indices, or integration runs will be affected by a config change."""
    current = read_lake_config(store)
    impacts = []
    rebuild_stages = []
    if proposed_data.get('generic_encoder', current.get('generic_encoder')) != current.get('generic_encoder'):
        rebuild_stages.extend(['indexing', 'discovery', 'integration'])
        impacts.append('Generic encoder changed: re-profile and rebuild Discovery before starting new Integration runs. Saved runs retain their results.')
    if proposed_data.get('generic_dimensions', current.get('generic_dimensions')) != current.get('generic_dimensions'):
        rebuild_stages.extend(['indexing', 'discovery', 'integration'])
        impacts.append('Embedding dimensions changed: rebuild profiling and Discovery. Saved Integration runs remain available.')
    if proposed_data.get('reranker_id', current.get('reranker_id')) != current.get('reranker_id'):
        rebuild_stages.append('integration')
        impacts.append('Reranker changed: new Integration ranking uses this model. Profiling, Discovery scores, and saved runs are preserved.')

    # 1. Bundle change
    new_bundle = proposed_data.get("bundle_id")
    if new_bundle and new_bundle != current["bundle_id"]:
        cur_b = DEFAULT_BUNDLES.get(current["bundle_id"], {})
        new_b = DEFAULT_BUNDLES.get(new_bundle, {})
        if cur_b.get("retrieval_encoder") != new_b.get("retrieval_encoder"):
            rebuild_stages.extend(["indexing", "discovery", "integration"])
            impacts.append("Retrieval encoder changed: all lake vectors and discovery links must be rebuilt.")
        elif cur_b.get("scoring_model") != new_b.get("scoring_model"):
            rebuild_stages.extend(["discovery", "integration"])
            impacts.append("Scoring model changed: discovery links and integration runs must be rebuilt.")
        elif cur_b.get("reranker") != new_b.get("reranker"):
            rebuild_stages.append("integration")
            impacts.append("Reranker changed: candidate ranking and integration runs will be invalidated.")

    # 2. Projection / Null policy change
    new_proj = proposed_data.get("projection_policy")
    if new_proj:
        merged_proj = {**current["projection_policy"], **new_proj}
        if merged_proj != current["projection_policy"]:
            rebuild_stages.extend(["indexing", "discovery", "integration"])
            impacts.append("Projection or null policy changed: source profiles, indices, and all downstream stages must be rebuilt.")

    # 3. Candidate policy change
    new_cand = proposed_data.get("candidate_policy")
    if new_cand:
        merged_cand = {**current["candidate_policy"], **new_cand}
        if merged_cand != current["candidate_policy"]:
            rebuild_stages.append("integration")
            impacts.append("Candidate policy changed: candidate pair pool must be re-evaluated.")
            if merged_cand.get("profiling_top_k") != current.get("candidate_policy", {}).get("profiling_top_k"):
                rebuild_stages.append("indexing")
                impacts.append("Profiling Top-K changed: lake profiling must be re-run to update table-document candidate neighborhoods.")

    # 4. Schema / Prompt change
    new_schema = proposed_data.get("schema_config")
    new_prompt = proposed_data.get("prompt_id")
    if (new_prompt and new_prompt != current["prompt_id"]) or (new_schema and new_schema != current["schema_config"]):
        impacts.append("Schema or prompt preset changed: subsequent integration runs will use new predicates; existing runs retain their historical snapshots.")

    # 5. Context / Example change
    new_ctx = proposed_data.get("context_config")
    if new_ctx and new_ctx != current.get("context_config"):
        impacts.append("Context/example configuration changed: subsequent integration runs will use the updated prompt context; existing runs retain their historical snapshots.")

    return {
        "has_impact": len(impacts) > 0,
        "impacts": impacts,
        "invalidated_stages": sorted(set(rebuild_stages)),
        "current_revision": current.get("revision"),
    }


# =====================================================================
# Immutable Execution Snapshot
# =====================================================================

def resolve_lake_snapshot(store: Any) -> Dict[str, Any]:
    """Resolves installation defaults + lake-scoped overrides into an immutable execution snapshot.

    No private credentials, API keys, or machine-specific file paths enter the snapshot.
    """
    import settings
    global_settings = settings.read(store)
    lake_cfg = read_lake_config(store)

    bundle = copy.deepcopy(DEFAULT_BUNDLES.get(lake_cfg['bundle_id'], DEFAULT_BUNDLES['generic-adapter-v1']))
    if lake_cfg['bundle_id'] == 'generic-adapter-v1':
        from model_registry import configured_bundle
        effective = configured_bundle(lake_cfg)
        bundle.update({k: effective[k] for k in ('retrieval_encoder', 'dimensions', 'encoder_revision', 'token_limit')})
        from encoder_defaults import options
        bundle.update(options(effective['retrieval_encoder']))
    if lake_cfg.get('reranker_id'):
        from reranker_config import MODELS
        bundle['reranker'] = MODELS[lake_cfg['reranker_id']]
    prompt = DEFAULT_PROMPTS.get(lake_cfg["prompt_id"], DEFAULT_PROMPTS["generic-evidence-v1"])
    schema = lake_cfg.get("schema_config") or {
        "mode": prompt["mode"],
        "labels": list(prompt["labels"]),
        "definitions": dict(prompt["definitions"]),
    }

    # Merge LLM settings: global settings plus any lake overrides
    llm_merged = copy.deepcopy(global_settings["llm"])
    if "llm_overrides" in lake_cfg:
        for k, v in lake_cfg["llm_overrides"].items():
            if v is not None and k in llm_merged and k != "key_env":
                llm_merged[k] = v

    # Omit API secrets / private credentials from snapshot
    safe_llm = {
        "provider": llm_merged.get("provider"),
        "base_url": llm_merged.get("base_url"),
        "model": llm_merged.get("model"),
        "temperature": llm_merged.get("temperature"),
        "top_p": llm_merged.get("top_p"),
        "max_output_tokens": llm_merged.get("max_output_tokens"),
        "timeout_seconds": llm_merged.get("timeout_seconds"),
    }

    # Context configuration
    raw_ctx = lake_cfg.get("context_config", DEFAULT_CONTEXT_CONFIG)
    from context_service import render_effective_context
    effective_ctx_text = render_effective_context(raw_ctx)
    safe_ctx = {
        "mode": raw_ctx.get("mode", "none"),
        "has_effective_context": bool(effective_ctx_text),
        "effective_context_length": len(effective_ctx_text),
    }

    resolved = {
        "snapshot_version": "1.0",
        "lake_id": getattr(store, "lake_id", "default"),
        "created": time.time(),
        "bundle": {
            "bundle_id": bundle["bundle_id"],
            "adapter_id": bundle["adapter_id"],
            "retrieval_encoder": bundle["retrieval_encoder"],
            "scoring_model": bundle["scoring_model"],
            "reranker": bundle["reranker"],
            "dimensions": bundle["dimensions"],
        },
        "prompt": {
            "prompt_id": prompt["prompt_id"],
            "mode": schema.get("mode", "strict"),
            "labels": list(schema.get("labels", [])),
            "definitions": dict(schema.get("definitions", {})),
        },
        "candidate_policy": copy.deepcopy(lake_cfg["candidate_policy"]),
        "projection_policy": copy.deepcopy(lake_cfg["projection_policy"]),
        "context_config": safe_ctx,
        "llm": safe_llm,
    }

    if bundle.get('encoder_revision'):
        resolved['bundle']['encoder_revision'] = bundle['encoder_revision']
        resolved['bundle']['token_limit'] = bundle['token_limit']
        for name in ('config_kwargs', 'prompt'):
            if name in bundle:
                resolved['bundle'][name] = copy.deepcopy(bundle[name])
    # Deterministic fingerprint of the configuration payload
    payload_to_hash = {
        "bundle": resolved["bundle"],
        "prompt": resolved["prompt"],
        "candidate_policy": resolved["candidate_policy"],
        "projection_policy": resolved["projection_policy"],
        "context_config": resolved["context_config"],
        "llm": resolved["llm"],
    }
    fingerprint = hashlib.sha256(json.dumps(payload_to_hash, sort_keys=True).encode("utf-8")).hexdigest()
    resolved["snapshot_id"] = fingerprint
    return resolved


def snapshot_policy_key(snapshot: Dict[str, Any]) -> str:
    """Computes execution policy key for cache matching and extension compatibility."""
    key_payload = [
        snapshot.get("bundle", {}).get("bundle_id"),
        snapshot.get("bundle", {}).get("adapter_id"),
        snapshot.get("prompt", {}).get("prompt_id"),
        snapshot.get("prompt", {}).get("mode"),
        sorted(snapshot.get("prompt", {}).get("labels", [])),
        snapshot.get("candidate_policy"),
        snapshot.get("projection_policy"),
        snapshot.get("context_config", {}).get("mode"),
        snapshot.get("context_config", {}).get("has_effective_context"),
        snapshot.get("llm", {}).get("provider"),
        snapshot.get("llm", {}).get("base_url"),
        snapshot.get("llm", {}).get("model"),
        snapshot.get("llm", {}).get("temperature"),
        snapshot.get("llm", {}).get("top_p"),
    ]
    return hashlib.sha256(json.dumps(key_payload, sort_keys=True).encode("utf-8")).hexdigest()
