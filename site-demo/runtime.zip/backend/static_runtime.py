"""Browser-only adapter for the ordinary saved-result API. No inference or sockets.

Executed inside a dedicated Pyodide worker. All writes affect its private copy.
The HTTP handler is reused as a dispatcher, without creating an HTTP server.
"""
import io, json, sqlite3, threading, base64, re
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlparse
import server, profiling, discovery

stores={}

class BrowserStore(server.Store):
    def __init__(self, root, lake_id):
        # No executor or model runtime: synchronous result operations only.
        self.root=Path(root);self.dbpath=self.root/'catalog.sqlite3';self.lake_id=lake_id
        self.settings_root=self.root;self.lock=threading.RLock()
        self.dirty=set()
        self.root.mkdir(parents=True,exist_ok=True)
    @contextmanager
    def db(self):
        with self.lock:
            db=sqlite3.connect(self.dbpath,timeout=30);db.row_factory=sqlite3.Row
            touched=set()
            def authorize(action,table,*args):
                if action in (sqlite3.SQLITE_INSERT,sqlite3.SQLITE_UPDATE,sqlite3.SQLITE_DELETE) and table and not table.startswith('sqlite_'):touched.add(table)
                return sqlite3.SQLITE_OK
            db.set_authorizer(authorize)
            try:
                with db:yield db
                self.dirty.update(touched)
            finally:db.close()

def patches(slug):
    store=stores[slug];result={}
    with store.db() as db:
        for name in list(store.dirty):
            schema=db.execute('SELECT sql FROM sqlite_master WHERE type=? AND name=?',('table',name)).fetchone()
            if not schema:continue
            columns=[c[1] for c in db.execute('PRAGMA table_info("'+name+'")')]
            result[name]={'sql':schema[0],'columns':columns,'rows':[
                [{'binary':base64.b64encode(v).decode()} if isinstance(v,bytes) else v for v in r]
                for r in db.execute('SELECT * FROM "'+name+'"')]}
    store.dirty.clear();return result

def restore(slug,patches):
    with stores[slug].db() as db:
        for name,p in patches.items():
            if not re.fullmatch(r'[a-zA-Z0-9_]+',name):raise ValueError('Invalid saved workspace table')
            if not db.execute('SELECT 1 FROM sqlite_master WHERE type=? AND name=?',('table',name)).fetchone():db.execute(p['sql'])
            db.execute('DELETE FROM "'+name+'"')
            db.executemany('INSERT INTO "'+name+'" VALUES('+','.join('?' for _ in p['columns'])+')',
                [[base64.b64decode(v['binary']) if isinstance(v,dict) and set(v)=={'binary'} else v for v in r] for r in p['rows']])
    stores[slug].dirty.clear()

def install(slug, metadata):
    store=BrowserStore('/workspaces/'+slug,metadata['lake_id']);stores[slug]=store
    for name,value in metadata['files'].items():
        (store.root/name).write_text(json.dumps(value),encoding='utf-8')
    with store.db() as db:
        db.execute('PRAGMA journal_mode=DELETE')
    return True

# Saved scores/profiles do not become stale because a browser has no model files.
# Input mutation and model computations are blocked below.
def profile_signature(store, policy=None):
    with store.db() as db:
        row=db.execute('SELECT signature FROM lake_profile WHERE id=1').fetchone()
        return row[0] if row else ''
def discovery_signature(store, scope_id=None):
    with store.db() as db:
        row=db.execute('SELECT signature FROM discovery_report WHERE id=1').fetchone()
        return row[0] if row else ''
profiling.signature=profile_signature
discovery.current_signature=discovery_signature

class Dispatcher(server.Handler):
    def allowed(self):return True
    def body(self,required=True):return self.payload
    def reply(self,code,data):self.code=code;self.result=data
    def send_response(self,code):self.code=code
    def send_header(self,key,value):self.response_headers[key]=value
    def end_headers(self):pass

INFERENCE={'suggest','suggest-alignments','concepts','schema-suggest','probe','summarize',
           'execute','feedback-pass','document-pass','relationship-probe','relationship-suggestions',
           'prepare-encoder','download','runtime-probe','llm-test','refine','start'}
POST_ROOTS={'knowledge','integration','augmentation','profile','discovery','context','config','thor'}

def dispatch(slug, path, method, body):
    store=stores[slug];parts=urlparse(path).path.strip('/').split('/')
    if parts[0]=='settings':
        if method!='GET':raise ValueError('Model and server settings require an inference backend.')
        if parts==['settings']:
            import settings
            return {'code':200,'data':{'settings':settings.defaults(),'active_api_python':'Browser workspace',
                'next_api_python':'','api_restart_required':False,'restart_available':False,
                'environments':[],'overrides':{},'key_available':False,'runtime':{'device':'browser','python':'Pyodide','vram_gib':0},'storage':'Private browser workspace'}}
        if parts==['settings','hf','loaded']:return {'code':200,'data':{'loaded':False,'repo_id':'','vram_mb':0}}
        if parts[-1] in ('hub','models','bundles','status'):
            return {'code':200,'data':{'models':[],'bundles':[],'loaded':None,'status':'idle'}}
    if parts in (['augmentation','status'],['inference','readiness']):
        return {'code':200,'data':{'ready':False,'sources':[],'blockers':[],
            'llm':{'active':False,'provider':'disabled','model':''},'thor':{'ready':False,'packages':{}}}}
    if method!='GET':
        if parts[0] not in POST_ROOTS or parts[-1] in INFERENCE or len(parts)==1 and parts[0] in ('integration','discovery'):
            raise ValueError('New model inference is unavailable here. You can explore, query and edit the saved results.')
        if parts[0]=='profile' and parts[1:] not in (['graph','query'],['graph','draft']):
            raise ValueError('Re-profiling requires an inference backend.')
        if parts==['discovery','filter']:
            raise ValueError('Preparing a new evidence view requires contextual model vectors. Saved evidence remains available.')
    request=object.__new__(Dispatcher)
    request.server=SimpleNamespace(store=store);request.lake_store=store
    request.path='/api/v1'+path;request.payload=body;request.code=200;request.result=None
    request.response_headers={};request.wfile=io.BytesIO()
    request.route(method)
    if request.result is None:
        request.result={'download':request.wfile.getvalue().decode('utf-8'),
            'content_type':request.response_headers.get('Content-Type','application/octet-stream')}
    return {'code':request.code,'data':request.result}
