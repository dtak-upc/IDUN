"""Explicit calendar-day validity reviews, pinned to assertion contributions."""
import datetime
import json
import re
import time
import knowledge as kg
import knowledge_auto as auto


def setup(store):
    auto.setup(store)
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_validity_events(id INTEGER PRIMARY KEY AUTOINCREMENT,run TEXT,revision TEXT,assertion TEXT,recorded REAL,data TEXT)')
        db.execute('CREATE INDEX IF NOT EXISTS kg_validity_lookup ON kg_validity_events(run,revision,assertion,id)')


def interval(value):
    if not isinstance(value,dict):raise ValueError('Describe both validity boundaries')
    output={'precision':'day','semantics':'start-inclusive/end-exclusive'}
    for side in ('start','end'):
        boundary=value.get(side)
        if not isinstance(boundary,dict) or boundary.get('mode') not in ('unknown','date','open'):raise ValueError('Choose date, unknown or explicitly open for each boundary')
        mode=boundary['mode'];date=boundary.get('date','')
        if mode=='date':
            if not isinstance(date,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',date):raise ValueError('Use an exact calendar date YYYY-MM-DD')
            try:datetime.date.fromisoformat(date)
            except ValueError as e:raise ValueError('Invalid calendar date') from e
        elif date:raise ValueError('An unknown or open boundary cannot also have a date')
        output[side]={'mode':mode,'date':date if mode=='date' else None}
    if output['start']['mode']==output['end']['mode']=='date' and output['start']['date']>=output['end']['date']:raise ValueError('Exclusive end must be after the start')
    return output


def latest(db,run,revision,assertion):
    row=db.execute('SELECT * FROM kg_validity_events WHERE run=? AND revision=? AND assertion=? ORDER BY id DESC LIMIT 1',(run,revision,assertion)).fetchone()
    return dict(json.loads(row['data']),event=row['id'],recorded=row['recorded']) if row else None


def read(store,body):
    runs=auto.selected(body);graph=auto.view(store,runs)
    if body.get('revision')!=graph['revision']:raise ValueError('Query schema changed; choose the assertion again')
    assertion=body.get('assertion')
    if not isinstance(assertion,str) or not assertion:raise ValueError('Choose an assertion in Instances')
    layers={l['run']:l for l in graph['layers']};items=[]
    with store.db() as db:
        for run in runs:
            row=db.execute('SELECT data FROM kg_auto_instances WHERE run=? AND id=?',(run,assertion)).fetchone()
            if not row:continue
            a=json.loads(row['data']);revision=layers[run]['revision']
            items.append({'run':run,'revision':revision,'title':layers[run]['title'],'evidence':a['evidence'],
                          'review':latest(db,run,revision,assertion),'records':[{'label':a[s]['label'],'source':a[s]['source']} for s in ('subject','object')]})
    if not items:raise ValueError('Assertion is outside the selected pinned runs')
    return {'assertion':assertion,'items':items,'token':kg.digest([graph['revision'],assertion,items])}


def capture(db,projections):
    if not db.execute("SELECT 1 FROM sqlite_master WHERE name='kg_validity_events'").fetchone():return {}
    refs={}
    for run,revision in projections.items():
        for row in db.execute('SELECT assertion,max(id) event FROM kg_validity_events WHERE run=? AND revision=? GROUP BY assertion',(run,revision)):
            refs.setdefault(run,{})[row['assertion']]=row['event']
    return refs


def captured(db,snapshot,run,assertion):
    id=snapshot.get('validity',{}).get(run,{}).get(assertion)
    if id is None:return None
    row=db.execute('SELECT * FROM kg_validity_events WHERE id=? AND run=? AND revision=? AND assertion=?',(id,run,snapshot['projections'][run],assertion)).fetchone()
    if not row:raise ValueError('Captured validity review unavailable; current reviews will not be substituted')
    return dict(json.loads(row['data']),event=row['id'],recorded=row['recorded'])


def route(store,action,body):
    setup(store)
    with store.lock:
        state=read(store,body)
        if action=='validity-record':return state
        if action not in ('save-validity','clear-validity'):raise ValueError('Unknown validity operation')
        if body.get('token')!=state['token']:raise ValueError('Validity review changed; reload before saving')
        contribution=next((i for i in state['items'] if i['run']==body.get('run')),None)
        if not contribution:raise ValueError('Choose a contributing run')
        note=body.get('note','')
        if not isinstance(note,str) or not 1<=len(note.strip())<=2000:raise ValueError('Explain this validity decision (1–2000 characters)')
        data={'status':'cleared' if action=='clear-validity' else 'reviewed','note':note.strip(),'basis':'manual','interval':None,'evidence':None}
        if action=='save-validity':
            data['interval']=interval(body.get('interval'));basis=body.get('basis')
            if basis not in ('evidence','manual'):raise ValueError('Choose source interpretation or manual entry')
            data['basis']=basis
            if basis=='evidence':
                index=body.get('evidence_index');quote=body.get('quote')
                if type(index) is not int or not 0<=index<len(contribution['evidence']):raise ValueError('Choose a stored evidence passage')
                passage=contribution['evidence'][index]
                text=passage.get('context_text') or passage.get('text','')
                if not isinstance(quote,str) or not 1<=len(quote.strip())<=2500 or quote.strip() not in text:raise ValueError('Cite an exact excerpt from the chosen passage')
                data['evidence']={'index':index,'digest':kg.digest(passage),'quote':quote.strip()}
        with store.db() as db:
            meta=json.loads(db.execute('SELECT data FROM kg_auto_runs WHERE run=?',(contribution['run'],)).fetchone()[0])
            data['assets']=meta['assets']
            db.execute('INSERT INTO kg_validity_events(run,revision,assertion,recorded,data) VALUES(?,?,?,?,?)',(contribution['run'],contribution['revision'],state['assertion'],time.time(),json.dumps(data)))
        return read(store,body)
