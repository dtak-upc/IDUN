"""Evidence-grounded, record-level class inference; never renames predicates."""
import json
import threading
import knowledge as kg


def setup(store):
    with store.db() as db:
        db.execute('CREATE TABLE IF NOT EXISTS kg_semantic_concepts(run TEXT PRIMARY KEY,revision TEXT,data TEXT)')


def read(store,run,revision):
    setup(store)
    with store.db() as db:
        row=db.execute('SELECT revision,data FROM kg_semantic_concepts WHERE run=?',(run,)).fetchone()
    return json.loads(row['data']) if row and row['revision']==revision else {}


def validate(result,records):
    values=result.get('records') if isinstance(result,dict) else None
    if not isinstance(values,list) or len(values)!=len(records):raise ValueError('Concept inference must classify every supplied record')
    known={r['id'] for r in records};seen=set();out={}
    for v in values:
        if not isinstance(v,dict) or v.get('id') not in known or v['id'] in seen:raise ValueError('Unknown or duplicate record in concept inference')
        seen.add(v['id'])
        for key,limit in [('concept',100),('definition',800),('reason',1200)]:
            if not isinstance(v.get(key),str) or not 0<len(v[key].strip())<=limit:raise ValueError('Invalid semantic concept '+key)
        out[v['id']]={k:v[k].strip() for k in ('concept','definition','reason')}
    return out


def refine(store,body):
    import knowledge_auto as auto
    import settings,llm,lake_config
    import knowledge_prompts as prompts
    prompt=prompts.effective(store,'concepts')
    runs=auto.selected(body);graph=auto.view(store,runs)
    if any(l['update_available'] for l in graph['layers']):raise ValueError('Apply pending Integration updates before refining concepts')
    if not runs:raise ValueError('Select Integration runs first')
    revisions={r:kg.load_plan(store,r)[1] for r in runs}
    config=dict(settings.read(store)['llm'])
    for k,v in lake_config.read_lake_config(store).get('llm_overrides',{}).items():
        if v is not None and k in config and k!='key_env':config[k]=v
    config=settings.llm_validate(config)
    if config['provider']=='disabled' or not config.get('model'):raise ValueError('Select an LLM in Settings to infer semantic concepts')
    key=str(store.root)
    with kg._guard:
        if kg._jobs.get(key,{}).get('status')=='running':raise ValueError('Wait for the current graph task')
        job={'status':'running','phase':'Reading records and evidence for semantic concepts','cancel':threading.Event()};kg._jobs[key]=job
        store.knowledge_active=True;store.knowledge_cancel=job['cancel']
    def work():
        try:
            def check():
                if job['cancel'].is_set():raise InterruptedError('Concept inference cancelled')
            records={};members={r:set() for r in runs}
            with store.db() as db:
                for run in runs:
                    for row in db.execute('SELECT data FROM kg_auto_instances WHERE run=?',(run,)):
                        a=json.loads(row[0])
                        for side in ('subject','object'):
                            r=a[side];members[run].add(r['id'])
                            item=records.setdefault(r['id'],{'id':r['id'],'label':r['label'],'attributes':dict(zip(r['columns'],r['cells'])),'evidence':[]})
                            for p in a['evidence']:
                                text=(p.get('context_text') or p.get('text',''))[:1800]
                                if text and text not in item['evidence'] and len(item['evidence'])<3:item['evidence'].append(text)
            inferred={};vocabulary={};items=list(records.values())
            schema=llm.obj({'records':{'type':'array','items':llm.obj({k:{'type':'string'} for k in ('id','concept','definition','reason')})}})
            for start in range(0,len(items),24):
                check();batch=items[start:start+24];job['phase']=f'Inferring semantic concepts · {start}/{len(items)} records'
                messages=prompts.messages(prompt,{'vocabulary':vocabulary,'records':batch})
                if config['provider']=='huggingface':
                    from relationship_probe import structured_request
                    result=structured_request(config,messages,schema,config['timeout_seconds'],check)
                else:result=llm.request_cancellable({'operation':'knowledge_schema','config':config,'messages':messages,'schema':schema,'timeout':config['timeout_seconds']},check)
                values=validate(result,batch);inferred.update(values)
                for v in values.values():vocabulary.setdefault(v['concept'],v['definition'])
            check();setup(store)
            with store.lock,store.db() as db:
                if any(kg.load_plan(store,r)[1]!=rev for r,rev in revisions.items()):raise ValueError('Integration changed during inference; refresh and retry')
                for run in runs:
                    db.execute('INSERT OR REPLACE INTO kg_semantic_concepts VALUES(?,?,?)',(run,revisions[run],json.dumps({'model':config['model'],'prompt':prompt,'records':{rid:inferred[rid] for rid in members[run]}})))
            auto.sync(store,{'runs':runs},apply_concepts=True)
            job.update(status='completed',phase='Semantic concepts ready; Integration relationship names preserved')
        except Exception as e:job.update(status='failed',phase=str(e))
        finally:store.knowledge_active=False
    thread=threading.Thread(target=work,daemon=True);store.knowledge_thread=thread;thread.start()
    return {'status':'running'}
